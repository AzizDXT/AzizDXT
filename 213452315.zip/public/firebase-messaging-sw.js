// Firebase Service Worker for Background Notifications
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyBpMSXGurET-5cdwq3AuTehA2ufcddTS9w",
  authDomain: "taleb-bata.firebaseapp.com",
  projectId: "taleb-bata",
  storageBucket: "taleb-bata.appspot.com",
  messagingSenderId: "885963257139",
  appId: "1:885963257139:web:a4efce2e0215dce719fa46"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Firebase Messaging
const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage((payload) => {
  console.log('🔥 [SW] Background message received:', payload);
  
  const notificationTitle = payload.notification?.title || 'طالب - Taleb';
  const notificationOptions = {
    body: payload.notification?.body || 'لديك رسالة جديدة',
    icon: '/src/assets/logo.png',
    badge: '/src/assets/logo.png',
    image: '/src/assets/logo.png',
    tag: 'taleb-notification',
    requireInteraction: false,
    data: payload.data || {}
  };

  // Show notification
  self.registration.showNotification(notificationTitle, notificationOptions);
  
  // Send message to main app
  self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({
        type: 'FIREBASE_MESSAGE',
        payload: payload
      });
    });
  });
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  console.log('🔥 [SW] Notification clicked:', event);
  
  event.notification.close();
  
  // Open the app
  event.waitUntil(
    self.clients.matchAll().then(clients => {
      if (clients.length > 0) {
        return clients[0].focus();
      } else {
        return self.clients.openWindow('/');
      }
    })
  );
});

console.log('🔥 [SW] Firebase Service Worker loaded successfully');
