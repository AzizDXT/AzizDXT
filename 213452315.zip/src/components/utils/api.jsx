// API Configuration for Taleb Backend
const API_BASE_URL = 'https://api.taleb.run';
 
// Disable proxy for direct API access
const USE_PROXY = false; // Always use direct API access
const PROXY_BASE_URL = '/api/proxy';

// Central function to build API URLs - ensures all URLs use the same base
export const buildApiUrl = (path) => {
  const baseUrl = USE_PROXY ? PROXY_BASE_URL : API_BASE_URL;
  return `${baseUrl}${path}`;
};

// Export API_BASE_URL for direct access when needed
export { API_BASE_URL };

// API endpoints
const createEndpoints = (useProxy) => {
  const prefix = useProxy ? '' : '/api';
  return {
    // Authentication
    LOGIN: `${prefix}/v1/auth/login`,
    REGISTER: `${prefix}/v1/auth/register`,
    LOGOUT: `${prefix}/v1/auth/logout`,
    REFRESH_TOKEN: `${prefix}/v1/auth/refresh`,
    
    // Username and Email validation
    CHECK_USERNAME: `${prefix}/v1/auth/check-username`,
    CHECK_EMAIL: `${prefix}/v1/auth/check-email`,
    
    // OAuth
    GOOGLE_AUTH: `${prefix}/v1/auth/oauth/google`,
    APPLE_AUTH: `${prefix}/v1/auth/oauth/apple`,
    MICROSOFT_AUTH: `${prefix}/v1/auth/oauth/microsoft`,
    
    // User Profile
    USER_PROFILE: `${prefix}/v1/profile`,
    UPDATE_PROFILE: `${prefix}/v1/profile`,
    UPLOAD_PROFILE_IMAGE: `${prefix}/v1/profile/upload-profile-image`,
    UPLOAD_BANNER_IMAGE: `${prefix}/v1/profile/upload-banner-image`,
    DELETE_PROFILE_IMAGE: `${prefix}/v1/profile/delete-profile-image`,
    DELETE_BANNER_IMAGE: `${prefix}/v1/profile/delete-banner-image`,
    PROFILE_POSTS: `${prefix}/v1/profile/posts`,
    PROFILE_REELS: `${prefix}/v1/profile/reels`,
    
    // Account Settings
    CHANGE_PASSWORD: `${prefix}/v1/profile/password`,
    UPDATE_EMAIL: `${prefix}/v1/profile/email`,
    DELETE_ACCOUNT: `${prefix}/v1/profile/delete`,
    
    // Models
    GET_MODELS: `${prefix}/v1/models`,

    // Chat endpoints
    GET_CHAT_ROOMS: `${prefix}/v1/chat/rooms`,
    CREATE_CHAT_ROOM: `${prefix}/v1/chat/rooms`,
    DELETE_CHAT_ROOM: `${prefix}/v1/chat/rooms/{room_id}`,
    GET_CHAT_MESSAGES: `${prefix}/v1/chat/rooms/{room_id}/messages`,
    SEND_CHAT_MESSAGE: `${prefix}/v1/chat/rooms/{room_id}/messages`,
    DELETE_MESSAGE: `${prefix}/v1/chat/rooms/{room_id}/messages/{message_id}`,
    MARK_CHAT_SEEN: `${prefix}/v1/chat/rooms/{room_id}/mark-seen`,
    MARK_MESSAGE_SEEN: `${prefix}/v1/chat/rooms/{room_id}/messages/{message_id}/mark-seen`,
    DELETE_CHAT_FOR_ME: `${prefix}/v1/chat/rooms/{room_id}/delete-for-me`,
    PIN_MESSAGE: `${prefix}/v1/chat/rooms/{room_id}/messages/{message_id}/pin`,
    UNPIN_MESSAGE: `${prefix}/v1/chat/rooms/{room_id}/messages/{message_id}/pin`,
    GET_PINNED_MESSAGES: `${prefix}/v1/chat/rooms/{room_id}/pinned-messages`,
    REPLY_TO_MESSAGE: `${prefix}/v1/chat/messages/{room_id}/{message_id}/reply`,
    ADD_REACTION: `${prefix}/v1/chat/messages/{room_id}/{message_id}/reaction`,
    REMOVE_REACTION: `${prefix}/v1/chat/messages/{room_id}/{message_id}/reaction`,
    GET_MESSAGE_REACTIONS: `${prefix}/v1/chat/messages/{room_id}/{message_id}/reactions`,
    GET_AVAILABLE_REACTIONS: `${prefix}/v1/chat/available-reactions`,
    GET_CHAT_MEDIA: `${prefix}/v1/chat/media/{room_id}`,
    GET_CHAT_REQUESTS: `${prefix}/v1/chat/requests`,
    GET_PENDING_CHAT_REQUESTS: `${prefix}/v1/chat/requests/pending`,
    GET_SENT_CHAT_REQUESTS: `${prefix}/v1/chat/requests/sent`,
    ACCEPT_CHAT_REQUEST: `${prefix}/v1/chat/requests/{request_id}/accept`,
    REJECT_CHAT_REQUEST: `${prefix}/v1/chat/requests/{request_id}/reject`,
    CANCEL_CHAT_REQUEST: `${prefix}/v1/chat/requests/{request_id}/cancel`,
    FORWARD_MESSAGES: `${prefix}/v1/chat/messages/forward`,
    
    // User Profile endpoints for chat
    GET_USER_PROFILE: `${prefix}/v1/users/profile/{user_id}`,
    GET_CURRENT_USER: `${prefix}/v1/profile`,
    QUICK_USER_SEARCH: `${prefix}/v1/users/search/quick`,
    
    // Firebase Device Registration
    REGISTER_DEVICE_TOKEN: `${prefix}/v1/firebase/devices/register`,
    UPDATE_DEVICE_TOKEN: `${prefix}/v1/firebase/devices/{device_id}`,

    // Memories endpoints
    GET_MEMORIES: `${prefix}/v1/memories/`,
    ADD_MEMORY: `${prefix}/v1/memories/add`,
    GET_MEMORY: `${prefix}/v1/memories/{memory_id}`,
    UPDATE_MEMORY: `${prefix}/v1/memories/{memory_id}/update`,
    DELETE_MEMORY: `${prefix}/v1/memories/{memory_id}`,
    DELETE_ALL_MEMORIES: `${prefix}/v1/memories/delete/user`,

    // Notes endpoints
    CREATE_NOTE: `${prefix}/v1/notes/create`,
    GET_NOTE_BY_ID: `${prefix}/v1/notes/{id}`,
    UPDATE_NOTE: `${prefix}/v1/notes/{id}`,
    DELETE_NOTE: `${prefix}/v1/notes/{id}`,
    GET_ALL_NOTES: `${prefix}/v1/notes`, // For the old getNotes method
    FILTER_NOTES: `${prefix}/v1/notes/filter`,

    // Notes Tags Management
    GET_NOTE_TAGS: `${prefix}/v1/notes/manage/tags`,
    CREATE_NOTE_TAG: `${prefix}/v1/notes/manage/tags`,
    GET_NOTES_BY_TAG: `${prefix}/v1/notes/manage/tags/{tagName}/notes`,
    UPDATE_NOTE_TAG: `${prefix}/v1/notes/manage/tags/{tagName}`,
    DELETE_NOTE_TAG: `${prefix}/v1/notes/manage/tags/{tagName}`,
    GET_NOTE_TAG_STATS: `${prefix}/v1/notes/manage/tags/stats`,

    // Cloud Storage
    UPLOAD_FILE: `${prefix}/v1/storage/upload`,
    GET_STORAGE_FILES: `${prefix}/v1/storage/files`,
    GET_STORAGE_FILE: `${prefix}/v1/storage/files/{file_id}`,
    UPDATE_STORAGE_FILE: `${prefix}/v1/storage/files/{file_id}`,
    DOWNLOAD_STORAGE_FILE: `${prefix}/v1/storage/files/{file_id}/download`,
    GET_FILE_THUMBNAIL: `${prefix}/v1/storage/files/{file_id}/thumbnail`,
    MOVE_FILE_TO_TRASH: `${prefix}/v1/storage/files/{file_id}/trash`,
    DELETE_FILE_PERMANENTLY: `${prefix}/v1/storage/files/{file_id}/permanent`,
    GET_TRASH_FILES: `${prefix}/v1/storage/trash`,
    RESTORE_FILE_FROM_TRASH: `${prefix}/v1/storage/trash/{file_id}/restore`,
    CLEANUP_TRASH: `${prefix}/v1/storage/trash/cleanup`,
    CONFIGURE_FILE_SHARE: `${prefix}/v1/storage/files/{file_id}/share`,
    ACCESS_SHARED_FILE: `${prefix}/v1/storage/share/{share_token}`,
    DOWNLOAD_SHARED_FILE: `${prefix}/v1/storage/share/{share_token}/download`,
    ACCESS_SHARED_FILE_AUTH: `${prefix}/v1/storage/auth/share/{share_token}`,
    DOWNLOAD_SHARED_FILE_AUTH: `${prefix}/v1/storage/auth/share/{share_token}/download`,
    GET_SHARED_FILES: `${prefix}/v1/storage/shared-files`,
    REQUEST_FILE_ACCESS: `${prefix}/v1/storage/files/{file_id}/request-access`,
    GET_FILE_ACCESS_REQUESTS: `${prefix}/v1/storage/files/{file_id}/access-requests`,
    RESPOND_TO_ACCESS_REQUEST: `${prefix}/v1/storage/files/{file_id}/access-requests/{request_id}/respond`,
    GET_STORAGE_QUOTA: `${prefix}/v1/storage/quota`,
    CREATE_FOLDER: `${prefix}/v1/storage/folders`,
    GET_FOLDERS: `${prefix}/v1/storage/folders`,
    GET_FOLDER_CONTENTS: `${prefix}/v1/storage/folders/{folder_id}`,
    MOVE_FILES_TO_FOLDER: `${prefix}/v1/storage/folders/{folder_id}/move-files`,
    MOVE_FILES_TO_ROOT: `${prefix}/v1/storage/files/move-to-root`,
    CONFIGURE_FOLDER_SHARE: `${prefix}/v1/storage/folders/{folder_id}/share`,
    ACCESS_SHARED_FOLDER: `${prefix}/v1/storage/folder-share/{share_token}`,
    ADD_SHARED_FILE_TO_STORAGE: `${prefix}/v1/storage/shared-files/{share_token}/add-to-my-storage`,
    ADD_SHARED_FOLDER_TO_STORAGE: `${prefix}/v1/storage/folder-share/{share_token}/add-to-my-storage`,

    // Rewards and Leaderboard endpoints
    GET_CURRENT_SEASON: `${prefix}/v1/rewards/season/current`,
    GET_LEADERBOARD: `${prefix}/v1/rewards/leaderboard`,
    GET_USER_REWARDS: `${prefix}/v1/rewards/user`,
    GET_DAILY_TASKS: `${prefix}/v1/rewards/daily-tasks`,

    // Academic Schedule endpoints (UPDATED to use stdsch)
    GET_STUDENT_SCHEDULE: `${prefix}/v1/stdsch/schedule`,
    GET_ATTENDANCE_RECORDS: `${prefix}/v1/stdsch/attendance`,
    GET_NEXT_CLASS: `${prefix}/v1/stdsch/next-class`,
    GET_SESSION_DETAILS: `${prefix}/v1/stdsch/sessions/{sessionId}`,
    GET_ATTENDANCE_STATS: `${prefix}/v1/stdsch/attendance/stats`,
    GET_ACADEMIC_SUMMARY: `${prefix}/v1/stdsch/summary`,
    UPDATE_ATTENDANCE_STATUS: `${prefix}/v1/stdsch/sessions/{sessionId}/attendance`,
    UPLOAD_SCHEDULE_FILE: `${prefix}/v1/stdsch/schedule/upload`,
    GET_FILE_PREVIEW: `${prefix}/v1/storage/files/{file_id}/preview`, // Added based on getFilePreviewUrl

    // Academic Profile Analysis endpoints (NEW)
    UPLOAD_TRANSCRIPT_FILES: `${prefix}/v1/stdprf/analysis`,
    GET_ANALYSIS_RESULTS: `${prefix}/v1/stdprf/analysis/{task_id}`,
    GET_LATEST_ANALYSIS: `${prefix}/v1/stdprf/general`,
    UPDATE_LATEST_ANALYSIS: `${prefix}/v1/stdprf/general`,
    UPDATE_ANALYSIS_RESULTS: `${prefix}/v1/stdprf/analysis/{task_id}`,
    GET_ANALYSIS_TASKS: `${prefix}/v1/stdprf/tasks`,
    GET_TASK_DETAILS: `${prefix}/v1/stdprf/tasks/{task_id}`,
    CANCEL_ANALYSIS_TASK: `${prefix}/v1/stdprf/tasks/{task_id}`,

    // Student Schedule API endpoints (stdsch - Complete Integration)
    SCHEDULE_CONFIG: `${prefix}/v1/stdsch/config`,
    SCHEDULE_UPDATE_CONFIG: `${prefix}/v1/stdsch/config`,
    SCHEDULE_TIMEZONES: `${prefix}/v1/stdsch/timezones`,
    SCHEDULE_UPLOAD: `${prefix}/v1/stdsch/upload`,
    SCHEDULE_TASKS: `${prefix}/v1/stdsch/tasks`,
    SCHEDULE_TASK_DETAILS: `${prefix}/v1/stdsch/tasks/{task_id}`,
    SCHEDULE_CANCEL_TASK: `${prefix}/v1/stdsch/tasks/{task_id}`,
    SCHEDULE_TASK_STREAM: `${prefix}/v1/stdsch/tasks/{task_id}/stream`,
    SCHEDULE_ANALYSIS: `${prefix}/v1/stdsch/analysis/{task_id}`,
    SCHEDULE_UPDATE_ANALYSIS: `${prefix}/v1/stdsch/analysis/{task_id}`,
    SCHEDULE_UPCOMING: `${prefix}/v1/stdsch/upcoming`,
    SCHEDULE_UPCOMING_POST: `${prefix}/v1/stdsch/upcoming`,
    SCHEDULE_STATS: `${prefix}/v1/stdsch/stats`,
    SCHEDULE_GENERAL: `${prefix}/v1/stdsch/general`,
    SCHEDULE_UPDATE_GENERAL: `${prefix}/v1/stdsch/general`,
    SCHEDULE_LATEST: `${prefix}/v1/stdsch/latest`,
    SCHEDULE_HEALTH: `${prefix}/v1/stdsch/health`,
    SCHEDULE_NEXT_CLASS: `${prefix}/v1/stdsch/next-class`,
    SCHEDULE_COURSE_DETAILS: `${prefix}/v1/stdsch/courses/{course_code}`,
    SCHEDULE_COURSE_ATTENDANCE: `${prefix}/v1/stdsch/courses/{course_code}/attendance`,
    SCHEDULE_NEXT_CLASS_ATTENDANCE: `${prefix}/v1/stdsch/next-class-attendance`,
    SCHEDULE_COURSE_ATTENDANCE_COMPLETE: `${prefix}/v1/stdsch/courses/{course_code}/attendance-complete`,
    SCHEDULE_UPDATE_ATTENDANCE: `${prefix}/v1/stdsch/attendance/{session_id}`,
    SCHEDULE_BULK_UPDATE_ATTENDANCE: `${prefix}/v1/stdsch/attendance/bulk-update`,
    SCHEDULE_COURSE_ATTENDANCE_ANALYTICS: `${prefix}/v1/stdsch/courses/{course_code}/attendance-analytics`,
    SCHEDULE_ATTENDANCE_SUMMARY: `${prefix}/v1/stdsch/attendance-summary`,

    // Tasks endpoints
    GET_TASKS: `${prefix}/v1/tasks`,
    FILTER_TASKS: `${prefix}/v1/tasks/filter`,
    CREATE_TASK: `${prefix}/v1/tasks/create`,
    GET_TASK: `${prefix}/v1/tasks/{id}`,
    UPDATE_TASK: `${prefix}/v1/tasks/{id}`,
    DELETE_TASK: `${prefix}/v1/tasks/{id}`,
    COMPLETE_TASK: `${prefix}/v1/tasks/{id}/complete`,
    GET_UPCOMING_TASKS: `${prefix}/v1/tasks/upcoming/next`,
    GET_OVERDUE_TASKS: `${prefix}/v1/tasks/overdue/list`,
    GET_TASKS_STATS: `${prefix}/v1/tasks/stats/summary`,
    SEARCH_TASKS: `${prefix}/v1/tasks/search/{searchTerm}`,

    // AI Chat Conversations endpoints
    GET_CHAT_CONVERSATIONS: `${prefix}/v1/chatai`,
    GET_CHAT_CONVERSATION: `${prefix}/v1/chatai/{chat_id}`,
    GET_AI_CHAT_MESSAGES: `${prefix}/v1/chatai/{chat_id}/messages`,
    SEND_AI_CHAT_MESSAGE: `${prefix}/v1/chatai/{chat_id}/messages`,
    CREATE_CHAT_CONVERSATION: `${prefix}/v1/chatai`,
    CREATE_NEW_CHAT: `${prefix}/v1/chatai/new`,
    DELETE_CHAT_CONVERSATION: `${prefix}/v1/chatai/{chat_id}`,
    UPDATE_CHAT_CONVERSATION: `${prefix}/v1/chatai/{chat_id}`,
    UPLOAD_CHAT_ATTACHMENT: `${prefix}/v1/chatai/{chat_id}/attachments`,
    
    // Chat Completions (Streaming)
    CHAT_COMPLETIONS: `${prefix}/v1/models/chat/completions`,
    
    // Stories
    GET_STORIES: `${prefix}/v1/stories`,
    GET_MY_STORIES: `${prefix}/v1/stories/my-stories`,
    CREATE_STORY: `${prefix}/v1/stories`,
    UPLOAD_STORY_MEDIA: `${prefix}/v1/stories/form`,
    GET_STORY_MEDIA: `${prefix}/v1/stories/media/{media_id}`,
  };
};

export const API_ENDPOINTS = createEndpoints(USE_PROXY);

// Debug information
console.log('API Configuration:', {
  API_BASE_URL,
  USE_PROXY,
  PROXY_BASE_URL,
});

// Cookie utilities for cross-subdomain token storage
const setCrossDomainCookie = (name, value, days = 30) => {
  try {
    if (typeof document === 'undefined') return; // Only run in browser environment
    const expires = new Date();
    expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
    
    // Determine domain based on current location
    const hostname = window.location.hostname;
    let domain = '.taleb.run'; // Default for production
    
    // For localhost or development
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname.includes('localhost')) {
      domain = null; // Don't set domain for localhost
    }
    
    const cookieString = domain 
      ? `${name}=${value}; expires=${expires.toUTCString()}; path=/; domain=${domain}; SameSite=None; Secure`
      : `${name}=${value}; expires=${expires.toUTCString()}; path=/; SameSite=Lax`;
    
    document.cookie = cookieString;
    
    console.log('Cookie set:', cookieString);
  } catch (error) {
    console.error('Error setting cross-domain cookie:', error);
  }
};

const getCrossDomainCookie = (name) => {
  try {
    if (typeof document === 'undefined') return null; // Only run in browser environment
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  } catch (error) {
    console.error('Error getting cross-domain cookie:', error);
    return null;
  }
};

const deleteCrossDomainCookie = (name) => {
  try {
    if (typeof document === 'undefined') return; // Only run in browser environment
    
    // Determine domain based on current location
    const hostname = window.location.hostname;
    let domain = '.taleb.run'; // Default for production
    
    // For localhost or development
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname.includes('localhost')) {
      domain = null; // Don't set domain for localhost
    }
    
    if (domain) {
      document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=${domain}`;
    }
    // Also try to delete without domain for local cleanup
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/`;
    console.log('Cookie deleted:', name);
  } catch (error) {
    console.error('Error deleting cross-domain cookie:', error);
  }
};

// HTTP Client
class ApiClient {
  constructor() {
    this.baseURL = USE_PROXY ? PROXY_BASE_URL : API_BASE_URL;
    this.defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  // Get auth token from storage with cross-domain cookie support
  getAuthToken() {
    if (typeof window !== 'undefined') {
      // First try to get from cross-domain cookie
      const cookieToken = getCrossDomainCookie('access_token');
      if (cookieToken) {
        return cookieToken;
      }
      
      // Fallback to localStorage
      return localStorage.getItem('taleb-access-token') || localStorage.getItem('access_token');
    }
    return null;
  }

  // Set auth token in both localStorage and cross-domain cookie
  setAuthToken(token) {
    if (typeof window !== 'undefined' && token) {
      // Save in localStorage for backward compatibility
      localStorage.setItem('taleb-access-token', token);
      localStorage.setItem('access_token', token);
      
      // Save in cross-domain cookie for subdomain access
      setCrossDomainCookie('access_token', token, 30); // 30 days expiration
      setCrossDomainCookie('Authorization', `Bearer ${token}`, 30); // إضافة Authorization أيضاً
      
      console.log('Token saved in localStorage and cross-domain cookies');
    }
  }

  // Remove auth token from both localStorage and cross-domain cookie
  removeAuthToken() {
    if (typeof window !== 'undefined') {
      // Remove from localStorage
      localStorage.removeItem('taleb-access-token');
      localStorage.removeItem('access_token');
      
      // Remove from cross-domain cookie
      deleteCrossDomainCookie('access_token');
      deleteCrossDomainCookie('Authorization');
      
      console.log('Token removed from localStorage and cross-domain cookies');
    }
  }

  // Set auth headers for fetch requests
  getHeaders(customHeaders = {}) {
    const headers = { ...this.defaultHeaders, ...customHeaders };
    const token = this.getAuthToken();
    
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    
    return headers;
  }

  // Get auth headers specifically for contexts like EventSource that might need them directly
  getAuthHeaders() {
    const token = this.getAuthToken();
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  }


  // Generic request method with better error handling
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      mode: 'cors',
      credentials: 'include', // تغيير من omit إلى include لإرسال cookies
      cache: 'no-cache',
      ...options,
    };

    // Special handling for FormData
    if (config.body instanceof FormData) {
      console.log('FormData detected in request, letting browser set headers');
      const token = this.getAuthToken();
      config.headers = token ? { 'Authorization': `Bearer ${token}` } : {};
    } else {
      if (!config.headers) {
        config.headers = this.getHeaders(options.headers);
      }
    }

    console.log('API Request:', {
      url,
      method: config.method || 'GET',
      headers: config.headers,
      bodyType: config.body ? config.body.constructor.name : 'none',
      baseURL: this.baseURL,
      endpoint: endpoint
    });

    try {
      const response = await fetch(url, config);
      
      // Handle token expiration
      if (response.status === 401) {
        console.log('Token expired, attempting refresh...');
        const refreshed = await this.refreshToken();
        if (refreshed) {
          // Retry the original request
          if (config.body instanceof FormData) {
            const token = this.getAuthToken();
            config.headers = token ? { 'Authorization': `Bearer ${token}` } : {};
          } else {
            if (!config.headers) {
              config.headers = this.getHeaders(options.headers);
            }
          }
          const retryResponse = await fetch(url, config);
          if (!retryResponse.ok) {
            const errorData = await this.parseErrorResponse(retryResponse);
            throw new Error(errorData.message || `HTTP ${retryResponse.status}: ${retryResponse.statusText}`);
          }
          return await this.parseSuccessResponse(retryResponse);
        } else {
          // Redirect to login
          this.logout();
          throw new Error('Session expired. Please login again.');
        }
      }

      if (!response.ok) {
        const errorData = await this.parseErrorResponse(response);
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }

      return await this.parseSuccessResponse(response);
    } catch (error) {
      console.error('API Request Error:', {
        url,
        error: error.message,
        stack: error.stack
      });
      
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error: Unable to connect to server. Please check your internet connection.');
      }
      if (error.name === 'AbortError') {
        throw new Error('Request was cancelled.');
      }
      throw error;
    }
  }

  // Helper method to parse error responses
  async parseErrorResponse(response) {
    try {
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const errorData = await response.json();
        console.error('API Error Response:', JSON.stringify(errorData, null, 2));
        
        // استخراج رسالة الخطأ من الاستجابة
        let errorMessage = `HTTP ${response.status}`;
        
        if (errorData.detail) {
          if (Array.isArray(errorData.detail)) {
            // معالجة أخطاء التحقق من Pydantic
            const validationErrors = errorData.detail.map(err => {
              const field = err.loc ? err.loc.join('.') : 'unknown';
              return `${field}: ${err.msg}`;
            }).join(', ');
            errorMessage = `Validation error: ${validationErrors}`;
          } else if (typeof errorData.detail === 'string') {
            errorMessage = errorData.detail;
          }
        } else if (errorData.message) {
          errorMessage = errorData.message;
        } else if (errorData.error) {
          errorMessage = errorData.error;
        }

        return {
          message: errorMessage,
          status: response.status,
          data: errorData
        };
      } else {
        const textData = await response.text();
        console.error('API Error (non-JSON):', textData);
        return {
          message: textData || `HTTP ${response.status}: ${response.statusText}`,
          status: response.status,
          data: null
        };
      }
    } catch (parseError) {
      console.error('Error parsing error response:', parseError.message);
      return {
        message: `HTTP ${response.status}: ${response.statusText}`,
        status: response.status,
        data: null
      };
    }
  }

  // Helper method to parse success responses
  async parseSuccessResponse(response) {
    try {
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }
      return response;
    } catch (parseError) {
      console.error('Error parsing success response:', parseError);
      return response;
    }
  }

  // HTTP Methods
  async get(endpoint, params = {}) {
    const query = new URLSearchParams(params).toString();
    const url = query ? `${endpoint}?${query}` : endpoint;
    return this.request(url, { method: 'GET' });
  }

  async post(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async put(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async patch(endpoint, data = {}) {
    return this.request(endpoint, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  async delete(endpoint) {
    return this.request(endpoint, {
      method: 'DELETE',
    });
  }

  // Authentication methods with enhanced token management
  async login(email, password, deviceInfo = '') {
    try {
      console.log('Attempting login for:', email);
      const response = await this.post(API_ENDPOINTS.LOGIN, { 
        email, 
        password,
        device_info: deviceInfo || this.getDeviceInfo(),
        force_new_token: false
      });
      
      console.log('Login response:', response);
      
      if (response.access_token) {
        // Use the new token management methods
        this.setAuthToken(response.access_token);
        localStorage.setItem('taleb-user-data', JSON.stringify(response));
        
        // Store refresh token if available
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
        
        console.log('Login successful, token saved');
      } else {
        console.error('Login response missing access_token:', response);
        throw new Error('Invalid response from server: missing access token');
      }
      
      return response;
    } catch (error) {
      console.error('Login error:', {
        message: error.message,
        stack: error.stack
      });
      
      // Provide user-friendly error messages
      if (error.message.includes('401') || error.message.includes('Unauthorized')) {
        throw new Error('Invalid email or password. Please check your credentials and try again.');
      } else if (error.message.includes('404')) {
        throw new Error('User not found. Please check your email address.');
      } else if (error.message.includes('429')) {
        throw new Error('Too many login attempts. Please try again later.');
      } else if (error.message.includes('Network error')) {
        throw new Error('Unable to connect to server. Please check your internet connection.');
      } else {
        throw new Error(error.message || 'Login failed. Please try again.');
      }
    }
  }

  async register(userData) {
    try {
      console.log('Attempting registration for:', userData.email);
      
      // تحويل البيانات لتطابق ما يتوقعه الخادم
      const registrationData = {
        email: userData.email,
        name: userData.name,
        username: userData.username,
        password: userData.password,
        confirm_password: userData.confirmPassword, // تحويل من confirmPassword إلى confirm_password
        date_of_birth: userData.dateOfBirth, // تحويل من dateOfBirth إلى date_of_birth
        country: userData.country,
        institutional_account: false,
        is_private: false,
        profile_image_url: null,
        device_info: this.getDeviceInfo() // Added for consistency with login
      };

      console.log('Registration data being sent:', registrationData);
      
      const response = await this.post(API_ENDPOINTS.REGISTER, registrationData);
      
      console.log('Registration response:', response);
      
      if (response.access_token) {
        this.setAuthToken(response.access_token);
        localStorage.setItem('taleb-user-data', JSON.stringify(response));
        
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
        
        console.log('Registration successful, token saved');
      } else {
        console.error('Registration response missing access_token:', response);
        throw new Error('Invalid response from server: missing access token');
      }
      
      return response;
    } catch (error) {
      console.error('Registration error:', {
        message: error.message,
        name: error.name,
        stack: error.stack,
        fullError: error
      });
      
      // Provide user-friendly error messages
      if (error.message.includes('400') || error.message.includes('Bad Request')) {
        throw new Error('Invalid registration data. Please check all fields and try again.');
      } else if (error.message.includes('409') || error.message.includes('Conflict')) {
        throw new Error('Email or username already exists. Please use different credentials.');
      } else if (error.message.includes('422')) {
        throw new Error('Please fill all required fields correctly.');
      } else if (error.message.includes('Network error')) {
        throw new Error('Unable to connect to server. Please check your internet connection.');
      } else {
        throw new Error(error.message || 'Registration failed. Please try again.');
      }
    }
  }

  async logout() {
    try {
      console.log('Logging out user...');
      // لا نستخدم API logout لأنه يحذف جميع الجلسات
      // await this.post(API_ENDPOINTS.LOGOUT);
    } catch (error) {
      console.warn('Logout API call failed (ignored):', error.message);
    } finally {
      // Use the new token management methods
      this.removeAuthToken();
      localStorage.removeItem('taleb-user-data');
      localStorage.removeItem('taleb-refresh-token');
      deleteCrossDomainCookie('refresh_token');
      
      console.log('User logged out, tokens cleared');
      
      // Only redirect if we're not already on the login page
      if (typeof window !== 'undefined' && !window.location.pathname.includes('/Auth') && !window.location.pathname.includes('/login')) {
        setTimeout(() => {
          window.location.href = '/Auth';
        }, 100);
      }
    }
  }

  async refreshToken() {
    try {
      const refreshToken = localStorage.getItem('taleb-refresh-token') || getCrossDomainCookie('refresh_token');
      if (!refreshToken) {
        console.log('No refresh token available');
        return false;
      }

      console.log('Attempting to refresh token...');
      const response = await this.post(API_ENDPOINTS.REFRESH_TOKEN, {
        refresh_token: refreshToken,
        device_info: this.getDeviceInfo()
      });

      if (response.access_token) {
        // Use the new token management methods
        this.setAuthToken(response.access_token);
        
        if (response.user_data) {
          localStorage.setItem('taleb-user-data', JSON.stringify(response.user_data));
        }
        
        // Update refresh token if provided
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
        
        console.log('Token refreshed successfully');
        return true;
      }
    } catch (error) {
      console.error('Token refresh failed:', error.message);
      return false;
    }
    return false;
  }

  // Validation methods
  async checkUsername(username) {
    try {
      const response = await this.get(`${API_ENDPOINTS.CHECK_USERNAME}/${encodeURIComponent(username)}`);
      return response;
    } catch (error) {
      console.error('Username validation error:', {
        message: error.message,
        fullError: JSON.stringify(error, Object.getOwnPropertyNames(error))
      });
      throw error;
    }
  }

  async checkEmail(email) {
    try {
      const response = await this.get(`${API_ENDPOINTS.CHECK_EMAIL}/${encodeURIComponent(email)}`);
      return response;
    } catch (error) {
      console.error('Email validation error:', {
        message: error.message,
        fullError: JSON.stringify(error, Object.getOwnPropertyNames(error))
      });
      throw error;
    }
  }

  // OAuth methods with enhanced token management
  async googleOAuth(googleData) {
    try {
      const response = await this.post(API_ENDPOINTS.GOOGLE_AUTH, {
        ...googleData,
        device_info: this.getDeviceInfo()
      });
      
      if (response.access_token) {
        // Use the new token management methods
        this.setAuthToken(response.access_token);
        localStorage.setItem('taleb-user-data', JSON.stringify(response));
        
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
      }
      
      return response;
    } catch (error) {
      throw error;
    }
  }

  async appleOAuth(appleData) {
    try {
      const response = await this.post(API_ENDPOINTS.APPLE_AUTH, {
        ...appleData,
        device_info: this.getDeviceInfo()
      });
      
      if (response.access_token) {
        // Use the new token management methods
        this.setAuthToken(response.access_token);
        localStorage.setItem('taleb-user-data', JSON.stringify(response));
        
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
      }
      
      return response;
    } catch (error) {
      throw error;
    }
  }

  async microsoftOAuth(microsoftData) {
    try {
      const response = await this.post(API_ENDPOINTS.MICROSOFT_AUTH, {
        ...microsoftData,
        device_info: this.getDeviceInfo()
      });
      
      if (response.access_token) {
        // Use the new token management methods
        this.setAuthToken(response.access_token);
        localStorage.setItem('taleb-user-data', JSON.stringify(response));
        
        if (response.refresh_token) {
          localStorage.setItem('taleb-refresh-token', response.refresh_token);
          setCrossDomainCookie('refresh_token', response.refresh_token, 30);
        }
      }
      
      return response;
    } catch (error) {
      throw error;
    }
  }

  // Profile methods
  async getProfile(includeRecentContent = false, recentLimit = 5, contentType = 'mixed') {
    try {
      const params = {
        include_recent_content: includeRecentContent,
        recent_limit: recentLimit,
        content_type: contentType
      };
      
      const response = await this.get(API_ENDPOINTS.USER_PROFILE, params);
      
      // Transform image URLs to full URLs if they're relative
      // Handle both local API paths and external URLs (like Google OAuth)
      if (response.profile_image_url) {
        if (response.profile_image_url.startsWith('/api/')) {
          // Local API path - convert to full URL
          response.profile_image_url = `${API_BASE_URL}${response.profile_image_url}`;
        } else if (response.profile_image_url.startsWith('http')) {
          // External URL (like Google) - keep as is
          console.log('External profile image URL:', response.profile_image_url);
        }
      }
      
      if (response.banner_image_url) {
        if (response.banner_image_url.startsWith('/api/')) {
          // Local API path - convert to full URL
          response.banner_image_url = `${API_BASE_URL}${response.banner_image_url}`;
        } else if (response.banner_image_url.startsWith('http')) {
          // External URL - keep as is
          console.log('External banner image URL:', response.banner_image_url);
        }
      }
      
      return response;
    } catch (error) {
      throw error;
    }
  }

  async updateProfile(profileData) {
    try {
      const updateData = {
        name: profileData.name?.trim() || undefined,
        username: profileData.username?.trim() || undefined,
        bio: profileData.bio?.trim() || undefined,
        country: profileData.country?.trim() || undefined,
        is_private: profileData.is_private !== undefined ? profileData.is_private : undefined,
      };

      // Remove undefined values
      Object.keys(updateData).forEach(key => 
        updateData[key] === undefined && delete updateData[key]
      );

      return await this.post(API_ENDPOINTS.UPDATE_PROFILE, updateData);
    } catch (error) {
      throw error;
    }
  }

  async uploadProfileImage(file) {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      return await this.request(API_ENDPOINTS.UPLOAD_PROFILE_IMAGE, {
        method: 'POST',
        body: formData
      });
    } catch (error) {
      throw error;
    }
  }

  async uploadBannerImage(file) {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      return await this.request(API_ENDPOINTS.UPLOAD_BANNER_IMAGE, {
        method: 'POST',
        body: formData
      });
    } catch (error) {
      throw error;
    }
  }

  async deleteProfileImage() {
    try {
      return await this.delete(API_ENDPOINTS.DELETE_PROFILE_IMAGE);
    } catch (error) {
      throw error;
    }
  }

  async deleteBannerImage() {
    try {
      return await this.delete(API_ENDPOINTS.DELETE_BANNER_IMAGE);
    } catch (error) {
      throw error;
    }
  }

  async getProfilePosts(page = 1, limit = 20) {
    try {
      return await this.get(API_ENDPOINTS.PROFILE_POSTS, { page, limit });
    } catch (error) {
      throw error;
    }
  }

  async getProfileReels(page = 1, limit = 20) {
    try {
      return await this.get(API_ENDPOINTS.PROFILE_REELS, { page, limit });
    } catch (error) {
      throw error;
    }
  }

  async changePassword(currentPassword, newPassword) {
    try {
      return await this.post(API_ENDPOINTS.CHANGE_PASSWORD, {
        current_password: currentPassword,
        new_password: newPassword
      });
    } catch (error) {
      throw error;
    }
  }

  async updateEmail(newEmail, password) {
    try {
      return await this.post(API_ENDPOINTS.UPDATE_EMAIL, {
        new_email: newEmail,
        password: password
      });
    } catch (error) {
      throw error;
    }
  }

  async deleteAccount(password) {
    try {
      // Use this.request directly to send a body with DELETE method
      return await this.request(API_ENDPOINTS.DELETE_ACCOUNT, {
        method: 'DELETE',
        body: JSON.stringify({
          password: password
        })
      });
    } catch (error) {
      throw error;
    }
  }

  // Memories API methods
  async getMemories(skip = 0, limit = 100) {
    try {
      return await this.get(API_ENDPOINTS.GET_MEMORIES, { skip, limit });
    } catch (error) {
      throw error;
    }
  }

  async addMemory(content, metaData = {}) {
    try {
      return await this.post(API_ENDPOINTS.ADD_MEMORY, {
        content,
        meta_data: metaData
      });
    } catch (error) {
      throw error;
    }
  }

  async getMemory(memoryId) {
    try {
      const endpoint = API_ENDPOINTS.GET_MEMORY.replace('{memory_id}', memoryId);
      return await this.get(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async updateMemory(memoryId, content, metaData = {}) {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_MEMORY.replace('{memory_id}', memoryId);
      return await this.post(endpoint, {
        content,
        meta_data: metaData
      });
    } catch (error) {
      throw error;
    }
  }

  async deleteMemory(memoryId) {
    try {
      const endpoint = API_ENDPOINTS.DELETE_MEMORY.replace('{memory_id}', memoryId);
      return await this.delete(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async deleteAllMemories() {
    try {
      return await this.delete(API_ENDPOINTS.DELETE_ALL_MEMORIES);
    } catch (error) {
      throw error;
    }
  }

  // Notes API methods
  async createNote(content, meta = {}) {
    try {
      return await this.post(API_ENDPOINTS.CREATE_NOTE, {
        content,
        meta: {
          tags: meta.tags || [],
          color: meta.color || '#323232',
          pinned: meta.pinned || false,
          attachments: meta.attachments || []
        }
      });
    } catch (error) {
      throw error;
    }
  }

  async getNoteById(id) {
    try {
      const endpoint = API_ENDPOINTS.GET_NOTE_BY_ID.replace('{id}', id);
      return await this.get(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async updateNote(id, content, meta = {}) {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_NOTE.replace('{id}', id);
      return await this.put(endpoint, {
        content,
        meta: {
          tags: meta.tags || [],
          color: meta.color || '#323232',
          pinned: meta.pinned || false,
          attachments: meta.attachments || []
        }
      });
    } catch (error) {
      throw error;
    }
  }

  async deleteNote(id) {
    try {
      const endpoint = API_ENDPOINTS.DELETE_NOTE.replace('{id}', id);
      return await this.delete(endpoint);
    } catch (error) {
      throw error;
    }
  }

  // الطريقة القديمة لجلب الملاحظات
  async getNotes(skip = 0, limit = 5) {
    try {
      return await this.get(API_ENDPOINTS.GET_ALL_NOTES, { skip, limit });
    } catch (error) {
      throw error;
    }
  }

  // الطريقة الجديدة المُفضّلة لفلترة الملاحظات
  async filterNotes(filters = {}) {
    try {
      const body = {
        skip: filters.skip || 0,
        limit: filters.limit || 50,
      };
      if (filters.tag !== undefined) body.tag = filters.tag;
      if (filters.pinned !== undefined) body.pinned = filters.pinned;
      if (filters.search !== undefined) body.search = filters.search;

      return await this.post(API_ENDPOINTS.FILTER_NOTES, body);
    } catch (error) {
      throw error;
    }
  }

  // Notes Tags Management API methods
  async getNoteTags() {
    try {
      return await this.get(API_ENDPOINTS.GET_NOTE_TAGS);
    } catch (error) {
      throw error;
    }
  }

  async createNoteTag(name, color = '#232423', description = '') {
    try {
      return await this.post(API_ENDPOINTS.CREATE_NOTE_TAG, {
        name,
        color,
        description
      });
    } catch (error) {
      throw error;
    }
  }

  async getNotesByTag(tagName, skip = 0, limit = 50) {
    try {
      const endpoint = API_ENDPOINTS.GET_NOTES_BY_TAG.replace('{tagName}', encodeURIComponent(tagName));
      return await this.get(endpoint, { skip, limit });
    } catch (error) {
      throw error;
    }
  }

  async updateNoteTag(tagName, data) {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_NOTE_TAG.replace('{tagName}', encodeURIComponent(tagName));
      return await this.put(endpoint, data);
    } catch (error) {
      throw error;
    }
  }

  async deleteNoteTag(tagName, force = false) {
    try {
      const endpoint = API_ENDPOINTS.DELETE_NOTE_TAG.replace('{tagName}', encodeURIComponent(tagName));
      return await this.delete(`${endpoint}?force=${force}`);
    } catch (error) {
      throw error;
    }
  }

  async getNoteTagStats() {
    try {
      return await this.get(API_ENDPOINTS.GET_NOTE_TAG_STATS);
    } catch (error) {
      throw error;
    }
  }

  // Cloud Storage API methods
  async uploadFile(file, description = '', tags = [], folderId = null) {
    const formData = new FormData();
    formData.append('file', file);
    if (description) formData.append('description', description);
    if (tags.length > 0) {
      formData.append('tags', JSON.stringify(tags));
    }
    if (folderId) formData.append('folder_id', folderId);

    return await this.request(API_ENDPOINTS.UPLOAD_FILE, {
      method: 'POST',
      body: formData,
      headers: {} // Remove Content-Type to let browser set it for FormData
    });
  }

  async getStorageFiles(params = {}) {
    return await this.get(API_ENDPOINTS.GET_STORAGE_FILES, params);
  }

  async getStorageFile(fileId) {
    const endpoint = API_ENDPOINTS.GET_STORAGE_FILE.replace('{file_id}', fileId);
    return await this.get(endpoint);
  }

  async updateStorageFile(fileId, data) {
    const endpoint = API_ENDPOINTS.UPDATE_STORAGE_FILE.replace('{file_id}', fileId);
    return await this.put(endpoint, data);
  }

  async downloadStorageFile(fileId) {
    const endpoint = API_ENDPOINTS.DOWNLOAD_STORAGE_FILE.replace('{file_id}', fileId);
    return await this.get(endpoint);
  }

  async getFileThumbnail(fileId, size = 300) {
    const endpoint = API_ENDPOINTS.GET_FILE_THUMBNAIL.replace('{file_id}', fileId);
    return await this.get(endpoint, { size });
  }

  async moveFileToTrash(fileId) {
    const endpoint = API_ENDPOINTS.MOVE_FILE_TO_TRASH.replace('{file_id}', fileId);
    return await this.delete(endpoint);
  }

  async deleteFilePermanently(fileId) {
    const endpoint = API_ENDPOINTS.DELETE_FILE_PERMANENTLY.replace('{file_id}', fileId);
    return await this.delete(endpoint);
  }

  async getTrashFiles(params = {}) {
    return await this.get(API_ENDPOINTS.GET_TRASH_FILES, params);
  }

  async restoreFileFromTrash(fileId) {
    const endpoint = API_ENDPOINTS.RESTORE_FILE_FROM_TRASH.replace('{file_id}', fileId);
    return await this.post(endpoint);
  }

  async cleanupTrash() {
    return await this.delete(API_ENDPOINTS.CLEANUP_TRASH);
  }

  async configureFileShare(fileId, shareConfig) {
    const endpoint = API_ENDPOINTS.CONFIGURE_FILE_SHARE.replace('{file_id}', fileId);
    return await this.post(endpoint, shareConfig);
  }

  async accessSharedFile(shareToken, password = null) {
    const endpoint = API_ENDPOINTS.ACCESS_SHARED_FILE.replace('{share_token}', shareToken);
    return await this.get(endpoint, { password });
  }

  async downloadSharedFile(shareToken, password = null) {
    const endpoint = API_ENDPOINTS.DOWNLOAD_SHARED_FILE.replace('{share_token}', shareToken);
    return await this.get(endpoint, { password });
  }

  async accessSharedFileAuth(shareToken) {
    const endpoint = API_ENDPOINTS.ACCESS_SHARED_FILE_AUTH.replace('{share_token}', shareToken);
    return await this.get(endpoint);
  }

  async downloadSharedFileAuth(shareToken) {
    const endpoint = API_ENDPOINTS.DOWNLOAD_SHARED_FILE_AUTH.replace('{share_token}', shareToken);
    return await this.get(endpoint);
  }

  async getSharedFiles(params = {}) {
    return await this.get(API_ENDPOINTS.GET_SHARED_FILES, params);
  }

  async requestFileAccess(fileId, message = '') {
    const endpoint = API_ENDPOINTS.REQUEST_FILE_ACCESS.replace('{file_id}', fileId);
    return await this.post(endpoint, { message });
  }

  async getFileAccessRequests(fileId) {
    const endpoint = API_ENDPOINTS.GET_FILE_ACCESS_REQUESTS.replace('{file_id}', fileId);
    return await this.get(endpoint);
  }

  async respondToAccessRequest(fileId, requestId, responseData) {
    const endpoint = API_ENDPOINTS.RESPOND_TO_ACCESS_REQUEST
      .replace('{file_id}', fileId)
      .replace('{request_id}', requestId);
    return await this.post(endpoint, responseData);
  }

  async getStorageQuota() {
    return await this.get(API_ENDPOINTS.GET_STORAGE_QUOTA);
  }

  async createFolder(folderData) {
    return await this.post(API_ENDPOINTS.CREATE_FOLDER, folderData);
  }

  async getFolders(params = {}) {
    const effectiveParams = { ...params };
    if (params.parent_folder_id === null) {
      effectiveParams.parent_folder_id = 'null'; // API expects 'null' string for root
    }
    return await this.get(API_ENDPOINTS.GET_FOLDERS, effectiveParams);
  }

  async getFolderContents(folderId) {
    const endpoint = API_ENDPOINTS.GET_FOLDER_CONTENTS.replace('{folder_id}', folderId);
    return await this.get(endpoint);
  }

  async moveFilesToFolder(folderId, fileIds) {
    const endpoint = API_ENDPOINTS.MOVE_FILES_TO_FOLDER.replace('{folder_id}', folderId);
    return await this.post(endpoint, { file_ids: fileIds });
  }

  async moveFilesToRoot(fileIds) {
    return await this.post(API_ENDPOINTS.MOVE_FILES_TO_ROOT, { file_ids: fileIds });
  }

  async configureFolderShare(folderId, shareConfig) {
    const endpoint = API_ENDPOINTS.CONFIGURE_FOLDER_SHARE.replace('{folder_id}', folderId);
    return await this.post(endpoint, shareConfig);
  }

  async accessSharedFolder(shareToken, password = null) {
    const endpoint = API_ENDPOINTS.ACCESS_SHARED_FOLDER.replace('{share_token}', shareToken);
    return await this.get(endpoint, { password });
  }

  async addSharedFileToStorage(shareToken, options = {}) {
    const endpoint = API_ENDPOINTS.ADD_SHARED_FILE_TO_STORAGE.replace('{share_token}', shareToken);
    return await this.post(endpoint, options);
  }

  async addSharedFolderToStorage(shareToken, options = {}) {
    const endpoint = API_ENDPOINTS.ADD_SHARED_FOLDER_TO_STORAGE.replace('{share_token}', shareToken);
    return await this.post(endpoint, options);
  }

  // Academic Schedule API methods
  async getStudentSchedule() {
    try {
      return await this.get(API_ENDPOINTS.GET_STUDENT_SCHEDULE);
    } catch (error) {
      throw error;
    }
  }

  async getAttendanceRecords() {
    try {
      return await this.get(API_ENDPOINTS.GET_ATTENDANCE_RECORDS);
    } catch (error) {
      throw error;
    }
  }

  async getNextClass() {
    try {
      return await this.get(API_ENDPOINTS.GET_NEXT_CLASS);
    } catch (error) {
      throw error;
    }
  }

  async getSessionDetails(sessionId) {
    try {
      const endpoint = API_ENDPOINTS.GET_SESSION_DETAILS.replace('{sessionId}', sessionId);
      return await this.get(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async getAttendanceStats() {
    try {
      return await this.get(API_ENDPOINTS.GET_ATTENDANCE_STATS);
    } catch (error) {
      throw error;
    }
  }

  async getAcademicSummary() {
    try {
      return await this.get(API_ENDPOINTS.GET_ACADEMIC_SUMMARY);
    } catch (error) {
      throw error;
    }
  }

  async updateAttendanceStatus(sessionId, status, notes = '') {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_ATTENDANCE_STATUS.replace('{sessionId}', sessionId);
      return await this.put(endpoint, { status, notes });
    } catch (error) {
      throw error;
    }
  }

  async uploadScheduleFile(file) {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      return await this.request(API_ENDPOINTS.UPLOAD_SCHEDULE_FILE, {
        method: 'POST',
        body: formData,
        headers: {} // Remove Content-Type to let browser set it for FormData
      });
    } catch (error) {
      throw error;
    }
  }

  // Academic Profile Analysis API methods
  async uploadTranscriptFiles(files, description = '') {
    const formData = new FormData();
    
    files.forEach(file => {
      formData.append('files', file);
    });
    
    if (description) {
      formData.append('description', description);
    }

    return await this.request(API_ENDPOINTS.UPLOAD_TRANSCRIPT_FILES, {
      method: 'POST',
      body: formData,
      headers: {} // Remove Content-Type to let browser set it for FormData
    });
  }

  async getAnalysisResults(taskId) {
    const endpoint = API_ENDPOINTS.GET_ANALYSIS_RESULTS.replace('{task_id}', taskId);
    return await this.get(endpoint);
  }

  async getLatestAnalysis() {
    return await this.get(API_ENDPOINTS.GET_LATEST_ANALYSIS);
  }

  async updateLatestAnalysis(updates) {
    return await this.post(API_ENDPOINTS.UPDATE_LATEST_ANALYSIS, updates);
  }

  async updateAnalysisResults(taskId, updateData) {
    const endpoint = API_ENDPOINTS.UPDATE_ANALYSIS_RESULTS.replace('{task_id}', taskId);
    return await this.put(endpoint, updateData);
  }

  async getAnalysisTasks(skip = 0, limit = 10) {
    return await this.get(API_ENDPOINTS.GET_ANALYSIS_TASKS, { skip, limit });
  }

  async getAnalysisTaskDetails(taskId, stream = false) {
    const endpoint = API_ENDPOINTS.GET_TASK_DETAILS.replace('{task_id}', taskId);
    return await this.get(endpoint, { stream });
  }

  async cancelAnalysisTask(taskId, reason = 'User requested cancellation') {
    const endpoint = API_ENDPOINTS.CANCEL_ANALYSIS_TASK.replace('{task_id}', taskId);
    return await this.request(endpoint, {
      method: 'DELETE',
      body: JSON.stringify({ reason }),
    });
  }

  async hasAcademicData() {
    try {
      const data = await this.getLatestAnalysis();
      // Assuming 'student_info' and 'student_name' are indicative of academic data presence
      return data && data.student_info && data.student_info.student_name;
    } catch (error) {
      // If getLatestAnalysis throws an error (e.g., 404 if no data, or 401 if unauthorized),
      // we can consider that there's no academic data or access is denied.
      if (error.message.includes('Authentication required') || error.message.includes('404')) {
        return false;
      }
      console.error('Error checking academic data:', error);
      throw error; // Re-throw other errors for upstream handling
    }
  }

  // Student Schedule API methods (Complete Implementation)
  
  // 1. Configuration
  async getScheduleConfig() {
    return await this.get(API_ENDPOINTS.SCHEDULE_CONFIG);
  }

  async updateScheduleConfig(config) {
    return await this.put(API_ENDPOINTS.SCHEDULE_UPDATE_CONFIG, config);
  }

  async getScheduleTimezones() {
    return await this.get(API_ENDPOINTS.SCHEDULE_TIMEZONES);
  }

  // 2. File Processing
  async uploadScheduleFiles(files, description = '') {
    const formData = new FormData();
    
    files.forEach(file => {
      formData.append('files', file);
    });
    
    if (description) {
      formData.append('description', description);
    }

    return await this.request(API_ENDPOINTS.SCHEDULE_UPLOAD, {
      method: 'POST',
      body: formData,
      headers: {} // Remove Content-Type for FormData to let browser set it
    });
  }

  // 3. Task Management
  async getScheduleTasks() {
    return await this.get(API_ENDPOINTS.SCHEDULE_TASKS);
  }

  async getScheduleTaskDetails(taskId) {
    const endpoint = API_ENDPOINTS.SCHEDULE_TASK_DETAILS.replace('{task_id}', taskId);
    return await this.get(endpoint);
  }

  async cancelScheduleTask(taskId) {
    const endpoint = API_ENDPOINTS.SCHEDULE_CANCEL_TASK.replace('{task_id}', taskId);
    return await this.delete(endpoint);
  }

  // 4. Real-time Task Streaming
  createScheduleTaskStream(taskId, onUpdate, onError) {
    const endpoint = API_ENDPOINTS.SCHEDULE_TASK_STREAM.replace('{task_id}', taskId);
    const url = `${this.baseURL}${endpoint}`;
    
    // Since EventSource doesn't support custom headers and backend requires auth,
    // we'll use fetch with ReadableStream for secure streaming
    console.log('Creating secure fetch stream for task:', taskId);
    
    let isClosed = false;
    let abortController = new AbortController();
    
    const startStream = async () => {
      try {
        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Accept': 'text/event-stream',
            'Cache-Control': 'no-cache',
            ...this.getAuthHeaders()
          },
          credentials: 'include',
          signal: abortController.signal
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        if (!response.body) {
          throw new Error('Response body not supported');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (!isClosed) {
          const { done, value } = await reader.read();
          
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6));
                console.log('Stream data received:', data);
                
                // Send update to callback
                onUpdate(data);
                
                // Auto-close connection when task is completed
                if (data.status === 'completed' || data.status === 'failed') {
                  console.log(`Task ${data.status}, closing stream connection`);
                  isClosed = true;
                  abortController.abort();
                  break;
                }
              } catch (error) {
                console.error('Error parsing stream data:', error);
              }
            }
          }
          
          // Break out of the loop if connection should be closed
          if (isClosed) break;
        }
        
        // Ensure reader is closed
        try {
          await reader.cancel();
        } catch (e) {
          console.log('Reader already closed');
        }
        
      } catch (error) {
        if (error.name === 'AbortError') {
          console.log('Stream aborted');
          return;
        }
        console.error('Fetch stream error:', error);
        onError?.(error);
      }
    };

    // Start the stream
    startStream();

    // Return a mock EventSource-like object for compatibility
    return {
      close: () => {
        console.log('Manually closing stream connection');
        isClosed = true;
        abortController.abort();
      },
      onmessage: null,
      onerror: null,
      readyState: 1, // OPEN
      url: url
    };
  }

  // 5. Analysis Results
  async getScheduleAnalysis(taskId) {
    const endpoint = API_ENDPOINTS.SCHEDULE_ANALYSIS.replace('{task_id}', taskId);
    return await this.get(endpoint);
  }

  async updateScheduleAnalysis(taskId, updates) {
    const endpoint = API_ENDPOINTS.SCHEDULE_UPDATE_ANALYSIS.replace('{task_id}', taskId);
    return await this.put(endpoint, updates);
  }

  // 6. Current Schedule Data
  async getScheduleGeneral() {
    return await this.get(API_ENDPOINTS.SCHEDULE_GENERAL);
  }

  async updateScheduleGeneral(updates) {
    return await this.post(API_ENDPOINTS.SCHEDULE_UPDATE_GENERAL, updates);
  }

  async getLatestSchedule() {
    return await this.get(API_ENDPOINTS.SCHEDULE_LATEST);
  }

  // 7. Upcoming Classes
  async getUpcomingClasses(params = {}) {
    return await this.get(API_ENDPOINTS.SCHEDULE_UPCOMING, params);
  }

  async getUpcomingClassesFiltered(filters) {
    return await this.post(API_ENDPOINTS.SCHEDULE_UPCOMING_POST, filters);
  }

  // Note: getNextClass is duplicated. The one above under "Academic Schedule API methods" is the older.
  // The one defined here is the 'stdsch' specific one. Keeping both for now as per original code structure,
  // but logically getNextClass under academicAPI should point to scheduleAPI.getNextClass.
  // For now, will align 'academicAPI.getNextClass' to 'scheduleAPI.getNextClass'.
  // This specific method will remain as part of the `ApiClient` but the exported one will be controlled.
  async getNextClassStdsch() { // Renamed internally to avoid conflict with the existing one
    return await this.get(API_ENDPOINTS.SCHEDULE_NEXT_CLASS);
  }

  async getNextClassWithAttendance() {
    return await this.get(API_ENDPOINTS.SCHEDULE_NEXT_CLASS_ATTENDANCE);
  }

  // 8. Course Details
  async getCourseDetails(courseCode) {
    const endpoint = API_ENDPOINTS.SCHEDULE_COURSE_DETAILS.replace('{course_code}', courseCode);
    return await this.get(endpoint);
  }

  async getCourseAttendance(courseCode) {
    const endpoint = API_ENDPOINTS.SCHEDULE_COURSE_ATTENDANCE.replace('{course_code}', courseCode);
    return await this.get(endpoint);
  }

  async getCourseAttendanceComplete(courseCode) {
    const endpoint = API_ENDPOINTS.SCHEDULE_COURSE_ATTENDANCE_COMPLETE.replace('{course_code}', courseCode);
    return await this.get(endpoint);
  }

  // 9. Attendance Management
  async updateSessionAttendance(sessionId, attendanceData) {
    const endpoint = API_ENDPOINTS.SCHEDULE_UPDATE_ATTENDANCE.replace('{session_id}', sessionId);
    return await this.put(endpoint, attendanceData);
  }

  async bulkUpdateAttendance(attendanceUpdates) {
    return await this.post(API_ENDPOINTS.SCHEDULE_BULK_UPDATE_ATTENDANCE, attendanceUpdates);
  }

  async getAttendanceSummary() {
    return await this.get(API_ENDPOINTS.SCHEDULE_ATTENDANCE_SUMMARY);
  }

  // 10. Analytics
  async getCourseAttendanceAnalytics(courseCode) {
    const endpoint = API_ENDPOINTS.SCHEDULE_COURSE_ATTENDANCE_ANALYTICS.replace('{course_code}', courseCode);
    return await this.get(endpoint);
  }

  async getScheduleStats() {
    return await this.get(API_ENDPOINTS.SCHEDULE_STATS);
  }

  // 11. Health Check
  async getScheduleHealth() {
    return await this.get(API_ENDPOINTS.SCHEDULE_HEALTH);
  }

  // Helper method to check if schedule data exists
  async hasScheduleData() {
    try {
      const data = await this.getScheduleGeneral();
      // Assuming 'student_info' and 'student_name' are indicative of academic data presence
      return data && data.student_info && data.student_info.student_name;
    } catch (error) {
      if (error.message.includes('Authentication required') || 
          error.message.includes('404') || 
          error.message.includes('Access denied')) {
        return false;
      }
      console.error('Error checking schedule data:', error);
      return false; // Return false if an error indicates no data or access issues
    }
  }


  // Tasks API methods
  async getTasks(skip = 0, limit = 50) {
    try {
      return await this.get(API_ENDPOINTS.GET_TASKS, { skip, limit });
    } catch (error) {
      throw error;
    }
  }

  async filterTasks(filters = {}) {
    try {
      const body = {
        skip: filters.skip || 0,
        limit: filters.limit || 50,
      };
      if (filters.status !== undefined) body.status = filters.status;
      if (filters.priority !== undefined) body.priority = filters.priority;
      if (filters.tag !== undefined) body.tag = filters.tag;
      if (filters.pinned !== undefined) body.pinned = filters.pinned;
      if (filters.overdue !== undefined) body.overdue = filters.overdue;
      if (filters.due_today !== undefined) body.due_today = filters.due_today;
      if (filters.search !== undefined) body.search = filters.search;

      return await this.post(API_ENDPOINTS.FILTER_TASKS, body);
    } catch (error) {
      throw error;
    }
  }

  async createTask(taskData) {
    try {
      return await this.post(API_ENDPOINTS.CREATE_TASK, taskData);
    } catch (error) {
      throw error;
    }
  }

  async getTask(id) {
    try {
      const endpoint = API_ENDPOINTS.GET_TASK.replace('{id}', id);
      return await this.get(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async updateTask(id, taskData) {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_TASK.replace('{id}', id);
      return await this.put(endpoint, taskData);
    } catch (error) {
      throw error;
    }
  }

  async deleteTask(id) {
    try {
      const endpoint = API_ENDPOINTS.DELETE_TASK.replace('{id}', id);
      return await this.delete(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async completeTask(id, completionData) {
    try {
      const endpoint = API_ENDPOINTS.COMPLETE_TASK.replace('{id}', id);
      return await this.post(endpoint, completionData);
    } catch (error) {
      throw error;
    }
  }

  async getUpcomingTasks(limit = 100) {
    try {
      return await this.get(API_ENDPOINTS.GET_UPCOMING_TASKS, { limit });
    } catch (error) {
      throw error;
    }
  }

  async getOverdueTasks(limit = 50) {
    try {
      return await this.get(API_ENDPOINTS.GET_OVERDUE_TASKS, { limit });
    } catch (error) {
      throw error;
    }
  }

  async getTasksStats() {
    try {
      return await this.get(API_ENDPOINTS.GET_TASKS_STATS);
    } catch (error) {
      throw error;
    }
  }

  async searchTasks(searchTerm, limit = 50) {
    try {
      const endpoint = API_ENDPOINTS.SEARCH_TASKS.replace('{searchTerm}', encodeURIComponent(searchTerm));
      return await this.get(endpoint, { limit });
    } catch (error) {
      throw error;
    }
  }

  // AI Chat Conversations endpoints (ONLY methods that are NOT moved to top-level exports)
  async getChatConversation(chatId) {
    try {
      const endpoint = API_ENDPOINTS.GET_CHAT_CONVERSATION.replace('{chat_id}', chatId);
      return await this.get(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async sendChatMessage(chatId, message, attachmentFileId = null) {
    try {
      const endpoint = API_ENDPOINTS.SEND_CHAT_MESSAGE.replace('{chat_id}', chatId);
      return await this.post(endpoint, { message, attachment_file_id: attachmentFileId });
    } catch (error) {
      throw error;
    }
  }

  async createChatConversation(title, initialMessage = null) {
    try {
      return await this.post(API_ENDPOINTS.CREATE_CHAT_CONVERSATION, { title, initial_message: initialMessage });
    } catch (error) {
      throw error;
    }
  }

  async createNewChat(title = 'محادثة جديدة') {
    try {
      return await this.post(API_ENDPOINTS.CREATE_NEW_CHAT, { title });
    } catch (error) {
      throw error;
    }
  }

  async deleteChatConversation(chatId) {
    try {
      const endpoint = API_ENDPOINTS.DELETE_CHAT_CONVERSATION.replace('{chat_id}', chatId);
      return await this.delete(endpoint);
    } catch (error) {
      throw error;
    }
  }

  async updateChatConversation(chatId, updates) {
    try {
      const endpoint = API_ENDPOINTS.UPDATE_CHAT_CONVERSATION.replace('{chat_id}', chatId);
      return await this.put(endpoint, updates);
    } catch (error) {
      throw error;
    }
  }

  async uploadChatAttachment(chatId, file) {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const endpoint = API_ENDPOINTS.UPLOAD_CHAT_ATTACHMENT.replace('{chat_id}', chatId);
      return await this.request(endpoint, {
        method: 'POST',
        body: formData,
        headers: {} // Remove Content-Type to let browser set it for FormData
      });
    } catch (error) {
      throw error;
    }
  }

  // Chat Completions with Streaming Support
  async sendChatCompletions(messages, model, options = {}) {
    try {
      // Ensure we have a chat_id for streaming requests
      let chatId = options.chatId;
      if (!chatId && options.stream !== false) {
        // Get or generate chat_id if not provided for streaming
        chatId = chatUtils.getCurrentChatId();
      }

      const requestBody = {
        messages: messages,
        model: model,
        stream: options.stream !== false, // Default to true
        web_search: options.webSearch || false,
        image_gen: options.imageGen || false,
        temperature: options.temperature || 0.7,
        ...(chatId && { chat_id: chatId })
      };

      console.log('🚀 Sending chat completions request:', {
        ...requestBody,
        webSearchEnabled: requestBody.web_search,
        imageGenEnabled: requestBody.image_gen
      });

      const response = await fetch(`${this.baseURL}${API_ENDPOINTS.CHAT_COMPLETIONS}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/plain, text/event-stream, */*', // Accept both raw text and SSE
          'Authorization': `Bearer ${this.getAuthToken()}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await this.parseErrorResponse(response);
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }

      return response;
    } catch (error) {
      console.error('Chat completions error:', error);
      throw error;
    }
  }

  // ENHANCED streaming reader for web search and image generation support
  createStreamingReader(response, onChunk, onComplete, onError) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    let webSearchUrls = [];
    let isWebSearchPhase = false;
    let webSearchComplete = false;
    let imageGenData = null;

    const processStream = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          
          if (done) {
            const metadata = {};
            if (webSearchUrls.length > 0) {
              metadata.searchUrls = webSearchUrls;
            }
            if (imageGenData) {
              metadata.imageGenData = imageGenData;
            }
            onComplete?.(Object.keys(metadata).length > 0 ? metadata : null);
            break;
          }

          // Decode the chunk
          const chunk = decoder.decode(value, { stream: true });
          
          // Handle raw text streaming (backward compatibility) - but check for mixed content
          if (!chunk.includes('data: ') && !chunk.includes('\n') && !isWebSearchPhase) {
            // This is pure raw text streaming - handle character by character
            if (chunk.includes('[DONE]')) {
              const textBeforeDone = chunk.split('[DONE]')[0];
              if (textBeforeDone) {
                // Send character by character for smooth streaming
                for (let i = 0; i < textBeforeDone.length; i++) {
                  onChunk?.(textBeforeDone[i], 'content');
                  await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
                }
              }
              const metadata = {};
              if (webSearchUrls.length > 0) {
                metadata.searchUrls = webSearchUrls;
              }
              if (imageGenData) {
                metadata.imageGenData = imageGenData;
              }
              onComplete?.(Object.keys(metadata).length > 0 ? metadata : null);
              return;
            } else if (chunk.trim()) {
              // Send character by character for smooth streaming
              for (let i = 0; i < chunk.length; i++) {
                onChunk?.(chunk[i], 'content');
                await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
              }
            }
            continue;
          }
          
          buffer += chunk;
          
          // Process complete lines
          const lines = buffer.split('\n');
          buffer = lines.pop() || ''; // Keep incomplete line in buffer
          
          for (const line of lines) {
            if (!line.trim()) continue;
            
            // Check if it's SSE format (data: {...})
            if (line.startsWith('data: ')) {
              try {
                const jsonStr = line.substring(6); // Remove 'data: '
                const data = JSON.parse(jsonStr);
                
                // Handle web search streaming format
                if (data.choices && data.choices[0] && data.choices[0].websearch_status === true) {
                  isWebSearchPhase = true;
                  const content = data.choices[0].delta?.content;
                  if (content && content.trim()) {
                    // This is a web search URL
                    const url = content.trim();
                    if (url.startsWith('http')) {
                      webSearchUrls.push(url);
                      // Notify about web search progress
                      onChunk?.('', 'websearch_url', { url, urls: [...webSearchUrls] });
                    }
                  }
                  continue;
                }
                
                // Handle image generation streaming format
                if (data.choices && data.choices[0] && data.choices[0].delta) {
                  const delta = data.choices[0].delta;
                  
                  // Check for image generation data - include even if image_gen is false
                  if (delta.image_gen !== undefined || delta.image_generation_progress || delta.generated_images) {
                    console.log('🎨 Image generation data received in stream:', delta);
                    
                    const imageGenMetadata = {};
                    
                    // Always include image_gen if it's defined (even if false)
                    if (delta.image_gen !== undefined) {
                      imageGenMetadata.image_gen = delta.image_gen;
                    }
                    
                    if (delta.image_generation_progress) {
                      imageGenMetadata.image_generation_progress = delta.image_generation_progress;
                    }
                    
                    if (delta.generated_images) {
                      imageGenMetadata.generated_images = delta.generated_images;
                    }
                    
                    // Store image generation data for completion
                    imageGenData = { ...imageGenData, ...imageGenMetadata };
                    
                    // Notify about image generation progress
                    onChunk?.('', 'image_generation', imageGenMetadata);
                    
                    // If there's also content, continue to process it
                    if (!delta.content) {
                      continue;
                    }
                  }
                }
                
                // Handle regular streaming content from JSON
                if (data.choices && data.choices[0] && data.choices[0].delta?.content) {
                  if (isWebSearchPhase && !webSearchComplete) {
                    // Mark web search as complete and start regular content
                    webSearchComplete = true;
                    onChunk?.('', 'websearch_complete', { searchUrls: webSearchUrls });
                  }
                  
                  const content = data.choices[0].delta.content;
                  // Send character by character for smooth streaming
                  for (let i = 0; i < content.length; i++) {
                    onChunk?.(content[i], 'content');
                    await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
                  }
                }
              } catch (parseError) {
                // Not JSON, might be raw text after web search - handle as content
                const content = line.substring(6);
                if (content && !content.includes('[DONE]')) {
                  // Check if we're in web search phase and need to complete it
                  if (isWebSearchPhase && !webSearchComplete) {
                    webSearchComplete = true;
                    onChunk?.('', 'websearch_complete', { searchUrls: webSearchUrls });
                  }
                  // Send character by character for smooth streaming
                  for (let i = 0; i < content.length; i++) {
                    onChunk?.(content[i], 'content');
                    await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
                  }
                } else if (content.includes('[DONE]')) {
                  // Handle [DONE] in SSE format
                  const textBeforeDone = content.split('[DONE]')[0];
                  if (textBeforeDone) {
                    for (let i = 0; i < textBeforeDone.length; i++) {
                      onChunk?.(textBeforeDone[i], 'content');
                      await new Promise(resolve => setTimeout(resolve, 5));
                    }
                  }
                  const metadata = {};
                  if (webSearchUrls.length > 0) {
                    metadata.searchUrls = webSearchUrls;
                  }
                  if (imageGenData) {
                    metadata.imageGenData = imageGenData;
                  }
                  onComplete?.(Object.keys(metadata).length > 0 ? metadata : null);
                  return;
                }
              }
            } else {
              // Raw text line - could be after web search phase
              if (line.includes('[DONE]')) {
                const textBeforeDone = line.split('[DONE]')[0];
                if (textBeforeDone) {
                  // Send character by character for smooth streaming
                  for (let i = 0; i < textBeforeDone.length; i++) {
                    onChunk?.(textBeforeDone[i], 'content');
                    await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
                  }
                }
                const metadata = {};
                if (webSearchUrls.length > 0) {
                  metadata.searchUrls = webSearchUrls;
                }
                if (imageGenData) {
                  metadata.imageGenData = imageGenData;
                }
                onComplete?.(Object.keys(metadata).length > 0 ? metadata : null);
                return;
              } else if (line.trim()) {
                // Regular text content - could be after web search
                if (isWebSearchPhase && !webSearchComplete) {
                  webSearchComplete = true;
                  onChunk?.('', 'websearch_complete', { searchUrls: webSearchUrls });
                }
                // Send character by character for smooth streaming
                for (let i = 0; i < line.length; i++) {
                  onChunk?.(line[i], 'content');
                  await new Promise(resolve => setTimeout(resolve, 5)); // 5ms delay
                }
                // Add newline for line breaks
                onChunk?.('\n', 'content');
              }
            }
          }
        }
      } catch (error) {
        console.error('Streaming error:', error);
        onError?.(error);
      }
    };

    processStream();

    return () => reader.cancel();
  }

  // File URLs
  getFileDownloadUrl(fileId) {
    return `${this.baseURL}${API_ENDPOINTS.DOWNLOAD_STORAGE_FILE.replace('{file_id}', fileId)}`;
  }

  getFileThumbnailUrl(fileId, size = 300) {
    return `${this.baseURL}${API_ENDPOINTS.GET_FILE_THUMBNAIL.replace('{file_id}', fileId)}?size=${size}`;
  }

  getFilePreviewUrl(fileId) {
    // This assumes API_ENDPOINTS.GET_FILE_PREVIEW has been added in createEndpoints
    return `${this.baseURL}${API_ENDPOINTS.GET_FILE_PREVIEW.replace('{file_id}', fileId)}`;
  }

  // Utility methods
  getDeviceInfo() {
    if (typeof window !== 'undefined') {
      const userAgent = navigator.userAgent || '';
      const platform = navigator.platform || '';
      
      // Enhanced browser detection
      let browserName = 'Unknown';
      let browserVersion = 'Unknown';
      
      try {
        if (userAgent.includes('Chrome') && !userAgent.includes('Edg')) {
          browserName = 'Chrome';
          const match = userAgent.match(/Chrome\/([0-9.]+)/);
          browserVersion = match ? match[1] : 'Unknown';
        } else if (userAgent.includes('Firefox')) {
          browserName = 'Firefox';
          const match = userAgent.match(/Firefox\/([0-9.]+)/);
          browserVersion = match ? match[1] : 'Unknown';
        } else if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) {
          browserName = 'Safari';
          const match = userAgent.match(/Version\/([0-9.]+)/);
          browserVersion = match ? match[1] : 'Unknown';
        } else if (userAgent.includes('Edg')) {
          browserName = 'Edge';
          const match = userAgent.match(/Edg\/([0-9.]+)/);
          browserVersion = match ? match[1] : 'Unknown';
        }
      } catch (error) {
        console.warn('Error parsing user agent:', error);
      }

      // Enhanced OS detection
      let osName = 'Unknown';
      let osVersion = '';
      try {
        if (userAgent.includes('Windows NT')) {
          osName = 'Windows';
          const match = userAgent.match(/Windows NT ([0-9.]+)/);
          osVersion = match ? match[1] : '';
        } else if (userAgent.includes('Mac OS X')) {
          osName = 'macOS';
          const match = userAgent.match(/Mac OS X ([0-9_.]+)/);
          osVersion = match ? match[1].replace(/_/g, '.') : '';
        } else if (userAgent.includes('Linux')) {
          osName = 'Linux';
        } else if (userAgent.includes('Android')) {
          osName = 'Android';
          const match = userAgent.match(/Android ([0-9.]+)/);
          osVersion = match ? match[1] : '';
        } else if (userAgent.includes('iOS')) {
          osName = 'iOS';
          const match = userAgent.match(/OS ([0-9_]+)/);
          osVersion = match ? match[1].replace(/_/g, '.') : '';
        }
      } catch (error) {
        console.warn('Error parsing OS:', error);
      }

      return `${browserName} ${browserVersion} on ${osName}${osVersion ? ' ' + osVersion : ''}`;
    }
    return 'Server Side Rendering';
  }

  // Check if user is authenticated with cross-domain cookie support
  isAuthenticated() {
    if (typeof window === 'undefined') return false;
    const token = this.getAuthToken(); // This now checks both cookie and localStorage
    const userData = localStorage.getItem('taleb-user-data');
    return !!(token && userData);
  }

  // Get user data from storage
  getUserData() {
    if (typeof window === 'undefined') return null;
    try {
      const userData = localStorage.getItem('taleb-user-data');
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      console.error('Failed to parse user data:', error);
      return null;
    }
  }

  // Get daily tasks/rewards
  async getDailyTasks(language = 'ar') {
    try {
      const response = await this.get(API_ENDPOINTS.GET_DAILY_TASKS, { language });
      return response;
    } catch (error) {
      console.error('Failed to get daily tasks:', error);
      throw error;
    }
  }

  // Quick user search for autocomplete/suggestions
  async quickUserSearch(query, limit = 10) {
    try {
      const response = await this.get(API_ENDPOINTS.QUICK_USER_SEARCH, { 
        q: query, 
        limit: limit 
      });
      return response;
    } catch (error) {
      console.error('Failed to search users:', error);
      throw error;
    }
  }

  // Rewards and Leaderboard API functions
  async getCurrentSeason(language = 'en') {
    try {
      const url = buildApiUrl(`${API_ENDPOINTS.GET_CURRENT_SEASON}?language=${language}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get current season: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get current season:', error);
      throw error;
    }
  }

  async getLeaderboard(limit = 10, language = 'en') {
    try {
      const url = buildApiUrl(`${API_ENDPOINTS.GET_LEADERBOARD}?limit=${limit}&language=${language}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get leaderboard: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get leaderboard:', error);
      throw error;
    }
  }

  async getUserRewards(language = 'en') {
    try {
      const url = buildApiUrl(`${API_ENDPOINTS.GET_USER_REWARDS}?language=${language}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get user rewards: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get user rewards:', error);
      throw error;
    }
  }
}

// Image Cache Management
const IMAGE_CACHE_KEY = 'taleb-image-cache';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

// Get cached image
export const getCachedImage = (imageUrl, type) => {
  try {
    if (typeof localStorage === 'undefined') return null; // Only run in browser environment
    const cache = JSON.parse(localStorage.getItem(IMAGE_CACHE_KEY) || '{}');
    const cacheKey = `${type}_${imageUrl}`;
    const cached = cache[cacheKey];
    
    if (cached && (Date.now() - cached.timestamp) < CACHE_DURATION) {
      return cached.data;
    }
    
    return null;
  } catch (error) {
    console.warn('Error reading image cache:', error);
    return null;
  }
};

// Set cached image
export const setCachedImage = (imageUrl, type, data) => {
  try {
    if (typeof localStorage === 'undefined') return; // Only run in browser environment
    const cache = JSON.parse(localStorage.getItem(IMAGE_CACHE_KEY) || '{}');
    const cacheKey = `${type}_${imageUrl}`;
    
    cache[cacheKey] = {
      data,
      timestamp: Date.now()
    };
    
    localStorage.setItem(IMAGE_CACHE_KEY, JSON.stringify(cache));
  } catch (error) {
    console.warn('Error setting image cache:', error);
  }
};

// Clear image cache
export const clearImageCache = (type = null) => {
  try {
    if (typeof localStorage === 'undefined') return; // Only run in browser environment
    if (!type) {
      localStorage.removeItem(IMAGE_CACHE_KEY);
      return;
    }
    
    const cache = JSON.parse(localStorage.getItem(IMAGE_CACHE_KEY) || '{}');
    Object.keys(cache).forEach(key => {
      if (key.startsWith(`${type}_`)) {
        delete cache[key];
      }
    });
    
    localStorage.setItem(IMAGE_CACHE_KEY, JSON.stringify(cache));
  } catch (error) {
    console.warn('Error clearing image cache:', error);
  }
};

// Load image with caching and retry
export const loadImageWithCache = async (imageUrl, type = 'image', maxRetries = 3) => {
  if (!imageUrl) return null;
  
  // Check cache first
  const cached = getCachedImage(imageUrl, type);
  if (cached) {
    return cached;
  }
  
  // جرب طرق مختلفة لتحميل الصورة
  const api = new ApiClient();
  const token = api.getAuthToken();
  
  console.log('Loading image with authentication:', {
    imageUrl,
    hasToken: !!token,
    tokenLength: token ? token.length : 0
  });
  
  const methods = [
    // الطريقة الأولى: مع التوكن وتتبع redirects
    () => fetch(imageUrl.startsWith('http') ? imageUrl : `${API_BASE_URL}${imageUrl}`, {
      headers: token ? {
        'Authorization': `Bearer ${token}`,
        'Accept': 'image/*',
        'Cache-Control': 'no-cache'
      } : { 'Accept': 'image/*' },
      mode: 'cors',
      cache: 'no-store',
      redirect: 'follow', // تتبع redirects تلقائياً
      credentials: 'include' // إرسال cookies
    }),
    
    // الطريقة الثانية: مع التوكن في URL كمعامل
    () => {
      const separator = imageUrl.includes('?') ? '&' : '?';
      const urlWithToken = token ? `${imageUrl}${separator}token=${encodeURIComponent(token)}` : imageUrl;
      const finalUrl = urlWithToken.startsWith('http') ? urlWithToken : `${API_BASE_URL}${urlWithToken}`;
      return fetch(finalUrl, {
        headers: {
          'Accept': 'image/*'
        },
        mode: 'cors',
        cache: 'force-cache',
        redirect: 'follow',
        credentials: 'include'
      });
    },
    
    // الطريقة الثانية ب: مع cookies فقط
    () => {
      const finalUrl = imageUrl.startsWith('http') ? imageUrl : `${API_BASE_URL}${imageUrl}`;
      return fetch(finalUrl, {
        headers: {
          'Accept': 'image/*',
          'X-Requested-With': 'XMLHttpRequest'
        },
        mode: 'cors',
        cache: 'no-cache',
        redirect: 'follow',
        credentials: 'include'
      });
    },
    
    // الطريقة الثالثة: بدون معاملات إضافية
    () => {
      const cleanUrl = imageUrl.split('?')[0];
      const finalUrl = cleanUrl.startsWith('http') ? cleanUrl : `${API_BASE_URL}${cleanUrl}`;
      return fetch(finalUrl, {
        headers: token ? {
          'Authorization': `Bearer ${token}`,
          'Accept': 'image/*'
        } : { 'Accept': 'image/*' },
        mode: 'cors',
        cache: 'force-cache',
        redirect: 'follow',
        credentials: 'include'
      });
    },
    
    // الطريقة الرابعة: محاولة مباشرة بدون تعديل
    () => {
      const finalUrl = imageUrl.startsWith('http') ? imageUrl : `${API_BASE_URL}${imageUrl}`;
      return fetch(finalUrl, {
        mode: 'cors',
        cache: 'force-cache',
        redirect: 'follow',
        credentials: 'include'
      });
    },
    
    // الطريقة الخامسة: استخدام API client مباشرة
    async () => {
      const endpoint = imageUrl.startsWith('http') ? 
        imageUrl.replace(API_BASE_URL, '') : 
        imageUrl;
      
      try {
        const response = await fetch(api.baseURL + endpoint, {
          method: 'GET',
          headers: api.getHeaders({ 'Accept': 'image/*' }),
          mode: 'cors',
          credentials: 'include',
          redirect: 'follow',
          cache: 'no-cache'
        });
        return response;
      } catch (error) {
        console.warn('API client method failed:', error);
        throw error;
      }
    }
  ];
  
  // جرب كل طريقة
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    for (let methodIndex = 0; methodIndex < methods.length; methodIndex++) {
      try {
        console.log(`Trying method ${methodIndex + 1}, attempt ${attempt} for: ${imageUrl}`);
        const response = await methods[methodIndex]();
        
        if (response.ok) {
          // تحقق من نوع المحتوى
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.startsWith('image/')) {
            const blob = await response.blob();
            const objectUrl = URL.createObjectURL(blob);
            
            // Cache the image
            setCachedImage(imageUrl, type, objectUrl);
            console.log(`Successfully loaded image using method ${methodIndex + 1}:`, imageUrl);
            return objectUrl;
          } else {
            console.warn(`Response is not an image (${contentType}) for method ${methodIndex + 1}:`, imageUrl);
            
            // إذا كان الرد HTML، قد يكون redirect page
            if (contentType && contentType.includes('text/html')) {
              console.log('Received HTML response, might be a redirect page');
            }
          }
        } else {
          console.warn(`HTTP ${response.status} for method ${methodIndex + 1}:`, imageUrl);
        }
      } catch (error) {
        console.warn(`Image load method ${methodIndex + 1} attempt ${attempt} failed for ${imageUrl}:`, error.message);
      }
    }
    
    // انتظار قبل المحاولة التالية
    if (attempt < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 500));
    }
  }
  
  console.error(`Failed to load image after ${maxRetries} attempts with all methods:`, {
    imageUrl,
    hasToken: !!token,
    apiBaseUrl: API_BASE_URL,
    methods: methods.length
  });
  return null;
};

// Test function to debug image loading issues
export const testImageLoad = async (imageUrl) => {
  console.log('Testing image load for:', imageUrl);
  
  const api = new ApiClient();
  const token = api.getAuthToken();
  
  console.log('Auth info:', {
    hasToken: !!token,
    tokenPreview: token ? token.substring(0, 20) + '...' : 'none',
    cookies: document.cookie
  });
  
  try {
    const response = await fetch(imageUrl, {
      method: 'GET',
      headers: token ? {
        'Authorization': `Bearer ${token}`,
        'Accept': 'image/*'
      } : { 'Accept': 'image/*' },
      mode: 'cors',
      credentials: 'include',
      redirect: 'follow'
    });
    
    console.log('Test response:', {
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
      url: response.url,
      redirected: response.redirected
    });
    
    if (response.ok) {
      const contentType = response.headers.get('content-type');
      console.log('Content type:', contentType);
      
      if (contentType && contentType.startsWith('image/')) {
        console.log('✅ Image loaded successfully');
        return true;
      } else {
        console.log('❌ Response is not an image');
        const text = await response.text();
        console.log('Response body preview:', text.substring(0, 200));
        return false;
      }
    } else {
      console.log('❌ HTTP error:', response.status, response.statusText);
      return false;
    }
  } catch (error) {
    console.error('❌ Network error:', error);
    return false;
  }
};

// Create and export API client instance
const api = new ApiClient();
export default api;

// Helper for requests, handling proxy path adjustment if necessary
const apiRequest = async (path, options = {}) => {
  let adjustedPath = path;
  if (USE_PROXY && path.startsWith('/api/')) {
    adjustedPath = path.substring('/api'.length); // Remove '/api' prefix for proxied requests
  }
  return api.request(adjustedPath, { method: 'GET', ...options });
};

// AI Chat Conversations endpoints
export const getChatConversations = async (skip = 0, limit = 10) => {
  try {
    if (typeof apiRequest !== 'function') {
      console.error('apiRequest is not a function');
      throw new Error('API function not available');
    }
    
    const response = await apiRequest(`/api/v1/chatai/?skip=${skip}&limit=${limit}`);
    return response;
  } catch (error) {
    console.error('Error fetching chat conversations:', error);
    throw error;
  }
};

// Get specific chat by ID
export const getChatById = async (chatId) => {
  try {
    if (typeof apiRequest !== 'function') {
      console.error('apiRequest is not a function');
      throw new Error('API function not available');
    }
    
    const response = await apiRequest(`/api/v1/chatai/${chatId}`);
    return response;
  } catch (error) {
    console.error('Error fetching chat by ID:', error);
    throw error;
  }
};

export const getChatMessages = async (chatId) => {
  try {
    if (typeof apiRequest !== 'function') {
      console.error('apiRequest is not a function');
      throw new Error('API function not available');
    }
    
    const response = await apiRequest(`/api/v1/chatai/${chatId}/messages`);
    return response;
  } catch (error) {
    console.error('Error fetching chat messages:', error);
    throw error;
  }
};

// Update chat conversation
export const updateChatConversation = async (chatId, chatData) => {
  try {
    if (typeof apiRequest !== 'function') {
      console.error('apiRequest is not a function');
      throw new Error('API function not available');
    }
    
    const response = await apiRequest(`/api/v1/chatai/${chatId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(chatData)
    });
    return response;
  } catch (error) {
    console.error('Error updating chat conversation:', error);
    throw error;
  }
};

// AI Generated Images endpoints - إصلاح مماثل
export const getAIGeneratedImages = async (page = 1, limit = 10) => {
  try {
    const response = await apiRequest(`/api/v1/storage/files?page=${page}&limit=${limit}&tag=ai-generated`);
    return response;
  } catch (error) {
    console.error('Error fetching AI generated images:', error);
    throw error;
  }
};

export const getAIGeneratedImagesCount = async () => {
  try {
    const response = await apiRequest('/api/v1/storage/files?page=1&limit=50&tag=ai-generated&count_only=true');
    return response.count || 0;
  } catch (error) {
    console.error('Error fetching AI images count:', error);
    return 0;
  }
};

// Get file download URL (for both images and documents)
export const getFileDownloadUrl = (fileId) => {
  return buildApiUrl(`/api/v1/storage/files/${fileId}/download`);
};

export const getImageDownloadUrl = (fileId) => {
  return buildApiUrl(`/api/v1/storage/files/${fileId}/download`);
};

// Export legacy API functions for backward compatibility
export const authAPI = {
  checkUsername: (username) => api.checkUsername(username),
  checkEmail: (email) => api.checkEmail(email),
  register: (userData) => api.register(userData),
  login: (email, password) => api.login(email, password),
  googleOAuth: (googleData) => api.googleOAuth(googleData),
  appleOAuth: (appleData) => api.appleOAuth(appleData),
  microsoftOAuth: (microsoftData) => api.microsoftOAuth(microsoftData),
  logout: () => api.logout(),
  getCurrentUser: () => api.getUserData(),
  isAuthenticated: () => api.isAuthenticated()
};

export const profileAPI = {
  getProfile: (includeRecentContent, recentLimit, contentType) => 
    api.getProfile(includeRecentContent, recentLimit, contentType),
  updateProfile: (profileData) => api.updateProfile(profileData),
  uploadProfileImage: (file) => api.uploadProfileImage(file),
  uploadBannerImage: (file) => api.uploadBannerImage(file),
  deleteProfileImage: () => api.deleteProfileImage(),
  deleteBannerImage: () => api.deleteBannerImage(),
  getPosts: (page, limit) => api.getProfilePosts(page, limit),
  getReels: (page, limit) => api.getProfileReels(page, limit)
};

export const settingsAPI = {
  changePassword: (currentPassword, newPassword) => api.changePassword(currentPassword, newPassword),
  updateEmail: (newEmail, password) => api.updateEmail(newEmail, password),
  deleteAccount: (password) => api.deleteAccount(password)
};

// Export memories API functions
export const memoriesAPI = {
  getMemories: (skip, limit) => api.getMemories(skip, limit),
  addMemory: (content, metaData) => api.addMemory(content, metaData),
  getMemory: (memoryId) => api.getMemory(memoryId),
  updateMemory: (memoryId, content, metaData) => api.updateMemory(memoryId, content, metaData),
  deleteMemory: (memoryId) => api.deleteMemory(memoryId),
  deleteAllMemories: () => api.deleteAllMemories()
};

// Export notes API functions
export const notesAPI = {
  createNote: (content, meta) => api.createNote(content, meta),
  getNoteById: (id) => api.getNoteById(id),
  updateNote: (id, content, meta) => api.updateNote(id, content, meta),
  deleteNote: (id) => api.deleteNote(id),
  getNotes: (skip, limit) => api.getNotes(skip, limit),
  filterNotes: (filters) => api.filterNotes(filters),
  // New Notes Tag Management API functions
  getNoteTags: () => api.getNoteTags(),
  createNoteTag: (name, color, description) => api.createNoteTag(name, color, description),
  getNotesByTag: (tagName, skip, limit) => api.getNotesByTag(tagName, skip, limit),
  updateNoteTag: (tagName, data) => api.updateNoteTag(tagName, data),
  deleteNoteTag: (tagName, force) => api.deleteNoteTag(tagName, force),
  getNoteTagStats: () => api.getNoteTagStats()
};

// Upload file to cloud storage
export const uploadFileToCloud = async (file, description = '', tags = []) => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    if (description) formData.append('description', description);
    if (tags.length > 0) formData.append('tags', JSON.stringify(tags));

    const response = await fetch(`${API_BASE_URL}/api/v1/storage/upload`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${getAuthToken()}`,
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Upload failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error uploading file to cloud:', error);
    throw error;
  }
};

// Upload image from URL to cloud storage
export const uploadImageFromUrl = async (imageUrl, filename, description = '', tags = ['ai-generated']) => {
  try {
    // Fetch the image as blob
    const imageResponse = await fetch(imageUrl);
    if (!imageResponse.ok) {
      throw new Error('Failed to fetch image');
    }
    
    const blob = await imageResponse.blob();
    const file = new File([blob], filename, { type: blob.type });
    
    return await uploadFileToCloud(file, description, tags);
  } catch (error) {
    console.error('Error uploading image from URL:', error);
    throw error;
  }
};

// Export Cloud Storage API functions
export const cloudStorageAPI = {
  uploadFile: (file, description, tags, folderId) => api.uploadFile(file, description, tags, folderId),
  getStorageFiles: (params) => api.getStorageFiles(params),
  getStorageFile: (fileId) => api.getStorageFile(fileId),
  updateStorageFile: (fileId, data) => api.updateStorageFile(fileId, data),
  downloadStorageFile: (fileId) => api.downloadStorageFile(fileId),
  getFileThumbnail: (fileId, size) => api.getFileThumbnail(fileId, size),
  moveFileToTrash: (fileId) => api.moveFileToTrash(fileId),
  deleteFilePermanently: (fileId) => api.deleteFilePermanently(fileId),
  getTrashFiles: (params) => api.getTrashFiles(params),
  restoreFileFromTrash: (fileId) => api.restoreFileFromTrash(fileId),
  cleanupTrash: () => api.cleanupTrash(),
  configureFileShare: (fileId, shareConfig) => api.configureFileShare(fileId, shareConfig),
  accessSharedFile: (shareToken, password) => api.accessSharedFile(shareToken, password),
  downloadSharedFile: (shareToken, password) => api.downloadSharedFile(shareToken, password),
  accessSharedFileAuth: (shareToken) => api.accessSharedFileAuth(shareToken),
  downloadSharedFileAuth: (shareToken) => api.downloadSharedFileAuth(shareToken),
  getSharedFiles: (params) => api.getSharedFiles(params),
  requestFileAccess: (fileId, message) => api.requestFileAccess(fileId, message),
  getFileAccessRequests: (fileId) => api.getFileAccessRequests(fileId),
  respondToAccessRequest: (fileId, requestId, responseData) => api.respondToAccessRequest(fileId, requestId, responseData),
  getStorageQuota: () => api.getStorageQuota(),
  createFolder: (folderData) => api.createFolder(folderData),
  getFolders: (params) => api.getFolders(params),
  getFolderContents: (folderId) => api.getFolderContents(folderId),
  moveFilesToFolder: (folderId, fileIds) => api.moveFilesToFolder(folderId, fileIds),
  moveFilesToRoot: (fileIds) => api.moveFilesToRoot(fileIds),
  configureFolderShare: (folderId, shareConfig) => api.configureFolderShare(folderId, shareConfig),
  accessSharedFolder: (shareToken, password) => api.accessSharedFolder(shareToken, password),
  addSharedFileToStorage: (shareToken, options) => api.addSharedFileToStorage(shareToken, options),
  addSharedFolderToStorage: (shareToken, options) => api.addSharedFolderToStorage(shareToken, options),
};

// Export Academic Schedule & Profile Analysis API functions
export const academicAPI = {
  getStudentSchedule: () => api.getStudentSchedule(),
  getAttendanceRecords: () => api.getAttendanceRecords(),
  // Renamed the original getNextClass to point to the new stdsch specific one
  getNextClass: () => api.getNextClassStdsch(), 
  getSessionDetails: (sessionId) => api.getSessionDetails(sessionId),
  getAttendanceStats: () => api.getAttendanceStats(),
  getAcademicSummary: () => api.getAcademicSummary(),
  updateAttendanceStatus: (sessionId, status, notes) => api.updateAttendanceStatus(sessionId, status, notes),
  uploadScheduleFile: (file) => api.uploadScheduleFile(file),
  // New Academic Profile Analysis functions
  uploadTranscriptFiles: (files, description) => api.uploadTranscriptFiles(files, description),
  getAnalysisResults: (taskId) => api.getAnalysisResults(taskId),
  getLatestAnalysis: () => api.getLatestAnalysis(),
  updateLatestAnalysis: (updates) => api.updateLatestAnalysis(updates),
  updateAnalysisResults: (taskId, updateData) => api.updateAnalysisResults(taskId, updateData),
  getAnalysisTasks: (skip, limit) => api.getAnalysisTasks(skip, limit),
  getAnalysisTaskDetails: (taskId, stream) => api.getAnalysisTaskDetails(taskId, stream),
  cancelAnalysisTask: (taskId, reason) => api.cancelAnalysisTask(taskId, reason),
  hasAcademicData: () => api.hasAcademicData()
};

// Export Tasks API functions
export const tasksAPI = {
  getTasks: (skip, limit) => api.getTasks(skip, limit),
  filterTasks: (filters) => api.filterTasks(filters),
  createTask: (taskData) => api.createTask(taskData),
  getTask: (id) => api.getTask(id),
  updateTask: (id, taskData) => api.updateTask(id, taskData),
  deleteTask: (id) => api.deleteTask(id),
  completeTask: (id, completionData) => api.completeTask(id, completionData),
  getUpcomingTasks: (limit) => api.getUpcomingTasks(limit),
  getOverdueTasks: (limit) => api.getOverdueTasks(limit),
  getTasksStats: () => api.getTasksStats(),
  searchTasks: (searchTerm, limit) => api.searchTasks(searchTerm, limit)
};

// Export Schedule API functions
export const scheduleAPI = {
  // Configuration
  getConfig: () => api.getScheduleConfig(),
  updateConfig: (config) => api.updateScheduleConfig(config),
  getTimezones: () => api.getScheduleTimezones(),
  
  // File Processing
  uploadFiles: (files, description) => api.uploadScheduleFiles(files, description),
  
  // Task Management
  getTasks: () => api.getScheduleTasks(),
  getTaskDetails: (taskId) => api.getScheduleTaskDetails(taskId),
  cancelTask: (taskId) => api.cancelScheduleTask(taskId),
  createTaskStream: (taskId, onUpdate, onError) => api.createScheduleTaskStream(taskId, onUpdate, onError),
  
  // Analysis
  getAnalysis: (taskId) => api.getScheduleAnalysis(taskId),
  updateAnalysis: (taskId, updates) => api.updateScheduleAnalysis(taskId, updates),
  
  // Current Data
  getGeneral: () => api.getScheduleGeneral(),
  updateGeneral: (updates) => api.updateScheduleGeneral(updates),
  getLatest: () => api.getLatestSchedule(),
  
  // Classes
  getUpcoming: (params) => api.getUpcomingClasses(params),
  getUpcomingFiltered: (filters) => api.getUpcomingClassesFiltered(filters),
  getNextClass: () => api.getNextClassStdsch(), // Explicitly use the stdsch version
  getNextClassWithAttendance: () => api.getNextClassWithAttendance(),
  
  // Courses
  getCourseDetails: (courseCode) => api.getCourseDetails(courseCode),
  getCourseAttendance: (courseCode) => api.getCourseAttendance(courseCode),
  getCourseAttendanceComplete: (courseCode) => api.getCourseAttendanceComplete(courseCode),
  
  // Attendance
  updateAttendance: (sessionId, data) => api.updateSessionAttendance(sessionId, data),
  bulkUpdateAttendance: (updates) => api.bulkUpdateAttendance(updates),
  getAttendanceSummary: () => api.getAttendanceSummary(),
  getCourseAnalytics: (courseCode) => api.getCourseAttendanceAnalytics(courseCode),
  
  // System
  getStats: () => api.getScheduleStats(),
  getHealth: () => api.getScheduleHealth(),
  hasData: () => api.hasScheduleData()
};

// Export file URL utilities
export const fileUrlAPI = {
  getFileDownloadUrl: (fileId) => getFileDownloadUrl(fileId), // Now uses the new top-level getFileDownloadUrl
  getFileThumbnailUrl: (fileId, size) => api.getFileThumbnailUrl(fileId, size),
  getFilePreviewUrl: (fileId) => api.getFilePreviewUrl(fileId),
};

export const downloadImage = async (fileId, filename) => {
  try {
    // Check if running in a browser environment
    if (typeof document === 'undefined') {
      console.warn("downloadImage can only be executed in a browser environment.");
      return;
    }
    const downloadUrl = getImageDownloadUrl(fileId);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (error) {
    console.error('Error downloading image:', error);
    throw error;
  }
};

// Models API functions
export const getModels = async (skip = 0, limit = 100, sourceType = null, isActive = null) => {
  try {
    const params = new URLSearchParams({
      skip: skip.toString(),
      limit: limit.toString()
    });
    
    if (sourceType) params.append('source_type', sourceType);
    if (isActive !== null) params.append('is_active', isActive.toString());
    
    const url = buildApiUrl(`${API_ENDPOINTS.GET_MODELS}?${params.toString()}`);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${api.getAuthToken()}`
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch models: ${response.status}`);
    }

    const data = await response.json();
    return data.models || [];
  } catch (error) {
    console.error('Error fetching models:', error);
    throw error;
  }
};

// AI Chat Conversations API functions
export const chatAPI = {
  getConversations: (skip, limit) => getChatConversations(skip, limit), // Point to the new top-level function
  getConversation: (chatId) => api.getChatConversation(chatId),
  getById: (chatId) => getChatById(chatId), // New: Point to the new top-level getChatById
  getMessages: (chatId, skip, limit) => getChatMessages(chatId, skip, limit), // Point to the new top-level function
  sendMessage: (chatId, message, attachmentFileId) => api.sendChatMessage(chatId, message, attachmentFileId),
  createConversation: (title, initialMessage) => api.createChatConversation(title, initialMessage),
  createNewChat: (title) => api.createNewChat(title), // New function for creating new chat
  deleteConversation: (chatId) => api.deleteChatConversation(chatId),
  updateConversation: (chatId, updates) => api.updateChatConversation(chatId, updates),
  uploadAttachment: (chatId, file) => api.uploadChatAttachment(chatId, file),
  // New streaming chat completions
  sendCompletions: (messages, model, options) => api.sendChatCompletions(messages, model, options),
  createStreamingReader: (response, onChunk, onComplete, onError) => api.createStreamingReader(response, onChunk, onComplete, onError),
};


// Chat ID Management Utilities
export const chatUtils = {
  // Get current chat ID from localStorage or generate new one
  getCurrentChatId: () => {
    let chatId = localStorage.getItem('currentChatId');
    if (!chatId) {
      chatId = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('currentChatId', chatId);
      console.log('Generated new chat_id:', chatId);
    }
    return chatId;
  },

  // Set current chat ID
  setCurrentChatId: (chatId) => {
    if (chatId) {
      localStorage.setItem('currentChatId', chatId);
      console.log('Set current chat_id:', chatId);
    }
  },

  // Clear current chat ID (for new conversations)
  clearCurrentChatId: () => {
    localStorage.removeItem('currentChatId');
    console.log('Cleared current chat_id');
  },

  // Generate new chat ID
  generateChatId: () => {
    const chatId = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('currentChatId', chatId);
    console.log('Generated and set new chat_id:', chatId);
    return chatId;
  }
};

// Helper function to build full image URL
const buildImageUrl = (imagePath) => {
  if (!imagePath) return 'https://via.placeholder.com/60x60?text=U';
  
  // If it's already a full URL, return as is
  if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
    return imagePath;
  }
  
  // If it's a relative path, build full URL
  if (imagePath.startsWith('/')) {
    return `${API_BASE_URL}${imagePath}`;
  }
  
  // If it's just a path without leading slash, add it
  return `${API_BASE_URL}/${imagePath}`;
};

// Stories API functions
export const storiesAPI = {
  // Get all stories
  getStories: async (page = 1, limit = 20) => {
    try {
      const response = await api.get(API_ENDPOINTS.GET_STORIES, {
        params: { page, limit }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching stories:', error);
      throw error;
    }
  },

  // Get my stories
  getMyStories: async (includeArchived = false, page = 1, limit = 20) => {
    try {
      const response = await api.get(API_ENDPOINTS.GET_MY_STORIES, {
        params: { 
          include_archived: includeArchived,
          page, 
          limit 
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching my stories:', error);
      throw error;
    }
  },

  // Create new story
  createStory: async (storyData) => {
    try {
      const response = await api.post(API_ENDPOINTS.CREATE_STORY, storyData);
      return response.data;
    } catch (error) {
      console.error('Error creating story:', error);
      throw error;
    }
  },

  // Upload story media
  uploadStoryMedia: async (formData) => {
    try {
      const response = await api.post(API_ENDPOINTS.UPLOAD_STORY_MEDIA, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error uploading story media:', error);
      throw error;
    }
  },

  // Get story media URL
  getStoryMediaUrl: (mediaId) => {
    return buildApiUrl(API_ENDPOINTS.GET_STORY_MEDIA.replace('{media_id}', mediaId));
  },

  // Build full media URL
  buildMediaUrl: (mediaUrl) => {
    if (!mediaUrl) return null;
    
    // If it's already a full URL, return as is
    if (mediaUrl.startsWith('http://') || mediaUrl.startsWith('https://')) {
      return mediaUrl;
    }
    
    // If it's a relative path, build full URL
    if (mediaUrl.startsWith('/')) {
      return `${API_BASE_URL}${mediaUrl}`;
    }
    
    // If it's just a path without leading slash, add it
    return `${API_BASE_URL}/${mediaUrl}`;
  }
};

// Chat Service API functions for Communities
export const chatService = {
  // Get chat rooms with pagination
  getChatRooms: async (limit = 50, offset = 0) => {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        offset: offset.toString()
      });
      
      const url = buildApiUrl(`${API_ENDPOINTS.GET_CHAT_ROOMS}?${params.toString()}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch chat rooms: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch chat rooms:', error);
      throw error;
    }
  },

  // Get user profile by ID
  getUserProfile: async (userId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_USER_PROFILE.replace('{user_id}', userId));
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch user profile: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
      throw error;
    }
  },

  // Get multiple user profiles (for batch requests)
  getUserProfiles: async (userIds) => {
    try {
      const promises = userIds.map(id => chatService.getUserProfile(id));
      const profiles = await Promise.all(promises);
      return profiles;
    } catch (error) {
      console.error('Failed to fetch user profiles:', error);
      throw error;
    }
  },

  // Get chat messages for a specific room
  getChatMessages: async (roomId, limit = 50, offset = 0) => {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        offset: offset.toString()
      });
      
      const url = buildApiUrl(`${API_ENDPOINTS.GET_CHAT_MESSAGES.replace('{room_id}', roomId)}?${params.toString()}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch chat messages: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch chat messages:', error);
      throw error;
    }
  },

  // Send a message to a chat room
  sendMessage: async (roomId, message, files = [], replyToId = null) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.SEND_CHAT_MESSAGE.replace('{room_id}', roomId));
      
      // إنشاء FormData للـ multipart/form-data
      const formData = new FormData();
      
      // إضافة النص
      if (message) {
        formData.append('message', message);
      }
      
      // إضافة ID الرد إذا كان موجود
      if (replyToId) {
        formData.append('reply_to_id', replyToId);
      }
      
      // إضافة الملفات
      if (files && Array.isArray(files) && files.length > 0) {
        files.forEach(file => {
          formData.append('files', file);
        });
      }
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${api.getAuthToken()}`
          // لا نضع Content-Type لأن FormData يضعه تلقائياً مع boundary
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Failed to send message: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to send message:', error);
      throw error;
    }
  },

  // Mark chat as seen
  markChatAsSeen: async (roomId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.MARK_CHAT_SEEN.replace('{room_id}', roomId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to mark chat as seen: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to mark chat as seen:', error);
      throw error;
    }
  },

  // Mark specific message as seen
  markMessageAsSeen: async (roomId, messageId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.MARK_MESSAGE_SEEN.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to mark message as seen: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to mark message as seen:', error);
      throw error;
    }
  },

  // Create a new chat room
  createChatRoom: async (userId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.CREATE_CHAT_ROOM);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify({
          user_id: userId,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to create chat room: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to create chat room:', error);
      throw error;
    }
  },

  // Get current user info
  getCurrentUser: async () => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_CURRENT_USER);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch current user: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch current user:', error);
      throw error;
    }
  },

  // Register device token for push notifications
  registerDeviceToken: async (token, deviceType = 'web', deviceName = null, deviceId = null) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.REGISTER_DEVICE_TOKEN);
      
      // جمع معلومات الجهاز من المتصفح
      const deviceInfo = {
        os_version: navigator.platform || 'Unknown',
        app_version: '1.0.0', // يمكن تحديثه لاحقاً
        model: navigator.userAgent || 'Unknown',
        manufacturer: 'Web Browser',
        language: navigator.language || 'en',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      };

      const requestBody = {
        token: token,
        device_type: deviceType,
        device_name: deviceName || `${navigator.userAgent.split(' ')[0]} Browser`,
        device_id: deviceId || `web_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        device_info: deviceInfo
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`Failed to register device token: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to register device token:', error);
      throw error;
    }
  },

  // Update device token
  updateDeviceToken: async (deviceId, token, deviceType = 'web', deviceName = null, deviceIdParam = null) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.UPDATE_DEVICE_TOKEN.replace('{device_id}', deviceId));
      
      // جمع معلومات الجهاز من المتصفح
      const deviceInfo = {
        os_version: navigator.platform || 'Unknown',
        app_version: '1.0.0', // يمكن تحديثه لاحقاً
        model: navigator.userAgent || 'Unknown',
        manufacturer: 'Web Browser',
        language: navigator.language || 'en',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      };

      const requestBody = {
        token: token,
        device_type: deviceType,
        device_name: deviceName || `${navigator.userAgent.split(' ')[0]} Browser`,
        device_id: deviceIdParam || `web_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        device_info: deviceInfo
      };

      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`Failed to update device token: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to update device token:', error);
      throw error;
    }
  },

  // Delete chat room
  deleteChatRoom: async (roomId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.DELETE_CHAT_ROOM.replace('{room_id}', roomId));
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to delete chat room: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to delete chat room:', error);
      throw error;
    }
  },

  // Delete message
  deleteMessage: async (roomId, messageId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.DELETE_MESSAGE.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to delete message: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to delete message:', error);
      throw error;
    }
  },

  // Delete chat for me
  deleteChatForMe: async (roomId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.DELETE_CHAT_FOR_ME.replace('{room_id}', roomId));
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to delete chat for me: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to delete chat for me:', error);
      throw error;
    }
  },

  // Pin message
  pinMessage: async (roomId, messageId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.PIN_MESSAGE.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to pin message: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to pin message:', error);
      throw error;
    }
  },

  // Unpin message
  unpinMessage: async (roomId, messageId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.UNPIN_MESSAGE.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to unpin message: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to unpin message:', error);
      throw error;
    }
  },

  // Get pinned messages
  getPinnedMessages: async (roomId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_PINNED_MESSAGES.replace('{room_id}', roomId));
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get pinned messages: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get pinned messages:', error);
      throw error;
    }
  },

  // Reply to message
  replyToMessage: async (roomId, messageId, replyContent) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.REPLY_TO_MESSAGE.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify({
          content: replyContent,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to reply to message: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to reply to message:', error);
      throw error;
    }
  },

  // Add reaction
  addReaction: async (roomId, messageId, reactionType) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.ADD_REACTION.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify({
          reaction_type: reactionType,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to add reaction: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to add reaction:', error);
      throw error;
    }
  },

  // Remove reaction
  removeReaction: async (roomId, messageId, reactionType) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.REMOVE_REACTION.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify({
          reaction_type: reactionType,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to remove reaction: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to remove reaction:', error);
      throw error;
    }
  },

  // Get message reactions
  getMessageReactions: async (roomId, messageId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_MESSAGE_REACTIONS.replace('{room_id}', roomId).replace('{message_id}', messageId));
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get message reactions: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get message reactions:', error);
      throw error;
    }
  },

  // Get available reactions
  getAvailableReactions: async () => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_AVAILABLE_REACTIONS);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get available reactions: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get available reactions:', error);
      throw error;
    }
  },

  // Get chat media
  getChatMedia: async (roomId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_CHAT_MEDIA.replace('{room_id}', roomId));
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get chat media: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get chat media:', error);
      throw error;
    }
  },

  // Get chat requests
  getChatRequests: async () => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_CHAT_REQUESTS);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get chat requests: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get chat requests:', error);
      throw error;
    }
  },

  // Get pending chat requests
  getPendingChatRequests: async () => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_PENDING_CHAT_REQUESTS);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get pending chat requests: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get pending chat requests:', error);
      throw error;
    }
  },

  // Get sent chat requests
  getSentChatRequests: async () => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.GET_SENT_CHAT_REQUESTS);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get sent chat requests: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get sent chat requests:', error);
      throw error;
    }
  },

  // Accept chat request
  acceptChatRequest: async (requestId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.ACCEPT_CHAT_REQUEST.replace('{request_id}', requestId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to accept chat request: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to accept chat request:', error);
      throw error;
    }
  },

  // Reject chat request
  rejectChatRequest: async (requestId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.REJECT_CHAT_REQUEST.replace('{request_id}', requestId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to reject chat request: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to reject chat request:', error);
      throw error;
    }
  },

  // Cancel chat request
  cancelChatRequest: async (requestId) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.CANCEL_CHAT_REQUEST.replace('{request_id}', requestId));
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to cancel chat request: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to cancel chat request:', error);
      throw error;
    }
  },

  // Forward messages
  forwardMessages: async (messageIds, targetRoomIds) => {
    try {
      const url = buildApiUrl(API_ENDPOINTS.FORWARD_MESSAGES);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${api.getAuthToken()}`
        },
        body: JSON.stringify({
          message_ids: messageIds,
          target_room_ids: targetRoomIds,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to forward messages: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to forward messages:', error);
      throw error;
    }
  },

};

// Export the client instance for direct usage
export { api as apiClient };
