// Create Firebase Service Worker content dynamically with REAL VAPID KEY
export function createFirebaseServiceWorker() {
  const swContent = `
// 🔥 Firebase Service Worker for FCM with REAL VAPID KEY
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

const firebaseConfig = {
  apiKey: "AIzaSyBpMSXGurET-5cdwq3AuTehA2ufcddTS9w",
  authDomain: "taleb-bata.firebaseapp.com",
  projectId: "taleb-bata",
  storageBucket: "taleb-bata.firebasestorage.app",
  messagingSenderId: "885963257139",
  appId: "1:885963257139:web:a4efce2e0215dce719fa46",
};

console.log('🔥 Firebase Service Worker starting with REAL config...');

// تهيئة Firebase في Service Worker
firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

console.log('✅ Firebase initialized in Service Worker');

// 📱 VAPID KEY CONFIGURED
const VAPID_KEY = "BGBFNO4rPFx6Cz0p0NZdrlav9d_m6CM6C-7_muzNF_su3UDUf1G1x7RcaLkVaHvN4M7tYzIR1C9El3WAjBEGImY";
console.log('🔑 VAPID Key configured in SW:', VAPID_KEY.substring(0, 20) + '...');

// استقبال الإشعارات في الخلفية
messaging.onBackgroundMessage(function(payload) {
  console.log('🔥 [Firebase SW] Background message received:', payload);
  
  const notificationTitle = payload.notification?.title || 'طالب - Taleb Notification';
  const notificationOptions = {
    body: payload.notification?.body || 'You have a new notification from Taleb',
    icon: '/logo.png',
    badge: '/logo.png',
    tag: payload.data?.tag || 'taleb-general',
    data: {
      ...payload.data,
      timestamp: new Date().toISOString(),
      source: 'firebase_background'
    },
    requireInteraction: true,
    actions: [
      {
        action: 'view',
        title: '👀 View',
        icon: '/logo.png'
      },
      {
        action: 'dismiss',
        title: '❌ Dismiss'
      }
    ]
  };

  console.log('📱 Showing notification:', notificationTitle, notificationOptions);
  
  self.registration.showNotification(notificationTitle, notificationOptions);
});

// Handle notification click
self.addEventListener('notificationclick', function(event) {
  console.log('👆 [Firebase SW] Notification click received:', event);
  
  event.notification.close();
  
  const action = event.action;
  const data = event.notification.data || {};
  
  console.log('🎯 Action clicked:', action);
  console.log('📦 Notification data:', data);
  
  if (action === 'dismiss') {
    console.log('❌ Notification dismissed');
    return;
  }
  
  // Handle the click action - open app
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
      console.log('🔍 Found clients:', clientList.length);
      
      // If app is already open, focus it
      for (let i = 0; i < clientList.length; i++) {
        let client = clientList[i];
        if (client.url.includes(self.location.origin)) {
          console.log('✅ Focusing existing client');
          return client.focus();
        }
      }
      
      // If app is not open, open it
      console.log('🚀 Opening new client');
      return clients.openWindow('/');
    })
  );
});

// Handle notification close
self.addEventListener('notificationclose', function(event) {
  console.log('🔕 [Firebase SW] Notification closed:', event.notification.tag);
});

// Service Worker installation
self.addEventListener('install', function(event) {
  console.log('🔧 [Firebase SW] Installing...');
  self.skipWaiting();
});

// Service Worker activation
self.addEventListener('activate', function(event) {
  console.log('⚡ [Firebase SW] Activated!');
  event.waitUntil(self.clients.claim());
});

console.log('🔥✅ Firebase Service Worker fully loaded with REAL VAPID KEY!');
`;

  console.log('🔧 Creating Firebase Service Worker with REAL VAPID KEY...');
  
  // Create blob and register service worker
  const blob = new Blob([swContent], { type: 'application/javascript' });
  const swUrl = URL.createObjectURL(blob);
  
  return navigator.serviceWorker.register(swUrl, {
    scope: '/'
  }).then((registration) => {
    console.log('🔥✅ Firebase Service Worker registered successfully with REAL CONFIG!');
    console.log('📱 Registration details:', registration);
    return registration;
  }).catch((error) => {
    console.error('❌ Firebase Service Worker registration failed:', error);
    throw error;
  });
}
