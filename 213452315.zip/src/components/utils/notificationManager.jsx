import React from 'react';
import { useI18n } from './i18n';

class NotificationManager {
  constructor() {
    this.notifications = [];
    this.listeners = [];
    this.maxNotifications = 5;
    this.initialized = false;
    this.notificationService = null;
  }

  async initialize() {
    if (this.initialized) return;

    try {
      // Dynamically import Firebase service to avoid circular dependency
      const { notificationService } = await import('./firebase');
      this.notificationService = notificationService;

      // Initialize Firebase notifications
      if (this.notificationService && this.notificationService.initializeNotifications) {
        const firebaseEnabled = await this.notificationService.initializeNotifications();
        
        if (firebaseEnabled) {
          console.log('Firebase notifications enabled in manager');
        } else {
          console.log('Firebase notifications not enabled, but manager initialized');
        }
      } else {
        console.warn('Firebase notification service not available');
      }

      // Listen for Firebase notifications
      if (typeof window !== 'undefined') {
        window.addEventListener('firebaseNotification', (event) => {
          this.handleFirebaseNotification(event.detail);
        });

        // Listen for browser notifications permission changes
        if ('permissions' in navigator) {
          navigator.permissions.query({ name: 'notifications' }).then((result) => {
            result.addEventListener('change', () => {
              console.log('Notification permission changed:', result.state);
            });
          }).catch(() => {
            // Ignore permission query errors
          });
        }
      }

      this.initialized = true;
    } catch (error) {
      console.error('Error initializing notification manager:', error);
      // Still mark as initialized to prevent repeated attempts
      this.initialized = true;
    }
  }

  handleFirebaseNotification(payload) {
    const notification = {
      id: Date.now(),
      title: payload.notification?.title || 'Taleb',
      message: payload.notification?.body || 'You have a new notification',
      type: payload.data?.type || 'info',
      timestamp: new Date(),
      data: payload.data || {},
      read: false,
      persistent: payload.data?.persistent === 'true'
    };

    this.addNotification(notification);
  }

  addNotification(notification) {
    // Add to notifications array
    this.notifications.unshift(notification);

    // Limit the number of notifications
    if (this.notifications.length > this.maxNotifications) {
      this.notifications = this.notifications.slice(0, this.maxNotifications);
    }

    // Notify listeners
    this.notifyListeners();

    // Auto-remove non-persistent notifications after 5 seconds
    if (!notification.persistent) {
      setTimeout(() => {
        this.removeNotification(notification.id);
      }, 5000);
    }
  }

  removeNotification(id) {
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.notifyListeners();
  }

  markAsRead(id) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      notification.read = true;
      this.notifyListeners();
    }
  }

  markAllAsRead() {
    this.notifications.forEach(n => n.read = true);
    this.notifyListeners();
  }

  clearAll() {
    this.notifications = [];
    this.notifyListeners();
  }

  getUnreadCount() {
    return this.notifications.filter(n => !n.read).length;
  }

  subscribe(listener) {
    this.listeners.push(listener);
    
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notifyListeners() {
    this.listeners.forEach(listener => {
      try {
        listener(this.notifications);
      } catch (error) {
        console.error('Error in notification listener:', error);
      }
    });
  }

  // Predefined notification types
  showScheduleReminder(classInfo) {
    this.addNotification({
      id: Date.now(),
      title: 'Class Reminder',
      message: `${classInfo.course_code} starts in 15 minutes`,
      type: 'schedule',
      timestamp: new Date(),
      data: { ...classInfo },
      read: false,
      persistent: true
    });
  }

  showTaskDeadline(task) {
    this.addNotification({
      id: Date.now(),
      title: 'Task Deadline',
      message: `"${task.title}" is due soon`,
      type: 'task',
      timestamp: new Date(),
      data: { ...task },
      read: false,
      persistent: true
    });
  }

  showGradeUpdate(grade) {
    this.addNotification({
      id: Date.now(),
      title: 'Grade Updated',
      message: `New grade available for ${grade.course_code}`,
      type: 'grade',
      timestamp: new Date(),
      data: { ...grade },
      read: false,
      persistent: true
    });
  }

  showSystemUpdate(message) {
    this.addNotification({
      id: Date.now(),
      title: 'System Update',
      message: message,
      type: 'system',
      timestamp: new Date(),
      data: {},
      read: false,
      persistent: false
    });
  }

  // Test notification
  showTestNotification() {
    this.addNotification({
      id: Date.now(),
      title: 'Test Notification',
      message: 'This is a test notification from Taleb',
      type: 'test',
      timestamp: new Date(),
      data: {},
      read: false,
      persistent: false
    });

    // Also show browser notification if service is available
    if (this.notificationService && this.notificationService.sendTestNotification) {
      this.notificationService.sendTestNotification();
    }
  }
}

// Create singleton instance
export const notificationManager = new NotificationManager();

// React hook for using notifications
export const useNotifications = () => {
  const [notifications, setNotifications] = React.useState([]);
  const { t } = useI18n();

  React.useEffect(() => {
    // Initialize notification manager
    notificationManager.initialize();

    // Subscribe to notifications
    const unsubscribe = notificationManager.subscribe(setNotifications);

    return unsubscribe;
  }, []);

  return {
    notifications,
    unreadCount: notificationManager.getUnreadCount(),
    markAsRead: (id) => notificationManager.markAsRead(id),
    markAllAsRead: () => notificationManager.markAllAsRead(),
    clearAll: () => notificationManager.clearAll(),
    showTest: () => notificationManager.showTestNotification()
  };
};

// Export for direct use
export default notificationManager;
