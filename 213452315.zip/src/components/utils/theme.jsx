import React, { createContext, useContext, useState, useEffect } from 'react';

// Theme detection
const detectTheme = () => {
  // Check localStorage first
  const savedTheme = localStorage.getItem('taleb-theme');
  if (savedTheme && ['light', 'dark'].includes(savedTheme)) {
    return savedTheme;
  }
  
  // Check system preference
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  
  // Default to light
  return 'light';
};

// Theme Context
const ThemeContext = createContext();

// Theme Provider Component
export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(detectTheme());

  // Toggle theme
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    changeTheme(newTheme);
  };

  // Change theme
  const changeTheme = (newTheme) => {
    if (['light', 'dark'].includes(newTheme)) {
      setTheme(newTheme);
      localStorage.setItem('taleb-theme', newTheme);
      
      // Update document attributes
      document.documentElement.setAttribute('data-theme', newTheme);
      document.documentElement.classList.remove('light', 'dark');
      document.documentElement.classList.add(newTheme);
      
      // Update body class
      document.body.className = document.body.className.replace(/\btheme-\w+\b/g, '');
      document.body.classList.add(`theme-${newTheme}`);
    }
  };

  // Listen for system theme changes
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e) => {
      // Only change if user hasn't manually set a theme
      if (!localStorage.getItem('taleb-theme')) {
        changeTheme(e.matches ? 'dark' : 'light');
      }
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  // Initialize theme on mount
  useEffect(() => {
    changeTheme(theme);
  }, []);

  const value = {
    theme,
    toggleTheme,
    changeTheme,
    isDark: theme === 'dark',
    isLight: theme === 'light'
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

// Hook to use Theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};

// Theme classes helper
export const getThemeClasses = (theme) => {
  const baseClasses = 'transition-colors duration-300';
  
  if (theme === 'dark') {
    return `${baseClasses} bg-gray-900 text-white`;
  }
  
  return `${baseClasses} bg-white text-gray-900`;
};

export default {
  ThemeProvider,
  useTheme,
  getThemeClasses,
  detectTheme
};
