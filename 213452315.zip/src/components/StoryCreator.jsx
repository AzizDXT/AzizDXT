import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Image, Video, Type, Palette, Download, Share2, Smile, Heart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { storiesAPI } from './utils/api';
import { useI18n } from './utils/i18n';

export default function StoryCreator({ isOpen, onClose, onStoryCreated }) {
  const { t, language } = useI18n();
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [mediaType, setMediaType] = useState(null);
  const [textOverlay, setTextOverlay] = useState('');
  const [textPosition, setTextPosition] = useState({ x: 50, y: 20 });
  const [textColor, setTextColor] = useState('#FFFFFF');
  const [textSize, setTextSize] = useState(24);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedSticker, setSelectedSticker] = useState(null);
  const [stickerPosition, setStickerPosition] = useState({ x: 50, y: 50 });
  const fileInputRef = useRef(null);
  const canvasRef = useRef(null);

  const handleFileSelect = useCallback((file) => {
    if (!file) return;

    const type = file.type.startsWith('image/') ? 'image' : 'video';
    setMediaType(type);
    setSelectedFile(file);
    
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInputChange = (e) => {
    const file = e.target.files[0];
    handleFileSelect(file);
  };

  const handleTextDrag = (e) => {
    if (!e.target.closest('.text-overlay')) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setTextPosition({ 
      x: Math.max(0, Math.min(100, x)), 
      y: Math.max(0, Math.min(100, y)) 
    });
  };

  const handleTextClick = (e) => {
    if (e.target.closest('.text-overlay')) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setTextPosition({ 
      x: Math.max(0, Math.min(100, x)), 
      y: Math.max(0, Math.min(100, y)) 
    });
  };

  const handleCreateStory = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('media', selectedFile);
      formData.append('media_type', mediaType);
      
      if (textOverlay.trim()) {
        formData.append('text_overlay', textOverlay);
        formData.append('text_position', JSON.stringify(textPosition));
        formData.append('text_color', textColor);
        formData.append('text_size', textSize.toString());
      }

      // Upload story media
      const uploadResult = await storiesAPI.uploadStoryMedia(formData);
      
      if (uploadResult.success) {
        // Create story with uploaded media
        const storyData = {
          media_id: uploadResult.media_id,
          media_type: mediaType,
          text_overlay: textOverlay.trim() || null,
          text_position: textOverlay.trim() ? textPosition : null,
          text_color: textOverlay.trim() ? textColor : null,
          text_size: textOverlay.trim() ? textSize : null
        };

        const storyResult = await storiesAPI.createStory(storyData);
        
        if (storyResult.success) {
          onStoryCreated?.(storyResult.story);
          handleClose();
        }
      }
    } catch (error) {
      console.error('Error creating story:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setMediaType(null);
    setTextOverlay('');
    setTextPosition({ x: 50, y: 20 });
    setTextColor('#FFFFFF');
    setTextSize(24);
    setIsUploading(false);
    onClose();
  };

  const textColors = [
    '#FFFFFF', '#000000', '#FF0000', '#00FF00', '#0000FF', 
    '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080'
  ];

  const stickers = [
    { id: 'heart', icon: Heart, color: '#FF0000' },
    { id: 'star', icon: Star, color: '#FFD700' },
    { id: 'smile', icon: Smile, color: '#FFA500' }
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && handleClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-md max-h-[90vh] overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              {t('stories.createStory')}
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-4 space-y-4">
            {!selectedFile ? (
              /* File Upload Area */
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                    : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 dark:text-gray-300 mb-2">
                  {t('stories.dragDropFiles')}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('stories.supportedFormats')}
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileInputChange}
                  className="hidden"
                />
              </div>
            ) : (
              /* Media Preview and Editor */
              <div className="space-y-4">
                {/* Media Preview */}
                <div 
                  className="relative aspect-[9/16] bg-black rounded-lg overflow-hidden cursor-crosshair"
                  onMouseMove={handleTextDrag}
                  onClick={handleTextClick}
                >
                  {mediaType === 'image' ? (
                    <img
                      src={previewUrl}
                      alt="Story preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <video
                      src={previewUrl}
                      className="w-full h-full object-cover"
                      controls
                    />
                  )}
                  
                  {/* Text Overlay */}
                  {textOverlay && (
                    <div
                      className="absolute text-overlay cursor-move select-none pointer-events-auto"
                      style={{
                        left: `${textPosition.x}%`,
                        top: `${textPosition.y}%`,
                        color: textColor,
                        fontSize: `${textSize}px`,
                        fontWeight: 'bold',
                        textShadow: textColor === '#FFFFFF' ? '2px 2px 4px rgba(0,0,0,0.8)' : '2px 2px 4px rgba(255,255,255,0.8)',
                        transform: 'translate(-50%, -50%)',
                        textAlign: 'center',
                        maxWidth: '90%',
                        wordWrap: 'break-word'
                      }}
                    >
                      {textOverlay}
                    </div>
                  )}

                  {/* Sticker Overlay */}
                  {selectedSticker && (
                    <div
                      className="absolute cursor-move select-none pointer-events-auto"
                      style={{
                        left: `${stickerPosition.x}%`,
                        top: `${stickerPosition.y}%`,
                        transform: 'translate(-50%, -50%)'
                      }}
                    >
                      <selectedSticker.icon 
                        className="w-12 h-12 drop-shadow-lg" 
                        style={{ color: selectedSticker.color }}
                      />
                    </div>
                  )}
                </div>

                {/* Text Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {t('stories.addText')}
                  </label>
                  <Textarea
                    value={textOverlay}
                    onChange={(e) => setTextOverlay(e.target.value)}
                    placeholder={t('stories.textPlaceholder')}
                    className="min-h-[80px]"
                  />
                </div>

                {/* Text Controls */}
                {textOverlay && (
                  <div className="space-y-3">
                    {/* Text Size */}
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {t('stories.textSize')}
                      </label>
                      <input
                        type="range"
                        min="12"
                        max="48"
                        value={textSize}
                        onChange={(e) => setTextSize(Number(e.target.value))}
                        className="w-full mt-1"
                      />
                    </div>

                    {/* Text Color */}
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {t('stories.textColor')}
                      </label>
                      <div className="flex gap-2 mt-2">
                        {textColors.map((color) => (
                          <button
                            key={color}
                            onClick={() => setTextColor(color)}
                            className={`w-8 h-8 rounded-full border-2 ${
                              textColor === color ? 'border-gray-400' : 'border-gray-200'
                            }`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Stickers */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {t('stories.addSticker')}
                  </label>
                  <div className="flex gap-2">
                    {stickers.map((sticker) => {
                      const IconComponent = sticker.icon;
                      return (
                        <button
                          key={sticker.id}
                          onClick={() => setSelectedSticker(sticker)}
                          className={`p-2 rounded-lg border-2 transition-colors ${
                            selectedSticker?.id === sticker.id 
                              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                              : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                          }`}
                        >
                          <IconComponent 
                            className="w-6 h-6" 
                            style={{ color: sticker.color }}
                          />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex gap-3 p-4 border-t border-gray-200 dark:border-gray-700">
            <Button
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              disabled={isUploading}
            >
              {t('common.cancel')}
            </Button>
            {selectedFile && (
              <Button
                onClick={handleCreateStory}
                className="flex-1"
                disabled={isUploading}
              >
                {isUploading ? t('common.uploading') : t('stories.shareStory')}
              </Button>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
