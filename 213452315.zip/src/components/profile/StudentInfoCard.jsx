import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Hash, GraduationCap, ShieldCheck, Flag, Calendar, GitBranch, CheckCircle, Award, BookOpen } from 'lucide-react';
import { useI18n } from '../utils/i18n';

const InfoItem = ({ icon, label, value, color = 'text-[var(--accent-color)]' }) => (
  <div className="flex items-start gap-3 p-4 rounded-xl bg-[var(--background-secondary)] hover:shadow-md transition-all duration-200">
    <div className={`mt-1 ${color}`}>{icon}</div>
    <div className="flex-1">
      <p className="text-sm font-medium text-[var(--text-secondary)]">{label}</p>
      <p className="font-bold text-[var(--text-primary)] mt-1">{value || 'N/A'}</p>
    </div>
  </div>
);

export default function StudentInfoCard({ info }) {
  const { t } = useI18n();
  
  if (!info) return null;

  return (
    <Card className="bg-[var(--background)] border-[var(--border-color)] shadow-lg">
      <CardHeader>
        <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
          <User className="w-6 h-6" />
          {t('academic.studentInfo')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          <InfoItem 
            icon={<User size={20} />} 
            label={t('academic.student_name')} 
            value={info.student_name}
            color="text-blue-500"
          />
          <InfoItem 
            icon={<Hash size={20} />} 
            label={t('academic.student_number')} 
            value={info.student_number}
            color="text-green-500"
          />
          <InfoItem 
            icon={<Hash size={20} />} 
            label={t('academic.ouvs_id')} 
            value={info.ouvs_id}
            color="text-purple-500"
          />
          <InfoItem 
            icon={<GraduationCap size={20} />} 
            label={t('academic.program')} 
            value={info.program_of_study}
            color="text-indigo-500"
          />
          <InfoItem 
            icon={<ShieldCheck size={20} />} 
            label={t('academic.major')} 
            value={info.major}
            color="text-cyan-500"
          />
          <InfoItem 
            icon={<Award size={20} />} 
            label={t('academic.degree')} 
            value={info.degree}
            color="text-orange-500"
          />
          <InfoItem 
            icon={<Flag size={20} />} 
            label={t('academic.nationality')} 
            value={info.nationality}
            color="text-red-500"
          />
          <InfoItem 
            icon={<GitBranch size={20} />} 
            label={t('academic.branch')} 
            value={info.branch}
            color="text-teal-500"
          />
          <InfoItem 
            icon={<CheckCircle size={20} />} 
            label={t('academic.status')} 
            value={t('academic.status.enrolled')}
            color="text-green-600"
          />
          <InfoItem 
            icon={<Calendar size={20} />} 
            label={t('academic.admission_date')} 
            value={info.admission_date ? new Date(info.admission_date).toLocaleDateString() : 'N/A'}
            color="text-pink-500"
          />
          <InfoItem 
            icon={<BookOpen size={20} />} 
            label={t('academic.admission_basis')} 
            value={info.basis_of_admission}
            color="text-violet-500"
          />
          <InfoItem 
            icon={<Calendar size={20} />} 
            label={t('academic.date_of_birth')} 
            value={info.date_of_birth ? new Date(info.date_of_birth).toLocaleDateString() : 'N/A'}
            color="text-amber-500"
          />
        </div>
      </CardContent>
    </Card>
  );
}
