import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useI18n } from '../utils/i18n';

const getGradeColor = (grade) => {
    if (!grade) return 'text-[var(--text-secondary)]';
    if (['A+', 'A'].includes(grade)) return 'text-green-600 font-bold bg-green-100 dark:bg-green-900';
    if (['A-', 'B+', 'B'].includes(grade)) return 'text-blue-600 font-semibold bg-blue-100 dark:bg-blue-900';
    if (['B-', 'C+', 'C'].includes(grade)) return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900';
    if (['C-', 'D+', 'D'].includes(grade)) return 'text-orange-600 bg-orange-100 dark:bg-orange-900';
    if (['F'].includes(grade)) return 'text-red-600 font-bold bg-red-100 dark:bg-red-900';
    return 'text-[var(--text-primary)]';
};

const getStatusIcon = (grade) => {
    if (!grade) return <Clock size={14} className="text-yellow-500" />;
    if (['F'].includes(grade)) return <AlertCircle size={14} className="text-red-500" />;
    return <CheckCircle size={14} className="text-green-500" />;
};

export default function CourseTable({ title, description, courses }) {
    const { t } = useI18n();
    
    if (!courses || courses.length === 0) return null;

    const completedCourses = courses.filter(course => course.grade).length;
    const totalCourses = courses.length;
    const completionRate = totalCourses > 0 ? (completedCourses / totalCourses) * 100 : 0;

    return (
        <Card className="bg-[var(--background)] border-[var(--border-color)] shadow-lg">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-[var(--text-primary)] text-xl">{title}</CardTitle>
                        {description && <CardDescription className="mt-1">{description}</CardDescription>}
                    </div>
                    <div className="text-right">
                        <div className="text-2xl font-bold text-[var(--text-primary)]">
                            {completionRate.toFixed(0)}%
                        </div>
                        <div className="text-sm text-[var(--text-secondary)]">
                            {completedCourses}/{totalCourses} courses
                        </div>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[100px]">{t('academic.table.status')}</TableHead>
                                <TableHead>{t('academic.table.code')}</TableHead>
                                <TableHead className="hidden md:table-cell">{t('academic.table.name')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.credits')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.grade')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.points')}</TableHead>
                                <TableHead className="hidden lg:table-cell">{t('academic.table.semester')}</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {courses.map((course, index) => (
                                <TableRow key={index} className="hover:bg-[var(--background-secondary)]">
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            {getStatusIcon(course.grade)}
                                        </div>
                                    </TableCell>
                                    <TableCell className="font-medium text-[var(--text-primary)]">
                                        {course.course_code}
                                    </TableCell>
                                    <TableCell className="hidden md:table-cell text-[var(--text-secondary)] max-w-xs">
                                        <div className="truncate" title={course.course_name}>
                                            {course.course_name}
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-center font-medium text-[var(--text-primary)]">
                                        {course.credits}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        {course.grade ? (
                                            <Badge className={`${getGradeColor(course.grade)} px-2 py-1`}>
                                                {course.grade}
                                            </Badge>
                                        ) : (
                                            <Badge variant="outline" className="text-[var(--text-secondary)]">
                                                {t('academic.table.pending')}
                                            </Badge>
                                        )}
                                    </TableCell>
                                    <TableCell className="text-center text-[var(--text-primary)] font-medium">
                                        {course.gpa_points || '-'}
                                    </TableCell>
                                    <TableCell className="hidden lg:table-cell text-[var(--text-secondary)] text-sm">
                                        {course.semester || t('academic.table.tbd')}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
}
