import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Target, Award, BookOpen } from 'lucide-react';
import { useI18n } from '../utils/i18n';

const GradeCircle = ({ gpa, size = 'large' }) => {
  const percentage = Math.min((gpa / 4.0) * 100, 100);
  const radius = size === 'large' ? 45 : 35;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  let colorClass = 'text-green-500';
  let bgColor = 'from-green-400 to-green-600';
  
  if (gpa < 2.0) {
    colorClass = 'text-red-500';
    bgColor = 'from-red-400 to-red-600';
  } else if (gpa < 2.5) {
    colorClass = 'text-orange-500';
    bgColor = 'from-orange-400 to-orange-600';
  } else if (gpa < 3.0) {
    colorClass = 'text-yellow-500';
    bgColor = 'from-yellow-400 to-yellow-600';
  } else if (gpa < 3.5) {
    colorClass = 'text-blue-500';
    bgColor = 'from-blue-400 to-blue-600';
  }

  const containerSize = size === 'large' ? 'w-40 h-40' : 'w-32 h-32';
  const textSize = size === 'large' ? 'text-2xl' : 'text-xl';

  return (
    <div className={`relative ${containerSize} mx-auto flex items-center justify-center`}>
      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
        <circle
          className="text-gray-200"
          strokeWidth="6"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
        />
        <circle
          className={colorClass}
          strokeWidth="6"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={`${textSize} font-bold text-[var(--text-primary)]`}>
          {gpa.toFixed(2)}
        </span>
        <span className="text-sm text-[var(--text-secondary)]">GPA</span>
      </div>
    </div>
  );
};

export default function AcademicProgress({ studentInfo }) {
  const { t } = useI18n();
  
  if (!studentInfo) return null;

  const { gpa, plan_credits, academic_record } = studentInfo;

  // Calculate total completed credits from all sections
  const completed_credits = academic_record ? 
    Object.values(academic_record).reduce((total, section) => {
      return total + (section.credits_completed || 0);
    }, 0) : 0;
  
  const progressPercentage = plan_credits > 0 ? Math.min((completed_credits / plan_credits) * 100, 100) : 0;

  // Calculate completion by category
  const categoryProgress = academic_record ? Object.entries(academic_record).map(([key, section]) => {
    const displayNames = {
      general_requirements: t('academic.category.general'),
      special_requirements_mandatory: t('academic.category.major'),
      faculty_requirements_mandatory: t('academic.category.faculty'),
      university_requirements_electives: t('academic.category.electives')
    };
    
    return {
      name: displayNames[key] || key,
      completed: section.credits_completed || 0,
      needed: section.credits_needed || 0,
      percentage: section.credits_needed > 0 ? (section.credits_completed / section.credits_needed) * 100 : 0
    };
  }) : [];

  const getGpaStatus = (gpa) => {
    if (gpa >= 3.5) return t('academic.gpa_status.excellent');
    if (gpa >= 3.0) return t('academic.gpa_status.good');
    if (gpa >= 2.5) return t('academic.gpa_status.satisfactory');
    return t('academic.gpa_status.needs_improvement');
  };

  return (
    <Card className="bg-[var(--background)] border-[var(--border-color)] shadow-lg">
      <CardHeader>
        <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
          <TrendingUp className="w-6 h-6" />
          {t('academic.progress')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Overall Progress - Fixed Centering */}
          <div className="space-y-6">
            <div className="flex flex-col items-center justify-center">
              <GradeCircle gpa={gpa} />
              <div className="mt-4 text-center">
                <h3 className="text-lg font-semibold text-[var(--text-primary)]">{t('academic.overall_gpa')}</h3>
                <p className="text-sm text-[var(--text-secondary)]">
                  {getGpaStatus(gpa)}
                </p>
              </div>
            </div>
          </div>

          {/* Credits Progress */}
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-semibold text-[var(--text-primary)] flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  {t('academic.credits_progress')}
                </h3>
                <span className="text-sm text-[var(--text-secondary)]">
                  {completed_credits}/{plan_credits}
                </span>
              </div>
              <Progress value={progressPercentage} className="w-full h-3 mb-4" />
              <div className="text-center">
                <p className="text-2xl font-bold text-[var(--text-primary)]">
                  {progressPercentage.toFixed(1)}%
                </p>
                <p className="text-sm text-[var(--text-secondary)]">{t('academic.credits_complete')}</p>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="space-y-3">
              <h4 className="font-medium text-[var(--text-primary)] flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                {t('academic.by_category')}
              </h4>
              {categoryProgress.map((category, index) => (
                <div key={index} className="space-y-1">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-[var(--text-secondary)]">{category.name}</span>
                    <span className="text-[var(--text-primary)] font-medium">
                      {category.completed}/{category.needed}
                    </span>
                  </div>
                  <Progress value={Math.min(category.percentage, 100)} className="h-2" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
