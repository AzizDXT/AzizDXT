import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, RotateCcw, Crop, RotateCw } from 'lucide-react';
import { useI18n } from '../utils/i18n';
import ReactCrop, { centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

// Image cropping dialog component with proper zoom and rotation handling
function ImageCropDialog({ 
  isOpen, 
  onClose, 
  onSave, 
  imageFile, 
  cropType 
}) {
  const [imageUrl, setImageUrl] = useState('');
  const [crop, setCrop] = useState();
  const [rotation, setRotation] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [imageDimensions, setImageDimensions] = useState({ width: 0, height: 0 });
  
  const imgRef = useRef(null);
  const { t, language } = useI18n();

  // Calculate initial crop based on type - fills maximum available space
  const getInitialCrop = useCallback((img) => {
    if (!img) return;
    
    const aspect = cropType === 'profile' ? 1 : 4; // 1:1 for profile, 4:1 for banner
    const imgWidth = img.width;
    const imgHeight = img.height;
    
    let cropWidth, cropHeight;
    
    if (cropType === 'profile') {
      // For profile (1:1), use the smaller dimension
      const size = Math.min(imgWidth, imgHeight);
      cropWidth = size;
      cropHeight = size;
    } else {
      // For banner (4:1), calculate based on aspect ratio
      if (imgWidth / imgHeight > 4) {
        // Image is wider than 4:1, use height as constraint
        cropHeight = imgHeight;
        cropWidth = imgHeight * 4;
      } else {
        // Image is taller than 4:1, use width as constraint
        cropWidth = imgWidth;
        cropHeight = imgWidth / 4;
      }
    }
    
    // Center the crop
    const x = (imgWidth - cropWidth) / 2;
    const y = (imgHeight - cropHeight) / 2;
    
    // Convert to percentage
    const crop = {
      x: (x / imgWidth) * 100,
      y: (y / imgHeight) * 100,
      width: (cropWidth / imgWidth) * 100,
      height: (cropHeight / imgHeight) * 100,
      unit: '%'
    };
    
    setCrop(crop);
  }, [cropType]);

  useEffect(() => {
    if (imageFile) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImageUrl(e.target.result);
        setCrop(undefined);
        setRotation(0);
      };
      reader.readAsDataURL(imageFile);
    }
  }, [imageFile]);

  const onImageLoad = useCallback((e) => {
    const img = e.target;
    setImageDimensions({
      width: img.naturalWidth,
      height: img.naturalHeight
    });
    // Create initial crop immediately after image loads
    setTimeout(() => getInitialCrop(img), 100);
  }, [getInitialCrop]);

  const handleRotation = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const resetRotation = () => {
    setRotation(0);
  };

  // Proper cropping function that handles rotation correctly
  const cropImage = async () => {
    if (!imgRef.current || !crop || !imageDimensions.width || !imageDimensions.height) {
      return null;
    }

    setIsLoading(true);
    
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = imgRef.current;

      // Convert percentage crop to pixel crop on original image
      const pixelCrop = {
        x: (crop.x / 100) * imageDimensions.width,
        y: (crop.y / 100) * imageDimensions.height,
        width: (crop.width / 100) * imageDimensions.width,
        height: (crop.height / 100) * imageDimensions.height,
      };

      // Set canvas size to final crop dimensions
      canvas.width = pixelCrop.width;
      canvas.height = pixelCrop.height;

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Create a temporary canvas for the full image with transformations
      const tempCanvas = document.createElement('canvas');
      const tempCtx = tempCanvas.getContext('2d');
      
      // Set temp canvas size to accommodate rotated image
      const maxDimension = Math.max(imageDimensions.width, imageDimensions.height);
      tempCanvas.width = maxDimension * 2;
      tempCanvas.height = maxDimension * 2;

      // Center the image on temp canvas
      const centerX = tempCanvas.width / 2;
      const centerY = tempCanvas.height / 2;

      // Apply transformations to temp canvas
      tempCtx.save();
      tempCtx.translate(centerX, centerY);
      tempCtx.rotate((rotation * Math.PI) / 180);
      tempCtx.drawImage(
        img,
        -imageDimensions.width / 2,
        -imageDimensions.height / 2,
        imageDimensions.width,
        imageDimensions.height
      );
      tempCtx.restore();

      // Calculate the position of our crop area on the temp canvas
      const rotatedCropX = centerX + (pixelCrop.x - imageDimensions.width / 2);
      const rotatedCropY = centerY + (pixelCrop.y - imageDimensions.height / 2);

      // Draw the cropped portion from temp canvas to final canvas
      ctx.drawImage(
        tempCanvas,
        rotatedCropX,
        rotatedCropY,
        pixelCrop.width,
        pixelCrop.height,
        0,
        0,
        canvas.width,
        canvas.height
      );

      // Convert to blob
      return new Promise((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], imageFile.name, {
              type: imageFile.type,
              lastModified: Date.now(),
            });
            resolve(file);
          } else {
            resolve(null);
          }
        }, imageFile.type, 0.95);
      });
    } catch (error) {
      console.error('Error cropping image:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    const croppedFile = await cropImage();
    if (croppedFile) {
      onSave(croppedFile);
    }
    onClose();
  };

  if (!isOpen || !imageFile) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-[var(--background)] rounded-3xl p-6 max-w-4xl mx-4 shadow-2xl max-h-[95vh] overflow-auto border border-[var(--border-color)]" 
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-[var(--text-primary)]">
              {cropType === 'profile' 
                ? (language === 'ar' ? 'قص صورة الملف الشخصي (1:1)' : 'Crop Profile Image (1:1)')
                : (language === 'ar' ? 'قص صورة الغلاف (4:1)' : 'Crop Banner Image (4:1)')
              }
            </h3>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--background-secondary)] transition-colors">
              <X className="w-6 h-6 text-[var(--text-secondary)]" />
            </button>
          </div>
          
          {/* Controls */}
          <div className="mb-6 flex items-center gap-4 p-4 bg-[var(--background-secondary)] rounded-2xl flex-wrap justify-center">
            {/* Rotation Controls */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRotation}
                className="h-8 px-3"
              >
                <RotateCw className="w-4 h-4 mr-1" />
                {language === 'ar' ? 'دوران' : 'Rotate'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={resetRotation}
                className="h-8 px-3"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                {language === 'ar' ? 'إعادة تعيين' : 'Reset'}
              </Button>
            </div>
          </div>
          
          {/* Image Cropper */}
          <div className="mb-6 flex justify-center">
            <div className="relative bg-gray-100 dark:bg-gray-800 rounded-2xl overflow-hidden">
              <ReactCrop
                crop={crop}
                onChange={(_, percentCrop) => setCrop(percentCrop)}
                aspect={cropType === 'profile' ? 1 : 4}
                minWidth={100}
                minHeight={100}
                keepSelection
                className="max-w-full max-h-[500px]"
              >
                <img
                  ref={imgRef}
                  src={imageUrl}
                  alt="Crop preview"
                  onLoad={onImageLoad}
                  style={{
                    transform: `rotate(${rotation}deg)`,
                    transformOrigin: 'center',
                    maxWidth: '100%',
                    maxHeight: '500px',
                    width: 'auto',
                    height: 'auto'
                  }}
                  draggable={false}
                />
              </ReactCrop>
            </div>
          </div>

          {/* Instructions */}
          <div className="mb-6 text-center text-sm text-[var(--text-secondary)] bg-[var(--background-secondary)] p-4 rounded-2xl">
            <p className="mb-2">
              {language === 'ar' 
                ? 'اسحب الزوايا لتغيير الحجم • اسحب المنطقة لتحريكها • التحديد تم إنشاؤه تلقائياً'
                : 'Drag corners to resize • Drag area to move • Selection created automatically'
              }
            </p>
            <p className="text-xs opacity-75">
              {cropType === 'profile' 
                ? (language === 'ar' ? 'النسبة المطلوبة: مربع (1:1)' : 'Required ratio: Square (1:1)')
                : (language === 'ar' ? 'النسبة المطلوبة: مستطيل أفقي (4:1)' : 'Required ratio: Horizontal rectangle (4:1)')
              }
            </p>
          </div>

          {/* Action Buttons */}
          <div className={`flex gap-4 ${language === 'ar' ? 'flex-row-reverse' : ''}`}>
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 h-12 rounded-2xl"
            >
              {t('common.cancel')}
            </Button>
            <Button
              onClick={handleSave}
              disabled={isLoading || !crop}
              className="flex-1 h-12 bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90 rounded-2xl shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  {language === 'ar' ? 'جاري المعالجة...' : 'Processing...'}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Crop className="w-4 h-4" />
                  {language === 'ar' ? 'قص وحفظ' : 'Crop & Save'}
                </div>
              )}
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

export default ImageCropDialog; 