
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend } from 'recharts';
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Target, Award } from 'lucide-react';
import { useI18n } from '../utils/i18n';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function AcademicAnalytics({ studentData, semesterRecords, academicRecord }) {
  const { t, language, isRTL } = useI18n();
  
  if (!studentData) return null;

  // Prepare GPA Trend Data
  const gpaData = semesterRecords?.map(record => ({
    semester: record.semester?.replace('2024/2025 ', '') || 'N/A',
    gpa: record.semester_gpa || 0,
    credits: record.total_credits || 0
  })) || [];

  // Prepare Grade Distribution Data
  const gradeDistribution = {};
  if (academicRecord) {
    Object.values(academicRecord).forEach(section => {
      section.courses.forEach(course => {
        if (course.grade) {
          gradeDistribution[course.grade] = (gradeDistribution[course.grade] || 0) + 1;
        }
      });
    });
  }

  const gradeData = Object.entries(gradeDistribution).map(([grade, count]) => ({
    grade,
    count,
    percentage: ((count / Object.values(gradeDistribution).reduce((a, b) => a + b, 0)) * 100).toFixed(1)
  }));

  // Prepare Credits by Category Data
  const categoryData = academicRecord ? Object.entries(academicRecord).map(([key, section]) => {
    const displayNames = {
      general_requirements: t('academic.category.general'),
      special_requirements_mandatory: t('academic.category.major'),
      faculty_requirements_mandatory: t('academic.category.faculty'),
      university_requirements_electives: t('academic.category.electives')
    };
    
    return {
      name: displayNames[key] || key,
      completed: section.credits_completed || 0,
      needed: section.credits_needed || 0,
      remaining: (section.credits_needed || 0) - (section.credits_completed || 0)
    };
  }) : [];

  // Calculate Performance Metrics
  const avgGPA = gpaData.length > 0 ? 
    (gpaData.reduce((sum, item) => sum + item.gpa, 0) / gpaData.length).toFixed(2) : '0.00';

  const totalCompleted = categoryData.reduce((sum, cat) => sum + cat.completed, 0);
  const totalNeeded = categoryData.reduce((sum, cat) => sum + cat.needed, 0);
  const overallProgress = totalNeeded > 0 ? ((totalCompleted / totalNeeded) * 100).toFixed(1) : '0.0';

  return (
    <div className="space-y-6">
      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">{t('academic.analytics.avg_gpa')}</p>
                <p className="text-2xl font-bold">{avgGPA}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">{t('academic.analytics.overall_progress')}</p>
                <p className="text-2xl font-bold">{overallProgress}%</p>
              </div>
              <Target className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">{t('academic.analytics.credits_earned')}</p>
                <p className="text-2xl font-bold">{totalCompleted}</p>
              </div>
              <Award className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">{t('academic.analytics.courses_passed')}</p>
                <p className="text-2xl font-bold">{Object.values(gradeDistribution).reduce((a, b) => a + b, 0)}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GPA Trend Chart */}
        <Card className="bg-[var(--background)] border-[var(--border-color)]">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              {t('academic.analytics.gpa_trend')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={gpaData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="semester" />
                <YAxis domain={[0, 4]} />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="gpa" 
                  stroke="#8884d8" 
                  strokeWidth={3}
                  dot={{ fill: '#8884d8', strokeWidth: 2, r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Grade Distribution Pie Chart */}
        <Card className="bg-[var(--background)] border-[var(--border-color)]">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
              <PieChartIcon className="w-5 h-5" />
              {t('academic.analytics.grade_distribution')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={gradeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={false} // Disable labels on slices
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {gradeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name, props) => [`${value} (${props.payload.percentage}%)`, props.payload.grade]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Credits by Category Bar Chart */}
      <Card className="bg-[var(--background)] border-[var(--border-color)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            {t('academic.analytics.credits_by_category')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={categoryData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="completed" fill="#82ca9d" name={t('academic.analytics.completed_credits')} />
              <Bar dataKey="remaining" fill="#ffc658" name={t('academic.analytics.remaining_credits')} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Academic Insights */}
      <Card className="bg-[var(--background)] border-[var(--border-color)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)]">Academic Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-blue-50 border-l-4 border-blue-500">
              <h4 className="font-semibold text-blue-800">Performance Trend</h4>
              <p className="text-blue-700">
                {gpaData.length > 1 && gpaData[gpaData.length - 1].gpa > gpaData[0].gpa 
                  ? (language === 'ar' 
                      ? "معدلك التراكمي يظهر اتجاهاً تصاعدياً! استمر في العمل الممتاز." 
                      : "Your GPA is showing an upward trend! Keep up the excellent work.")
                  : (language === 'ar' 
                      ? "فكر في التركيز على تحسين عادات الدراسة لتعزيز معدلك التراكمي." 
                      : "Consider focusing on improving your study habits to boost your GPA.")}
              </p>
            </div>
            
            <div className="p-4 rounded-lg bg-green-50 border-l-4 border-green-500">
              <h4 className="font-semibold text-green-800">Progress Status</h4>
              <p className="text-green-700">
                {language === 'ar' 
                  ? `لقد أكملت ${overallProgress}% من متطلبات درجتك العلمية. ${parseFloat(overallProgress) > 50 ? 'أنت تجاوزت نصف الطريق إلى التخرج!' : 'ابق مركزاً على أهدافك الأكاديمية.'}`
                  : `You have completed ${overallProgress}% of your degree requirements. ${parseFloat(overallProgress) > 50 ? "You're over halfway to graduation!" : "Stay focused on your academic goals."}`
                }
              </p>
            </div>

            <div className="p-4 rounded-lg bg-purple-50 border-l-4 border-purple-500">
              <h4 className="font-semibold text-purple-800">Strongest Areas</h4>
              <p className="text-purple-700">
                {language === 'ar' 
                  ? `أفضل أداء لك في المقررات التي حصلت فيها على درجة '${gradeData[0]?.grade || 'A'}'. فكر في الاستفادة من هذه القوة في اختيار المقررات المستقبلية.`
                  : `Your best performance is in courses where you achieved grade '${gradeData[0]?.grade || 'A'}'. Consider leveraging these strengths in future course selections.`
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
