import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useI18n } from '../utils/i18n';

// ReactCrop implementation
function ReactCrop({ 
  crop, 
  onChange, 
  onComplete, 
  aspect = 1, 
  circularCrop = false, 
  className = '',
  children 
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);

  const handleMouseDown = useCallback((e, type = 'move') => {
    e.preventDefault();
    setIsDragging(type === 'move');
    setIsResizing(type === 'resize');
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      setDragStart({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  }, []);

  const handleMouseMove = useCallback((e) => {
    if (!isDragging && !isResizing || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    if (isDragging) {
      const newX = Math.max(0, Math.min(100 - crop.width, x - crop.width / 2));
      const newY = Math.max(0, Math.min(100 - crop.height, y - crop.height / 2));
      
      const newCrop = { ...crop, x: newX, y: newY };
      onChange(null, newCrop);
      onComplete && onComplete(newCrop);
    } else if (isResizing) {
      const newWidth = Math.max(10, Math.min(100 - crop.x, x - crop.x));
      let newHeight = newWidth / aspect;
      
      if (crop.y + newHeight > 100) {
        newHeight = 100 - crop.y;
      }
      
      const newCrop = { ...crop, width: newWidth, height: newHeight };
      onChange(null, newCrop);
      onComplete && onComplete(newCrop);
    }
  }, [isDragging, isResizing, crop, aspect, onChange, onComplete]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsResizing(false);
  }, []);

  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);

  return (
    <div ref={containerRef} className={`relative inline-block ${className}`}>
      {children}
      {crop && (
        <>
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-black bg-opacity-50 pointer-events-none" />
          
          {/* Crop area */}
          <div
            className={`absolute border-2 border-white cursor-move ${
              circularCrop ? 'rounded-full overflow-hidden' : ''
            }`}
            style={{
              left: `${crop.x}%`,
              top: `${crop.y}%`,
              width: `${crop.width}%`,
              height: `${crop.height}%`,
              backgroundColor: 'transparent',
              boxShadow: circularCrop 
                ? '0 0 0 2px white, 0 0 0 9999px rgba(0, 0, 0, 0.5)'
                : '0 0 0 2px white, 0 0 0 9999px rgba(0, 0, 0, 0.5)'
            }}
            onMouseDown={(e) => handleMouseDown(e, 'move')}
          >
            {/* Grid lines for non-circular crops */}
            {!circularCrop && (
              <div className="absolute inset-0 pointer-events-none">
                <svg className="w-full h-full">
                  <line x1="33.33%" y1="0" x2="33.33%" y2="100%" stroke="rgba(255,255,255,0.5)" strokeWidth="1" />
                  <line x1="66.66%" y1="0" x2="66.66%" y2="100%" stroke="rgba(255,255,255,0.5)" strokeWidth="1" />
                  <line x1="0" y1="33.33%" x2="100%" y2="33.33%" stroke="rgba(255,255,255,0.5)" strokeWidth="1" />
                  <line x1="0" y1="66.66%" x2="100%" y2="66.66%" stroke="rgba(255,255,255,0.5)" strokeWidth="1" />
                </svg>
              </div>
            )}
            
            {/* Resize handle */}
            <div
              className="absolute bottom-0 right-0 w-3 h-3 bg-white border border-gray-300 cursor-se-resize"
              onMouseDown={(e) => handleMouseDown(e, 'resize')}
            />
          </div>
        </>
      )}
    </div>
  );
}

// Helper functions
function centerCrop(crop, width, height) {
  return {
    ...crop,
    x: (100 - crop.width) / 2,
    y: (100 - crop.height) / 2
  };
}

function makeAspectCrop(crop, aspect, width, height) {
  const completeCrop = { ...crop };
  
  if (width && height && completeCrop.width && completeCrop.height) {
    const cropAspect = completeCrop.width / completeCrop.height;
    
    if (cropAspect > aspect) {
      completeCrop.width = completeCrop.height * aspect;
    } else if (cropAspect < aspect) {
      completeCrop.height = completeCrop.width / aspect;
    }
  }
  
  return completeCrop;
}

// Image cropping dialog component
function ImageCropDialog({ 
  isOpen, 
  onClose, 
  onSave, 
  imageFile, 
  cropType 
}) {
  const [crop, setCrop] = useState();
  const [completedCrop, setCompletedCrop] = useState();
  const [imageUrl, setImageUrl] = useState('');
  const imgRef = useRef(null);
  const { t, language } = useI18n();

  // Set default crop based on type
  const defaultCrop = cropType === 'profile' 
    ? { unit: '%', width: 100, height: 100, x: 0, y: 0 }
    : { unit: '%', width: 100, height: 25, x: 0, y: 37.5 };

  useEffect(() => {
    if (imageFile) {
      const url = URL.createObjectURL(imageFile);
      setImageUrl(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [imageFile]);

  const onImageLoad = useCallback((e) => {
    const { naturalWidth: width, naturalHeight: height } = e.currentTarget;
    
    let aspectRatio = 1;
    if (cropType === 'banner') {
      aspectRatio = 4; // 4:1 for banner - better matches actual display
    }
    
    const crop = centerCrop(
      makeAspectCrop(defaultCrop, aspectRatio, width, height),
      width,
      height
    );
    
    setCrop(crop);
    setCompletedCrop(crop);
  }, [cropType, defaultCrop]);

  const getCroppedImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current || !imageFile) return null;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const image = imgRef.current;
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;

    canvas.width = completedCrop.width * scaleX;
    canvas.height = completedCrop.height * scaleY;

    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(
      image,
      completedCrop.x * scaleX,
      completedCrop.y * scaleY,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY,
      0,
      0,
      canvas.width,
      canvas.height
    );

    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          resolve(null);
          return;
        }
        const file = new File([blob], imageFile.name, {
          type: imageFile.type,
          lastModified: Date.now(),
        });
        resolve(file);
      }, imageFile.type, 1.0); // استخدام جودة 100%
    });
  }, [completedCrop, imageFile]);

  const handleSave = async () => {
    const croppedFile = await getCroppedImage();
    if (croppedFile) {
      onSave(croppedFile);
    }
    onClose();
  };

  if (!isOpen || !imageFile) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-[var(--background)] rounded-2xl p-6 max-w-4xl mx-4 shadow-xl max-h-[90vh] overflow-auto border border-[var(--border-color)]" 
          onClick={(e) => e.stopPropagation()}
        >
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">
            {cropType === 'profile' 
              ? (language === 'ar' ? 'قص صورة الملف الشخصي' : 'Crop Profile Image')
              : (language === 'ar' ? 'قص صورة الغلاف' : 'Crop Banner Image')
            }
          </h3>
          
          <div className="mb-4">
            <ReactCrop
              crop={crop}
              onChange={(_, percentCrop) => setCrop(percentCrop)}
              onComplete={(c) => setCompletedCrop(c)}
              aspect={cropType === 'profile' ? 1 : 4}
              circularCrop={cropType === 'profile'}
              className="max-w-full max-h-96"
            >
              <img
                ref={imgRef}
                src={imageUrl}
                alt="Crop preview"
                onLoad={onImageLoad}
                className="max-w-full max-h-96"
                draggable={false}
              />
            </ReactCrop>
          </div>

          <div className={`flex gap-4 ${language === 'ar' ? 'flex-row-reverse' : ''}`}>
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-[var(--border-color)] text-[var(--text-secondary)] rounded-lg hover:bg-[var(--background-secondary)] transition-colors"
            >
              {t('common.cancel')}
            </button>
            <button
              onClick={handleSave}
              className="flex-1 px-4 py-2 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-lg hover:opacity-90 transition-colors"
            >
              {language === 'ar' ? 'حفظ ورفع' : 'Save and Upload'}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

export default ImageCropDialog;
