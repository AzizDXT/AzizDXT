import React, { useState, useEffect, useRef } from 'react';
import { loadImageWithCache } from '../utils/api';
import { User, Loader2 } from 'lucide-react';

export default function CachedImage({ 
  src, 
  alt, 
  className = '', 
  type = 'image',
  fallback = null,
  onLoad = null,
  onError = null,
  ...props 
}) {
  const [imageSrc, setImageSrc] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const retryTimeoutRef = useRef(null);
  const maxRetries = 3;

  const clearRetryTimeout = () => {
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = null;
    }
  };

  const retryLoadImage = (imageUrl, isExternal = false) => {
    if (retryCount >= maxRetries) {
      console.error(`Max retries (${maxRetries}) reached for image:`, imageUrl);
      setHasError(true);
      setIsLoading(false);
      onError && onError(new Error(`Max retries reached for image: ${imageUrl}`));
      return;
    }

    const delay = retryCount === 0 ? 0 : 4000; // 0ms for first retry, 4s for subsequent
    
    retryTimeoutRef.current = setTimeout(() => {
      console.log(`Retrying image load (attempt ${retryCount + 1}/${maxRetries}):`, imageUrl);
      setRetryCount(prev => prev + 1);
      
      if (isExternal) {
        // For external images, try to load directly
        const img = new Image();
        img.onload = () => {
          console.log('External image loaded successfully on retry:', imageUrl);
          setImageSrc(imageUrl);
          setHasError(false);
          setIsLoading(false);
          onLoad && onLoad();
        };
        img.onerror = () => {
          console.error(`External image failed to load on retry ${retryCount + 1}:`, imageUrl);
          retryLoadImage(imageUrl, true);
        };
        img.src = imageUrl;
      } else {
        // For local images, retry with cache system
        loadImageWithCache(src, type)
          .then(cachedSrc => {
            if (cachedSrc) {
              setImageSrc(cachedSrc);
              setHasError(false);
              setIsLoading(false);
              onLoad && onLoad();
            } else {
              retryLoadImage(imageUrl, false);
            }
          })
          .catch(error => {
            console.error(`Error loading cached image on retry ${retryCount + 1}:`, error);
            retryLoadImage(imageUrl, false);
          });
      }
    }, delay);
  };

  useEffect(() => {
    if (!src) {
      setIsLoading(false);
      setHasError(true);
      return;
    }

    setIsLoading(true);
    setHasError(false);
    setRetryCount(0);
    clearRetryTimeout();
    
    // Check if it's an external URL (like Google OAuth) or starts with http
    if (src.startsWith('http') && !src.includes('taleb.run')) {
      // External URL - load directly
      console.log('Loading external image:', src);
      const img = new Image();
      img.onload = () => {
        console.log('External image loaded successfully:', src);
        setImageSrc(src);
        setHasError(false);
        setIsLoading(false);
        onLoad && onLoad();
      };
      img.onerror = () => {
        console.error('External image failed to load:', src);
        retryLoadImage(src, true);
      };
      img.src = src;
      return;
    }
    
    // Check if it's a Google OAuth URL (even if truncated)
    if (src.includes('googleusercontent.com') || src.includes('lh3.googleusercontent.com')) {
      // Google OAuth URL - try to reconstruct if truncated
      let fullUrl = src;
      if (!src.startsWith('http')) {
        fullUrl = `https://${src}`;
      }
      console.log('Loading Google OAuth image:', fullUrl);
      const img = new Image();
      img.onload = () => {
        console.log('Google OAuth image loaded successfully:', fullUrl);
        setImageSrc(fullUrl);
        setHasError(false);
        setIsLoading(false);
        onLoad && onLoad();
      };
      img.onerror = () => {
        console.error('Google OAuth image failed to load:', fullUrl);
        retryLoadImage(fullUrl, true);
      };
      img.src = fullUrl;
      return;
    }
    
    // Local URL - use cache system
    loadImageWithCache(src, type)
      .then(cachedSrc => {
        if (cachedSrc) {
          setImageSrc(cachedSrc);
          setHasError(false);
          setIsLoading(false);
          onLoad && onLoad();
        } else {
          retryLoadImage(src, false);
        }
      })
      .catch(error => {
        console.error('Error loading cached image:', error);
        retryLoadImage(src, false);
      });
  }, [src, type, onLoad, onError]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      clearRetryTimeout();
    };
  }, []);

  if (isLoading) {
    return (
      <div className={`${className} bg-gray-200 dark:bg-gray-700 animate-pulse rounded flex items-center justify-center`}>
        <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
        {retryCount > 0 && (
          <div className="absolute bottom-1 text-xs text-gray-500">
            Retry {retryCount}/{maxRetries}
          </div>
        )}
      </div>
    );
  }

  if (hasError || !imageSrc) {
    // For external URLs, try to show the image directly as fallback
    if (src && (src.startsWith('http') || src.includes('googleusercontent.com'))) {
      let fallbackUrl = src;
      if (src.includes('googleusercontent.com') && !src.startsWith('http')) {
        fallbackUrl = `https://${src}`;
      }
      
      return (
        <img
          src={fallbackUrl}
          alt={alt}
          className={className}
          onError={() => {
            console.error('External image failed to load:', fallbackUrl);
            setHasError(true);
            onError && onError(new Error('External image failed to load'));
          }}
          onLoad={() => {
            console.log('External image loaded successfully:', fallbackUrl);
            onLoad && onLoad();
          }}
          {...props}
        />
      );
    }
    
    return fallback || (
      <div className={`${className} bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center`}>
        <User className="w-8 h-8 text-gray-400" />
      </div>
    );
  }

  return (
    <img
      src={imageSrc}
      alt={alt}
      className={className}
      onError={() => {
        console.error('Image failed to load:', imageSrc);
        setHasError(true);
        onError && onError(new Error('Image failed to load'));
      }}
      onLoad={() => {
        console.log('Image loaded successfully:', imageSrc);
        onLoad && onLoad();
      }}
      {...props}
    />
  );
}
