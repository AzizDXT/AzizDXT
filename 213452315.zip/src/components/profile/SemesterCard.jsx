
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, TrendingUp, BookOpen } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useI18n } from '../utils/i18n';

const getGradeColor = (grade) => {
    if (!grade) return 'text-[var(--text-secondary)]';
    if (['A+', 'A'].includes(grade)) return 'text-green-600 font-bold bg-green-100 dark:bg-green-900';
    if (['A-', 'B+', 'B'].includes(grade)) return 'text-blue-600 font-semibold bg-blue-100 dark:bg-blue-900';
    if (['B-', 'C+', 'C'].includes(grade)) return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900';
    if (['C-', 'D+', 'D'].includes(grade)) return 'text-orange-600 bg-orange-100 dark:bg-orange-900';
    if (['F'].includes(grade)) return 'text-red-600 font-bold bg-red-100 dark:bg-red-900';
    return 'text-[var(--text-primary)]';
};

export default function SemesterCard({ record }) {
    const { t } = useI18n();
    if (!record) return null;

    const isCompleted = record.status === 'Completed';
    const gpaColor = record.semester_gpa >= 3.5 ? 'text-green-600' : 
                    record.semester_gpa >= 3.0 ? 'text-blue-600' :
                    record.semester_gpa >= 2.5 ? 'text-yellow-600' : 'text-red-600';

    return (
        <Card className="bg-[var(--background)] border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-[var(--text-primary)] text-xl flex items-center gap-2">
                            <BookOpen className="w-5 h-5" />
                            {record.semester}
                        </CardTitle>
                        <div className="flex items-center gap-4 mt-2">
                            {isCompleted ? (
                                <div className="flex items-center gap-2 text-green-600">
                                    <CheckCircle size={16} />
                                    <span className="text-sm font-medium">{t('tasks.filters.completed')}</span>
                                </div>
                            ) : (
                                <div className="flex items-center gap-2 text-blue-600">
                                    <Clock size={16} />
                                    <span className="text-sm font-medium">{t('tasks.filters.in_progress')}</span>
                                </div>
                            )}
                        </div>
                    </div>
                    
                    <div className="text-right space-y-2">
                        <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-[var(--text-secondary)]" />
                            <span className={`text-2xl font-bold ${gpaColor}`}>
                                {record.semester_gpa.toFixed(2)}
                            </span>
                        </div>
                        <div className="text-sm text-[var(--text-secondary)]">
                            {record.total_credits} {t('academic.credits')} • {record.total_points} {t('academic.table.points')}
                        </div>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>{t('academic.table.code')}</TableHead>
                                <TableHead className="hidden md:table-cell">{t('academic.table.name')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.credits')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.grade')}</TableHead>
                                <TableHead className="text-center">{t('academic.table.points')}</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {record.courses?.map((course, index) => (
                                <TableRow key={index} className="hover:bg-[var(--background-secondary)]">
                                    <TableCell className="font-medium text-[var(--text-primary)]">
                                        {course.course_code}
                                    </TableCell>
                                    <TableCell className="hidden md:table-cell text-[var(--text-secondary)] max-w-xs">
                                        <div className="truncate" title={course.course_name}>
                                            {course.course_name}
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-center font-medium text-[var(--text-primary)]">
                                        {course.credits}
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Badge className={`${getGradeColor(course.grade)} px-2 py-1`}>
                                            {course.grade}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-center text-[var(--text-primary)] font-medium">
                                        {course.gpa_points}
                                    </TableCell>
                                </TableRow>
                            )) || (
                                <TableRow>
                                    <TableCell colSpan={5} className="text-center text-[var(--text-secondary)]">
                                        {t('academic.course_table.no_courses')}
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
}
