import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { X, Loader2 } from 'lucide-react';
import { useI18n } from '../utils/i18n';
import CountrySelector from '../ui/CountrySelector';


export default function EditProfileModal({ isOpen, onClose, profile, onSave }) {
  const { t, isRTL, language } = useI18n();
  const [formData, setFormData] = useState({ 
    name: '', 
    bio: '', 
    username: '', 
    country: '' 
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        bio: profile.bio || '',
        username: profile.username || '',
        country: profile.country || '',
      });
    }
  }, [profile, isOpen]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSave(formData);
      onClose();
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setIsSaving(false);
    }
  };


  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="relative rounded-3xl p-6 w-full max-w-lg shadow-xl bg-[var(--background)] border border-[var(--border-color)]"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-[var(--text-primary)]">{t('profile.editProfile')}</h3>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--background-secondary)]">
              <X className="w-5 h-5 text-[var(--text-secondary)]" />
            </button>
          </div>
          
          <div className="space-y-6">
            <div>
              <Label htmlFor="name" className="text-[var(--text-secondary)] mb-2 block">{t('auth.name')}</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="h-12 text-base rounded-2xl"
                placeholder={t('auth.namePlaceholder')}
              />
            </div>
            
            <div>
              <Label htmlFor="username" className="text-[var(--text-secondary)] mb-2 block">{t('auth.username')}</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="h-12 text-base rounded-2xl"
                placeholder={t('auth.usernamePlaceholder')}
              />
            </div>
            
            <div>
              <Label htmlFor="bio" className="text-[var(--text-secondary)] mb-2 block">{t('profile.bio')}</Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="h-32 text-base rounded-2xl"
                maxLength={500}
                placeholder={language === 'ar' ? 'اكتب نبذة عنك...' : 'Write something about yourself...'}
              />
              <p className="text-xs text-[var(--text-muted)] mt-2 text-right">
                {formData.bio?.length || 0} / 500
              </p>
            </div>
            
            <CountrySelector
              value={formData.country}
              onChange={(value) => setFormData({ ...formData, country: value })}
              placeholder={t('auth.countryPlaceholder')}
              label={t('auth.country')}
              isRTL={isRTL}
            />
          </div>
          
          <div className={`flex gap-4 mt-8 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Button onClick={onClose} variant="outline" className="flex-1 h-12 rounded-2xl" disabled={isSaving}>
              {t('common.cancel')}
            </Button>
            <Button onClick={handleSave} className="flex-1 h-12 bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90 rounded-2xl" disabled={isSaving}>
              {isSaving ? <Loader2 className="animate-spin" /> : t('common.save')}
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
