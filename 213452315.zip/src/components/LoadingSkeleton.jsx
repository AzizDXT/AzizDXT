import React from 'react';
import { motion } from 'framer-motion';

// Skeleton for stats cards
export const StatsSkeleton = () => (
  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
    {[1, 2, 3, 4].map((i) => (
      <motion.div
        key={i}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 * i }}
        className="bg-[var(--background)] rounded-xl p-6 shadow-sm border border-[var(--border-color)]"
      >
        <div className="animate-pulse">
          <div className="flex items-center justify-between mb-4">
            <div className="w-8 h-8 bg-[var(--background-secondary)] rounded-lg"></div>
            <div className="w-20 h-6 bg-[var(--background-secondary)] rounded"></div>
          </div>
          <div className="space-y-2">
            <div className="h-4 bg-[var(--background-secondary)] rounded w-3/4"></div>
            <div className="h-2 bg-[var(--background-secondary)] rounded"></div>
            <div className="h-3 bg-[var(--background-secondary)] rounded w-1/2"></div>
          </div>
        </div>
      </motion.div>
    ))}
  </div>
);

// Skeleton for stories section
export const StoriesSkeleton = () => (
  <div className="bg-[var(--background)] rounded-xl p-6 shadow-sm border border-[var(--border-color)]">
    <div className="animate-pulse">
      <div className="h-6 bg-[var(--background-secondary)] rounded w-32 mb-4"></div>
      <div className="flex gap-4 overflow-x-auto pb-2">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="flex-shrink-0 text-center">
            <div className="w-16 h-16 bg-[var(--background-secondary)] rounded-full mb-2"></div>
            <div className="h-3 bg-[var(--background-secondary)] rounded w-12"></div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// Skeleton for daily challenges
export const ChallengesSkeleton = () => (
  <div className="space-y-4">
    <div className="animate-pulse">
      <div className="h-8 bg-[var(--background-secondary)] rounded w-48 mb-4"></div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="bg-[var(--background)] rounded-xl p-4 shadow-sm border border-[var(--border-color)]">
            <div className="animate-pulse">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 bg-[var(--background-secondary)] rounded-lg"></div>
                <div className="w-16 h-6 bg-[var(--background-secondary)] rounded"></div>
              </div>
              <div className="h-4 bg-[var(--background-secondary)] rounded mb-2"></div>
              <div className="h-3 bg-[var(--background-secondary)] rounded w-2/3"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// Skeleton for posts
export const PostsSkeleton = () => (
  <div className="space-y-4">
    <div className="animate-pulse">
      <div className="h-8 bg-[var(--background-secondary)] rounded w-40 mb-4"></div>
      <div className="bg-[var(--background)] rounded-xl p-6 shadow-sm border border-[var(--border-color)]">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-[var(--background-secondary)] rounded-full"></div>
          <div className="flex-1">
            <div className="h-4 bg-[var(--background-secondary)] rounded w-32 mb-2"></div>
            <div className="h-3 bg-[var(--background-secondary)] rounded w-24"></div>
          </div>
        </div>
        <div className="space-y-3">
          <div className="h-4 bg-[var(--background-secondary)] rounded"></div>
          <div className="h-4 bg-[var(--background-secondary)] rounded w-5/6"></div>
          <div className="h-4 bg-[var(--background-secondary)] rounded w-4/6"></div>
        </div>
        <div className="h-64 bg-[var(--background-secondary)] rounded-lg mt-4"></div>
        <div className="flex items-center gap-6 mt-4">
          <div className="h-4 bg-[var(--background-secondary)] rounded w-12"></div>
          <div className="h-4 bg-[var(--background-secondary)] rounded w-12"></div>
          <div className="h-4 bg-[var(--background-secondary)] rounded w-12"></div>
        </div>
      </div>
    </div>
  </div>
);

// Coming Soon component with blur effect
export const ComingSoon = ({ title, description, icon: Icon }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="relative bg-[var(--background)] rounded-xl p-6 shadow-sm border border-[var(--border-color)] overflow-hidden"
  >
    {/* Blur overlay */}
    <div className="absolute inset-0 bg-gradient-to-br from-[var(--background)]/80 to-[var(--background-secondary)]/80 backdrop-blur-sm z-10"></div>
    
    {/* Content */}
    <div className="relative z-20 text-center">
      <div className="w-16 h-16 bg-[var(--accent-color)] rounded-full flex items-center justify-center mx-auto mb-4">
        {Icon && <Icon className="w-8 h-8 text-[var(--accent-text-color)]" />}
      </div>
      <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">{title}</h3>
      <p className="text-[var(--text-secondary)] mb-4">{description}</p>
      <div className="inline-flex items-center px-4 py-2 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-full text-sm font-medium">
        <span className="animate-pulse mr-2">✨</span>
        Coming Soon
      </div>
    </div>
  </motion.div>
);

// Coming Soon in Arabic
export const ComingSoonAR = ({ title, description, icon: Icon }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="relative bg-[var(--background)] rounded-xl p-6 shadow-sm border border-[var(--border-color)] overflow-hidden"
  >
    {/* Blur overlay */}
    <div className="absolute inset-0 bg-gradient-to-br from-[var(--background)]/80 to-[var(--background-secondary)]/80 backdrop-blur-sm z-10"></div>
    
    {/* Content */}
    <div className="relative z-20 text-center">
      <div className="w-16 h-16 bg-[var(--accent-color)] rounded-full flex items-center justify-center mx-auto mb-4">
        {Icon && <Icon className="w-8 h-8 text-[var(--accent-text-color)]" />}
      </div>
      <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">{title}</h3>
      <p className="text-[var(--text-secondary)] mb-4">{description}</p>
      <div className="inline-flex items-center px-4 py-2 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-full text-sm font-medium">
        <span className="animate-pulse ml-2">✨</span>
        قريباً
      </div>
    </div>
  </motion.div>
);
