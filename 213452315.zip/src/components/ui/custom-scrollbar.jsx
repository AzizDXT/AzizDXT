import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const CustomScrollbar = ({ 
  children, 
  className = '', 
  maxHeight = 'auto',
  showScrollbar = 'hover', // 'always', 'hover', 'never'
  scrollbarWidth = 6,
  trackColor = 'transparent',
  thumbColor = 'var(--text-secondary)',
  thumbHoverColor = 'var(--text-primary)',
  borderRadius = 3,
  fallbackToNative = true, // New prop to enable native scrollbar fallback
  ...props 
}) => {
  const containerRef = useRef(null);
  const contentRef = useRef(null);
  const scrollbarRef = useRef(null);
  const thumbRef = useRef(null);
  
  const [isScrollable, setIsScrollable] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [thumbHeight, setThumbHeight] = useState(0);
  const [thumbTop, setThumbTop] = useState(0);
  const [showThumb, setShowThumb] = useState(false);
  const [useNativeScrollbar, setUseNativeScrollbar] = useState(false);

  const updateScrollbar = useCallback(() => {
    if (!containerRef.current || !contentRef.current) return;

    const container = containerRef.current;
    const content = contentRef.current;
    
    const containerHeight = container.clientHeight;
    const contentHeight = content.scrollHeight;
    const scrollTop = container.scrollTop;
    
    const scrollable = contentHeight > containerHeight;
    setIsScrollable(scrollable);
    
    if (scrollable) {
      const thumbHeightRatio = containerHeight / contentHeight;
      const newThumbHeight = Math.max(thumbHeightRatio * containerHeight, 20);
      const maxThumbTop = containerHeight - newThumbHeight;
      const scrollRatio = scrollTop / (contentHeight - containerHeight);
      const newThumbTop = scrollRatio * maxThumbTop;
      
      setThumbHeight(newThumbHeight);
      setThumbTop(newThumbTop);
      
      // Show/hide scrollbar based on showScrollbar prop
      if (showScrollbar === 'always') {
        setShowThumb(true);
      } else if (showScrollbar === 'hover') {
        setShowThumb(isHovering || isDragging);
      } else {
        setShowThumb(false);
      }
    } else {
      setShowThumb(false);
    }
  }, [isHovering, isDragging, showScrollbar]);

  const handleScroll = useCallback(() => {
    updateScrollbar();
  }, [updateScrollbar]);

  const handleMouseDown = useCallback((e) => {
    if (!containerRef.current) return;
    
    e.preventDefault();
    setIsDragging(true);
    
    const container = containerRef.current;
    const containerRect = container.getBoundingClientRect();
    const startY = e.clientY;
    const startScrollTop = container.scrollTop;
    const containerHeight = container.clientHeight;
    const contentHeight = container.scrollHeight;
    
    const handleMouseMove = (e) => {
      const deltaY = e.clientY - startY;
      const scrollRatio = deltaY / (containerHeight - thumbHeight);
      const newScrollTop = startScrollTop + scrollRatio * (contentHeight - containerHeight);
      
      container.scrollTop = Math.max(0, Math.min(newScrollTop, contentHeight - containerHeight));
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [thumbHeight]);

  const handleTrackClick = useCallback((e) => {
    if (!containerRef.current || !scrollbarRef.current) return;
    
    const container = containerRef.current;
    const scrollbar = scrollbarRef.current;
    const scrollbarRect = scrollbar.getBoundingClientRect();
    const clickY = e.clientY - scrollbarRect.top;
    
    const containerHeight = container.clientHeight;
    const contentHeight = container.scrollHeight;
    const scrollRatio = (clickY - thumbHeight / 2) / (containerHeight - thumbHeight);
    const newScrollTop = scrollRatio * (contentHeight - containerHeight);
    
    container.scrollTop = Math.max(0, Math.min(newScrollTop, contentHeight - containerHeight));
  }, [thumbHeight]);

  // Check if custom scrollbar is working properly
  useEffect(() => {
    const checkScrollbarFunctionality = () => {
      if (!containerRef.current || !fallbackToNative) return;
      
      const container = containerRef.current;
      const hasOverflow = container.scrollHeight > container.clientHeight;
      
      // If content overflows but custom scrollbar isn't showing, use native
      if (hasOverflow && !showThumb && showScrollbar !== 'never') {
        setUseNativeScrollbar(true);
      } else {
        setUseNativeScrollbar(false);
      }
    };

    const timeoutId = setTimeout(checkScrollbarFunctionality, 100);
    return () => clearTimeout(timeoutId);
  }, [showThumb, showScrollbar, fallbackToNative, isScrollable]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const resizeObserver = new ResizeObserver(updateScrollbar);
    resizeObserver.observe(container);
    
    container.addEventListener('scroll', handleScroll, { passive: true });
    
    // Initial update
    updateScrollbar();
    
    return () => {
      resizeObserver.disconnect();
      container.removeEventListener('scroll', handleScroll);
    };
  }, [handleScroll, updateScrollbar]);

  useEffect(() => {
    updateScrollbar();
  }, [children, updateScrollbar]);

  return (
    <div 
      className={`relative ${className}`}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      {...props}
    >
      {/* Content Container */}
      <div
        ref={containerRef}
        className={useNativeScrollbar ? "overflow-auto" : "overflow-auto scrollbar-hide"}
        style={{ 
          maxHeight,
          paddingRight: (isScrollable && showScrollbar !== 'never' && !useNativeScrollbar) ? scrollbarWidth + 4 : 0
        }}
      >
        <div ref={contentRef}>
          {children}
        </div>
      </div>
      
      {/* Custom Scrollbar - only show if not using native */}
      <AnimatePresence>
        {isScrollable && showThumb && !useNativeScrollbar && (
          <motion.div
            ref={scrollbarRef}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute top-0 right-0 h-full cursor-pointer z-10"
            style={{ width: scrollbarWidth + 4 }}
            onClick={handleTrackClick}
          >
            {/* Track */}
            <div
              className="w-full h-full flex justify-center"
              style={{ backgroundColor: trackColor }}
            >
              {/* Thumb */}
              <motion.div
                ref={thumbRef}
                className="cursor-grab active:cursor-grabbing transition-colors duration-200"
                style={{
                  width: scrollbarWidth,
                  height: thumbHeight,
                  backgroundColor: isDragging || isHovering ? thumbHoverColor : thumbColor,
                  borderRadius: borderRadius,
                  transform: `translateY(${thumbTop}px)`,
                }}
                onMouseDown={handleMouseDown}
                whileHover={{ 
                  backgroundColor: thumbHoverColor,
                  scale: 1.1 
                }}
                whileTap={{ scale: 0.95 }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CustomScrollbar; 