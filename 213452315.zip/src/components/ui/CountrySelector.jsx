import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Search, Globe } from 'lucide-react';
import { useI18n } from '../utils/i18n';
import { countries, searchCountries, getCountryName } from '../../utils/countries';

export default function CountrySelector({ 
  value, 
  onChange, 
  placeholder, 
  label, 
  disabled = false, 
  className = "",
  isRTL = false 
}) {
  const { language } = useI18n();
  const [showDropdown, setShowDropdown] = useState(false);
  const [search, setSearch] = useState('');

  const filteredCountries = searchCountries(search, language);

  const handleCountrySelect = (country) => {
    const countryName = getCountryName(country, language);
    onChange(countryName);
    setShowDropdown(false);
    setSearch('');
  };

  const handleInputChange = (e) => {
    const inputValue = e.target.value;
    onChange(inputValue);
    setSearch(inputValue);
    setShowDropdown(true);
  };

  const handleInputFocus = () => {
    setShowDropdown(true);
  };

  return (
    <div className={`relative ${className}`}>
      {label && (
        <Label htmlFor="country" className="text-[var(--text-primary)] mb-2 block">
          {label}
        </Label>
      )}
      
      <div className="relative">
        <Input
          id="country"
          value={value}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          className={`h-12 rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element ${isRTL ? 'pr-12' : 'pl-12'}`}
          placeholder={placeholder}
          disabled={disabled}
          autoComplete="country"
        />
        <Globe className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 transform -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]`} />
      </div>
      
      {showDropdown && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="absolute top-full left-0 right-0 mt-2 bg-[var(--background)] border border-[var(--border-color)] rounded-2xl shadow-2xl z-50 max-h-60 overflow-hidden"
        >
          <div className="p-3 border-b border-[var(--border-color)]">
            <div className="relative">
              <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 w-4 h-4 text-[var(--text-secondary)]`} />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={language === 'ar' ? 'ابحث عن الدولة...' : 'Search country...'}
                className={`h-10 rounded-xl ${isRTL ? 'pr-10' : 'pl-10'}`}
                autoFocus
              />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filteredCountries.map((country) => (
              <button
                key={country.code}
                onClick={() => handleCountrySelect(country)}
                className="w-full px-4 py-3 text-left hover:bg-[var(--background-secondary)] flex items-center gap-3 transition-colors"
              >
                <span className="text-xl">{country.flag}</span>
                <div className="flex-1">
                  <div className="font-medium text-[var(--text-primary)]">
                    {getCountryName(country, language)}
                  </div>
                  <div className="text-sm text-[var(--text-secondary)]">
                    {country.phone} • {country.code}
                  </div>
                </div>
              </button>
            ))}
            {filteredCountries.length === 0 && (
              <div className="p-4 text-center text-[var(--text-secondary)]">
                {language === 'ar' ? 'لم يتم العثور على دول' : 'No countries found'}
              </div>
            )}
          </div>
        </motion.div>
      )}
      
      {/* Backdrop to close dropdown */}
      {showDropdown && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setShowDropdown(false)}
        />
      )}
    </div>
  );
}
