import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bug, 
  X, 
  RefreshCw, 
  Database, 
  Wifi, 
  WifiOff,
  AlertTriangle,
  CheckCircle,
  Info,
  Copy,
  Download,
  Trash2,
  Eye,
  EyeOff
} from 'lucide-react';
import { useI18n } from '../utils/i18n';

export default function DebugCenter({ isOpen, onClose }) {
  const { t, isRTL } = useI18n();
  const [activeTab, setActiveTab] = useState('general');
  const [debugInfo, setDebugInfo] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [logs, setLogs] = useState([]);

  // Mock debug information
  const mockDebugInfo = {
    general: {
      appVersion: '1.0.0',
      buildDate: new Date().toISOString(),
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      cookieEnabled: navigator.cookieEnabled,
      onLine: navigator.onLine,
      memory: performance.memory ? {
        used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024),
        total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024),
        limit: Math.round(performance.memory.jsHeapSizeLimit / 1024 / 1024)
      } : null
    },
    api: {
      baseUrl: 'https://api.taleb.com',
      endpoints: [
        { name: 'Auth', status: 'online', responseTime: '120ms' },
        { name: 'Users', status: 'online', responseTime: '85ms' },
        { name: 'Communities', status: 'online', responseTime: '95ms' },
        { name: 'Notifications', status: 'online', responseTime: '110ms' },
        { name: 'Firebase', status: 'online', responseTime: '200ms' }
      ],
      lastError: null,
      totalRequests: 1247,
      successRate: '99.2%'
    },
    storage: {
      localStorage: {
        items: Object.keys(localStorage).length,
        size: new Blob(Object.values(localStorage)).size,
        keys: Object.keys(localStorage).slice(0, 10)
      },
      sessionStorage: {
        items: Object.keys(sessionStorage).length,
        size: new Blob(Object.values(sessionStorage)).size,
        keys: Object.keys(sessionStorage).slice(0, 10)
      },
      indexedDB: {
        available: 'indexedDB' in window,
        databases: []
      }
    },
    performance: {
      loadTime: performance.timing ? performance.timing.loadEventEnd - performance.timing.navigationStart : 0,
      domContentLoaded: performance.timing ? performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart : 0,
      firstPaint: performance.getEntriesByType('paint').find(entry => entry.name === 'first-paint')?.startTime || 0,
      firstContentfulPaint: performance.getEntriesByType('paint').find(entry => entry.name === 'first-contentful-paint')?.startTime || 0,
      resources: performance.getEntriesByType('resource').length
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadDebugInfo();
    }
  }, [isOpen]);

  const loadDebugInfo = async () => {
    setIsLoading(true);
    try {
      // Simulate loading
      await new Promise(resolve => setTimeout(resolve, 500));
      setDebugInfo(mockDebugInfo);
    } catch (error) {
      console.error('Error loading debug info:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearLogs = () => {
    setLogs([]);
  };

  const exportDebugInfo = () => {
    const dataStr = JSON.stringify(debugInfo, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `debug-info-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'offline':
        return <WifiOff className="w-4 h-4 text-red-500" />;
      case 'error':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default:
        return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'offline':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'error':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="bg-[var(--background)] rounded-2xl shadow-2xl border border-[var(--border-color)] w-full max-w-6xl max-h-[90vh] overflow-hidden"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
            <div className="flex items-center gap-3">
              <Bug className="w-8 h-8 text-amber-500" />
              <div>
                <h2 className="text-2xl font-bold text-[var(--text-primary)]">
                  {t('debug.title') || 'Debug Center'}
                </h2>
                <p className="text-[var(--text-secondary)]">
                  {t('debug.description') || 'System diagnostics and debugging information'}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <X className="w-6 h-6" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="general" className="flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  {t('debug.general') || 'General'}
                </TabsTrigger>
                <TabsTrigger value="api" className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  {t('debug.api') || 'API'}
                </TabsTrigger>
                <TabsTrigger value="storage" className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  {t('debug.storage') || 'Storage'}
                </TabsTrigger>
                <TabsTrigger value="performance" className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  {t('debug.performance') || 'Performance'}
                </TabsTrigger>
              </TabsList>

              {/* General Tab */}
              <TabsContent value="general" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Info className="w-5 h-5" />
                      {t('debug.appInfo') || 'Application Information'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.version') || 'Version'}
                        </label>
                        <p className="text-[var(--text-primary)]">{debugInfo.general?.appVersion}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.buildDate') || 'Build Date'}
                        </label>
                        <p className="text-[var(--text-primary)]">
                          {debugInfo.general?.buildDate ? new Date(debugInfo.general.buildDate).toLocaleString() : '-'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.language') || 'Language'}
                        </label>
                        <p className="text-[var(--text-primary)]">{debugInfo.general?.language}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.platform') || 'Platform'}
                        </label>
                        <p className="text-[var(--text-primary)]">{debugInfo.general?.platform}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Wifi className="w-5 h-5" />
                      {t('debug.connection') || 'Connection Status'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      {debugInfo.general?.onLine ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <WifiOff className="w-5 h-5 text-red-500" />
                      )}
                      <span className={debugInfo.general?.onLine ? 'text-green-600' : 'text-red-600'}>
                        {debugInfo.general?.onLine ? t('debug.online') || 'Online' : t('debug.offline') || 'Offline'}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                {debugInfo.general?.memory && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="w-5 h-5" />
                        {t('debug.memory') || 'Memory Usage'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-[var(--text-secondary)]">
                            {t('debug.used') || 'Used'}
                          </span>
                          <span className="text-sm font-medium">
                            {debugInfo.general.memory.used} MB
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-[var(--text-secondary)]">
                            {t('debug.total') || 'Total'}
                          </span>
                          <span className="text-sm font-medium">
                            {debugInfo.general.memory.total} MB
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-[var(--text-secondary)]">
                            {t('debug.limit') || 'Limit'}
                          </span>
                          <span className="text-sm font-medium">
                            {debugInfo.general.memory.limit} MB
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* API Tab */}
              <TabsContent value="api" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Database className="w-5 h-5" />
                      {t('debug.apiStatus') || 'API Status'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {debugInfo.api?.endpoints?.map((endpoint, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-[var(--background-secondary)]">
                          <div className="flex items-center gap-3">
                            {getStatusIcon(endpoint.status)}
                            <span className="font-medium">{endpoint.name}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className={getStatusColor(endpoint.status)}>
                              {endpoint.status}
                            </Badge>
                            <span className="text-sm text-[var(--text-secondary)]">
                              {endpoint.responseTime}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RefreshCw className="w-5 h-5" />
                      {t('debug.apiStats') || 'API Statistics'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-[var(--text-primary)]">
                          {debugInfo.api?.totalRequests || 0}
                        </p>
                        <p className="text-sm text-[var(--text-secondary)]">
                          {t('debug.totalRequests') || 'Total Requests'}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">
                          {debugInfo.api?.successRate || '0%'}
                        </p>
                        <p className="text-sm text-[var(--text-secondary)]">
                          {t('debug.successRate') || 'Success Rate'}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-[var(--text-primary)]">
                          {debugInfo.api?.baseUrl || '-'}
                        </p>
                        <p className="text-sm text-[var(--text-secondary)]">
                          {t('debug.baseUrl') || 'Base URL'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Storage Tab */}
              <TabsContent value="storage" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Database className="w-5 h-5" />
                      {t('debug.localStorage') || 'Local Storage'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-[var(--text-secondary)]">
                          {t('debug.items') || 'Items'}
                        </span>
                        <span className="text-sm font-medium">
                          {debugInfo.storage?.localStorage?.items || 0}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-[var(--text-secondary)]">
                          {t('debug.size') || 'Size'}
                        </span>
                        <span className="text-sm font-medium">
                          {debugInfo.storage?.localStorage?.size ? 
                            `${Math.round(debugInfo.storage.localStorage.size / 1024)} KB` : '0 KB'}
                        </span>
                      </div>
                      <div>
                        <span className="text-sm text-[var(--text-secondary)]">
                          {t('debug.keys') || 'Keys'}
                        </span>
                        <div className="mt-2 space-y-1">
                          {debugInfo.storage?.localStorage?.keys?.map((key, index) => (
                            <div key={index} className="flex items-center justify-between p-2 rounded bg-[var(--background-secondary)]">
                              <span className="text-sm font-mono">{key}</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(localStorage.getItem(key))}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Performance Tab */}
              <TabsContent value="performance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RefreshCw className="w-5 h-5" />
                      {t('debug.performance') || 'Performance Metrics'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.loadTime') || 'Load Time'}
                        </label>
                        <p className="text-[var(--text-primary)]">
                          {debugInfo.performance?.loadTime ? `${debugInfo.performance.loadTime}ms` : '-'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.domContentLoaded') || 'DOM Content Loaded'}
                        </label>
                        <p className="text-[var(--text-primary)]">
                          {debugInfo.performance?.domContentLoaded ? `${debugInfo.performance.domContentLoaded}ms` : '-'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.firstPaint') || 'First Paint'}
                        </label>
                        <p className="text-[var(--text-primary)]">
                          {debugInfo.performance?.firstPaint ? `${Math.round(debugInfo.performance.firstPaint)}ms` : '-'}
                        </p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-[var(--text-secondary)]">
                          {t('debug.resources') || 'Resources'}
                        </label>
                        <p className="text-[var(--text-primary)]">
                          {debugInfo.performance?.resources || 0}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={loadDebugInfo}
                disabled={isLoading}
                className="flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                {t('debug.refresh') || 'Refresh'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportDebugInfo}
                className="flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                {t('debug.export') || 'Export'}
              </Button>
            </div>
            <Button onClick={onClose}>
              {t('common.close') || 'Close'}
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
