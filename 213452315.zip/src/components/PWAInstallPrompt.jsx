import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, Smartphone, Monitor, Share } from 'lucide-react';
import { useI18n } from './utils/i18n';

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const { t, language } = useI18n();

  useEffect(() => {
    // Check if already dismissed
    const isDismissed = localStorage.getItem('taleb-pwa-dismissed') === 'true';
    setDismissed(isDismissed);

    // Check if iOS
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    setIsIOS(iOS);

    // Check if running as standalone
    const standalone = window.matchMedia('(display-mode: standalone)').matches || 
                     window.navigator.standalone || 
                     document.referrer.includes('android-app://');
    setIsStandalone(standalone);

    console.log('PWA Install Prompt initialized:', {
      isDismissed,
      iOS,
      standalone,
      userAgent: navigator.userAgent
    });

    // Listen for beforeinstallprompt event (Android/Chrome)
    const handleBeforeInstallPrompt = (e) => {
      console.log('beforeinstallprompt event received');
      e.preventDefault();
      setDeferredPrompt(e);
    };

    // Listen for app installed event
    const handleAppInstalled = () => {
      setShowPrompt(false);
      setDeferredPrompt(null);
      setIsInstalling(false);
    };

    // Listen for splash screen completion
    const handleSplashComplete = () => {
      console.log('Splash screen completed, showing PWA prompt');
      if (!isDismissed && !standalone) {
        // Show prompt after splash screen completes
        setTimeout(() => {
          console.log('Setting showPrompt to true via splash complete');
          setShowPrompt(true);
        }, 2000); // Show after 2 seconds of splash completion
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('splashScreenComplete', handleSplashComplete);

    // Fallback: Show prompt after a reasonable delay regardless of splash screen
    const fallbackTimer = setTimeout(() => {
      console.log('Fallback timer triggered, showing PWA prompt');
      if (!isDismissed && !standalone) {
        console.log('Setting showPrompt to true via fallback');
        setShowPrompt(true);
      }
    }, 3000); // Show after 3 seconds as fallback (reduced for testing)

    // Show iOS prompt if conditions are met (after splash screen)
    if (iOS && !standalone && !isDismissed) {
      // Wait for splash screen completion
      const checkSplashComplete = () => {
        if (document.querySelector('.splash-screen')) {
          setTimeout(checkSplashComplete, 100);
        } else {
          setTimeout(() => {
            setShowPrompt(true);
          }, 2000);
        }
      };
      checkSplashComplete();
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('splashScreenComplete', handleSplashComplete);
      clearTimeout(fallbackTimer);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt && !isInstalling) {
      setIsInstalling(true);
      
      try {
        // Use requestAnimationFrame to ensure smooth UI
        requestAnimationFrame(async () => {
          try {
            await deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            
            if (outcome === 'accepted') {
              setDeferredPrompt(null);
              setShowPrompt(false);
            }
          } catch (error) {
            console.error('Install prompt failed:', error);
          } finally {
            setIsInstalling(false);
          }
        });
      } catch (error) {
        console.error('Install error:', error);
        setIsInstalling(false);
      }
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setDismissed(true);
    localStorage.setItem('taleb-pwa-dismissed', 'true');
  };

  // Don't show if already installed or dismissed
  console.log('PWA Install Prompt render check:', {
    isStandalone,
    dismissed,
    showPrompt,
    deferredPrompt: !!deferredPrompt
  });
  
  if (isStandalone || dismissed || !showPrompt) {
    return null;
  }

  const isMobile = window.innerWidth < 768;

  // Test button for debugging (remove in production)
  const testShowPrompt = () => {
    console.log('Test button clicked, forcing showPrompt to true');
    setShowPrompt(true);
  };

  return (
    <AnimatePresence>
      {showPrompt && (
        <>
          {/* Mobile Bottom Sheet */}
          {isMobile ? (
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ 
                type: "spring", 
                damping: 25, 
                stiffness: 300,
                opacity: { duration: 0.2 }
              }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-[var(--background)] border-t border-[var(--border-color)] rounded-t-3xl p-6 shadow-2xl"
              style={{ willChange: 'transform' }}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[var(--accent-color)] rounded-2xl flex items-center justify-center flex-shrink-0">
                    <img 
                      src="/src/assets/logo.png" 
                      alt="Taleb" 
                      className="w-8 h-8"
                      loading="lazy"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-bold text-[var(--text-primary)] truncate">
                      {language === 'ar' ? 'ثبّت تطبيق طالب' : 'Install Taleb App'}
                    </h3>
                    <p className="text-sm text-[var(--text-secondary)] truncate">
                      {language === 'ar' ? 'للوصول السريع والتجربة الأفضل' : 'For quick access and better experience'}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={handleDismiss} 
                  className="p-2 rounded-full hover:bg-[var(--background-secondary)] transition-colors flex-shrink-0"
                >
                  <X className="w-5 h-5 text-[var(--text-secondary)]" />
                </button>
              </div>

              {isIOS ? (
                <div className="space-y-4">
                  <div className="text-sm text-[var(--text-secondary)] space-y-3">
                    <p className="font-medium text-[var(--text-primary)]">
                      {language === 'ar' ? 'لتثبيت التطبيق على iOS:' : 'To install on iOS:'}
                    </p>
                    <div className="flex items-start gap-3">
                      <Share className="w-4 h-4 mt-0.5 text-blue-500 flex-shrink-0" />
                      <span>
                        {language === 'ar' 
                          ? 'اضغط على زر المشاركة أسفل الشاشة' 
                          : 'Tap the Share button at the bottom of the screen'
                        }
                      </span>
                    </div>
                    <div className="flex items-start gap-3">
                      <Smartphone className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                      <span>
                        {language === 'ar' 
                          ? 'اختر "إضافة إلى الشاشة الرئيسية"' 
                          : 'Select "Add to Home Screen"'
                        }
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={handleDismiss}
                    className="w-full py-3 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-2xl font-medium transition-transform active:scale-95"
                  >
                    {language === 'ar' ? 'فهمت' : 'Got it'}
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleInstall}
                  disabled={isInstalling}
                  className="w-full py-3 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-2xl font-medium flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-70 disabled:scale-100"
                >
                  {isInstalling ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-5 h-5 border-2 border-current border-t-transparent rounded-full"
                      />
                      {language === 'ar' ? 'جارِ التثبيت...' : 'Installing...'}
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5" />
                      {language === 'ar' ? 'ثبّت التطبيق' : 'Install App'}
                    </>
                  )}
                </button>
              )}
            </motion.div>
          ) : (
            /* Desktop Modal */
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
              onClick={handleDismiss}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.9, y: 20, opacity: 0 }}
                transition={{ 
                  type: "spring", 
                  damping: 25, 
                  stiffness: 300,
                  opacity: { duration: 0.2 }
                }}
                className="bg-[var(--background)] rounded-3xl p-8 max-w-md w-full shadow-2xl border border-[var(--border-color)]"
                onClick={(e) => e.stopPropagation()}
                style={{ willChange: 'transform' }}
              >
                <div className="text-center space-y-6">
                  <div className="w-20 h-20 bg-[var(--accent-color)] rounded-3xl flex items-center justify-center mx-auto">
                    <img 
                      src="/src/assets/logo.png" 
                      alt="Taleb" 
                      className="w-12 h-12"
                      loading="lazy"
                    />
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold text-[var(--text-primary)] mb-2">
                      {language === 'ar' ? 'ثبّت تطبيق طالب' : 'Install Taleb App'}
                    </h3>
                    <p className="text-[var(--text-secondary)]">
                      {language === 'ar' 
                        ? 'احصل على تجربة أفضل مع التطبيق المثبت على جهازك'
                        : 'Get a better experience with the app installed on your device'
                      }
                    </p>
                  </div>

                  <div className="flex items-center justify-center gap-8 text-sm text-[var(--text-secondary)]">
                    <div className="flex items-center gap-2">
                      <Monitor className="w-4 h-4" />
                      <span>{language === 'ar' ? 'سطح المكتب' : 'Desktop'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4" />
                      <span>{language === 'ar' ? 'الهاتف' : 'Mobile'}</span>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={handleDismiss}
                      className="flex-1 py-3 border border-[var(--border-color)] text-[var(--text-primary)] rounded-2xl font-medium hover:bg-[var(--background-secondary)] transition-colors"
                    >
                      {language === 'ar' ? 'ليس الآن' : 'Not now'}
                    </button>
                    <button
                      onClick={handleInstall}
                      disabled={isInstalling}
                      className="flex-1 py-3 bg-[var(--accent-color)] text-[var(--accent-text-color)] rounded-2xl font-medium hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                    >
                      {isInstalling ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="w-4 h-4 border-2 border-current border-t-transparent rounded-full"
                          />
                          {language === 'ar' ? 'جارِ...' : 'Installing...'}
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4" />
                          {language === 'ar' ? 'ثبّت' : 'Install'}
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </>
      )}
      
      {/* Test button for debugging - remove in production */}
      {!showPrompt && (
        <button
          onClick={testShowPrompt}
          className="fixed top-4 right-4 z-50 bg-red-500 text-white px-3 py-1 rounded text-xs"
        >
          Test PWA
        </button>
      )}
    </AnimatePresence>
  );
}
