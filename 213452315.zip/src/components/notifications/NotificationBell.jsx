import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, BellRing } from 'lucide-react';
import { useNotifications } from '../utils/notificationManager';
import { useI18n } from '../utils/i18n';
import NotificationCenter from './NotificationCenter';

const NotificationBell = ({ className = '' }) => {
  const { unreadCount } = useNotifications();
  const { isRTL, t } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [showDebug, setShowDebug] = useState(false);

  useEffect(() => {
    const handleOpenNotificationCenter = (event) => {
      if (event.detail?.showDebug) {
        setShowDebug(true);
        setIsOpen(true);
      }
    };

    window.addEventListener('openNotificationCenter', handleOpenNotificationCenter);
    
    return () => {
      window.removeEventListener('openNotificationCenter', handleOpenNotificationCenter);
    };
  }, []);

  const handleOpen = () => {
    setShowDebug(false);
    setIsOpen(true);
  };

  return (
    <>
      <button
        onClick={handleOpen}
        className={`flex items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 group relative text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)] hover:scale-105 ${className}`}
        title={t('sidebar.notifications')}
      >
        <motion.div
          animate={unreadCount > 0 ? { rotate: [0, -10, 10, -10, 0] } : {}}
          transition={{ duration: 0.5, repeat: unreadCount > 0 ? Infinity : 0, repeatDelay: 3 }}
        >
          {unreadCount > 0 ? (
            <BellRing className="w-5 h-5" />
          ) : (
            <Bell className="w-5 h-5" />
          )}
        </motion.div>

        {/* Label for larger screens */}
        <span className={`absolute ${isRTL ? 'right-16' : 'left-16'}
          bg-[var(--background)] text-[var(--text-primary)]
          px-3 py-2 rounded-lg text-sm font-medium
          opacity-0 group-hover:opacity-100 transition-opacity duration-200
          pointer-events-none whitespace-nowrap shadow-lg border border-[var(--border-color)]
        `}>
          {t('sidebar.notifications')}
        </span>
        
        <AnimatePresence>
          {unreadCount > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="absolute -top-1 -right-1"
            >
              <Badge 
                variant="destructive" 
                className="h-5 min-w-5 text-xs flex items-center justify-center p-0"
              >
                {unreadCount > 99 ? '99+' : unreadCount}
              </Badge>
            </motion.div>
          )}
        </AnimatePresence>
      </button>

      <AnimatePresence>
        {isOpen && (
          <NotificationCenter 
            isOpen={isOpen} 
            onClose={() => setIsOpen(false)}
            showDebug={showDebug}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default NotificationBell;
