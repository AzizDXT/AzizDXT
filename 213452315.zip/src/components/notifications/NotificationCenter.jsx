import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Bell, 
  X, 
  Check, 
  CheckCheck,
  Trash2,
  Clock,
  MessageCircle,
  Heart,
  Users,
  BookOpen,
  Zap,
  AlertTriangle,
  Info
} from 'lucide-react';
import { useI18n } from '../utils/i18n';
import { notificationService } from '../utils/firebase';

export default function NotificationCenter({ isOpen, onClose }) {
  const { t, isRTL, language } = useI18n();
  
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  // Storage keys
  const STORAGE_KEY = 'taleb-notifications';
  const UNREAD_COUNT_KEY = 'taleb-unread-count';

  useEffect(() => {
    if (isOpen) {
      loadNotifications();
    }
  }, [isOpen]);

  useEffect(() => {
    // Listen for new Firebase notifications
    const handleFirebaseMessage = (event) => {
      const { title, body, data } = event.detail;
      addNotification(title, body, data);
    };

    window.addEventListener('firebaseMessageReceived', handleFirebaseMessage);
    return () => {
      window.removeEventListener('firebaseMessageReceived', handleFirebaseMessage);
    };
  }, []);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      // Load from localStorage
      const storedNotifications = localStorage.getItem(STORAGE_KEY);
      const storedUnreadCount = localStorage.getItem(UNREAD_COUNT_KEY);
      
      if (storedNotifications) {
        const parsedNotifications = JSON.parse(storedNotifications);
        setNotifications(parsedNotifications);
      }
      
      if (storedUnreadCount) {
        setUnreadCount(parseInt(storedUnreadCount));
      }
    } catch (error) {
      console.error('Error loading notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveNotifications = (newNotifications) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newNotifications));
      const unread = newNotifications.filter(n => !n.read).length;
      setUnreadCount(unread);
      localStorage.setItem(UNREAD_COUNT_KEY, unread.toString());
    } catch (error) {
      console.error('Error saving notifications:', error);
    }
  };

  const addNotification = (title, body, data = {}) => {
    const newNotification = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      type: data.type || 'general',
      title: title,
      body: body,
      timestamp: new Date(),
      read: false,
      avatar: data.avatar || '/src/assets/logo.png',
      sender: data.sender || (language === 'ar' ? 'النظام' : 'System'),
      data: data
    };

    setNotifications(prev => {
      const updated = [newNotification, ...prev];
      saveNotifications(updated);
      return updated;
    });
  };

  const markAsRead = (notificationId) => {
    setNotifications(prev => {
      const updated = prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      );
      saveNotifications(updated);
      return updated;
    });
  };

  const markAllAsRead = () => {
    setNotifications(prev => {
      const updated = prev.map(notification => ({ ...notification, read: true }));
      saveNotifications(updated);
      return updated;
    });
  };

  const deleteNotification = (notificationId) => {
    setNotifications(prev => {
      const updated = prev.filter(n => n.id !== notificationId);
      saveNotifications(updated);
      return updated;
    });
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    saveNotifications([]);
  };

  const sendTestNotification = async () => {
    try {
      await notificationService.sendTestNotification();
    } catch (error) {
      console.error('Error sending test notification:', error);
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'message':
        return <MessageCircle className="w-5 h-5 text-blue-500" />;
      case 'like':
        return <Heart className="w-5 h-5 text-red-500" />;
      case 'comment':
        return <MessageCircle className="w-5 h-5 text-green-500" />;
      case 'system':
        return <Zap className="w-5 h-5 text-purple-500" />;
      case 'academic':
        return <BookOpen className="w-5 h-5 text-orange-500" />;
      default:
        return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationTypeLabel = (type) => {
    switch (type) {
      case 'message':
        return t('notifications.types.message') || (language === 'ar' ? 'رسالة' : 'Message');
      case 'like':
        return t('notifications.types.like') || (language === 'ar' ? 'إعجاب' : 'Like');
      case 'comment':
        return t('notifications.types.comment') || (language === 'ar' ? 'تعليق' : 'Comment');
      case 'system':
        return t('notifications.types.system') || (language === 'ar' ? 'نظام' : 'System');
      case 'academic':
        return t('notifications.types.academic') || (language === 'ar' ? 'أكاديمي' : 'Academic');
      default:
        return t('notifications.types.general') || (language === 'ar' ? 'عام' : 'General');
    }
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) {
      return t('notifications.time.now');
    } else if (minutes < 60) {
      return `${minutes} ${t('notifications.time.minutesAgo')}`;
    } else if (hours < 24) {
      return `${hours} ${t('notifications.time.hoursAgo')}`;
    } else {
      return `${days} ${t('notifications.time.daysAgo')}`;
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
            className="bg-[var(--background)] rounded-xl shadow-2xl border border-[var(--border-color)] w-full max-w-md mx-4 max-h-[80vh] overflow-hidden"
            initial={{ y: -50, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -50, opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
        >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-[var(--background-secondary)]">
              <Bell className="w-5 h-5 text-[var(--text-primary)]" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-[var(--text-primary)]">
                {t('notifications.title')}
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                {unreadCount > 0 
                  ? `${unreadCount} ${t('notifications.unread')}`
                  : t('notifications.allRead')
                }
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[var(--background-secondary)] transition-colors"
          >
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        {/* Actions */}
        <div className="p-3 border-b border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <button
                onClick={sendTestNotification}
                className="px-3 py-1.5 text-xs font-medium text-[var(--text-primary)] bg-[var(--background-secondary)] hover:bg-[var(--accent-color)] hover:text-[var(--accent-text-color)] rounded-full transition-colors"
              >
                {t('notifications.sendTest')}
              </button>
              {notifications.length > 0 && unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="px-3 py-1.5 text-xs font-medium text-[var(--text-primary)] bg-[var(--background-secondary)] hover:bg-[var(--accent-color)] hover:text-[var(--accent-text-color)] rounded-full transition-colors"
                >
                  {t('notifications.markAllRead')}
                </button>
              )}
              {notifications.length > 0 && (
                <button
                  onClick={clearAllNotifications}
                  className="px-3 py-1.5 text-xs font-medium text-[var(--text-primary)] bg-[var(--background-secondary)] hover:bg-[var(--accent-color)] hover:text-[var(--accent-text-color)] rounded-full transition-colors"
                >
                  {t('notifications.clearAll')}
                </button>
              )}
            </div>
            {notifications.length > 0 && (
              <span className="px-2 py-1 text-xs font-medium text-[var(--text-secondary)] bg-[var(--background-secondary)] rounded-full">
                {notifications.length} {t('notifications.total')}
              </span>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[60vh]">
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-6 w-6 border-2 border-[var(--border-color)] border-t-[var(--accent-color)]"></div>
              <span className="ml-3 text-sm text-[var(--text-secondary)]">
                {t('notifications.loading')}
              </span>
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <div className="p-4 rounded-full bg-[var(--background-secondary)] mb-4">
                <Bell className="w-8 h-8 text-[var(--text-secondary)]" />
              </div>
              <h3 className="text-lg font-medium text-[var(--text-primary)] mb-2">
                {t('notifications.empty.title')}
              </h3>
              <p className="text-sm text-[var(--text-secondary)] max-w-xs">
                {t('notifications.empty.description')}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {notifications.map((notification, index) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className={`p-3 rounded-lg border transition-all duration-200 hover:shadow-sm ${
                    !notification.read 
                      ? 'bg-[var(--background-secondary)] border-[var(--border-color)]' 
                      : 'bg-[var(--background)] border-[var(--border-color)]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      <img
                        src={notification.avatar}
                        alt={notification.sender}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div className="absolute -top-1 -right-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className={`text-sm font-medium text-[var(--text-primary)] truncate ${
                              !notification.read ? 'font-semibold' : ''
                            }`}>
                              {notification.title}
                            </h4>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-[var(--accent-color)] rounded-full flex-shrink-0"></div>
                            )}
                          </div>
                          <p className="text-xs text-[var(--text-secondary)] mb-2 line-clamp-2">
                            {notification.body}
                          </p>
                          <div className="flex items-center gap-1 text-xs text-[var(--text-secondary)]">
                            <Clock className="w-3 h-3" />
                            <span>{formatTime(notification.timestamp)}</span>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {!notification.read && (
                            <button
                              onClick={() => markAsRead(notification.id)}
                              className="p-1 rounded-full hover:bg-[var(--background-secondary)] transition-colors"
                              title={t('notifications.markAsRead')}
                            >
                              <Check className="w-3 h-3 text-[var(--text-secondary)]" />
                            </button>
                          )}
                          <button
                            onClick={() => deleteNotification(notification.id)}
                            className="p-1 rounded-full hover:bg-[var(--background-secondary)] transition-colors"
                            title={t('notifications.delete')}
                          >
                            <Trash2 className="w-3 h-3 text-[var(--text-secondary)]" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
                        )}
                      </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-4 border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="text-sm text-[var(--text-secondary)]">
            {notifications.length > 0 && (
              <span>
                {language === 'ar' 
                  ? `${unreadCount} ${t('notifications.unread')} من ${notifications.length} ${t('notifications.total')}`
                  : `${unreadCount} ${t('notifications.unread')} of ${notifications.length} ${t('notifications.total')}`
                }
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-[var(--text-primary)] bg-[var(--background-secondary)] hover:bg-[var(--accent-color)] hover:text-[var(--accent-text-color)] rounded-lg transition-colors"
          >
            {t('common.close')}
          </button>
        </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}