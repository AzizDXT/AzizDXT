import React from 'react';
import { motion } from 'framer-motion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Plus } from 'lucide-react';

export default function StoryRing({ 
  story, 
  isViewed = false, 
  onClick, 
  size = 'medium'
}) {
  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return {
          ring: 'w-16 h-16',
          avatar: 'w-14 h-14',
          text: 'text-xs'
        };
      case 'large':
        return {
          ring: 'w-24 h-24',
          avatar: 'w-20 h-20',
          text: 'text-sm'
        };
      default: // medium
        return {
          ring: 'w-20 h-20',
          avatar: 'w-16 h-16',
          text: 'text-xs'
        };
    }
  };

  const sizeClasses = getSizeClasses();

  return (
    <motion.div
      className="flex flex-col items-center gap-2 cursor-pointer"
      onClick={onClick}
      whileTap={{ scale: 0.95 }}
    >
      {/* Story Ring */}
      <div className={`relative ${sizeClasses.ring}`}>
        {/* Colored Ring - Instagram Style */}
        <div className={`absolute inset-0 rounded-full ${
          story.isMyStory 
            ? (story.hasStories 
                ? 'bg-gradient-to-tr from-orange-400 via-red-500 to-yellow-400'
                : 'bg-gradient-to-tr from-gray-300 to-gray-400')
            : (isViewed 
                ? 'bg-gradient-to-tr from-gray-300 to-gray-400' 
                : 'bg-gradient-to-tr from-orange-400 via-red-500 to-yellow-400')
        } p-1`}>
          <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
            {/* Avatar */}
            <Avatar className={`${sizeClasses.avatar} border-2 border-white shadow-sm`}>
              <AvatarImage src={story.avatar} />
              <AvatarFallback className="bg-gray-200 text-gray-700 font-semibold">
                {story.user.charAt(0)}
              </AvatarFallback>
            </Avatar>
            
            {/* Plus Icon for My Story */}
            {story.isMyStory && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                <Plus className="w-3 h-3 text-white" />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* User Name Only */}
      <div className="text-center max-w-20">
        <p className={`${sizeClasses.text} font-medium text-[var(--text-primary)] truncate`}>
          {story.user}
        </p>
      </div>
    </motion.div>
  );
} 