import React, { useState } from 'react';
import { User } from 'lucide-react';
import { API_BASE_URL } from '../utils/api';

export default function ChatImage({ 
  src, 
  alt, 
  className = '', 
  ...props 
}) {
  const [hasError, setHasError] = useState(false);

  // Build the full image URL using API_BASE_URL
  const getImageUrl = (imagePath) => {
    if (!imagePath) return null;
    
    // If it's already a full URL, return as is
    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      return imagePath;
    }
    
    // If it's a relative path starting with /api/, build full URL with API_BASE_URL
    if (imagePath.startsWith('/api/')) {
      return `${API_BASE_URL}${imagePath}`;
    }
    
    // If it's a relative path starting with /, build full URL with API_BASE_URL
    if (imagePath.startsWith('/')) {
      return `${API_BASE_URL}${imagePath}`;
    }
    
    // If it's just a path without leading slash, add it
    return `${API_BASE_URL}/${imagePath}`;
  };

  const imageUrl = getImageUrl(src);

  if (hasError || !imageUrl) {
    return (
      <div className={`${className} bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center`}>
        <User className="w-8 h-8 text-gray-400" />
      </div>
    );
  }

  return (
    <img
      src={imageUrl}
      alt={alt}
      className={className}
      onError={() => setHasError(true)}
      {...props}
    />
  );
}
