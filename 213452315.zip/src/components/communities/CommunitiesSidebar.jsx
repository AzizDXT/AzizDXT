import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useI18n } from '../utils/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  MessageCircle,
  Plus,
  StickyNote,
  UserPlus,
  Loader2,
  X,
  User
} from 'lucide-react';
import NoteModal from './NoteModal';
import { chatService, API_BASE_URL } from '../utils/api';
import api from '../utils/api';
import ChatImage from './ChatImage';

// Wrapper component that safely uses useI18n
function CommunitiesSidebarContent({ 
  selectedChat, 
  onChatSelect, 
  onNewChat,
  onSearch,
  onCreateGroup,
  onJoinGroup,
  onMarkChatAsSeen
}) {
  // Safely get i18n values with fallbacks
  let t, isRTL;
  try {
    const i18n = useI18n();
    t = i18n.t;
    isRTL = i18n.isRTL;
  } catch (error) {
    console.warn('I18n not available in CommunitiesSidebar, using fallbacks:', error);
    // Fallback values
    t = (key) => key;
    isRTL = false;
  }
  const [searchQuery, setSearchQuery] = useState('');
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showRequests, setShowRequests] = useState(false);
  const [notes, setNotes] = useState([]);
  const scrollContainerRef = useRef(null);
  
  // New state for API data
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [userProfiles, setUserProfiles] = useState({});
  const conversationsContainerRef = useRef(null);

  // Search states
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState(null);
  const searchInputRef = useRef(null);


  // Load conversations from API
  const loadConversations = useCallback(async (page = 0, reset = false) => {
    try {
      if (page === 0) {
        setLoading(true);
        setError(null);
      } else {
        setLoadingMore(true);
      }

      const limit = 20;
      const offset = page * limit;
      
      const response = await chatService.getChatRooms(limit, offset);
      
      if (response.rooms && response.rooms.length > 0) {
        // Get user profiles for all participants
        const userIds = response.rooms.map(room => room.other_participant.id);
        const profiles = await chatService.getUserProfiles(userIds);
        
        // Create profiles map
        const profilesMap = {};
        profiles.forEach(profile => {
          if (profile.profile) {
            profilesMap[profile.profile.id] = profile.profile;
          }
        });
        
        // Transform rooms to conversation format
        const newConversations = response.rooms.map(room => {
          const profile = profilesMap[room.other_participant.id];
          const profileImageUrl = profile?.profile_image_url || room.other_participant.profile_image_url;
          
          return {
            id: room.id,
            name: profile?.name || room.other_participant.name || 'Unknown User',
            username: profile?.username || room.other_participant.username || 'unknown',
            avatar: profileImageUrl, // Pass the URL directly to ChatImage component
            platform: 'Direct Message',
            isOnline: room.other_participant.is_online || false,
            lastSeen: room.other_participant.is_online ? t('communities.chat.online') : t('communities.chat.lastSeen') + ' ' + formatLastSeen(room.last_message_at),
            unreadCount: room.unread_count || 0,
            lastMessageAt: room.last_message_at,
            lastMessage: room.last_message,
            userId: room.other_participant.id
          };
        });

        if (reset) {
          setConversations(newConversations);
          setUserProfiles(profilesMap);
        } else {
          setConversations(prev => [...prev, ...newConversations]);
          setUserProfiles(prev => ({ ...prev, ...profilesMap }));
        }
        
        setHasMore(response.rooms.length === limit);
        setCurrentPage(page);
      } else {
        setHasMore(false);
      }
    } catch (error) {
      console.error('Failed to load conversations:', error);
      setError('Failed to load conversations');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [t]);

  // Format last seen time
  const formatLastSeen = (timestamp) => {
    if (!timestamp) return t('communities.chat.lastSeen') + ' ' + t('time.unknown');
    
    const now = new Date();
    const lastSeen = new Date(timestamp);
    const diffInMinutes = Math.floor((now - lastSeen) / (1000 * 60));
    
    if (diffInMinutes < 1) {
      return t('time.justNow');
    } else if (diffInMinutes < 60) {
      return t('time.minutesAgo', { count: diffInMinutes });
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return t('time.hoursAgo', { count: hours });
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return t('time.daysAgo', { count: days });
    }
  };

  // Mock data للصور الدائرية مع ملاحظات وهمية
  const circularImages = [
    {
      id: 1,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      name: 'أنت',
      note: 'ملاحظة سريعة للعمل',
      badge: 'اجتماع 9:43'
    },
    {
      id: 2,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop&crop=face',
      name: 'سارة أحمد',
      note: 'فكرة جديدة للمشروع',
      badge: 'مشروع 2:15'
    },
    {
      id: 3,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
      name: 'محمد علي',
      note: 'تذكير بالاجتماع',
      badge: 'دردشة 11:30'
    },
    {
      id: 4,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
      name: 'فاطمة حسن',
      note: 'قائمة المهام',
      badge: 'مهام 4:20'
    },
    {
      id: 5,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      name: 'أحمد خالد',
      note: 'أفكار للإبداع',
      badge: 'إبداع 7:45'
    },
    {
      id: 6,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop&crop=face',
      name: 'نور الدين',
      note: 'ملاحظات الدراسة',
      badge: 'دراسة 1:10'
    },
    {
      id: 7,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face',
      name: 'علي محمد',
      note: 'تذكير بالدردشة',
      badge: 'تذكير 6:30'
    },
    {
      id: 8,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face',
      name: 'زينب أحمد',
      note: 'أفكار للمستقبل',
      badge: 'أفكار 3:55'
    },
    {
      id: 9,
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=50&h=50&fit=crop&crop=face',
      name: 'حسن علي',
      note: 'ملاحظات العمل',
      badge: 'عمل 8:15'
    },
    {
      id: 10,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop&crop=face',
      name: 'مريم خالد',
      note: 'تذكير بالعائلة',
      badge: 'عائلة 5:40'
    }
  ];

  // Mock data للطلبات - في التطبيق الحقيقي ستأتي من API
  const requests = [
    {
      id: 1,
      type: 'friend',
      sender: {
        id: 1,
        name: 'أحمد محمد',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=60&h=60&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد إضافة صديق',
      timestamp: 'منذ 5 دقائق',
      status: 'pending'
    },
    {
      id: 2,
      type: 'group',
      sender: {
        id: 2,
        name: 'سارة أحمد',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=60&h=60&fit=crop&crop=face',
        status: 'offline'
      },
      message: 'يريد الانضمام إلى مجموعة الدراسة',
      timestamp: 'منذ ساعة',
      status: 'pending'
    },
    {
      id: 3,
      type: 'friend',
      sender: {
        id: 3,
        name: 'محمد علي',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد إضافة صديق',
      timestamp: 'منذ 3 ساعات',
      status: 'pending'
    },
    {
      id: 4,
      type: 'group',
      sender: {
        id: 4,
        name: 'فاطمة حسن',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=60&h=60&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد الانضمام إلى مجموعة الرياضيات',
      timestamp: 'منذ يوم',
      status: 'pending'
    }
  ];

  // Load conversations on component mount
  useEffect(() => {
    loadConversations(0, true);
  }, [loadConversations]);

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchInputRef.current && !searchInputRef.current.contains(event.target)) {
        setShowSearchResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Cleanup search timeout on unmount
  useEffect(() => {
    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [searchTimeout]);

  // دعم التمرير بالمحرك الدائري للماوس
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const handleWheel = (e) => {
      e.preventDefault();
      container.scrollLeft += e.deltaY;
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, []);

  // Infinite scroll for conversations
  useEffect(() => {
    const container = conversationsContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      
      if (isNearBottom && hasMore && !loadingMore && !loading) {
        loadConversations(currentPage + 1, false);
      }
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [hasMore, loadingMore, loading, currentPage, loadConversations]);

  // Quick user search function
  const performQuickSearch = useCallback(async (query) => {
    if (!query || query.length < 2) {
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }

    try {
      setIsSearching(true);
      const response = await api.quickUserSearch(query, 10);
      
      if (response.users) {
        setSearchResults(response.users);
        setShowSearchResults(true);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  // Handle search input change with debouncing
  const handleSearchInputChange = (e) => {
    const query = e.target.value;
    setSearchQuery(query);

    // Clear existing timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    // Set new timeout for debounced search
    const newTimeout = setTimeout(() => {
      performQuickSearch(query);
    }, 300);

    setSearchTimeout(newTimeout);
  };

  // Handle search form submission
  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      performQuickSearch(searchQuery.trim());
    }
  };

  // Handle user selection from search results
  const handleUserSelect = async (user) => {
    try {
      // Create a new chat with the selected user
      const newChat = {
        id: `temp-${user.id}`,
        name: user.name,
        username: user.username,
        avatar: user.profile_image_url,
        platform: 'Direct Message',
        isOnline: false,
        lastSeen: 'Unknown',
        unreadCount: 0,
        lastMessageAt: null,
        lastMessage: null,
        userId: user.id
      };

      // Select the chat
      onChatSelect(newChat);
      
      // Clear search
      setSearchQuery('');
      setSearchResults([]);
      setShowSearchResults(false);
      
      // Focus back to search input
      if (searchInputRef.current) {
        searchInputRef.current.blur();
      }
    } catch (error) {
      console.error('Failed to start chat with user:', error);
    }
  };

  // Clear search results
  const clearSearch = () => {
    setSearchQuery('');
    setSearchResults([]);
    setShowSearchResults(false);
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  const handleChatSelect = (chat) => {
    onChatSelect(chat);
    // Mark chat as seen and update unread count
    if (onMarkChatAsSeen) {
      onMarkChatAsSeen(chat.id);
    }
  };

  // Update unread count for a specific chat
  const updateUnreadCount = (chatId, count = 0) => {
    setConversations(prev => prev.map(chat => 
      chat.id === chatId ? { ...chat, unreadCount: count } : chat
    ));
  };

  // Expose updateUnreadCount to parent component
  useEffect(() => {
    if (onMarkChatAsSeen) {
      // Store the update function in the callback
      onMarkChatAsSeen.updateUnreadCount = updateUnreadCount;
    }
  }, [onMarkChatAsSeen]);

  const handleAddNote = (note) => {
    setNotes(prev => [...prev, note]);
  };

  const handleNoteModalClose = () => {
    setShowNoteModal(false);
  };

  const handleToggleRequests = () => {
    setShowRequests(!showRequests);
  };

  const handleBackToConversations = () => {
    setShowRequests(false);
  };

  const handleAcceptRequest = (requestId) => {
    // هنا يمكن إضافة منطق قبول الطلب
    console.log('تم قبول الطلب:', requestId);
  };

  const handleRejectRequest = (requestId) => {
    // هنا يمكن إضافة منطق رفض الطلب
    console.log('تم رفض الطلب:', requestId);
  };

  // Filter conversations based on search query
  const filteredConversations = conversations.filter(community =>
    community.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    community.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`w-80 bg-[var(--background-secondary)] border-${isRTL ? 'l' : 'r'} border-[var(--border-color)] flex flex-col h-full`}>
      {/* هيدر البحث */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-[var(--text-primary)]">{t('communities.sidebar.conversations')}</h1>
          <button className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] p-2 rounded-lg hover:bg-[var(--background)] transition-all duration-200">
            <MessageCircle className="w-5 h-5" />
          </button>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 w-4 h-4 text-[var(--text-secondary)]`} />
          <input
            ref={searchInputRef}
            type="text"
            placeholder={t('communities.sidebar.search')}
            value={searchQuery}
            onChange={handleSearchInputChange}
            onFocus={() => {
              if (searchResults.length > 0) {
                setShowSearchResults(true);
              }
            }}
            className={`w-full bg-[var(--background)] text-[var(--text-primary)] placeholder-[var(--text-secondary)] rounded-lg py-2 ${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] transition-all duration-200`}
          />
          
          {/* Clear search button */}
          {searchQuery && (
            <button
              onClick={clearSearch}
              className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2 w-4 h-4 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors`}
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {/* Search Results Dropdown */}
          <AnimatePresence>
            {showSearchResults && (searchResults.length > 0 || isSearching) && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="absolute top-full left-0 right-0 mt-2 bg-[var(--background)] border border-[var(--border-color)] rounded-lg shadow-lg z-50 max-h-64 overflow-y-auto"
              >
                {isSearching ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-4 h-4 animate-spin text-[var(--accent-color)] mr-2" />
                    <span className="text-sm text-[var(--text-secondary)]">Searching...</span>
                  </div>
                ) : searchResults.length > 0 ? (
                  <>
                    <div className="p-2 border-b border-[var(--border-color)]">
                      <p className="text-xs text-[var(--text-secondary)] font-medium">
                        {t('communities.sidebar.searchResults')} ({searchResults.length})
                      </p>
                    </div>
                    {searchResults.map((user, index) => (
                      <motion.div
                        key={user.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        onClick={() => handleUserSelect(user)}
                        className="flex items-center gap-3 p-3 hover:bg-[var(--background-secondary)] cursor-pointer transition-colors"
                      >
                        <div className="relative">
                          <ChatImage
                            src={user.profile_image_url}
                            alt={user.name}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                          {user.verified && (
                            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs">✓</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-medium text-[var(--text-primary)] truncate">
                              {user.name}
                            </h4>
                            {user.verified && (
                              <span className="text-xs text-blue-500">✓</span>
                            )}
                          </div>
                          <p className="text-xs text-[var(--text-secondary)] truncate">
                            @{user.username}
                          </p>
                          {user.institutional_account && (
                            <span className="inline-block text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded-full mt-1">
                              {t('communities.sidebar.institutional')}
                            </span>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <User className="w-4 h-4 text-[var(--text-secondary)]" />
                          <span className="text-xs text-[var(--text-secondary)]">
                            {t('communities.sidebar.startChat')}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </>
                ) : (
                  <div className="p-4 text-center">
                    <Search className="w-8 h-8 text-[var(--text-secondary)] mx-auto mb-2" />
                    <p className="text-sm text-[var(--text-secondary)]">
                      {t('communities.sidebar.noUsersFound')}
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* قسم الملاحظات السريعة */}
      <div className="p-4">
        <div className="mb-4">
          <h2 className="text-base font-semibold text-[var(--text-primary)] mb-3">ملاحظات سريعة</h2>
          
          {/* قائمة الصور الدائرية مع الملاحظات */}
          <div className="relative">
            <div 
              ref={scrollContainerRef}
              className="flex gap-4 overflow-x-auto pb-3 pt-4 custom-scrollbar"
              style={{ scrollbarWidth: 'thin', scrollbarColor: 'var(--border-color) transparent' }}
            >
              {circularImages.map((image) => (
                <div key={image.id} className="flex flex-col items-center min-w-0 flex-shrink-0 w-24">
                  <div className="relative cursor-pointer">
                    <img
                      src={image.avatar}
                      alt={image.name}
                      className="w-20 h-20 rounded-full object-cover"
                    />

                    {/* الأيقونة البيضاء فوق الصورة */}
                    <div className="absolute top-0 right-0 bg-white rounded-full flex items-center justify-center px-3 py-1.5 min-w-fit shadow-lg">
                      <span className="text-sm text-black font-medium whitespace-nowrap">{image.badge}</span>
                    </div>
                    {/* اسم المستخدم */}
                    <div className="text-center mt-3 w-full">
                      <p className="text-sm text-[var(--text-primary)] font-medium truncate w-full">{image.name}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            

          </div>
        </div>
      </div>

      {/* قائمة المجتمعات */}
      <div 
        ref={conversationsContainerRef}
        className="flex-1 overflow-y-auto custom-scrollbar"
      >
        <div className="p-2">
          <div className={`flex items-center justify-between mb-3 px-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <AnimatePresence mode="wait">
              <motion.h2
                key={showRequests ? 'requests' : 'conversations'}
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 5 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="text-base font-semibold text-[var(--text-primary)]"
              >
                {showRequests ? t('communities.sidebar.friendRequests') : t('communities.sidebar.conversations')}
              </motion.h2>
            </AnimatePresence>
            
            <AnimatePresence mode="wait">
              {showRequests ? (
                <motion.button
                  key="back-button"
                  initial={{ opacity: 0, x: isRTL ? -10 : 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: isRTL ? 10 : -10 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  onClick={handleBackToConversations}
                  className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-sm transition-colors cursor-pointer"
                >
                  {isRTL ? '→' : '←'} {t('communities.sidebar.conversations')}
                </motion.button>
              ) : (
                <motion.button
                  key="requests-button"
                  initial={{ opacity: 0, x: isRTL ? 10 : -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: isRTL ? -10 : 10 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  onClick={handleToggleRequests}
                  className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-sm transition-colors cursor-pointer"
                >
                  {t('communities.sidebar.friendRequests')}
                </motion.button>
              )}
            </AnimatePresence>
          </div>
          
          <AnimatePresence mode="wait">
            {showRequests ? (
              // عرض الطلبات
              <motion.div
                key="requests"
                initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isRTL ? -20 : 20 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="space-y-3"
              >
                {requests.map((request, index) => (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: index * 0.05 }}
                    className="flex items-center gap-3 p-3 rounded-lg bg-[var(--background-secondary)] border border-[var(--border-color)]"
                  >
                    <div className="relative">
                      <img
                        src={request.sender.avatar}
                        alt={request.sender.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-[var(--text-primary)] font-medium truncate">{request.sender.name}</h3>
                        <span className="text-xs text-[var(--text-secondary)]">{request.timestamp}</span>
                      </div>
                      <p className="text-sm text-[var(--text-secondary)] truncate">{request.message}</p>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleAcceptRequest(request.id)}
                        className="w-8 h-8 bg-white hover:bg-gray-100 text-black border border-gray-300 rounded-full transition-all duration-200 hover:scale-105 flex items-center justify-center"
                        title="قبول"
                      >
                        ✓
                      </button>
                      <button
                        onClick={() => handleRejectRequest(request.id)}
                        className="w-8 h-8 bg-white hover:bg-gray-100 text-black border border-gray-300 rounded-full transition-all duration-200 hover:scale-105 flex items-center justify-center"
                        title="رفض"
                      >
                        ✕
                      </button>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              // عرض المحادثات
              <motion.div
                key="conversations"
                initial={{ opacity: 0, x: isRTL ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: isRTL ? 20 : -20 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="space-y-3"
              >
                {/* Loading indicator */}
                {loading && conversations.length === 0 && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
                    <span className="ml-2 text-[var(--text-secondary)]">Loading conversations...</span>
                  </div>
                )}

                {/* Error message */}
                {error && conversations.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <div className="text-red-500 mb-2">⚠️</div>
                    <p className="text-[var(--text-secondary)] mb-4">{error}</p>
                    <button
                      onClick={() => loadConversations(0, true)}
                      className="px-4 py-2 bg-[var(--accent-color)] text-white rounded-lg hover:bg-[var(--accent-color)]/90 transition-colors"
                    >
                      Try Again
                    </button>
                  </div>
                )}

                {/* Conversations list */}
                {filteredConversations.length > 0 && (
                  <>
                    {filteredConversations.map((community, index) => (
                      <motion.div
                        key={community.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.15, delay: index * 0.03 }}
                        onClick={() => handleChatSelect(community)}
                        className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all hover:bg-[var(--background)] ${
                          selectedChat?.id === community.id ? 'bg-[var(--background)] border border-[var(--accent-color)]/20' : ''
                        }`}
                      >
                        <div className="relative">
                          <ChatImage
                            src={community.avatar}
                            alt={community.name}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          {community.isOnline && (
                            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-[var(--background-secondary)] rounded-full"></div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h3 className="text-[var(--text-primary)] font-medium truncate">{community.name}</h3>
                            <span className="text-xs text-[var(--text-secondary)]">
                              {community.lastMessageAt ? formatLastSeen(community.lastMessageAt) : t('time.justNow')}
                            </span>
                          </div>
                          <p className="text-sm text-[var(--text-secondary)] truncate">
                            {community.lastMessage?.content || community.lastSeen}
                          </p>
                        </div>
                        
                        {community.unreadCount > 0 && (
                          <div className="bg-[var(--accent-color)] text-white text-xs rounded-full min-w-5 h-5 flex items-center justify-center px-1">
                            {community.unreadCount > 4 ? '4+' : community.unreadCount}
                          </div>
                        )}
                      </motion.div>
                    ))}

                    {/* Load more indicator */}
                    {loadingMore && (
                      <div className="flex items-center justify-center py-4">
                        <Loader2 className="w-5 h-5 animate-spin text-[var(--accent-color)]" />
                        <span className="ml-2 text-sm text-[var(--text-secondary)]">Loading more...</span>
                      </div>
                    )}

                    {/* No more conversations */}
                    {!hasMore && conversations.length > 0 && (
                      <div className="text-center py-4">
                        <p className="text-sm text-[var(--text-secondary)]">No more conversations</p>
                      </div>
                    )}
                  </>
                )}

                {/* Empty state */}
                {!loading && !error && conversations.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <MessageCircle className="w-12 h-12 text-[var(--text-secondary)] mb-4" />
                    <p className="text-[var(--text-secondary)] mb-2">No conversations yet</p>
                    <p className="text-sm text-[var(--text-secondary)] opacity-70">Start a new conversation to get started</p>
                  </div>
                )}

                {/* No search results */}
                {!loading && !error && conversations.length > 0 && filteredConversations.length === 0 && searchQuery && (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <Search className="w-12 h-12 text-[var(--text-secondary)] mb-4" />
                    <p className="text-[var(--text-secondary)] mb-2">No conversations found</p>
                    <p className="text-sm text-[var(--text-secondary)] opacity-70">Try searching with different keywords</p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Note Modal */}
      <NoteModal
        isOpen={showNoteModal}
        onClose={handleNoteModalClose}
        onSave={handleAddNote}
      />

    </div>
  );
}

// Main component with error boundary
export default function CommunitiesSidebar(props) {
  return <CommunitiesSidebarContent {...props} />;
} 