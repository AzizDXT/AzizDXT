import React, { useState, useRef, useEffect } from 'react';
import { useI18n } from '../utils/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { chatService, API_BASE_URL } from '../utils/api';
import api from '../utils/api';
import ChatImage from './ChatImage';
import { 
  Send, 
  Paperclip, 
  Smile, 
  MoreHorizontal, 
  Phone, 
  Video, 
  Search, 
  Image as ImageIcon,
  File,
  Mic,
  X,
  Edit,
  Reply,
  Forward,
  Copy,
  Flag,
  Trash2,
  MessageCircle,
  Info,
  Heart,
  Plus,
  Camera,
  Check,
  CheckCheck,
  ArrowUp,
  Play,
  Pause,
  Square
} from 'lucide-react';

// Wrapper component that safely uses useI18n
function CommunitiesChatContent({ selectedChat, onBack }) {
  // Safely get i18n values with fallbacks
  let t, isRTL;
  try {
    const i18n = useI18n();
    t = i18n.t;
    isRTL = i18n.isRTL;
  } catch (error) {
    console.warn('I18n not available in CommunitiesChat, using fallbacks:', error);
    // Fallback values
    t = (key) => key;
    isRTL = false;
  }
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [hoveredMessage, setHoveredMessage] = useState(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const messagesContainerRef = useRef(null);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);
  const [userHasScrolled, setUserHasScrolled] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef(null);
  const recordingIntervalRef = useRef(null);
  const [playingAudio, setPlayingAudio] = useState(null);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasNewMessages, setHasNewMessages] = useState(false);
  const audioRef = useRef(null);

  // دالة لتحديد ما إذا كانت الرسالة من المستخدم الحالي
  const isCurrentUser = (senderId) => {
    const userData = api.getUserData();
    return userData && userData.id && senderId === userData.id;
  };

  // Load messages from API when chat is selected
  useEffect(() => {
    if (selectedChat && selectedChat.id) {
      loadMessages(selectedChat.id);
      // Mark chat as seen when opened
      markChatAsSeen(selectedChat.id);
      // Always scroll to bottom when opening chat
      setShouldAutoScroll(true);
      setUserHasScrolled(false);
      // Check if there are new messages
      if (selectedChat.unreadCount > 0) {
        setHasNewMessages(true);
        // Hide the indicator after 3 seconds
        setTimeout(() => setHasNewMessages(false), 3000);
      }
    }
  }, [selectedChat]);

  // Mark chat as seen
  const markChatAsSeen = async (roomId) => {
    try {
      await chatService.markChatAsSeen(roomId);
    } catch (error) {
      console.error('Failed to mark chat as seen:', error);
    }
  };

  // Load messages for a specific chat room
  const loadMessages = async (roomId) => {
    try {
      // Load latest 10 messages
      const response = await chatService.getChatMessages(roomId, 10, 0);
      if (response.messages) {
        const formattedMessages = response.messages.map(message => ({
          id: message.id,
          roomId: message.room_id,
          senderId: message.sender_id,
          senderName: message.sender?.name || 'Unknown User',
          senderUsername: message.sender?.username || 'unknown',
          senderAvatar: message.sender?.profile_image_url,
          content: message.content,
          timestamp: 'الآن',
          sentAt: message.sent_at,
          type: message.message_type || 'TEXT',
          status: message.status || 'SENT',
          isDeleted: message.is_deleted || false,
          deletedAt: message.deleted_at,
          replyToId: message.reply_to_id,
          replyTo: message.reply_to,
          reactions: message.reactions || [],
          attachments: message.attachments || [],
          mediaUrl: message.media_url,
          mediaType: message.media_type,
          mediaMetadata: message.media_metadata || {}
        }));
        setMessages(formattedMessages);
      }
    } catch (error) {
      console.error('Failed to load messages:', error);
      setMessages([]);
    }
  };

  // دالة تحميل المزيد من الرسائل
  const loadMoreMessages = async () => {
    if (!selectedChat || isLoadingMore) return;
    
    setIsLoadingMore(true);
    try {
      const response = await chatService.getChatMessages(selectedChat.id, 10, messages.length);
      if (response.messages) {
        const formattedMessages = response.messages.map(message => ({
          id: message.id,
          roomId: message.room_id,
          senderId: message.sender_id,
          senderName: message.sender?.name || 'Unknown User',
          senderUsername: message.sender?.username || 'unknown',
          senderAvatar: message.sender?.profile_image_url,
          content: message.content,
          timestamp: 'الآن',
          sentAt: message.sent_at,
          type: message.message_type || 'TEXT',
          status: message.status || 'SENT',
          isDeleted: message.is_deleted || false,
          deletedAt: message.deleted_at,
          replyToId: message.reply_to_id,
          replyTo: message.reply_to,
          reactions: message.reactions || [],
          attachments: message.attachments || [],
          mediaUrl: message.media_url,
          mediaType: message.media_type,
          mediaMetadata: message.media_metadata || {}
        }));
        
        // إضافة الرسائل الجديدة في بداية المصفوفة
        setMessages(prev => [...formattedMessages, ...prev]);
      }
    } catch (error) {
      console.error('Failed to load more messages:', error);
    } finally {
      setIsLoadingMore(false);
    }
  };


  // منطق ذكي للتمرير
  useEffect(() => {
    if (shouldAutoScroll && !userHasScrolled) {
    scrollToBottom();
    }
  }, [messages, shouldAutoScroll, userHasScrolled]);

  // مراقبة التمرير من المستخدم
  const handleScroll = () => {
    if (!messagesContainerRef.current) return;
    
    const container = messagesContainerRef.current;
    const { scrollTop, scrollHeight, clientHeight } = container;
    
    // إذا كان المستخدم قريب من الأسفل (ضمن 100px)، اسمح بالتمرير التلقائي
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
    
    if (isNearBottom) {
      setUserHasScrolled(false);
      setShouldAutoScroll(true);
    } else {
      setUserHasScrolled(true);
      setShouldAutoScroll(false);
    }
    
    // إذا كان المستخدم قريب من الأعلى (ضمن 100px)، حمّل المزيد من الرسائل
    const isNearTop = scrollTop < 100;
    
    if (isNearTop && !isLoadingMore && messages.length > 0) {
      loadMoreMessages();
    }
  };

  const scrollToBottom = () => {
    if (messagesEndRef.current && shouldAutoScroll) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSendMessage = async () => {
    if (message.trim() && selectedChat) {
              const userData = api.getUserData();
              const newMessage = {
          id: crypto.randomUUID(),
          senderId: userData?.id || 'me',
          senderName: userData?.name || t('communities.chat.title'),
          content: message,
          timestamp: 'الآن',
          type: 'text',
        status: 'sending'
        };
      
      setMessages(prev => [...prev, newMessage]);
      setMessage('');
      setReplyTo(null);
      
      // إعادة تعيين التمرير التلقائي عند إرسال رسالة جديدة
      setShouldAutoScroll(true);
      setUserHasScrolled(false);
      
      try {
        // Send message via API
        const response = await chatService.sendMessage(selectedChat.id, message, [], null);
        
        // Update message status to sent
        setMessages(prev => prev.map(msg => 
          msg.id === newMessage.id 
            ? { ...msg, id: response.message_id, status: 'sent' }
            : msg
        ));
      
        
      } catch (error) {
        console.error('Failed to send message:', error);
        // Update message status to failed
        setMessages(prev => prev.map(msg => 
          msg.id === newMessage.id 
            ? { ...msg, status: 'failed' }
            : msg
        ));
      }
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleAttachment = (type, file) => {
    setShowAttachmentMenu(false);
    // Handle different attachment types
    console.log(`Attaching ${type}`, file);
  };

  // دالة تسجيل الصوت
  const handleVoiceRecord = async () => {
    try {
      if (!isRecording) {
        // بدء التسجيل
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        
        const chunks = [];
        mediaRecorder.ondataavailable = (event) => {
          chunks.push(event.data);
        };
        
        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'audio/wav' });
          const audioUrl = URL.createObjectURL(blob);
          
          // إضافة الرسالة الصوتية
          const userData = api.getUserData();
          const voiceMessage = {
            id: crypto.randomUUID(),
            senderId: userData?.id || 'me',
            senderName: userData?.name || t('communities.chat.title'),
            content: 'رسالة صوتية',
            timestamp: 'الآن',
            type: 'voice',
            audioUrl: audioUrl,
            duration: recordingTime,
            status: 'sent'
          };
          
          setMessages(prev => [...prev, voiceMessage]);
          setRecordingTime(0);
          setIsRecording(false);
          
          // إيقاف التسجيل
          stream.getTracks().forEach(track => track.stop());
          
          // إعادة تعيين التمرير التلقائي
          setShouldAutoScroll(true);
          setUserHasScrolled(false);
        };
        
        mediaRecorder.start();
        setIsRecording(true);
        setRecordingTime(0);
        
        // بدء عداد الوقت
        recordingIntervalRef.current = setInterval(() => {
          setRecordingTime(prev => prev + 1);
        }, 1000);
        
      } else {
        // إيقاف التسجيل
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
          mediaRecorderRef.current.stop();
        }
        if (recordingIntervalRef.current) {
          clearInterval(recordingIntervalRef.current);
        }
      }
    } catch (error) {
      console.error('Error recording voice:', error);
      alert('لا يمكن الوصول إلى الميكروفون');
    }
  };

  // دالة تشغيل الرسائل الصوتية
  const handlePlayAudio = (audioUrl, messageId) => {
    if (playingAudio === messageId) {
      // إيقاف التشغيل
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      setPlayingAudio(null);
    } else {
      // تشغيل رسالة صوتية جديدة
      if (audioRef.current) {
        audioRef.current.pause();
      }
      
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      
      audio.onended = () => {
        setPlayingAudio(null);
      };
      
      audio.onerror = () => {
        console.error('Error playing audio');
        setPlayingAudio(null);
      };
      
      audio.play();
      setPlayingAudio(messageId);
    }
  };

  // دالة إدارة التفاعلات
  const handleReaction = async (messageId, reactionType) => {
    try {
      const currentMessage = messages.find(m => m.id === messageId);
      const currentReactions = currentMessage?.reactions || {};
        const currentCount = currentReactions[reactionType] || 0;
        
        if (currentCount > 0) {
        // إزالة التفاعل
        await chatService.removeReaction(selectedChat.id, messageId, reactionType);
      } else {
        // إضافة التفاعل
        await chatService.addReaction(selectedChat.id, messageId, reactionType);
      }
      
      // تحديث الواجهة محلياً
      setMessages(prev => prev.map(message => {
        if (message.id === messageId) {
          const newReactions = { ...currentReactions };
          
          if (currentCount > 0) {
          if (newReactions[reactionType] === 1) {
            delete newReactions[reactionType];
          } else {
            newReactions[reactionType] = currentCount - 1;
          }
        } else {
            newReactions[reactionType] = (newReactions[reactionType] || 0) + 1;
          }
          
          return { ...message, reactions: newReactions };
      }
      return message;
    }));
    } catch (error) {
      console.error('Failed to handle reaction:', error);
    }
  };

  // تنظيف عند إغلاق المكون
  useEffect(() => {
    return () => {
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handleMessageAction = async (action, message) => {
    setSelectedMessage(null);
    switch (action) {
      case 'reply':
        setReplyTo(message);
        break;
      case 'forward':
        console.log('Forward message:', message);
        // TODO: Implement forward functionality
        break;
      case 'copy':
        navigator.clipboard.writeText(message.content);
        break;
      case 'edit':
        console.log('Edit message:', message);
        // TODO: Implement edit functionality
        break;
      case 'report':
        console.log('Report message:', message);
        // TODO: Implement report functionality
        break;
      case 'delete':
        try {
          await chatService.deleteMessage(selectedChat.id, message.id);
        setMessages(prev => prev.filter(m => m.id !== message.id));
        } catch (error) {
          console.error('Failed to delete message:', error);
        }
        break;
      default:
        break;
    }
  };

  const isEmojiOnly = (text) => {
    const emojiRegex = /^[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]+$/u;
    return emojiRegex.test(text.trim());
  };



  // فحص أمان - إذا لم تكن هناك محادثة محددة، اعرض رسالة خطأ
  if (!selectedChat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[var(--background)]">
        <div className="text-center text-[var(--text-secondary)]">
          <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg">لا توجد محادثة محددة</p>
          <p className="text-sm opacity-70">يرجى اختيار محادثة من القائمة</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[var(--background)]">
      {/* Header - جعلته نحيف */}
      <div className="flex items-center justify-between p-3 border-b border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-1.5 hover:bg-[var(--background)] rounded-lg transition-all duration-200"
          >
            <ArrowUp className="w-4 h-4 rotate-90" />
            </button>
          
          <div className="relative">
            <ChatImage
              src={selectedChat.avatar}
              alt={selectedChat.name}
              className="w-8 h-8 rounded-full object-cover"
            />
            {selectedChat.isOnline && (
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-[var(--background-secondary)] rounded-full"></div>
            )}
      </div>

          <div>
            <h3 
              className="text-[var(--text-primary)] text-lg font-semibold mb-0.5"
            dir={isRTL ? 'rtl' : 'ltr'}
            style={{ 
                fontSize: '1.125rem',
                lineHeight: '1.3',
              fontFamily: isRTL ? 'inherit' : 'inherit'
            }}
          >
            {selectedChat.name}
          </h3>
          <p 
              className="text-[var(--text-secondary)] text-xs mb-0.5"
            dir={isRTL ? 'rtl' : 'ltr'}
            style={{ 
                fontSize: '0.75rem',
                lineHeight: '1.3'
            }}
          >
            {selectedChat.username} · {selectedChat.isOnline ? t('communities.chat.online') : selectedChat.lastSeen}
          </p>
          </div>
        </div>
          
        {/* زر profile.view في الجانب المقابل */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              if (selectedChat.userId) {
                // Navigate to user profile or open profile modal
                console.log('View profile for user:', selectedChat.userId);
              }
            }}
            className={`bg-transparent border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--background)] px-3 py-1.5 rounded-lg transition-all duration-200 text-xs ${isRTL ? 'arabic-button' : ''}`}
            dir={isRTL ? 'rtl' : 'ltr'}
            style={{ 
              fontSize: '0.75rem',
              lineHeight: '1.3'
            }}
          >
            {isRTL ? 'عرض الملف الشخصي' : 'View Profile'}
          </button>
        </div>
      </div>

      {/* منطقة الرسائل */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto overflow-x-hidden p-4 space-y-4 custom-scrollbar"
        onScroll={handleScroll}
        style={{ 
          scrollBehavior: 'smooth',
          scrollbarWidth: 'thin',
          scrollbarColor: 'rgba(156, 163, 175, 0.3) transparent'
        }}
      >
        {/* مؤشر تحميل المزيد من الرسائل */}
        {isLoadingMore && (
          <div className="flex justify-center py-4">
            <div className="flex items-center gap-2 text-[var(--text-secondary)]">
              <div className="w-4 h-4 border-2 border-[var(--accent-color)] border-t-transparent rounded-full animate-spin"></div>
              <span className="text-sm">{t('communities.chat.loadingMore')}</span>
            </div>
          </div>
        )}
        
        {/* مؤشر الرسائل الجديدة */}
        {hasNewMessages && (
          <div className="flex justify-center py-2">
            <div className="bg-[var(--accent-color)] text-white px-4 py-1 rounded-full text-xs font-medium shadow-lg animate-pulse">
              {t('communities.chat.newMessages')}
            </div>
          </div>
        )}
        
        {messages.map((message, index) => {
          // منطق تجميع الرسائل
          const showTimeDivider = false; // تم إزالة عرض الوقت
          
          // فحص إذا كان يوم جديد
          const showDateDivider = false; // تم إزالة عرض التاريخ
          
          // فحص إذا كانت الرسالة جزء من مجموعة
          const isGrouped = (() => {
            if (index === 0) return false;
            
            const currentMessage = message;
            const previousMessage = messages[index - 1];
            
            // إذا كان المرسل مختلف، ليست مجموعة
            if (currentMessage.senderId !== previousMessage.senderId) return false;
            
            // افتراض أن الرسائل المتتالية من نفس المرسل هي مجموعة
            return true;
          })();
          
          // فحص إذا كانت هذه آخر رسالة في المجموعة
          const isLastInGroup = (() => {
            if (index === messages.length - 1) return true; // آخر رسالة في الشات
            
            const currentMessage = message;
            const nextMessage = messages[index + 1];
            
            // إذا كان المرسل مختلف، هذه آخر رسالة في المجموعة
            if (currentMessage.senderId !== nextMessage.senderId) return true;
            
            // افتراض أن الرسائل المتتالية من نفس المرسل هي مجموعة
            return false;
          })();

          return (
            <React.Fragment key={message.id}>
              
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-end gap-2 relative ${
              isRTL 
                ? (isCurrentUser(message.senderId) ? 'justify-start' : 'justify-end')
                : (isCurrentUser(message.senderId) ? 'justify-end' : 'justify-start')
            }`}
          >
                
                {/* صورة المرسل - للرسائل التي ليست من المستخدم الحالي */}
                {!isCurrentUser(message.senderId) && !isGrouped && (
                  <div className={`relative flex-shrink-0 ${
                    isRTL 
                      ? 'order-2' 
                      : 'order-1'
                  }`}>
                    <ChatImage
                      src={message.senderAvatar}
                      alt={message.senderName}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  </div>
                )}
                
                {/* مساحة فارغة للرسائل المجمعة */}
                {!isCurrentUser(message.senderId) && isGrouped && (
                  <div className={`w-8 flex-shrink-0 ${
                    isRTL 
                      ? 'order-2' 
                      : 'order-1'
                  }`}></div>
                )}
                
            <div className={`${
              // تعديل ترتيب الرسائل حسب RTL/LTR
              isRTL 
                ? (isCurrentUser(message.senderId) ? 'order-1' : 'order-2')
                : (isCurrentUser(message.senderId) ? 'order-2' : 'order-1')
            } ${
              // إذا كانت الرسالة إيموجي فقط، لا نضع خلفية
              isEmojiOnly(message.content) 
                ? 'bg-transparent' 
                : isCurrentUser(message.senderId) 
                  ? 'bg-gray-800 text-white dark:bg-gray-700' 
                  : 'bg-white text-gray-800 dark:bg-gray-200 dark:text-gray-800'
            } ${
              isEmojiOnly(message.content) 
                ? 'p-1' 
                : 'max-w-xs lg:max-w-md rounded-2xl px-4 py-2'
                } relative arabic-message-bubble group ${
                  // إضافة padding أقل للرسائل المجمعة
                  isGrouped ? 'mb-1' : 'mb-3'
                }`}>
                  
                  {/* عرض الرسالة الصوتية */}
                  {message.type === 'voice' ? (
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[var(--accent-color)] rounded-full flex items-center justify-center">
                        <Mic className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <button 
                            onClick={() => handlePlayAudio(message.audioUrl, message.id)}
                            className={`w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200 ${
                              playingAudio === message.id 
                                ? 'bg-white text-[var(--accent-color)]' 
                                : 'bg-white/20 text-white hover:bg-white/30'
                            }`}
                          >
                            {playingAudio === message.id ? (
                              <Pause className="w-3 h-3" />
                            ) : (
                              <Play className="w-3 h-3" />
                            )}
                          </button>
                          <span className="text-xs text-white/80">
                            {Math.floor(message.duration / 60)}:{(message.duration % 60).toString().padStart(2, '0')}
                          </span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-1">
                          <div 
                            className={`h-1 rounded-full transition-all duration-200 ${
                              playingAudio === message.id ? 'bg-white' : 'bg-white/40'
                            }`} 
                            style={{ 
                              width: playingAudio === message.id ? '100%' : '0%',
                              animation: playingAudio === message.id ? 'pulse 2s infinite' : 'none'
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {/* عرض النص */}
                      {message.content && (
              <p 
                className={`${isEmojiOnly(message.content) ? 'text-4xl' : 'text-sm'} ${isRTL ? 'text-right arabic-text' : 'text-left'}`}
                dir={isRTL ? 'rtl' : 'ltr'}
                style={{ 
                  fontSize: isEmojiOnly(message.content) ? '2.25rem' : '0.875rem',
                  lineHeight: '1.5',
                  fontFamily: isRTL ? 'inherit' : 'inherit',
                  wordBreak: 'break-word',
                  whiteSpace: 'pre-wrap'
                }}
              >
                {message.content}
              </p>
                      )}
                      
                      {/* عرض المرفقات */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="space-y-2">
                          {message.attachments.map((attachment, idx) => (
                            <div key={idx} className="relative">
                              {attachment.file_type === 'image' ? (
                                <div className="relative group">
                                  <ChatImage
                                    src={attachment.file_url}
                                    alt={attachment.filename || 'Image'}
                                    className="max-w-xs rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                    onClick={() => {
                                      // يمكن إضافة modal لعرض الصورة بحجم كامل
                                      window.open(`${API_BASE_URL}${attachment.file_url}`, '_blank');
                                    }}
                                  />
                                  {attachment.filename && (
                                    <div className="absolute bottom-2 left-2 right-2 bg-black/70 text-white text-xs p-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                      {attachment.filename}
                                    </div>
                                  )}
                                </div>
                              ) : attachment.file_type === 'document' ? (
                                <div className="flex items-center gap-3 p-3 bg-white/10 rounded-lg border border-white/20">
                                  <File className="w-8 h-8 text-white/80" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm text-white truncate">
                                      {attachment.filename || 'Document'}
                                    </p>
                                    {attachment.size && (
                                      <p className="text-xs text-white/60">
                                        {(attachment.size / 1024 / 1024).toFixed(2)} MB
                                      </p>
                                    )}
                                  </div>
                                  <button
                                    onClick={() => {
                                      window.open(`${API_BASE_URL}${attachment.file_url}`, '_blank');
                                    }}
                                    className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-xs rounded transition-colors"
                                  >
                                    Download
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-3 p-3 bg-white/10 rounded-lg border border-white/20">
                                  <File className="w-8 h-8 text-white/80" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm text-white truncate">
                                      {attachment.filename || 'File'}
                                    </p>
                                    {attachment.size && (
                                      <p className="text-xs text-white/60">
                                        {(attachment.size / 1024 / 1024).toFixed(2)} MB
                                      </p>
                                    )}
                                  </div>
                                  <button
                                    onClick={() => {
                                      window.open(`${API_BASE_URL}${attachment.file_url}`, '_blank');
                                    }}
                                    className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-xs rounded transition-colors"
                                  >
                                    Download
                                  </button>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* عرض الصورة الرئيسية إذا كانت موجودة */}
                      {message.mediaUrl && message.mediaType === 'image' && (
                        <div className="relative group">
                          <ChatImage
                            src={message.mediaUrl}
                            alt="Media"
                            className="max-w-xs rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                            onClick={() => {
                              window.open(`${API_BASE_URL}${message.mediaUrl}`, '_blank');
                            }}
                          />
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* التفاعلات في حافة الرسالة */}
                  {message.reactions && Object.keys(message.reactions).length > 0 && (
                    <div className={`absolute -bottom-2 ${
                      isRTL 
                        ? (isCurrentUser(message.senderId) ? 'left-2' : 'right-2')
                        : (isCurrentUser(message.senderId) ? 'right-2' : 'left-2')
                    } flex items-center gap-1 bg-[var(--background)] px-2 py-1 rounded-full border border-[var(--border-color)] shadow-sm`}>
                      {Object.entries(message.reactions).slice(0, 3).map(([type, count]) => (
                        <span key={type} className="text-xs">
                          {type === 'like' && '❤️'}
                          {type === 'laugh' && '😂'}
                          {type === 'wow' && '😮'}
                          {type === 'love' && '🥰'}
                          {type === 'shock' && '😱'}
                          {count > 1 && count}
                        </span>
                      ))}
                      {Object.keys(message.reactions).length > 3 && (
                        <span className="text-xs text-[var(--text-secondary)]">
                          +{Object.keys(message.reactions).length - 3}
                        </span>
                      )}
                </div>
              )}
                  
                  {/* إضافة مساحة إضافية أسفل الرسائل التي تحتوي على تفاعلات */}
                  {message.reactions && Object.keys(message.reactions).length > 0 && (
                    <div className="h-8"></div>
                  )}
            </div>
            
                
                {/* أزرار الأدوات - تظهر بجانب الرسالة */}
                <div className={`order-3 flex items-center gap-1 mt-1 ${
                  isRTL 
                    ? (isCurrentUser(message.senderId) ? 'justify-end' : 'justify-start')
                    : (isCurrentUser(message.senderId) ? 'justify-end' : 'justify-start')
                }`}>
                  
                  {/* زر التفاعلات (إيموجي) */}
                  <button
                    onClick={() => setHoveredMessage(hoveredMessage === message.id ? null : message.id)}
                    className="p-1.5 hover:bg-[var(--background-secondary)] rounded-full transition-all duration-200 opacity-100"
                    title="تفاعلات"
                  >
                    <Smile className="w-4 h-4 text-[var(--text-secondary)]" />
                  </button>
                  
                  {/* زر الرد */}
                  <button
                    onClick={() => handleMessageAction('reply', message)}
                    className="p-1.5 hover:bg-[var(--background-secondary)] rounded-full transition-all duration-200 opacity-100"
                    title="رد"
                  >
                    <Reply className="w-4 h-4 text-[var(--text-secondary)]" />
                  </button>
                  
                  {/* زر التفاصيل (3 نقاط) */}
                  <button
                    onClick={() => setSelectedMessage(message)}
                    className="p-1.5 hover:bg-[var(--background-secondary)] rounded-full transition-all duration-200 opacity-100"
                    title="تفاصيل الرسالة"
                  >
                    <MoreHorizontal className="w-4 h-4 text-[var(--text-secondary)]" />
                  </button>
                </div>
                
                {/* قائمة التفاعلات - تظهر عند الضغط على زر الإيموجي */}
                {hoveredMessage === message.id && (
                  <div className={`absolute top-0 z-30 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-lg p-2 shadow-lg ${
                    isRTL 
                      ? (isCurrentUser(message.senderId) 
                          ? 'left-0' 
                          : 'right-0 -translate-x-full')
                      : (isCurrentUser(message.senderId) 
                          ? 'right-0 -translate-x-full' 
                          : 'left-0')
                  }`}>
                    <div className="flex gap-2">
                      {/* إعجاب */}
                      <button
                        onClick={() => {
                          handleReaction(message.id, 'like');
                          setHoveredMessage(null);
                        }}
                        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                          message.reactions?.like ? 'bg-red-100 text-red-500' : 'hover:bg-[var(--background)]'
                        }`}
                        title="إعجاب"
                      >
                        <Heart 
                          className={`w-5 h-5 ${message.reactions?.like ? 'fill-current' : ''}`} 
                        />
                      </button>
                      
                      {/* ضحك */}
                      <button
                        onClick={() => {
                          handleReaction(message.id, 'laugh');
                          setHoveredMessage(null);
                        }}
                        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                          message.reactions?.laugh ? 'bg-yellow-100 text-yellow-500' : 'hover:bg-[var(--background)]'
                        }`}
                        title="ضحك"
                      >
                        <span className="text-xl">😂</span>
                      </button>
                      
                      {/* تعجب */}
                      <button
                        onClick={() => {
                          handleReaction(message.id, 'wow');
                          setHoveredMessage(null);
                        }}
                        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                          message.reactions?.wow ? 'bg-blue-100 text-blue-500' : 'hover:bg-[var(--background)]'
                        }`}
                        title="تعجب"
                      >
                        <span className="text-xl">😮</span>
                      </button>
                      
                      {/* حب */}
                      <button
                        onClick={() => {
                          handleReaction(message.id, 'love');
                          setHoveredMessage(null);
                        }}
                        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                          message.reactions?.love ? 'bg-pink-100 text-pink-500' : 'hover:bg-[var(--background)]'
                        }`}
                        title="حب"
                      >
                        <span className="text-xl">🥰</span>
                      </button>
                      
                      {/* صدمة */}
                      <button
                        onClick={() => {
                          handleReaction(message.id, 'shock');
                          setHoveredMessage(null);
                        }}
                        className={`p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                          message.reactions?.shock ? 'bg-purple-100 text-purple-500' : 'hover:bg-[var(--background)]'
                        }`}
                        title="صدمة"
                      >
                        <span className="text-xl">😱</span>
                      </button>
                  </div>
                </div>
              )}

                {/* Message Actions - تظهر عند الضغط على زر ثلاث نقاط */}
                {selectedMessage && selectedMessage.id === message.id && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={`absolute top-0 z-40 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-lg p-2 shadow-lg ${
                      isRTL 
                        ? (isCurrentUser(message.senderId) 
                            ? 'left-0' 
                            : 'right-0 -translate-x-full')
                        : (isCurrentUser(message.senderId) 
                            ? 'right-0 -translate-x-full' 
                            : 'left-0')
                    }`}
                    style={{
                      transform: isRTL 
                        ? (isCurrentUser(message.senderId) 
                            ? 'translateX(0)' 
                            : 'translateX(100%)')
                        : (isCurrentUser(message.senderId) 
                            ? 'translateX(-100%)' 
                            : 'translateX(0)')
                    }}
                  >
                    <div className="flex flex-col gap-1">
                      
                      {/* زر الرد */}
                  <button
                    onClick={() => handleMessageAction('reply', message)}
                        className="flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02] whitespace-nowrap"
                  >
                        <Reply className="w-4 h-4" />
                        <span>رد</span>
                  </button>
                      
                      {/* زر النسخ */}
                  <button
                    onClick={() => handleMessageAction('copy', message)}
                        className="flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02] whitespace-nowrap"
                  >
                        <Copy className="w-4 h-4" />
                        <span>نسخ</span>
                  </button>
                      
                      {/* زر التعديل (للمستخدم فقط) */}
                  {isCurrentUser(message.senderId) && (
                    <button
                      onClick={() => handleMessageAction('edit', message)}
                          className="flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02] whitespace-nowrap"
                    >
                          <Edit className="w-4 h-4" />
                          <span>تعديل</span>
                    </button>
                  )}
                      
                      {/* زر الإبلاغ */}
                  <button
                    onClick={() => handleMessageAction('report', message)}
                        className="flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02] whitespace-nowrap"
                  >
                        <Flag className="w-4 h-4" />
                        <span>إبلاغ</span>
                  </button>
                      
                      {/* زر الحذف (للمستخدم فقط) */}
                  {isCurrentUser(message.senderId) && (
                    <button
                      onClick={() => handleMessageAction('delete', message)}
                          className="flex items-center gap-2 px-3 py-2 hover:bg-red-900 text-red-400 rounded text-sm transition-all duration-200 hover:scale-[1.02] whitespace-nowrap"
                    >
                          <Trash2 className="w-4 h-4" />
                          <span>حذف</span>
                    </button>
                  )}
                </div>
              </motion.div>
                )}
                  
                  
          </motion.div>
              </React.Fragment>
            );
          })}
        

        {/* Reply Preview */}
        {replyTo && (
          <div className="bg-[var(--background-secondary)] border-l-4 border-[var(--accent-color)] rounded-lg p-3 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm text-[var(--text-secondary)] mb-1">
                  رد على {replyTo.senderName}
                </p>
                <p className="text-sm text-[var(--text-primary)] line-clamp-2">
                  {replyTo.content}
                </p>
              </div>
              <button
                onClick={() => setReplyTo(null)}
                className="p-1 hover:bg-[var(--background)] rounded transition-all duration-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
        
        {/* Reference for auto-scroll */}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[var(--background)] relative">
        <div className="flex items-center gap-3">
          {/* زر المرفقات */}
            <button 
            onClick={() => setShowAttachmentMenu(!showAttachmentMenu)}
            className="p-2.5 hover:bg-[var(--background-secondary)] rounded-lg transition-all duration-200"
            title="مرفقات"
          >
            <Paperclip className="w-5 h-5" />
            </button>
          
          {/* قائمة المرفقات */}
          {showAttachmentMenu && (
            <div className="absolute bottom-full mb-2 left-4 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-lg p-3 shadow-2xl z-50">
              <div className="grid grid-cols-2 gap-3">
            <button 
                  onClick={() => {
                    document.getElementById('imageInput').click();
                    setShowAttachmentMenu(false);
                  }}
                  className="flex flex-col items-center gap-2 p-3 hover:bg-[var(--background)] rounded-lg transition-all duration-200"
                >
                  <ImageIcon className="w-6 h-6 text-[var(--accent-color)]" />
                  <span className="text-sm font-medium">صورة</span>
            </button>
                <button
                  onClick={() => {
                    document.getElementById('fileInput').click();
                    setShowAttachmentMenu(false);
                  }}
                  className="flex flex-col items-center gap-2 p-3 hover:bg-[var(--background)] rounded-lg transition-all duration-200"
                >
                  <File className="w-6 h-6 text-[var(--accent-color)]" />
                  <span className="text-sm font-medium">ملف</span>
                </button>
                <button
                  onClick={() => {
                    document.getElementById('cameraInput').click();
                    setShowAttachmentMenu(false);
                  }}
                  className="flex flex-col items-center gap-2 p-3 hover:bg-[var(--background)] rounded-lg transition-all duration-200"
                >
                  <Camera className="w-6 h-6 text-[var(--accent-color)]" />
                  <span className="text-sm font-medium">كاميرا</span>
                </button>
                <button
                  onClick={() => {
                    handleVoiceRecord();
                    setShowAttachmentMenu(false);
                  }}
                  className="flex flex-col items-center gap-2 p-3 hover:bg-[var(--background)] rounded-lg transition-all duration-200"
                >
                  <Mic className="w-6 h-6 text-[var(--accent-color)]" />
                  <span className="text-sm font-medium">صوت</span>
                </button>
              </div>
            </div>
          )}
          
          {/* زر الإيموجيز */}
            <button 
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="p-2.5 hover:bg-[var(--background-secondary)] rounded-lg transition-all duration-200"
              title="إيموجي"
            >
            <Smile className="w-5 h-5" />
            </button>
            
          {/* منطقة الإدخال */}
            <div className="flex-1 relative">
            {isRecording ? (
              /* عرض الأمواج الصوتية أثناء التسجيل */
              <div className="w-full bg-[var(--background-secondary)] rounded-2xl px-4 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-[var(--text-secondary)]">
                    تسجيل... {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  {/* أمواج صوتية متحركة */}
                  {[...Array(5)].map((_, index) => (
                    <div
                      key={index}
                      className="w-1 bg-[var(--accent-color)] rounded-full animate-pulse"
                      style={{
                        height: `${Math.random() * 20 + 10}px`,
                        animationDelay: `${index * 0.1}s`
                      }}
                    ></div>
                  ))}
                </div>
              </div>
            ) : (
              /* خانة الإدخال العادية */
              <input
                ref={inputRef}
                type="text"
                placeholder={t('communities.chat.placeholder')}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                dir={isRTL ? 'rtl' : 'ltr'}
                className={`w-full bg-[var(--background-secondary)] text-[var(--text-primary)] placeholder-[var(--text-secondary)] rounded-2xl py-2 px-4 focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)]/40 transition-all duration-200 ${isRTL ? 'text-right arabic-input' : 'text-left'}`}
                style={{ 
                  fontSize: '16px', // منع التصغير في iOS
                  lineHeight: '1.5',
                  fontFamily: isRTL ? 'inherit' : 'inherit'
                }}
              />
            )}
            </div>
            
          {/* زر الإرسال - يظهر فقط عند الكتابة */}
          {message.trim() ? (
            <button 
              onClick={handleSendMessage}
              className="bg-[var(--accent-color)] hover:bg-[var(--accent-color)]/90 text-white p-2.5 rounded-xl transition-all duration-200 hover:scale-105 shadow-lg"
              title="إرسال"
            >
              <ArrowUp className="w-5 h-5 text-white" />
            </button>
          ) : (
            <button
              onClick={handleVoiceRecord}
              className={`p-2.5 rounded-xl transition-all duration-200 hover:scale-105 shadow-lg ${
                isRecording 
                  ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse' 
                  : 'bg-[var(--accent-color)] hover:bg-[var(--accent-color)]/90 text-white'
              }`}
              title={isRecording ? 'إيقاف التسجيل' : 'تسجيل صوتي'}
            >
              {isRecording ? (
                <Square className="w-5 h-5 text-white" />
              ) : (
                <Mic className="w-5 h-5 text-white" />
              )}
            </button>
          )}
          </div>
          
          {/* Emoji Picker */}
          {showEmojiPicker && (
          <div className="absolute bottom-full mb-2 left-0 right-0 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-2xl p-4 shadow-2xl z-50">
            <div className="grid grid-cols-8 gap-3">
                {['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩', '🥳', '😏', '😒'].map((emoji, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setMessage(prev => prev + emoji);
                      setShowEmojiPicker(false);
                    }}
                  className="text-3xl hover:bg-[var(--background)] rounded-lg p-2 transition-all duration-200 hover:scale-110"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Hidden File Inputs */}
        <input
          id="fileInput"
          type="file"
          className="hidden"
          onChange={(e) => handleAttachment('file', e.target.files[0])}
          accept=".pdf,.doc,.docx,.txt,.zip,.rar"
        />
        <input
          id="imageInput"
          type="file"
          className="hidden"
          onChange={(e) => handleAttachment('image', e.target.files[0])}
          accept="image/*"
        />
      <input
        id="cameraInput"
        type="file"
        className="hidden"
        onChange={(e) => handleAttachment('camera', e.target.files[0])}
        accept="image/*"
        capture="environment"
      />

      {/* Message Actions Modal */}
      {selectedMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-[var(--background-secondary)] rounded-lg p-4 min-w-48 border border-[var(--border-color)] shadow-2xl">
            <div className="space-y-2">
              <button
                onClick={() => handleMessageAction('reply', selectedMessage)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02]"
              >
                <Reply className="w-4 h-4" />
                {t('communities.chat.reply')}
              </button>
              <button
                onClick={() => handleMessageAction('forward', selectedMessage)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02]"
              >
                <Reply className="w-4 h-4" />
                <span>إعادة توجيه</span>
              </button>
              <button
                onClick={() => handleMessageAction('copy', selectedMessage)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02]"
              >
                <Copy className="w-4 h-4" />
                {t('communities.chat.copy')}
              </button>
              {isCurrentUser(selectedMessage.senderId) && (
                <button
                  onClick={() => handleMessageAction('edit', selectedMessage)}
                  className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02]"
                >
                  <Edit className="w-4 h-4" />
                  {t('communities.chat.edit')}
                </button>
              )}
              <button
                onClick={() => handleMessageAction('report', selectedMessage)}
                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[var(--background)] rounded text-sm text-[var(--text-primary)] transition-all duration-200 hover:scale-[1.02]"
              >
                <Flag className="w-4 h-4" />
                {t('communities.chat.report')}
              </button>
              {isCurrentUser(selectedMessage.senderId) && (
                <button
                  onClick={() => handleMessageAction('delete', selectedMessage)}
                  className="w-full flex items-center gap-2 px-3 py-2 hover:bg-red-900 text-red-400 rounded text-sm transition-all duration-200 hover:scale-[1.02]"
                >
                  <Trash2 className="w-4 h-4" />
                  {t('communities.chat.delete')}
                </button>
              )}
            </div>
            <button
              onClick={() => setSelectedMessage(null)}
              className="w-full mt-4 p-2 border border-[var(--border-color)] rounded text-[var(--text-primary)] hover:bg-[var(--background)] transition-all duration-200 hover:scale-[1.02]"
            >
              {t('common.cancel')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Main component with error boundary
export default function CommunitiesChat(props) {
  return <CommunitiesChatContent {...props} />;
} 