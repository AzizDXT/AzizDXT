import React, { useState } from 'react';
import { useI18n } from '../utils/i18n';
import { X, Save, Edit3 } from 'lucide-react';

export default function NoteModal({ isOpen, onClose, onSave }) {
  const { t, isRTL } = useI18n();
  const [noteText, setNoteText] = useState('');
  const [noteTitle, setNoteTitle] = useState('');

  const handleSave = () => {
    if (noteText.trim() && noteTitle.trim()) {
      onSave({
        id: Date.now(),
        title: noteTitle,
        text: noteText,
        createdAt: new Date().toISOString()
      });
      setNoteText('');
      setNoteTitle('');
      onClose();
    }
  };

  const handleClose = () => {
    setNoteText('');
    setNoteTitle('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className={`bg-[var(--background)] rounded-2xl p-6 w-full max-w-md mx-4 border border-[var(--border-color)] shadow-2xl ${isRTL ? 'text-right' : 'text-left'}`}>
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[var(--accent-color)] rounded-full flex items-center justify-center">
              <Edit3 className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">
              {t('communities.notes.addNote') || 'إضافة ملاحظة'}
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-[var(--background-secondary)] rounded-lg transition-all duration-200 hover:scale-110"
          >
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4">
          {/* Title Input */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('communities.notes.title') || 'العنوان'}
            </label>
            <input
              type="text"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              placeholder={t('communities.notes.titlePlaceholder') || 'أدخل عنوان الملاحظة'}
              className="w-full px-4 py-3 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-xl text-[var(--text-primary)] placeholder-[var(--text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] transition-all duration-200"
            />
          </div>

          {/* Note Text Input */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('communities.notes.content') || 'المحتوى'}
            </label>
            <textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder={t('communities.notes.contentPlaceholder') || 'اكتب ملاحظتك هنا...'}
              rows={6}
              className="w-full px-4 py-3 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-xl text-[var(--text-primary)] placeholder-[var(--text-secondary)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] transition-all duration-200 resize-none"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 mt-6">
          <button
            onClick={handleClose}
            className="flex-1 px-4 py-3 border border-[var(--border-color)] text-[var(--text-primary)] rounded-xl hover:bg-[var(--background-secondary)] transition-all duration-200 hover:scale-105 active:scale-95"
          >
            {t('common.cancel') || 'إلغاء'}
          </button>
          <button
            onClick={handleSave}
            disabled={!noteText.trim() || !noteTitle.trim()}
            className="flex-1 px-4 py-3 bg-[var(--accent-color)] text-white rounded-xl hover:bg-[var(--accent-color)]/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            {t('common.save') || 'حفظ'}
          </button>
        </div>
      </div>
    </div>
  );
} 