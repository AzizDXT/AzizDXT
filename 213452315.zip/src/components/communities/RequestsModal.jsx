import React, { useState } from 'react';
import { useI18n } from '../utils/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Check, 
  X as XIcon, 
  User, 
  Users, 
  Clock,
  MessageCircle
} from 'lucide-react';

export default function RequestsModal({ isOpen, onClose }) {
  const { t, isRTL } = useI18n();
  const [requests, setRequests] = useState([
    {
      id: 1,
      type: 'friend',
      sender: {
        id: 1,
        name: 'أحمد محمد',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد إضافة صديق',
      timestamp: 'منذ 5 دقائق',
      status: 'pending'
    },
    {
      id: 2,
      type: 'group',
      sender: {
        id: 2,
        name: 'سارة أحمد',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
        status: 'offline'
      },
      message: 'يريد الانضمام إلى مجموعة الدراسة',
      timestamp: 'منذ ساعة',
      status: 'pending'
    },
    {
      id: 3,
      type: 'friend',
      sender: {
        id: 3,
        name: 'محمد علي',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد إضافة صديق',
      timestamp: 'منذ 3 ساعات',
      status: 'pending'
    },
    {
      id: 4,
      type: 'group',
      sender: {
        id: 4,
        name: 'فاطمة حسن',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
        status: 'online'
      },
      message: 'يريد الانضمام إلى مجموعة الرياضيات',
      timestamp: 'منذ يوم',
      status: 'pending'
    }
  ]);

  const handleAccept = (requestId) => {
    setRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: 'accepted' }
          : req
      )
    );
    // هنا يمكن إضافة منطق قبول الطلب
    console.log('تم قبول الطلب:', requestId);
  };

  const handleReject = (requestId) => {
    setRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: 'rejected' }
          : req
      )
    );
    // هنا يمكن إضافة منطق رفض الطلب
    console.log('تم رفض الطلب:', requestId);
  };

  const getStatusIcon = (type) => {
    switch (type) {
      case 'friend':
        return <User className="w-4 h-4" />;
      case 'group':
        return <Users className="w-4 h-4" />;
      default:
        return <MessageCircle className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'accepted':
        return 'text-green-600 bg-green-100';
      case 'rejected':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-blue-600 bg-blue-100';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'accepted':
        return 'تم القبول';
      case 'rejected':
        return 'تم الرفض';
      default:
        return 'في الانتظار';
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.2 }}
          className="bg-[var(--background)] rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-[var(--accent-color)] rounded-lg">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('communities.requests.title')}
                </h2>
                <p className="text-sm text-[var(--text-secondary)]">
                  {requests.filter(r => r.status === 'pending').length} طلب في الانتظار
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[var(--background-secondary)] rounded-lg transition-colors"
            >
              <X className="w-6 h-6 text-[var(--text-secondary)]" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[60vh]">
            {requests.length === 0 ? (
              <div className="text-center py-8">
                <MessageCircle className="w-16 h-16 mx-auto text-[var(--text-secondary)] opacity-50 mb-4" />
                <p className="text-lg text-[var(--text-secondary)]">لا توجد طلبات</p>
              </div>
            ) : (
              <div className="space-y-4">
                {requests.map((request) => (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-[var(--background-secondary)] rounded-lg p-4 border border-[var(--border-color)]"
                  >
                    <div className="flex items-start gap-4">
                      {/* Avatar */}
                      <div className="relative">
                        <img
                          src={request.sender.avatar}
                          alt={request.sender.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[var(--background)] ${
                          request.sender.status === 'online' ? 'bg-green-500' : 'bg-gray-400'
                        }`} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-[var(--text-primary)] truncate">
                            {request.sender.name}
                          </h3>
                          <div className="flex items-center gap-1 text-xs text-[var(--text-secondary)]">
                            {getStatusIcon(request.type)}
                            <span className="capitalize">
                              {request.type === 'friend' ? 'صديق' : 'مجموعة'}
                            </span>
                          </div>
                        </div>
                        
                        <p className="text-sm text-[var(--text-secondary)] mb-2">
                          {request.message}
                        </p>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-[var(--text-secondary)]" />
                            <span className="text-xs text-[var(--text-secondary)]">
                              {request.timestamp}
                            </span>
                          </div>
                          
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                            {getStatusText(request.status)}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      {request.status === 'pending' && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleAccept(request.id)}
                            className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                            title="قبول"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleReject(request.id)}
                            className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                            title="رفض"
                          >
                            <XIcon className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
            <div className="flex items-center justify-between">
              <div className="text-sm text-[var(--text-secondary)]">
                إجمالي الطلبات: {requests.length}
              </div>
              <button
                onClick={onClose}
                className="px-4 py-2 bg-[var(--accent-color)] text-white rounded-lg hover:bg-[var(--accent-color)] transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
} 