import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function SplashScreen({ onFinish }) {
  const [isVisible, setIsVisible] = useState(true);
  const [logoLoaded, setLogoLoaded] = useState(false);
  const [pageLoaded, setPageLoaded] = useState(false);
  const [mounted, setMounted] = useState(false);
  
  // Default values for when i18n is not available
  const [appName, setAppName] = useState('Taleb');
  const [appTagline, setAppTagline] = useState('Experience the Exceptional');
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isRTL, setIsRTL] = useState(false);
  
  // Try to get i18n values if available
  useEffect(() => {
    try {
      // Check if i18n is available
      if (window.t && window.t('app.name')) {
        setAppName(window.t('app.name'));
        setAppTagline(window.t('app.tagline'));
      }
      
      // Check current language from multiple sources
      const htmlLang = document.documentElement.lang;
      const htmlDir = document.documentElement.dir;
      const localStorageLang = localStorage.getItem('taleb-language') || localStorage.getItem('language');
      const sessionStorageLang = sessionStorage.getItem('taleb-language') || sessionStorage.getItem('language');
      
      // Determine the current language
      let detectedLang = htmlLang || localStorageLang || sessionStorageLang || 'en';
      if (detectedLang) {
        setCurrentLanguage(detectedLang);
      }
      
      // Check for RTL support from multiple sources
      const rtlCheck = htmlDir === 'rtl' || 
                      htmlLang === 'ar' || 
                      htmlLang?.startsWith('ar') ||
                      localStorageLang === 'ar' ||
                      sessionStorageLang === 'ar' ||
                      detectedLang === 'ar' ||
                      detectedLang?.startsWith('ar');
      
      setIsRTL(rtlCheck);
      
      if (rtlCheck) {
        setCurrentLanguage('ar');
        // Set Arabic text if i18n is not available
        if (!window.t) {
          setAppName('طالب');
          setAppTagline('تجربة استثنائية');
        }
      }
      
      console.log('🌍 Splash Screen Language Detection:', {
        htmlLang,
        htmlDir,
        localStorageLang,
        sessionStorageLang,
        detectedLang,
        isRTL: rtlCheck,
        finalLanguage: rtlCheck ? 'ar' : detectedLang
      });
    } catch (error) {
      // i18n not available, use defaults
      console.log('i18n not available, using default values');
    }
  }, []);

  // Use system preference for dark mode
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    setMounted(true);
    
    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e) => setIsDark(e.matches);
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  useEffect(() => {
    // Check if page is fully loaded
    const handleLoad = () => {
      setPageLoaded(true);
    };

    // Check current ready state
    if (document.readyState === 'complete') {
      setPageLoaded(true);
    } else {
      window.addEventListener('load', handleLoad);
      // Also listen for DOMContentLoaded as a fallback
      document.addEventListener('DOMContentLoaded', () => {
        setPageLoaded(true);
      });
    }

    // Fallback: ensure page is marked as loaded after a reasonable time
    const timeoutFallback = setTimeout(() => {
      setPageLoaded(true);
    }, 1000);

    // Additional fallback: ensure logo is marked as loaded after a reasonable time
    const logoFallback = setTimeout(() => {
      setLogoLoaded(true);
    }, 1500);

    return () => {
      window.removeEventListener('load', handleLoad);
      document.removeEventListener('DOMContentLoaded', () => {
        setPageLoaded(true);
      });
      clearTimeout(timeoutFallback);
      clearTimeout(logoFallback);
    };
  }, []);

  useEffect(() => {
    // Hide splash only when both logo and page are loaded, with minimum 2s display
    if (logoLoaded && pageLoaded) {
      const minDisplayTimer = setTimeout(() => {
        setIsVisible(false);
        // Dispatch custom event for PWA install prompt
        window.dispatchEvent(new CustomEvent('splashScreenComplete'));
        setTimeout(onFinish, 500); // Allow fade out animation to complete
      }, 2000); // Minimum 2 seconds display

      return () => clearTimeout(minDisplayTimer);
    }
    
    // Fallback: if page takes too long to load, show splash for at least 3 seconds
    const fallbackTimer = setTimeout(() => {
      if (!pageLoaded) {
        setPageLoaded(true);
      }
    }, 3000);

    // Additional fallback: ensure splash is hidden after maximum time
    const maxDisplayTimer = setTimeout(() => {
      setIsVisible(false);
      // Dispatch custom event for PWA install prompt
      window.dispatchEvent(new CustomEvent('splashScreenComplete'));
      setTimeout(onFinish, 500);
    }, 5000);

    return () => {
      clearTimeout(fallbackTimer);
      clearTimeout(maxDisplayTimer);
    };
  }, [logoLoaded, pageLoaded, onFinish]);

  // Don't render content until mounted to prevent hydration mismatch
  if (!mounted) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-[hsl(var(--background))] text-center"
           dir={isRTL ? 'rtl' : 'ltr'}>
        <style>
          {`
            @font-face {
              font-family: 'IBMPlexSansArabic';
              src: url('/src/assets/fonts/IBMPlexSansArabic.ttf') format('truetype');
              font-weight: normal;
              font-style: normal;
              font-display: block;
              unicode-range: U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF, U+0660-0669;
            }
            
            @font-face {
              font-family: 'Nekst';
              src: url('/src/assets/fonts/Nekst.otf') format('opentype');
              font-weight: normal;
              font-style: normal;
              font-display: block;
              unicode-range: U+0000-00FF, U+0100-017F, U+0180-024F, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+0030-0039;
            }
            
            /* Preload fonts for better performance */
            .font-preload {
              font-family: 'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif;
              position: absolute;
              left: -9999px;
              top: -9999px;
              visibility: hidden;
            }
          `}
        </style>
        <div className="text-center space-y-8">
          <div className="relative w-32 h-32 mx-auto">
            <img
              src="/logo.png"
              alt={isRTL ? 'شعار طالب' : 'Taleb Logo'}
              className="w-full h-full object-contain"
              onLoad={() => setLogoLoaded(true)}
              onError={() => setLogoLoaded(true)}
            />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl md:text-5xl font-bold text-[hsl(var(--foreground))] text-center"
                style={{ 
                  fontFamily: isRTL ? "'IBMPlexSansArabic', 'Nekst', system-ui, sans-serif" : "'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif",
                  direction: isRTL ? 'rtl' : 'ltr',
                  textAlign: 'center'
                }}
                dir={isRTL ? 'rtl' : 'ltr'}>
              {appName}
            </h1>
            <p className="text-lg font-light text-[hsl(var(--muted-foreground))] text-center"
               style={{ 
                 fontFamily: isRTL ? "'IBMPlexSansArabic', 'Nekst', system-ui, sans-serif" : "'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif",
                 direction: isRTL ? 'rtl' : 'ltr',
                 textAlign: 'center'
               }}
               dir={isRTL ? 'rtl' : 'ltr'}>
              {appTagline}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center transition-opacity duration-500 ${
      isVisible ? 'opacity-100' : 'opacity-0'
    } bg-[hsl(var(--background))] text-center`}
    dir={isRTL ? 'rtl' : 'ltr'}>
      <style>
        {`
          @font-face {
            font-family: 'IBMPlexSansArabic';
            src: url('/src/assets/fonts/IBMPlexSansArabic.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
            font-display: block;
            unicode-range: U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF, U+0660-0669;
          }
          
          @font-face {
            font-family: 'Nekst';
            src: url('/src/assets/fonts/Nekst.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
            font-display: block;
            unicode-range: U+0000-00FF, U+0100-017F, U+0180-024F, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+0030-0039;
          }
          
          /* Preload fonts for better performance */
          .font-preload {
            font-family: 'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif;
            position: absolute;
            left: -9999px;
            top: -9999px;
            visibility: hidden;
          }
        `}
      </style>
      {/* Font preload for better performance */}
      <div className="font-preload">
        <span>طالب Taleb</span>
      </div>
      
      <div className="text-center space-y-8">
        {/* Logo */}
        <div className={`relative transition-all duration-1000 ${logoLoaded ? 'scale-100 opacity-100' : 'scale-90 opacity-0'}`}>
          <div className="relative w-32 h-32 mx-auto">
            <img
              src="/logo.png"
              alt={isRTL ? 'شعار طالب' : 'Taleb Logo'}
              className="w-full h-full object-contain animate-float"
              onLoad={() => setLogoLoaded(true)}
              onError={() => setLogoLoaded(true)} // Fallback if image fails to load
            />
            {/* Glow effect around logo - adapts to theme */}
            <div className="absolute inset-0 rounded-full animate-pulse blur-xl bg-[hsl(var(--accent))] opacity-30"></div>
          </div>
        </div>

        {/* App Title */}
        <div className={`space-y-2 transition-all duration-1000 delay-300 ${logoLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
          <h1 
            className="text-4xl md:text-5xl font-bold text-[hsl(var(--foreground))] text-center"
            style={{ 
              fontFamily: isRTL ? "'IBMPlexSansArabic', 'Nekst', system-ui, sans-serif" : "'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif",
              direction: isRTL ? 'rtl' : 'ltr',
              textAlign: 'center'
            }}
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            {appName}
          </h1>
          <p className="text-lg font-light animate-pulse text-[hsl(var(--muted-foreground))] text-center"
             style={{ 
               fontFamily: isRTL ? "'IBMPlexSansArabic', 'Nekst', system-ui, sans-serif" : "'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif",
               direction: isRTL ? 'rtl' : 'ltr',
               textAlign: 'center'
             }}
             dir={isRTL ? 'rtl' : 'ltr'}>
            {appTagline}
          </p>
        </div>

        {/* Loading Animation */}
        <div className={`transition-all duration-1000 delay-500 ${logoLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
          <div className="flex items-center justify-center space-x-1" dir="ltr">
            <div className="w-2 h-2 rounded-full animate-bounce bg-[hsl(var(--muted-foreground))]" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 rounded-full animate-bounce bg-[hsl(var(--muted-foreground))]" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 rounded-full animate-bounce bg-[hsl(var(--muted-foreground))]" style={{ animationDelay: '300ms' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}