import React from 'react';
import { I18nProvider } from './utils/i18n';
import { ThemeProvider } from './utils/theme';

export default function AppProviders({ children }) {
  return (
    <ThemeProvider>
      <I18nProvider>
        {children}
      </I18nProvider>
    </ThemeProvider>
  );
}
