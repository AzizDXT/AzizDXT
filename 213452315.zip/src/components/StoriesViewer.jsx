import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, Play, Pause } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useI18n } from './utils/i18n';

export default function StoriesViewer({ 
  stories, 
  initialStoryIndex = 0, 
  isOpen, 
  onClose,
  onStoryComplete 
}) {
  const { t, language } = useI18n();
  const [currentStoryIndex, setCurrentStoryIndex] = useState(initialStoryIndex);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [isLongPress, setIsLongPress] = useState(false);
  
  const currentStory = stories[currentStoryIndex];
  const currentSlide = currentStory?.slides?.[currentSlideIndex];
  
  const progressIntervalRef = useRef(null);
  const longPressTimerRef = useRef(null);
  const longPressDuration = 500; // 500ms for long press
  
  const STORY_DURATION = 5000; // 5 seconds per slide
  const PROGRESS_UPDATE_INTERVAL = 50; // Update progress every 50ms

  // Reset progress when story or slide changes
  useEffect(() => {
    setProgress(0);
    setCurrentSlideIndex(0);
  }, [currentStoryIndex]);

  // Handle story progress
  useEffect(() => {
    if (!isOpen || !isPlaying || isLongPress) return;

    const startTime = Date.now();

    progressIntervalRef.current = setInterval(() => {
      const now = Date.now();
      const elapsed = now - startTime;
      const newProgress = Math.min((elapsed / STORY_DURATION) * 100, 100);
      
      setProgress(newProgress);

      if (newProgress >= 100) {
        // Move to next slide or story
        if (currentSlideIndex < currentStory.slides.length - 1) {
          // Next slide in same story
          setCurrentSlideIndex(prev => prev + 1);
        } else {
          // Next story
          if (currentStoryIndex < stories.length - 1) {
            setCurrentStoryIndex(prev => prev + 1);
          } else {
            // All stories completed
            onStoryComplete?.();
            onClose();
          }
        }
      }
    }, PROGRESS_UPDATE_INTERVAL);

    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, [isOpen, isPlaying, currentStoryIndex, currentSlideIndex, currentStory, stories.length, onStoryComplete, onClose, isLongPress]);

  // Long press handlers
  const handleMouseDown = (e) => {
    // Only handle long press on the story content, not on background
    if (e.target.closest('.story-content')) {
      longPressTimerRef.current = setTimeout(() => {
        setIsLongPress(true);
        setIsPlaying(false);
      }, longPressDuration);
    }
  };

  const handleMouseUp = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
    if (isLongPress) {
      setIsLongPress(false);
      setIsPlaying(true);
    }
  };

  const handleMouseLeave = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }
    if (isLongPress) {
      setIsLongPress(false);
      setIsPlaying(true);
    }
  };

  // Touch handlers for mobile
  const handleTouchStart = (e) => {
    handleMouseDown(e);
  };

  const handleTouchEnd = () => {
    handleMouseUp();
  };

  // Handle background click to close
  const handleBackgroundClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  // Navigation functions
  const goToNextStory = () => {
    if (currentStoryIndex < stories.length - 1) {
      setCurrentStoryIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const goToPreviousStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(prev => prev - 1);
    }
  };

  const goToNextSlide = () => {
    if (currentSlideIndex < currentStory.slides.length - 1) {
      setCurrentSlideIndex(prev => prev + 1);
    } else {
      goToNextStory();
    }
  };

  const goToPreviousSlide = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex(prev => prev - 1);
    } else {
      goToPreviousStory();
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!isOpen) return;
      
      switch (e.key) {
        case 'ArrowRight':
        case ' ':
          e.preventDefault();
          goToNextSlide();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          goToPreviousSlide();
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentStoryIndex, currentSlideIndex]);

  if (!isOpen || !currentStory) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black z-50 flex items-center justify-center"
        onClick={handleBackgroundClick}
      >
        {/* Mobile-style container with fixed aspect ratio */}
        <div className="relative w-full h-full max-w-sm mx-auto bg-black">
          {/* Story Header */}
          <div className="absolute top-0 left-0 right-0 z-10 p-4">
            {/* Progress Bars */}
            <div className="flex gap-1 mb-4">
              {currentStory.slides.map((_, index) => (
                <div key={index} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-white rounded-full"
                    initial={{ width: 0 }}
                    animate={{ 
                      width: index < currentSlideIndex 
                        ? '100%' 
                        : index === currentSlideIndex 
                          ? `${progress}%` 
                          : '0%' 
                    }}
                    transition={{ duration: 0.1 }}
                  />
                </div>
              ))}
            </div>
            
            {/* User Info */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="w-8 h-8 border-2 border-white">
                  <AvatarImage src={currentStory.avatar} />
                  <AvatarFallback className="bg-gray-600 text-white text-sm">
                    {currentStory.user.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-white font-semibold text-sm">{currentStory.user}</h3>
                  <p className="text-white/70 text-xs">
                    {language === 'ar' ? 'منذ قليل' : 'Just now'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="text-white hover:bg-white/20 w-8 h-8"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-white hover:bg-white/20 w-8 h-8"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Story Content - Mobile Portrait Style */}
          <div 
            className="relative w-full h-full flex items-center justify-center pt-24 pb-16 story-content"
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            <motion.div
              key={`${currentStoryIndex}-${currentSlideIndex}`}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              transition={{ duration: 0.3 }}
              className="relative w-full h-full max-w-sm"
            >
              {currentSlide?.type === 'image' ? (
                <img
                  src={currentSlide.content}
                  alt={currentSlide.caption || 'Story content'}
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : currentSlide?.type === 'video' ? (
                <video
                  src={currentSlide.content}
                  autoPlay
                  muted
                  loop
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg">
                  <div className="text-center text-white p-8">
                    <h2 className="text-xl font-bold mb-4">{currentSlide?.title || 'Story'}</h2>
                    <p className="text-base opacity-90">{currentSlide?.content || 'No content'}</p>
                  </div>
                </div>
              )}
              
              {/* Slide Caption */}
              {currentSlide?.caption && (
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-white text-sm font-medium bg-black/50 backdrop-blur-sm rounded-lg p-3 text-center">
                    {currentSlide.caption}
                  </p>
                </div>
              )}
            </motion.div>
          </div>

          {/* Navigation Buttons */}
          <div className="absolute inset-0 flex items-center justify-between p-4 pointer-events-none">
            <Button
              variant="ghost"
              size="icon"
              onClick={goToPreviousSlide}
              className="text-white hover:bg-white/20 pointer-events-auto w-10 h-10"
              disabled={currentStoryIndex === 0 && currentSlideIndex === 0}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={goToNextSlide}
              className="text-white hover:bg-white/20 pointer-events-auto w-10 h-10"
              disabled={currentStoryIndex === stories.length - 1 && currentSlideIndex === currentStory.slides.length - 1}
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Story Navigation Dots */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
            {stories.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentStoryIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentStoryIndex 
                    ? 'bg-white w-6' 
                    : 'bg-white/50'
                }`}
              />
            ))}
          </div>

          {/* Long Press Indicator */}
          {isLongPress && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <div className="text-white text-center">
                <Pause className="w-16 h-16 mx-auto mb-2" />
                <p className="text-sm">{language === 'ar' ? 'متوقف مؤقتاً' : 'Paused'}</p>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
} 