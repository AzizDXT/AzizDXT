import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { isAuthenticated, setRedirectAfterLogin } from '../utils/logout';

export default function ProtectedRoute({ children }) {
  const location = useLocation();

  // If not authenticated, redirect to auth page
  if (!isAuthenticated()) {
    // Store the attempted URL to redirect back after login
    setRedirectAfterLogin(location.pathname + location.search);
    return <Navigate to="/Auth" replace />;
  }

  return children;
}
