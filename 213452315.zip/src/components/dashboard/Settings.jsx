
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { 
  Settings as SettingsIcon, 
  Palette, 
  Shield, 
  Bell, 
  AlertTriangle,
  Globe,
  Sun,
  Moon,
  Key,
  Smartphone,
  Mail,
  Trash2,
  Check,
  Brain,
  Bookmark,
  Menu,
  Save,
  RotateCcw,
  GripVertical,
  Plus,
  Video,
  FileText as PostIcon,
  Link as LinkIcon,
  Edit2,
  X,
  Loader2,
  Download,
  LogOut
} from 'lucide-react';
import { useI18n } from '../utils/i18n';
import { useTheme } from '../utils/theme';
import api from '../utils/api';

// Mock data for Saved Content
const mockSavedContent = [
  { id: 1, title: "CYBERSECURITY BREAKTHROUGH", type: "reel", date: "2025-01-12", mediaUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=300&h=400&fit=crop" },
  { id: 2, title: "My Graduation Project Notes", type: "post", date: "2025-01-11", content: "Just compiled all my notes for the final presentation. Feeling nervous but excited!" },
  { id: 3, title: "AI in Healthcare - A Deep Dive", type: "post", date: "2025-01-10", mediaUrl: "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?w=300&h=200&fit=crop" },
];

const initialSidebarItems = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'communities', label: 'Communities', icon: 'communities' },
  { id: 'ai', label: 'AI Assistant', icon: 'ai' },
  { id: 'library', label: 'Library', icon: 'library' },
  { id: 'academic', label: 'Academic', icon: 'academic' },
  { id: 'profile', label: 'Profile', icon: 'profile' }
];

export default function Settings() {
  const [activeSection, setActiveSection] = useState('general');
  const { t, language, changeLanguage } = useI18n();
  const { theme, changeTheme } = useTheme();
  const navigate = useNavigate();
  
  // AI Memories state
  const [memories, setMemories] = useState([]);
  const [newMemory, setNewMemory] = useState('');
  const [editingMemory, setEditingMemory] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  
  const [savedContent, setSavedContent] = useState(mockSavedContent);
  const [sidebarItems, setSidebarItems] = useState(initialSidebarItems);

  // Modals state
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  // Logout function
  const handleLogout = async () => {
    try {
      await api.logout();
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
      // Force redirect even if API call fails
      navigate('/');
    }
  };

  // Add new state for dialogs
  const [showErrorDialog, setShowErrorDialog] = useState({ isOpen: false, title: '', message: '' });
  const [showConfirmDialog, setShowConfirmDialog] = useState({ isOpen: false, title: '', message: '', onConfirm: null });
  const [showSuccessDialog, setShowSuccessDialog] = useState({ isOpen: false, title: '', message: '' });

  useEffect(() => {
    const savedLayout = localStorage.getItem('taleb-sidebar-layout');
    if (savedLayout) {
      try {
        const parsedLayout = JSON.parse(savedLayout);
        if(Array.isArray(parsedLayout) && parsedLayout.every(i => i.id && i.label)) {
          setSidebarItems(parsedLayout);
        }
      } catch (e) {
        setSidebarItems(initialSidebarItems);
      }
    }

    // Load memories when component mounts or activeSection changes to 'memories'
    if (activeSection === 'memories') {
      loadMemories();
    }
  }, [activeSection]);

  // AI Memories functions
  const loadMemories = async () => {
    setIsLoading(true);
    try {
      const response = await api.getMemories(0, 100);
      console.log('Memories loaded:', response);
      setMemories(response || []);
    } catch (error) {
      console.error('Error loading memories:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addMemory = async () => {
    if (!newMemory.trim()) return;
    
    setIsAdding(true);
    try {
      console.log('Adding memory:', newMemory.trim());
      const response = await api.addMemory(newMemory.trim(), {});
      console.log('Memory added:', response);
      setMemories([response, ...memories]);
      setNewMemory('');
    } catch (error) {
      console.error('Error adding memory:', error);
      // استخدام نافذة حوار مخصصة بدلاً من alert
      setShowErrorDialog({
        isOpen: true,
        title: language === 'ar' ? 'خطأ في إضافة الذكرى' : 'Error Adding Memory',
        message: language === 'ar' ? 'فشل في إضافة الذكرى. يرجى المحاولة مرة أخرى.' : 'Failed to add memory. Please try again.'
      });
    } finally {
      setIsAdding(false);
    }
  };

  const startEditing = (memory) => {
    setEditingMemory(memory.id);
    setEditContent(memory.content);
  };

  const cancelEditing = () => {
    setEditingMemory(null);
    setEditContent('');
  };

  const updateMemory = async (memoryId) => {
    if (!editContent.trim()) return;
    
    setIsUpdating(true);
    try {
      const response = await api.updateMemory(memoryId, editContent.trim(), {});
      setMemories(memories.map(m => m.id === memoryId ? response : m));
      setEditingMemory(null);
      setEditContent('');
    } catch (error) {
      console.error('Error updating memory:', error);
      setShowErrorDialog({
        isOpen: true,
        title: language === 'ar' ? 'خطأ في تحديث الذكرى' : 'Error Updating Memory',
        message: language === 'ar' ? 'فشل في تحديث الذكرى. يرجى المحاولة مرة أخرى.' : 'Failed to update memory. Please try again.'
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const deleteMemory = async (memoryId) => {
    setShowConfirmDialog({
      isOpen: true,
      title: language === 'ar' ? 'حذف الذكرى' : 'Delete Memory',
      message: language === 'ar' ? 'هل أنت متأكد من رغبتك في حذف هذه الذكرى؟ لا يمكن التراجع عن هذا الإجراء.' : 'Are you sure you want to delete this memory? This action cannot be undone.',
      onConfirm: async () => {
        try {
          await api.deleteMemory(memoryId);
          setMemories(memories.filter(m => m.id !== memoryId));
          setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null }); // Close dialog
        } catch (error) {
          console.error('Error deleting memory:', error);
          setShowErrorDialog({
            isOpen: true,
            title: language === 'ar' ? 'خطأ في حذف الذكرى' : 'Error Deleting Memory',
            message: language === 'ar' ? 'فشل في حذف الذكرى. يرجى المحاولة مرة أخرى.' : 'Failed to delete memory. Please try again.'
          });
          setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null }); // Close dialog even on error
        }
      }
    });
  };

  const deleteAllMemories = async () => {
    setShowConfirmDialog({
      isOpen: true,
      title: language === 'ar' ? 'حذف جميع الذكريات' : 'Delete All Memories',
      message: language === 'ar' ? 'هل أنت متأكد من رغبتك في حذف جميع الذكريات؟ هذا الإجراء لا يمكن التراجع عنه!' : 'Are you sure you want to delete all memories? This action cannot be undone!',
      onConfirm: async () => {
        try {
          await api.deleteAllMemories();
          setMemories([]);
          setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null }); // Close dialog
        } catch (error) {
          console.error('Error deleting all memories:', error);
          setShowErrorDialog({
            isOpen: true,
            title: language === 'ar' ? 'خطأ في حذف الذكريات' : 'Error Deleting Memories',
            message: language === 'ar' ? 'فشل في حذف جميع الذكريات. يرجى المحاولة مرة أخرى.' : 'Failed to delete all memories. Please try again.'
          });
          setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null }); // Close dialog even on error
        }
      }
    });
  };

  const exportMemories = () => {
    const dataStr = JSON.stringify(memories, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `memories-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp * 1000); // Assuming timestamp is in seconds
    return language === 'ar' 
      ? date.toLocaleDateString('ar-SA')
      : date.toLocaleDateString('en-US');
  };

  // Sidebar functions
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const items = Array.from(sidebarItems);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    setSidebarItems(items);
  };

  const saveSidebarLayout = () => {
    localStorage.setItem('taleb-sidebar-layout', JSON.stringify(sidebarItems));
    
    // Dispatch custom event to notify sidebar component
    window.dispatchEvent(new CustomEvent('sidebarLayoutUpdated', { 
      detail: sidebarItems 
    }));
    
    // Show success feedback
    const button = document.querySelector('[data-save-sidebar]');
    if (button) {
      const originalText = button.textContent;
      const originalBgColor = button.style.backgroundColor;
      button.textContent = language === 'ar' ? '✓ تم الحفظ!' : '✓ Saved!';
      button.style.backgroundColor = '#10b981';
      button.disabled = true;
      
      setTimeout(() => {
        button.textContent = originalText;
        button.style.backgroundColor = originalBgColor;
        button.disabled = false;
      }, 2000);
    }
  };

  const resetSidebarLayout = () => {
    setSidebarItems(initialSidebarItems);
    localStorage.removeItem('taleb-sidebar-layout');
    
    // Dispatch custom event to notify sidebar component
    window.dispatchEvent(new CustomEvent('sidebarLayoutUpdated', { 
      detail: initialSidebarItems 
    }));
    
    // Show success feedback
    const button = document.querySelector('[data-reset-sidebar]');
    if (button) {
      const originalText = button.textContent;
      const originalBgColor = button.style.backgroundColor;
      button.textContent = language === 'ar' ? '✓ تم الإعادة!' : '✓ Reset!';
      button.style.backgroundColor = '#10b981';
      button.disabled = true;
      
      setTimeout(() => {
        button.textContent = originalText;
        button.style.backgroundColor = originalBgColor;
        button.disabled = false;
      }, 2000);
    }
  };

  const sections = [
    { id: 'general', label: t('settings.general'), icon: <SettingsIcon className="w-5 h-5" /> },
    { id: 'appearance', label: t('settings.appearance'), icon: <Palette className="w-5 h-5" /> },
    { id: 'memories', label: t('settings.memories'), icon: <Brain className="w-5 h-5" /> },
    { id: 'savedContent', label: t('settings.savedContent'), icon: <Bookmark className="w-5 h-5" /> },
    { id: 'sidebarLayout', label: t('settings.sidebarLayout'), icon: <Menu className="w-5 h-5" /> },
    { id: 'security', label: t('settings.security'), icon: <Shield className="w-5 h-5" /> },
    { id: 'notifications', label: t('settings.notifications'), icon: <Bell className="w-5 h-5" /> },
    { id: 'danger', label: t('settings.dangerZone'), icon: <AlertTriangle className="w-5 h-5" /> },
  ];

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'general':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-[var(--text-primary)]">
                  <Globe className="w-5 h-5" />
                  {t('settings.language')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3">
                  <button
                    onClick={() => changeLanguage && changeLanguage('en')}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 ${
                      language === 'en' 
                        ? 'border-[var(--accent-color)] bg-[var(--background-secondary)]' 
                        : 'border-[var(--border-color)] hover:border-[var(--accent-color)]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold">
                        EN
                      </div>
                      <span className="text-[var(--text-primary)]">
                        {t('language.english')}
                      </span>
                    </div>
                    {language === 'en' && <Check className="w-5 h-5 text-[var(--accent-color)]" />}
                  </button>

                  <button
                    onClick={() => changeLanguage && changeLanguage('ar')}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 ${
                      language === 'ar' 
                        ? 'border-[var(--accent-color)] bg-[var(--background-secondary)]' 
                        : 'border-[var(--border-color)] hover:border-[var(--accent-color)]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center text-white text-xs font-bold">
                        ع
                      </div>
                      <span className="text-[var(--text-primary)]">
                        {t('language.arabic')}
                      </span>
                    </div>
                    {language === 'ar' && <Check className="w-5 h-5 text-[var(--accent-color)]" />}
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'appearance':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-[var(--text-primary)]">
                  <Palette className="w-5 h-5" />
                  {t('settings.theme')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3">
                  <button
                    onClick={() => changeTheme && changeTheme('light')}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 ${
                      theme === 'light' 
                        ? 'border-[var(--accent-color)] bg-[var(--background-secondary)]' 
                        : `border-[var(--border-color)] hover:border-[var(--accent-color)]`
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
                        <Sun className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[var(--text-primary)]">
                        {t('settings.lightMode')}
                      </span>
                    </div>
                    {theme === 'light' && <Check className="w-5 h-5 text-[var(--accent-color)]" />}
                  </button>

                  <button
                    onClick={() => changeTheme && changeTheme('dark')}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all duration-200 ${
                      theme === 'dark' 
                        ? 'border-[var(--accent-color)] bg-[var(--background-secondary)]' 
                        : `border-[var(--border-color)] hover:border-[var(--accent-color)]`
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
                        <Moon className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-[var(--text-primary)]">
                        {t('settings.darkMode')}
                      </span>
                    </div>
                    {theme === 'dark' && <Check className="w-5 h-5 text-[var(--accent-color)]" />}
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'memories':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)] flex items-center gap-3">
                  <Brain className="w-5 h-5" />
                  {t('settings.memories.title')}
                </CardTitle>
                <CardDescription>
                  {t('settings.memories.description')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder={t('settings.memories.addPlaceholder')}
                    value={newMemory}
                    onChange={(e) => setNewMemory(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addMemory()}
                    className="flex-1"
                  />
                  <Button onClick={addMemory} disabled={isAdding || !newMemory.trim()}>
                    {isAdding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  </Button>
                </div>

                <div className="flex items-center justify-between text-sm text-[var(--text-secondary)]">
                  <span>{t('settings.memories.totalMemories')}: {memories.length}</span>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={exportMemories} disabled={memories.length === 0}>
                      <Download className="w-4 h-4 mr-2" />
                      {t('settings.memories.export')}
                    </Button>
                    <Button variant="destructive" size="sm" onClick={deleteAllMemories} disabled={memories.length === 0}>
                      <Trash2 className="w-4 h-4 mr-2" />
                      {t('settings.memories.clearAll')}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 max-h-80 overflow-y-auto pr-2">
                  {isLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
                    </div>
                  ) : memories.length === 0 ? (
                    <div className="text-center py-8 text-[var(--text-secondary)]">
                      <Brain className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>{language === 'ar' ? 'لا توجد ذكريات بعد' : 'No memories yet'}</p>
                    </div>
                  ) : (
                    memories.map((memory) => (
                      <div key={memory.id} className="p-3 rounded-lg bg-[var(--background-secondary)] border border-[var(--border-color)]">
                        {editingMemory === memory.id ? (
                          <div className="space-y-2">
                            <textarea
                              value={editContent}
                              onChange={(e) => setEditContent(e.target.value)}
                              className="w-full p-2 border border-[var(--border-color)] rounded-md bg-[var(--background)] text-[var(--text-primary)] resize-none min-h-[80px] max-h-[200px] overflow-y-auto"
                              rows={3}
                            />
                            <div className="flex gap-2 justify-end">
                              <Button size="sm" variant="outline" onClick={cancelEditing}>
                                <X className="w-4 h-4" />
                              </Button>
                              <Button 
                                size="sm" 
                                onClick={() => updateMemory(memory.id)}
                                disabled={isUpdating || !editContent.trim()}
                              >
                                {isUpdating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-[var(--text-primary)] break-words overflow-hidden max-h-[120px] overflow-y-auto">
                                {memory.content}
                              </p>
                              <span className="text-xs text-[var(--text-secondary)]">
                                {formatDate(memory.created_at)}
                                {memory.updated_at !== memory.created_at && ` • ${language === 'ar' ? 'محدث' : 'Updated'}`}
                              </span>
                            </div>
                            <div className="flex gap-1 ml-2 flex-shrink-0">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-[var(--text-secondary)] hover:text-[var(--text-primary)]" 
                                onClick={() => startEditing(memory)}
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-red-500 hover:bg-red-100" 
                                onClick={() => deleteMemory(memory.id)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'savedContent':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)] flex items-center gap-3">
                  <Bookmark className="w-5 h-5" />
                  {t('settings.savedContent.title')}
                </CardTitle>
                <CardDescription>
                  {t('settings.savedContent.description')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {savedContent.map((item) => (
                    <div key={item.id} className="group relative overflow-hidden rounded-lg border border-[var(--border-color)] bg-[var(--background-secondary)]">
                      {item.mediaUrl ? (
                        <img src={item.mediaUrl} alt={item.title} className="w-full h-40 object-cover" />
                      ) : (
                        <div className="w-full h-40 flex items-center justify-center bg-[var(--background-tertiary)]">
                           <PostIcon className="w-12 h-12 text-[var(--text-secondary)]" />
                        </div>
                      )}
                      <div className="p-3">
                        <div className="flex items-center gap-2 text-xs text-[var(--text-secondary)] mb-1">
                           {item.type === 'reel' ? <Video className="w-3 h-3"/> : <PostIcon className="w-3 h-3"/>}
                           <span>{item.type.charAt(0).toUpperCase() + item.type.slice(1)}</span>
                        </div>
                        <h4 className="font-semibold text-sm text-[var(--text-primary)] truncate">{item.title}</h4>
                        {item.content && <p className="text-xs text-[var(--text-secondary)] truncate">{item.content}</p>}
                      </div>
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                         <Button variant="outline" size="sm" className="bg-white/20 backdrop-blur-sm text-white border-white/50 hover:bg-white/30">
                           <LinkIcon className="w-4 h-4 mr-2" /> View
                         </Button>
                      </div>
                    </div>
                  ))}
                 </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'sidebarLayout':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)] flex items-center gap-3">
                  <Menu className="w-5 h-5" />
                  {t('settings.sidebarLayout.title')}
                </CardTitle>
                <CardDescription>
                  {t('settings.sidebarLayout.description')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-[var(--background-secondary)] rounded-lg border border-[var(--border-color)]">
                  <p className="text-sm text-[var(--text-secondary)] mb-3">
                    {language === 'ar' 
                      ? 'اسحب وأفلت لإعادة ترتيب أيقونات الشريط الجانبي. الترتيب الجديد سيتم حفظه تلقائياً.'
                      : 'Drag and drop to reorder sidebar icons. The new order will be saved automatically.'
                    }
                  </p>
                </div>

                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="sidebar-items">
                    {(provided) => (
                      <div 
                        {...provided.droppableProps} 
                        ref={provided.innerRef} 
                        className="space-y-2"
                      >
                        {sidebarItems.map((item, index) => (
                          <Draggable key={item.id} draggableId={item.id} index={index}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className={`flex items-center gap-3 p-4 rounded-lg border transition-all duration-200 ${
                                  snapshot.isDragging 
                                    ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)] shadow-lg scale-105' 
                                    : 'bg-[var(--background-secondary)] border-[var(--border-color)]'
                                }`}
                                style={{
                                  ...provided.draggableProps.style,
                                  cursor: snapshot.isDragging ? 'grabbing' : 'grab'
                                }}
                              >
                                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-[var(--background)]">
                                  <GripVertical className="w-4 h-4 text-[var(--text-secondary)]" />
                                </div>
                                <div className="flex-1">
                                  <div className="font-medium text-[var(--text-primary)]">
                                    {t(`sidebar.${item.id}`)}
                                  </div>
                                  <div className="text-sm text-[var(--text-secondary)]">
                                    {item.id}
                                  </div>
                                </div>
                                <div className="text-xs text-[var(--text-secondary)] bg-[var(--background)] px-2 py-1 rounded">
                                  {index + 1}
                                </div>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>

                <div className="flex gap-2 pt-4 border-t border-[var(--border-color)]">
                  <Button 
                    onClick={saveSidebarLayout} 
                    className="flex-1 bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90" 
                    data-save-sidebar
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {t('settings.sidebarLayout.saveChanges')}
                  </Button>
                  <Button 
                    onClick={resetSidebarLayout} 
                    variant="outline" 
                    className="flex-1"
                    data-reset-sidebar
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    {t('settings.sidebarLayout.resetDefault')}
                  </Button>
                </div>

                <div className="text-xs text-[var(--text-secondary)] text-center p-3 bg-[var(--background-secondary)] rounded-lg">
                  {language === 'ar' 
                    ? 'ملاحظة: التغييرات ستطبق على الشريط الجانبي في جميع الصفحات'
                    : 'Note: Changes will apply to the sidebar across all pages'
                  }
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)]">{t('settings.security')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--background-secondary)]">
                  <div className="flex items-center gap-3">
                    <Key className="w-5 h-5 text-[var(--text-secondary)]" />
                    <span className="text-[var(--text-primary)]">
                      {t('settings.changePassword')}
                    </span>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setShowPasswordModal(true)}>
                    {t('common.edit')}
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--background-secondary)]">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-[var(--text-secondary)]" />
                    <span className="text-[var(--text-primary)]">
                      {language === 'ar' ? 'تحديث البريد الإلكتروني' : 'Update Email'}
                    </span>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setShowEmailModal(true)}>
                    {t('common.edit')}
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg bg-[var(--background-secondary)]">
                  <div className="flex items-center gap-3">
                    <Smartphone className="w-5 h-5 text-[var(--text-secondary)]" />
                    <span className="text-[var(--text-primary)]">
                      {t('settings.twoFactor')}
                    </span>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'notifications':
        return (
          <div className="space-y-6">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)] flex items-center gap-3">
                  <Bell className="w-5 h-5" />
                  {t('settings.notifications')}
                </CardTitle>
                <CardDescription>
                  {t('settings.notificationsDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="font-medium text-[var(--text-primary)]">
                      {t('settings.pushNotifications')}
                    </div>
                    <div className="text-sm text-[var(--text-secondary)]">
                      {language === 'ar' ? 'إشعارات فورية على جهازك' : 'Instant notifications on your device'}
                    </div>
                  </div>
                  <Switch />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="font-medium text-[var(--text-primary)]">
                      {t('settings.emailNotifications')}
                    </div>
                    <div className="text-sm text-[var(--text-secondary)]">
                      {language === 'ar' ? 'إشعارات عبر البريد الإلكتروني' : 'Notifications via email'}
                    </div>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'danger':
        return (
          <div className="space-y-6">
            <Card className="border-red-500/30 bg-red-500/10">
              <CardHeader>
                <CardTitle className="text-red-500 flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5" />
                  {t('settings.dangerZone')}
                </CardTitle>
                <CardDescription className="text-red-500/80">
                  {t('settings.deleteAccountDesc')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="destructive" className="flex items-center gap-2 w-full" onClick={() => setShowDeleteModal(true)}>
                  <Trash2 className="w-4 h-4" />
                  {t('settings.deleteAccount')}
                </Button>
                <Button variant="outline" className="flex items-center gap-2 w-full text-red-600 border-red-200 hover:bg-red-50" onClick={handleLogout}>
                  <LogOut className="w-4 h-4" />
                  {t('sidebar.logout')}
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };
  
  return (
    <div className="max-w-6xl mx-auto p-0 md:p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-[var(--text-primary)]">
          {t('settings.title')}
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card className="bg-[var(--background)] border-[var(--border-color)]">
            <CardContent className="p-4">
              <nav className="space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 ${
                      activeSection === section.id
                        ? 'bg-[var(--background-secondary)] text-[var(--text-primary)] font-semibold'
                        : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    {section.icon}
                    {section.label}
                  </button>
                ))}
              </nav>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderSectionContent()}
          </motion.div>
        </div>
      </div>
      
      {/* Security Modals */}
      {showPasswordModal && (
        <PasswordChangeModal 
          isOpen={showPasswordModal}
          onClose={() => setShowPasswordModal(false)}
          onSuccess={() => {
            setShowPasswordModal(false);
            setShowSuccessDialog({
              isOpen: true,
              title: language === 'ar' ? 'تم تغيير كلمة المرور' : 'Password Changed',
              message: language === 'ar' ? 'تم تغيير كلمة المرور بنجاح.' : 'Password changed successfully.'
            });
          }}
        />
      )}
      
      {showEmailModal && (
        <EmailUpdateModal 
          isOpen={showEmailModal}
          onClose={() => setShowEmailModal(false)}
          onSuccess={() => {
            setShowEmailModal(false);
            setShowSuccessDialog({
              isOpen: true,
              title: language === 'ar' ? 'تم تحديث البريد الإلكتروني' : 'Email Updated',
              message: language === 'ar' ? 'تم تحديث البريد الإلكتروني بنجاح. يرجى التحقق من بريدك الإلكتروني الجديد.' : 'Email updated successfully. Please verify your new email address.'
            });
          }}
        />
      )}
      
      {showDeleteModal && (
        <DeleteAccountModal 
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
        />
      )}

      {/* Custom Dialog Components */}
      <ConfirmDialog
        isOpen={showConfirmDialog.isOpen}
        title={showConfirmDialog.title}
        message={showConfirmDialog.message}
        onConfirm={showConfirmDialog.onConfirm}
        onCancel={() => setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null })}
      />

      <ErrorDialog
        isOpen={showErrorDialog.isOpen}
        title={showErrorDialog.title}
        message={showErrorDialog.message}
        onClose={() => setShowErrorDialog({ isOpen: false, title: '', message: '' })}
      />

      <SuccessDialog
        isOpen={showSuccessDialog.isOpen}
        title={showSuccessDialog.title}
        message={showSuccessDialog.message}
        onClose={() => setShowSuccessDialog({ isOpen: false, title: '', message: '' })}
      />
    </div>
  );
}

// Enhanced Security Modals with API integration
function PasswordChangeModal({ isOpen, onClose, onSuccess }) {
  const { t, language } = useI18n();
  const [formData, setFormData] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.new_password !== formData.confirm_password) {
      setError(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (formData.new_password.length < 8) {
      setError(language === 'ar' ? 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' : 'Password must be at least 8 characters');
      return;
    }
    
    if (formData.new_password === formData.current_password) {
      setError(language === 'ar' ? 'كلمة المرور الجديدة لا يمكن أن تكون هي نفسها الحالية' : 'New password cannot be the same as current password');
      return;
    }

    setIsLoading(true);
    try {
      await api.changePassword(formData.current_password, formData.new_password);
      onSuccess();
    } catch (err) {
      console.error('Error changing password:', err);
      // Assuming API error returns a message property
      setError(err.response?.data?.message || err.message || (language === 'ar' ? 'فشل في تغيير كلمة المرور' : 'Failed to change password'));
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)]">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[var(--text-primary)]">
            {language === 'ar' ? 'تغيير كلمة المرور' : 'Change Password'}
          </h3>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--background-secondary)]">
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'كلمة المرور الحالية' : 'Current Password'}
            </label>
            <Input
              type="password"
              value={formData.current_password}
              onChange={(e) => setFormData({...formData, current_password: e.target.value})}
              className="w-full"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'كلمة المرور الجديدة' : 'New Password'}
            </label>
            <Input
              type="password"
              value={formData.new_password}
              onChange={(e) => setFormData({...formData, new_password: e.target.value})}
              className="w-full"
              minLength={8}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'تأكيد كلمة المرور الجديدة' : 'Confirm New Password'}
            </label>
            <Input
              type="password"
              value={formData.confirm_password}
              onChange={(e) => setFormData({...formData, confirm_password: e.target.value})}
              className="w-full"
              required
            />
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {language === 'ar' ? 'تغيير كلمة المرور' : 'Change Password'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function EmailUpdateModal({ isOpen, onClose, onSuccess }) {
  const { t, language } = useI18n();
  const [formData, setFormData] = useState({
    new_email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.new_email)) {
      setError(language === 'ar' ? 'يرجى إدخال بريد إلكتروني صحيح' : 'Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    try {
      await api.updateEmail(formData.new_email, formData.password);
      onSuccess();
    } catch (err) {
      console.error('Error updating email:', err);
      setError(err.response?.data?.message || err.message || (language === 'ar' ? 'فشل في تحديث البريد الإلكتروني' : 'Failed to update email'));
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)]">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[var(--text-primary)]">
            {language === 'ar' ? 'تحديث البريد الإلكتروني' : 'Update Email'}
          </h3>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--background-secondary)]">
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        <div className="mb-4 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-sm">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <div>
              {language === 'ar' 
                ? 'تنبيه: عند تغيير بريدك الإلكتروني، ستحتاج لتأكيد البريد الجديد للوصول للميزات المحمية.'
                : 'Notice: When you change your email, you\'ll need to verify the new email to access protected features.'
              }
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'البريد الإلكتروني الجديد' : 'New Email Address'}
            </label>
            <Input
              type="email"
              value={formData.new_email}
              onChange={(e) => setFormData({...formData, new_email: e.target.value})}
              className="w-full"
              placeholder="user@example.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'كلمة المرور الحالية' : 'Current Password'}
            </label>
            <Input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {language === 'ar' ? 'تحديث البريد' : 'Update Email'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function DeleteAccountModal({ isOpen, onClose }) {
  const { language } = useI18n();
  const [password, setPassword] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const expectedText = language === 'ar' ? 'حذف حسابي' : 'DELETE MY ACCOUNT';
    if (confirmText !== expectedText) {
      setError(language === 'ar' ? `يرجى كتابة "${expectedText}" للتأكيد` : `Please type "${expectedText}" to confirm`);
      return;
    }

    setIsLoading(true);
    try {
      await api.deleteAccount(password);
      // Redirect to login or home page after successful deletion
      window.location.href = '/';
    } catch (err) {
      console.error('Error deleting account:', err);
      setError(err.response?.data?.message || err.message || (language === 'ar' ? 'فشل في حذف الحساب' : 'Failed to delete account'));
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const expectedText = language === 'ar' ? 'حذف حسابي' : 'DELETE MY ACCOUNT';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border-2 border-red-500/30">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-red-500">
            {language === 'ar' ? 'حذف الحساب' : 'Delete Account'}
          </h3>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--background-secondary)]">
            <X className="w-5 h-5 text-[var(--text-secondary)]" />
          </button>
        </div>

        <div className="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-700">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <div className="font-semibold mb-2">
                {language === 'ar' ? 'تحذير: هذا الإجراء لا يمكن التراجع عنه!' : 'Warning: This action cannot be undone!'}
              </div>
              <ul className="space-y-1 text-xs">
                <li>• {language === 'ar' ? 'سيتم حذف جميع بياناتك نهائياً' : 'All your data will be permanently deleted'}</li>
                <li>• {language === 'ar' ? 'لن تتمكن من استرداد حسابك' : 'You will not be able to recover your account'}</li>
                <li>• {language === 'ar' ? 'سيتم تسجيل خروجك فوراً' : 'You will be logged out immediately'}</li>
              </ul>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? 'كلمة المرور للتأكيد' : 'Password to confirm'}
            </label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full"
              placeholder="••••••••"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {language === 'ar' ? `اكتب "${expectedText}" للتأكيد` : `Type "${expectedText}" to confirm`}
            </label>
            <Input
              type="text"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              className="w-full"
              placeholder={expectedText}
              required
            />
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </Button>
            <Button 
              type="submit" 
              variant="destructive" 
              disabled={isLoading || !password || confirmText !== expectedText}
              className="flex-1"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {language === 'ar' ? 'حذف الحساب' : 'Delete Account'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Custom Dialog Components
function ConfirmDialog({ isOpen, title, message, onConfirm, onCancel }) {
  const { language } = useI18n();
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)]">
        <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">{title}</h3>
        <p className="text-[var(--text-secondary)] mb-6">{message}</p>
        <div className="flex gap-3">
          <Button variant="outline" onClick={onCancel} className="flex-1">
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button variant="destructive" onClick={onConfirm} className="flex-1">
            {language === 'ar' ? 'تأكيد' : 'Confirm'}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ErrorDialog({ isOpen, title, message, onClose }) {
  const { language } = useI18n();
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-red-200">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-red-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-red-600 mb-2">{title}</h3>
            <p className="text-[var(--text-secondary)]">{message}</p>
          </div>
        </div>
        <Button onClick={onClose} className="w-full">
          {language === 'ar' ? 'موافق' : 'OK'}
        </Button>
      </div>
    </div>
  );
}

function SuccessDialog({ isOpen, title, message, onClose }) {
  const { language } = useI18n();
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-green-200">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
            <Check className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-green-600 mb-2">{title}</h3>
            <p className="text-[var(--text-secondary)]">{message}</p>
          </div>
        </div>
        <Button onClick={onClose} className="w-full">
          {language === 'ar' ? 'موافق' : 'OK'}
        </Button>
      </div>
    </div>
  );
}
