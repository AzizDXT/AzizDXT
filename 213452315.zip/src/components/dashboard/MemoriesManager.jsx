import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Trash2, Edit2, Save, X, Loader2, Brain, Download, AlertTriangle } from 'lucide-react';
import { useI18n } from '../utils/i18n';
import { memoriesAPI } from '../utils/api';
import { motion, AnimatePresence } from 'framer-motion';

export default function MemoriesManager() {
  const { t, language } = useI18n();
  const [memories, setMemories] = useState([]);
  const [newMemory, setNewMemory] = useState('');
  const [editingMemory, setEditingMemory] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // تحميل الذكريات عند بدء المكون
  useEffect(() => {
    loadMemories();
  }, []);

  const loadMemories = async () => {
    setIsLoading(true);
    try {
      const response = await memoriesAPI.getMemories(0, 100);
      console.log('Memories loaded:', response);
      setMemories(response || []);
    } catch (error) {
      console.error('Error loading memories:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addMemory = async () => {
    if (!newMemory.trim()) return;
    
    setIsAdding(true);
    try {
      console.log('Adding memory:', newMemory.trim());
      const response = await memoriesAPI.addMemory(newMemory.trim(), {});
      console.log('Memory added:', response);
      setMemories([response, ...memories]);
      setNewMemory('');
    } catch (error) {
      console.error('Error adding memory:', error);
      alert(language === 'ar' ? 'فشل في إضافة الذكرى' : 'Failed to add memory');
    } finally {
      setIsAdding(false);
    }
  };

  const startEditing = (memory) => {
    setEditingMemory(memory.id);
    setEditContent(memory.content);
  };

  const cancelEditing = () => {
    setEditingMemory(null);
    setEditContent('');
  };

  const updateMemory = async (memoryId) => {
    if (!editContent.trim()) return;
    
    setIsUpdating(true);
    try {
      const response = await memoriesAPI.updateMemory(memoryId, editContent.trim(), {});
      setMemories(memories.map(m => m.id === memoryId ? response : m));
      setEditingMemory(null);
      setEditContent('');
    } catch (error) {
      console.error('Error updating memory:', error);
      alert(language === 'ar' ? 'فشل في تحديث الذكرى' : 'Failed to update memory');
    } finally {
      setIsUpdating(false);
    }
  };

  const deleteMemory = async (memoryId) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذه الذكرى؟' : 'Are you sure you want to delete this memory?')) {
      return;
    }

    try {
      await memoriesAPI.deleteMemory(memoryId);
      setMemories(memories.filter(m => m.id !== memoryId));
    } catch (error) {
      console.error('Error deleting memory:', error);
      alert(language === 'ar' ? 'فشل في حذف الذكرى' : 'Failed to delete memory');
    }
  };

  const deleteAllMemories = async () => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف جميع الذكريات؟ هذا الإجراء لا يمكن التراجع عنه!' : 'Are you sure you want to delete all memories? This action cannot be undone!')) {
      return;
    }

    try {
      await memoriesAPI.deleteAllMemories();
      setMemories([]);
    } catch (error) {
      console.error('Error deleting all memories:', error);
      alert(language === 'ar' ? 'فشل في حذف جميع الذكريات' : 'Failed to delete all memories');
    }
  };

  const exportMemories = () => {
    const dataStr = JSON.stringify(memories, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `memories-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp * 1000);
    return language === 'ar' 
      ? date.toLocaleDateString('ar-SA')
      : date.toLocaleDateString('en-US');
  };

  return (
    <div className="space-y-4">
      {/* إضافة ذكرى جديدة */}
      <div className="flex gap-2">
        <Input
          placeholder={t('settings.memories.addPlaceholder')}
          value={newMemory}
          onChange={(e) => setNewMemory(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addMemory()}
          className="flex-1"
        />
        <Button onClick={addMemory} disabled={isAdding || !newMemory.trim()}>
          {isAdding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
        </Button>
      </div>

      {/* إحصائيات */}
      <div className="flex items-center justify-between text-sm text-[var(--text-secondary)]">
        <span>{t('settings.memories.totalMemories')}: {memories.length}</span>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportMemories} disabled={memories.length === 0}>
            <Download className="w-4 h-4 mr-2" />
            {t('settings.memories.export')}
          </Button>
          <Button variant="destructive" size="sm" onClick={deleteAllMemories} disabled={memories.length === 0}>
            <Trash2 className="w-4 h-4 mr-2" />
            {t('settings.memories.clearAll')}
          </Button>
        </div>
      </div>

      {/* قائمة الذكريات */}
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
          </div>
        ) : memories.length === 0 ? (
          <div className="text-center py-8 text-[var(--text-secondary)]">
            <Brain className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>{language === 'ar' ? 'لا توجد ذكريات بعد' : 'No memories yet'}</p>
          </div>
        ) : (
          <AnimatePresence>
            {memories.map((memory) => (
              <motion.div
                key={memory.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="p-3 rounded-lg bg-[var(--background-secondary)] border border-[var(--border-color)]"
              >
                {editingMemory === memory.id ? (
                  <div className="space-y-2">
                    <Input
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && updateMemory(memory.id)}
                      className="w-full"
                    />
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={cancelEditing}>
                        <X className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={() => updateMemory(memory.id)}
                        disabled={isUpdating || !editContent.trim()}
                      >
                        {isUpdating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-[var(--text-primary)] break-words">{memory.content}</p>
                      <span className="text-xs text-[var(--text-secondary)]">
                        {formatDate(memory.created_at)}
                        {memory.updated_at !== memory.created_at && ` • ${language === 'ar' ? 'محدث' : 'Updated'}`}
                      </span>
                    </div>
                    <div className="flex gap-1 ml-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-[var(--text-secondary)] hover:text-[var(--text-primary)]" 
                        onClick={() => startEditing(memory)}
                      >
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-red-500 hover:bg-red-100" 
                        onClick={() => deleteMemory(memory.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
