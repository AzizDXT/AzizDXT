
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  Home,
  Users,
  BookOpen,
  Plus, // This import is no longer strictly needed for `sidebarItems` but could be used elsewhere. Keeping for now.
  User,
  GraduationCap,
  Settings,
  LogOut,
  Zap,
  MoreHorizontal,
  Bug,
  Trophy
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { useI18n } from '../utils/i18n';
import { User as UserAPI } from '@/api/entities';
import NotificationBell from '../notifications/NotificationBell';

export default function Sidebar({ currentPageName, isMobile }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, isRTL, language } = useI18n();
  const [showMobileMore, setShowMobileMore] = useState(false);

  // Define sidebar items without create button
  const [sidebarItems, setSidebarItems] = useState([
    {
      id: 'home',
      label: t('sidebar.home'),
      icon: <Home className="w-5 h-5" />,
      path: createPageUrl('Dashboard', 'tab=home'),
      isMobileVisible: true
    },
    {
      id: 'communities',
      label: t('sidebar.communities'),
      icon: <Users className="w-5 h-5" />,
      path: createPageUrl('Communities'),
      isMobileVisible: true
    },
    {
      id: 'ai',
      label: t('sidebar.ai'),
      icon: <Zap className="w-5 h-5" />,
      path: createPageUrl('AIAssistant'),
      isMobileVisible: true
    },
    {
      id: 'library',
      label: t('sidebar.library'),
      icon: <BookOpen className="w-5 h-5" />,
      path: createPageUrl('Library'),
      isMobileVisible: true
    },
    {
      id: 'academic',
      label: t('sidebar.academic'),
      icon: <GraduationCap className="w-5 h-5" />,
      path: createPageUrl('Academic'),
      isMobileVisible: false
    },
    {
      id: 'profile',
      label: t('sidebar.profile'),
      icon: <User className="w-5 h-5" />,
      path: createPageUrl('Profile'),
      isMobileVisible: false
    }
  ]);

  // Clean up localStorage and ensure proper initialization
  useEffect(() => {
    // Clear any old localStorage data that might contain 'settings'
    const savedLayout = localStorage.getItem('taleb-sidebar-layout');
    if (savedLayout) {
      try {
        const parsedLayout = JSON.parse(savedLayout);
        // If the saved layout contains 'settings', remove it completely
        if (Array.isArray(parsedLayout) && parsedLayout.some(item => item.id === 'settings')) {
          localStorage.removeItem('taleb-sidebar-layout');
          console.log('Removed old sidebar layout containing settings');
        }
      } catch (e) {
        // If there's an error parsing, remove the corrupted data
        localStorage.removeItem('taleb-sidebar-layout');
        console.log('Removed corrupted sidebar layout data');
      }
    }
  }, []);

  // Load custom sidebar layout from localStorage
  useEffect(() => {
    const savedLayout = localStorage.getItem('taleb-sidebar-layout');
    if (savedLayout) {
      try {
        const parsedLayout = JSON.parse(savedLayout);
        if (Array.isArray(parsedLayout) && parsedLayout.every(i => i.id && i.label)) {
          // Filter out any 'settings' items from saved layout
          const filteredLayout = parsedLayout.filter(item => item.id !== 'settings');
          
          // Update sidebar items with filtered layout while preserving icon and path information
          const updatedItems = filteredLayout.map(savedItem => {
            const existingItem = sidebarItems.find(item => item.id === savedItem.id);
            return existingItem ? { ...existingItem, label: savedItem.label } : savedItem;
          });
          setSidebarItems(updatedItems);
        }
      } catch (e) {
        console.error('Error parsing saved sidebar layout:', e);
        // If there's an error, clear localStorage and use default
        localStorage.removeItem('taleb-sidebar-layout');
        setSidebarItems([
          {
            id: 'home',
            label: t('sidebar.home'),
            icon: <Home className="w-5 h-5" />,
            path: createPageUrl('Dashboard', 'tab=home'),
            isMobileVisible: true
          },
          {
            id: 'communities',
            label: t('sidebar.communities'),
            icon: <Users className="w-5 h-5" />,
            path: createPageUrl('Communities'),
            isMobileVisible: true
          },
          {
            id: 'ai',
            label: t('sidebar.ai'),
            icon: <Zap className="w-5 h-5" />,
            path: createPageUrl('AIAssistant'),
            isMobileVisible: true
          },
          {
            id: 'library',
            label: t('sidebar.library'),
            icon: <BookOpen className="w-5 h-5" />,
            path: createPageUrl('Library'),
            isMobileVisible: true
          },
          {
            id: 'academic',
            label: t('sidebar.academic'),
            icon: <GraduationCap className="w-5 h-5" />,
            path: createPageUrl('Academic'),
            isMobileVisible: false
          },
          {
            id: 'profile',
            label: t('sidebar.profile'),
            icon: <User className="w-5 h-5" />,
            path: createPageUrl('Profile'),
            isMobileVisible: false
          }
        ]);
      }
    }
  }, []);

  // Listen for sidebar layout updates
  useEffect(() => {
    const handleSidebarLayoutUpdate = (event) => {
      const newLayout = event.detail;
      if (Array.isArray(newLayout) && newLayout.every(i => i.id && i.label)) {
        // Update sidebar items with new layout while preserving icon and path information
        const updatedItems = newLayout.map(savedItem => {
          const existingItem = sidebarItems.find(item => item.id === savedItem.id);
          return existingItem ? { ...existingItem, label: savedItem.label } : savedItem;
        });
        setSidebarItems(updatedItems);
      }
    };

    window.addEventListener('sidebarLayoutUpdated', handleSidebarLayoutUpdate);
    return () => {
      window.removeEventListener('sidebarLayoutUpdated', handleSidebarLayoutUpdate);
    };
  }, [sidebarItems]);

  // Function to determine if a sidebar item is currently active based on current page name and tab
  const isActive = (itemId) => {
    if (currentPageName === 'Dashboard') {
      const urlParams = new URLSearchParams(location.search);
      const tab = urlParams.get('tab') || 'home'; // Default to 'home' if no tab param
      return tab === itemId;
    }
    // For pages like Profile, Academic, etc., match currentPageName (lowercase) with item id
    const pageNameLower = currentPageName?.toLowerCase();
    
    // Handle special cases for mapping
    if (itemId === 'ai' && pageNameLower === 'aiassistant') return true;
    if (itemId === 'communities' && pageNameLower === 'communities') return true;
    if (itemId === 'library' && pageNameLower === 'library') return true;
    if (itemId === 'settings' && pageNameLower === 'settings') return true;
    if (itemId === 'profile' && pageNameLower === 'profile') return true;
    if (itemId === 'academic' && pageNameLower === 'academic') return true;
    
    return pageNameLower === itemId;
  };


  // Function to completely reset sidebar layout
  const resetSidebarLayout = () => {
    localStorage.removeItem('taleb-sidebar-layout');
    setSidebarItems([
      {
        id: 'home',
        label: t('sidebar.home'),
        icon: <Home className="w-5 h-5" />,
        path: createPageUrl('Dashboard', 'tab=home'),
        isMobileVisible: true
      },
      {
        id: 'communities',
        label: t('sidebar.communities'),
        icon: <Users className="w-5 h-5" />,
        path: createPageUrl('Communities'),
        isMobileVisible: true
      },
      {
        id: 'ai',
        label: t('sidebar.ai'),
        icon: <Zap className="w-5 h-5" />,
        path: createPageUrl('AIAssistant'),
        isMobileVisible: true
      },
       {
         id: 'library',
         label: t('sidebar.library'),
         icon: <BookOpen className="w-5 h-5" />,
         path: createPageUrl('Library'),
         isMobileVisible: true
       },
       {
         id: 'academic',
         label: t('sidebar.academic'),
         icon: <GraduationCap className="w-5 h-5" />,
         path: createPageUrl('Academic'),
         isMobileVisible: false
       },
      {
        id: 'profile',
        label: t('sidebar.profile'),
        icon: <User className="w-5 h-5" />,
        path: createPageUrl('Profile'),
        isMobileVisible: false
      }
    ]);
  };

  const handleItemClick = (item) => {
    console.log('Navigating to:', item.path); // للتتبع
    navigate(item.path);
    // Close mobile "More" menu when an item is clicked
    setShowMobileMore(false);
  };

  return (
    <>
      {/* Desktop Sidebar (hidden on mobile, replaced by bottom nav) */}
      <aside
        className={`fixed top-0 ${isRTL ? 'right-0' : 'left-0'} h-full bg-[var(--background)]
          border-${isRTL ? 'l' : 'r'} border-[var(--border-color)]
          flex flex-col justify-between py-6 z-40 transition-all duration-300
          ${isMobile ? 'hidden' : 'w-20'}
        `}
      >
        {/* Logo at the top */}
        <div className="flex justify-center mb-6">
          <div className="w-12 h-12 rounded-xl overflow-hidden shadow-lg">
            <img
              src="/logo.png"
              alt="Taleb Logo"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

         {/* Leaderboard Button below logo */}
         <div className="flex justify-center mb-6">
           <button
             onClick={() => navigate(createPageUrl('Leaderboard'))}
             className="flex items-center justify-center w-12 h-12 rounded-2xl
               text-amber-600 hover:bg-amber-50 hover:text-amber-700
               transition-all duration-300 group relative hover:scale-105
               border-2 border-amber-200 hover:border-amber-300"
             title={t('sidebar.leaderboard') || (language === 'ar' ? 'لوحة المتصدرين' : 'Leaderboard')}
           >
             <Trophy className="w-5 h-5" />

             <span className={`absolute ${isRTL ? 'right-16' : 'left-16'}
               bg-amber-50 text-amber-700
               px-3 py-2 rounded-lg text-sm font-medium
               opacity-0 group-hover:opacity-100 transition-opacity duration-200
               pointer-events-none whitespace-nowrap shadow-lg border border-amber-200
             `}>
               {t('sidebar.leaderboard')}
             </span>
           </button>
         </div>

         {/* Notification Bell below leaderboard */}
         <div className="flex justify-center mb-6">
           <NotificationBell />
         </div>

        {/* Navigation Items in the center */}
        <nav className="flex-1 flex flex-col items-center justify-center space-y-4">
          {sidebarItems.map((item, index) => {
            const active = isActive(item.id);

            return (
              <div
                key={`${item.id}-${index}`}
                className="relative"
              >
                <button
                  onClick={() => handleItemClick(item)}
                  className={`flex items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 group relative ${
                    active
                      ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)] shadow-lg scale-110'
                      : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)] hover:scale-105'
                  }`}
                  title={item.label}
                >
                  {item.icon}

                  {/* Label for larger screens */}
                  <span className={`absolute ${isRTL ? 'right-16' : 'left-16'}
                    bg-[var(--background)] text-[var(--text-primary)]
                    px-3 py-2 rounded-lg text-sm font-medium
                    opacity-0 group-hover:opacity-100 transition-opacity duration-200
                    pointer-events-none whitespace-nowrap shadow-lg border border-[var(--border-color)]
                  `}>
                    {item.label}
                  </span>
                </button>
              </div>
            );
          })}
        </nav>

        {/* Bottom Actions - Settings and Logout */}
        <div className="flex flex-col items-center space-y-4">
           {/* Debug Button */}
           <div>
             <button
               onClick={() => {
                 // فتح Debug العام
                 window.dispatchEvent(new CustomEvent('openDebugCenter'));
               }}
               className="flex items-center justify-center w-12 h-12 rounded-2xl
                 text-red-500 hover:bg-red-50 hover:text-red-600
                 transition-all duration-300 group relative hover:scale-105
                 border-2 border-red-200 hover:border-red-300"
               title={t('sidebar.debugGeneral') || (language === 'ar' ? 'Debug العام' : 'Debug General')}
             >
               <Bug className="w-5 h-5" />

               <span className={`absolute ${isRTL ? 'right-16' : 'left-16'}
                 bg-red-50 text-red-600
                 px-3 py-2 rounded-lg text-sm font-medium
                 opacity-0 group-hover:opacity-100 transition-opacity duration-200
                 pointer-events-none whitespace-nowrap shadow-lg border border-red-200
               `}>
                 {t('sidebar.debugGeneral') || 'Debug General'}
               </span>
             </button>
           </div>

          {/* Settings Button */}
          <div>
            <button
              onClick={() => navigate(createPageUrl('Settings'))}
              className="flex items-center justify-center w-12 h-12 rounded-2xl
                text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]
                transition-all duration-300 group relative hover:scale-105"
              title={t('sidebar.settings') || (language === 'ar' ? 'الإعدادات' : 'Settings')}
            >
              <Settings className="w-5 h-5" />

              <span className={`absolute ${isRTL ? 'right-16' : 'left-16'}
                bg-[var(--background)] text-[var(--text-primary)]
                px-3 py-2 rounded-lg text-sm font-medium
                opacity-0 group-hover:opacity-100 transition-opacity duration-200
                pointer-events-none whitespace-nowrap shadow-lg border border-[var(--border-color)]
              `}>
                {t('sidebar.settings')}
              </span>
            </button>
          </div>

        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <AnimatePresence>
        {isMobile && (
          <motion.nav
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className={`mobile-sidebar-bottom fixed bottom-0 left-0 right-0 bg-[var(--background)] border-t border-[var(--border-color)] px-4 py-2 z-50 ${
              isRTL ? 'flex-row-reverse' : 'flex-row'
            } flex items-center justify-around`}
          >
            {/* Show first 4 main items */}
            {sidebarItems.filter(item => item.isMobileVisible).slice(0, 4).map((item) => (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleItemClick(item)}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all duration-200 ${
                  isActive(item.id)
                    ? 'text-[var(--accent-color)]'
                    : 'text-[var(--text-secondary)]'
                }`}
              >
                {React.cloneElement(item.icon, { className: "w-5 h-5" })}
                <span className="text-xs font-medium">{t(`sidebar.${item.id}`)}</span>
              </motion.button>
            ))}

            {/* Notification Bell in mobile */}
            <div className="flex flex-col items-center gap-1">
              <NotificationBell />
              <span className="text-xs font-medium text-[var(--text-secondary)]">
                {t('sidebar.notifications')}
              </span>
            </div>

             {/* Debug button in mobile */}
             <div className="flex flex-col items-center gap-1">
               <motion.button
                 whileTap={{ scale: 0.9 }}
                 onClick={() => {
                   window.dispatchEvent(new CustomEvent('openDebugCenter'));
                 }}
                 className="flex flex-col items-center gap-1 p-2 rounded-lg transition-colors text-red-500 hover:bg-red-50 border-2 border-red-200"
               >
                 <Bug className="w-5 h-5" />
                 <span className="text-xs font-medium">Debug</span>
               </motion.button>
             </div>

            {/* More button for additional items */}
            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowMobileMore(!showMobileMore)}
                className="flex flex-col items-center gap-1 p-2 rounded-lg transition-colors text-[var(--text-secondary)]"
              >
                <MoreHorizontal className="w-5 h-5" />
                <span className="text-xs font-medium">{t('common.more')}</span>
              </motion.button>

              <AnimatePresence>
                {showMobileMore && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    transition={{ duration: 0.15 }}
                    className={`absolute bottom-full ${isRTL ? 'left-0' : 'right-0'} mb-2 bg-[var(--background)] border border-[var(--border-color)] rounded-xl shadow-xl p-2 min-w-40`}
                  >
                    {sidebarItems.filter(item => !item.isMobileVisible).map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(item)}
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors w-full ${
                          isActive(item.id)
                            ? 'bg-[var(--background-secondary)] text-[var(--accent-color)]'
                            : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]'
                        }`}
                      >
                        {React.cloneElement(item.icon, { className: "w-4 h-4" })}
                        <span className="text-sm">{item.label}</span>
                      </button>
                    ))}
                    {/* Reset button for mobile more menu */}
                    <button
                      onClick={resetSidebarLayout}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors w-full text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]"
                    >
                      <Settings className="w-4 h-4" />
                      <span className="text-sm">{t('sidebar.resetLayout')}</span>
                    </button>
                    
                     {/* Debug button for mobile more menu */}
                     <button
                       onClick={() => {
                         setShowMobileMore(false);
                         window.dispatchEvent(new CustomEvent('openDebugCenter'));
                       }}
                       className="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors w-full text-red-500 hover:bg-red-50 hover:text-red-600 border-2 border-red-200"
                     >
                       <Bug className="w-4 h-4" />
                       <span className="text-sm">{t('sidebar.debugGeneral') || 'Debug General'}</span>
                     </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>

    </>
  );
}
