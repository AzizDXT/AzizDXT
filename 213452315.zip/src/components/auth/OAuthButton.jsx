import React from 'react';

function GoogleIcon() {
 return (
 <svg viewBox="0 0 24 24" className="w-full h-full">
 <path
 fill="#4285F4"
 d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
 />
 <path
 fill="#34A853"
 d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
 />
 <path
 fill="#FBBC05"
 d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
 />
 <path
 fill="#EA4335"
 d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
 />
 </svg>
 );
}

function AppleIcon({ isDark, isDisabled = false }) {
  const fillColor = isDisabled ? "#9CA3AF" : (isDark ? "#000000" : "#FFFFFF");
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className="w-full h-full"
      fill={fillColor}
    >
      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
    </svg>
  );
}

function MicrosoftIcon({ isDark, isDisabled = false }) {
  const colors = isDisabled ? {
    red: "#9CA3AF",
    blue: "#9CA3AF", 
    green: "#9CA3AF",
    yellow: "#9CA3AF"
  } : isDark ? {
    red: "#F25022",
    blue: "#00A4EF", 
    green: "#7FBA00",
    yellow: "#FFB900"
  } : {
    red: "#F25022",
    blue: "#00A4EF",
    green: "#7FBA00", 
    yellow: "#FFB900"
  };
  
 return (
 <svg viewBox="0 0 24 24" className="w-full h-full">
 <path fill={colors.red} d="M1 1h10v10H1z" />
 <path fill={colors.blue} d="M13 1h10v10H13z" />
 <path fill={colors.green} d="M1 13h10v10H1z" />
 <path fill={colors.yellow} d="M13 13h10v10H13z" />
 </svg>
 );
}

export default function OAuthButton({ provider, children, onClick, disabled = false, theme = 'light' }) {
  const isDark = theme === 'dark';
  
  // Disable Apple and Microsoft buttons
  const isDisabled = disabled || provider === 'apple' || provider === 'microsoft';
  
  const handleGoogleLogin = async () => {
    if (!window.google || !window.google.accounts) {
      console.error('Google Identity Services not loaded');
      return;
    }

    try {
      // Prompt for Google Sign-In
      const response = await new Promise((resolve, reject) => {
        window.google.accounts.id.prompt((notification) => {
          if (notification.isNotDisplayed()) {
            reject(new Error('Google Sign-In not displayed'));
          } else if (notification.isSkippedMoment()) {
            reject(new Error('Google Sign-In skipped'));
          } else if (notification.isDismissedMoment()) {
            reject(new Error('Google Sign-In dismissed'));
          }
        });

        // Set up callback for when user signs in
        window.google.accounts.id.initialize({
          client_id: '878560054397-ub4mlc59r6qklq6rpds2alhf0nbsrm0r.apps.googleusercontent.com',
          callback: (response) => {
            resolve(response);
          },
        });
      });

      // Decode JWT token to get user info
      const payload = JSON.parse(atob(response.credential.split('.')[1]));
      
      // Extract user data from JWT payload
      const userData = {
        access_token: response.credential, // ID Token (JWT)
        google_id: payload.sub,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
        device_info: navigator.userAgent
      };

      console.log('Google Sign-In successful:', userData);
      
      // Call the onClick handler with Google data
      if (onClick) {
        onClick(userData);
      }
    } catch (error) {
      console.error('Google Sign-In error:', error);
      // Fallback to manual prompt
      if (window.google && window.google.accounts) {
        window.google.accounts.id.prompt();
      }
    }
  };

  const handleClick = () => {
    if (provider === 'google') {
      handleGoogleLogin();
    } else if (provider === 'apple') {
      // Apple OAuth - for now just call onClick, implement actual Apple Sign-In later
      console.log('Apple Sign-In requested - implementation pending');
      if (onClick) {
        onClick();
      }
    } else if (onClick) {
      onClick();
    }
  };

 return (
 <button
 type="button"
 onClick={isDisabled ? undefined : handleClick}
 disabled={isDisabled}
 className={`w-full h-11 sm:h-12 rounded-lg sm:rounded-xl font-medium text-center transition-all duration-300 ease-out transform hover:scale-[1.02] hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed interactive-element ${
   isDisabled 
     ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
     : theme === 'dark' 
       ? 'bg-white text-black hover:bg-gray-100' 
       : 'bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90'
 }`}
 >
 <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse">
 <div className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0">
 {provider === 'google' ? <GoogleIcon /> : provider === 'apple' ? <AppleIcon isDark={theme === 'dark'} isDisabled={isDisabled} /> : <MicrosoftIcon isDark={theme === 'dark'} isDisabled={isDisabled} />}
 </div>
 
 <span className="text-sm font-medium">
 {children}
 </span>
 </div>
 </button>
 );
}
