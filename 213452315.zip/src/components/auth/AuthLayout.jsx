import React from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '../utils/i18n';
import { useTheme } from '../utils/theme';

export default function AuthLayout({ children }) {
  const { t, isRTL } = useI18n();
  const { theme } = useTheme();

  return (
    <div className={`min-h-screen flex ${isRTL ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Logo Side */}
      <motion.div 
        className={`bg-[var(--background)] relative overflow-hidden hidden lg:flex flex-1 items-center justify-center p-12 ${
          theme === 'dark' ? 'creative-gradient' : ''
        }`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        {/* Background Pattern */}
        <div className={`absolute inset-0 opacity-10 ${theme === 'dark' ? 'opacity-20' : 'opacity-10'}`}>
            <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-full blur-3xl animate-pulse" />
            <div className="absolute top-32 right-20 w-24 h-24 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full blur-2xl animate-pulse" />
            <div className="absolute bottom-20 left-20 w-28 h-28 bg-gradient-to-br from-green-400 to-emerald-400 rounded-full blur-2xl animate-pulse" />
        </div>

        {/* Main Content */}
        <div className="relative z-10 flex items-center justify-center w-full">
          <div className="text-center max-w-md">
            {/* Logo with Simple Animation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ 
                duration: 0.6,
                ease: "easeOut"
              }}
              className="relative mb-8"
            >
              <motion.div
                animate={{ 
                  y: [0, -8, 0],
                  rotateY: [0, 5, 0, -5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`relative w-48 h-48 mx-auto ${theme === 'dark' ? 'drop-shadow-2xl' : 'drop-shadow-lg'}`}
              >
                <img
                  src="/src/assets/logo.png"
                  alt="Taleb Logo"
                  className="w-full h-full object-contain"
                />
              </motion.div>
            </motion.div>

            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="space-y-4"
            >
              <h1 className={`text-6xl font-bold mb-4 text-[var(--text-primary)]`}>
                {t('app.name')}
              </h1>
              <p className="text-xl font-light text-[var(--text-secondary)]">
                {t('hero.title')}
              </p>
              <div className="mt-6 text-sm font-medium opacity-75 text-[var(--text-secondary)]">
                {t('app.tagline')}
              </div>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Form Side */}
      <motion.div 
        className={`w-full lg:w-1/2 flex items-center justify-center p-3 sm:p-4 relative overflow-hidden bg-[var(--background-secondary)]`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
      >
        {/* Content Container */}
        <div className="w-full max-w-md relative z-10">
          {children}
        </div>
      </motion.div>
    </div>
  );
}
