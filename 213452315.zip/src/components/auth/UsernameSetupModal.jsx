import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  User, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  Save,
  X
} from 'lucide-react';
import { useI18n } from '../utils/i18n';
import { useTheme } from '../utils/theme';
import api from '../utils/api';

export default function UsernameSetupModal({ 
  isOpen, 
  onClose, 
  onComplete, 
  userData 
}) {
  const { t, language, isRTL } = useI18n();
  const { theme } = useTheme();
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [validation, setValidation] = useState({ status: 'idle', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const usernameTimeoutRef = useRef(null);

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setUsername('');
      setValidation({ status: 'idle', message: '' });
      setIsLoading(false);
      setIsSubmitting(false);
    }
  }, [isOpen]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (usernameTimeoutRef.current) {
        clearTimeout(usernameTimeoutRef.current);
      }
    };
  }, []);

  const handleUsernameChange = (value) => {
    setUsername(value);
    setValidation({ status: 'idle', message: '' });
    
    if (value.trim()) {
      setValidation({ status: 'checking', message: t('validation.checking') || 'Checking...' });
      
      // Clear existing timeout
      if (usernameTimeoutRef.current) {
        clearTimeout(usernameTimeoutRef.current);
      }
      
      // Set new timeout for 1 second after user stops typing
      usernameTimeoutRef.current = setTimeout(async () => {
        try {
          const result = await api.checkUsername(value.trim());
          setValidation({ 
            status: result.available ? 'available' : 'unavailable', 
            message: result.message 
          });
        } catch (error) {
          setValidation({ status: 'error', message: 'Validation failed' });
        }
      }, 1000); // 1 second delay
    } else {
      setValidation({ status: 'idle', message: '' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!username.trim()) {
      setValidation({ status: 'error', message: t('errors.usernameRequired') || 'Username is required' });
      return;
    }
    
    if (validation.status === 'unavailable') {
      setValidation({ status: 'error', message: t('errors.usernameUnavailable') || 'Username is not available' });
      return;
    }
    
    if (validation.status === 'checking') {
      setValidation({ status: 'error', message: t('errors.waitForCheck') || 'Please wait for username check' });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Update user profile with username
      await api.updateProfile({ username: username.trim() });
      
      // Call onComplete to redirect to profile
      onComplete();
    } catch (error) {
      console.error('Error updating username:', error);
      setValidation({ status: 'error', message: error.message || 'Failed to update username' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getValidationIcon = () => {
    switch (validation.status) {
      case 'checking':
        return <Loader2 className="w-5 h-5 animate-spin text-blue-500" />;
      case 'available':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'unavailable':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getValidationColor = () => {
    switch (validation.status) {
      case 'available':
        return 'text-green-500';
      case 'unavailable':
      case 'error':
        return 'text-red-500';
      case 'checking':
        return 'text-blue-500';
      default:
        return 'text-gray-500';
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className={`relative w-full max-w-md ${theme === 'dark' ? 'card-dark glass-effect' : 'bg-white'} rounded-2xl shadow-2xl border border-[var(--border-color)] overflow-hidden`}
        >
          {/* Header */}
          <div className="relative p-6 border-b border-[var(--border-color)]">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              <X className="w-5 h-5 text-[var(--text-secondary)]" />
            </button>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">
                {language === 'ar' ? 'إنشاء اسم المستخدم' : 'Create Username'}
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                {language === 'ar' 
                  ? 'مرحباً بك! يرجى إنشاء اسم مستخدم فريد لاستكمال حسابك'
                  : 'Welcome! Please create a unique username to complete your account'
                }
              </p>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-[var(--text-primary)]">
                {language === 'ar' ? 'اسم المستخدم' : 'Username'}
              </Label>
              <div className="relative">
                <User className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]`} />
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => handleUsernameChange(e.target.value)}
                  placeholder={language === 'ar' ? 'أدخل اسم المستخدم' : 'Enter username'}
                  className={`${isRTL ? 'pr-12' : 'pl-12'} h-12 rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300`}
                  disabled={isSubmitting}
                />
                {validation.status !== 'idle' && (
                  <div className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2`}>
                    {getValidationIcon()}
                  </div>
                )}
              </div>
              
              {/* Validation Message */}
              {validation.message && (
                <p className={`text-xs mt-1 ${getValidationColor()}`}>
                  {validation.message}
                </p>
              )}
            </div>

            {/* User Info Preview */}
            {userData && (
              <div className="p-4 bg-[var(--background-secondary)] rounded-xl border border-[var(--border-color)]">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <img
                    src={userData.picture}
                    alt={userData.name}
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <p className="font-medium text-[var(--text-primary)]">{userData.name}</p>
                    <p className="text-sm text-[var(--text-secondary)]">{userData.email}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isSubmitting || validation.status === 'unavailable' || validation.status === 'checking'}
              className="w-full h-12 rounded-xl bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90 transition-all duration-300"
            >
              {isSubmitting ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Save className="w-5 h-5" />
                  <span>{language === 'ar' ? 'حفظ والانتقال للملف الشخصي' : 'Save & Go to Profile'}</span>
                </div>
              )}
            </Button>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
} 