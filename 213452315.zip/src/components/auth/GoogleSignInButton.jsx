import React, { useEffect, useRef, useState } from 'react';
import { useI18n } from '../utils/i18n';

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-full h-full">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );
}

export default function GoogleSignInButton({ 
  onSuccess, 
  onError, 
  disabled = false, 
  theme = 'light',
  className = '' 
}) {
  const { t, language } = useI18n();
  const isInitialized = useRef(false);
  const [isSigningIn, setIsSigningIn] = useState(false);

  useEffect(() => {
    // Wait a bit for the page to fully load
    const timer = setTimeout(() => {
      // Load Google Identity Services script if not already loaded
      if (!window.google || !window.google.accounts) {
        console.log('Google not available, loading script...');
        loadGoogleScript();
      } else {
        console.log('Google already available, initializing...');
        initializeGoogleSignIn();
        isInitialized.current = true;
      }
    }, 100);

    // Cleanup function
    return () => {
      clearTimeout(timer);
      // Reset signing in state when component unmounts
      setIsSigningIn(false);
    };
  }, []);

  const loadGoogleScript = () => {
    // Check if script is already loaded
    if (document.querySelector('script[src*="accounts.google.com/gsi/client"]')) {
      console.log('Google script already exists, waiting for it to load...');
      // Wait a bit for the script to finish loading
      setTimeout(() => {
        if (window.google && window.google.accounts) {
          initializeGoogleSignIn();
          isInitialized.current = true;
        } else {
          console.warn('Google script exists but not loaded yet, retrying...');
          setTimeout(() => {
            if (window.google && window.google.accounts) {
              initializeGoogleSignIn();
              isInitialized.current = true;
            }
          }, 1000);
        }
      }, 100);
      return;
    }

    console.log('Loading Google Identity Services script...');
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => {
      console.log('Google script loaded successfully');
      if (window.google && window.google.accounts) {
        initializeGoogleSignIn();
        isInitialized.current = true;
      } else {
        console.warn('Google script loaded but accounts not available yet');
      }
    };
    script.onerror = (error) => {
      console.error('Failed to load Google script:', error);
    };
    document.head.appendChild(script);
  };

  const initializeGoogleSignIn = () => {
    if (!window.google || !window.google.accounts) {
      console.error('Google Identity Services not loaded');
      return;
    }

    try {
      console.log('Initializing Google Sign-In...');
      
      // Add FedCM support to avoid future deprecation warnings
      const config = {
        client_id: '878560054397-ub4mlc59r6qklq6rpds2alhf0nbsrm0r.apps.googleusercontent.com',
        callback: handleCredentialResponse,
        auto_select: false,
        cancel_on_tap_outside: true,
        prompt_parent_id: null, // Let Google handle positioning
        state_cookie_domain: window.location.hostname,
        ux_mode: 'popup',
        itp_support: true,
      };

      // Add FedCM support if available
      if (window.FederatedCredential) {
        config.fedcm_support = true;
        console.log('FedCM support enabled for future compatibility');
      }
      
      window.google.accounts.id.initialize(config);
      
      console.log('Google Sign-In initialized successfully');
    } catch (error) {
      console.error('Error initializing Google Sign-In:', error);
      if (onError) onError(error);
    }
  };

  const handleCredentialResponse = (response) => {
    try {
      // Prevent multiple calls
      if (isSigningIn) {
        console.log('Google Sign-In already in progress, ignoring duplicate response');
        return;
      }
      
      setIsSigningIn(true);
      
      // Decode JWT token to get user info
      const payload = JSON.parse(atob(response.credential.split('.')[1]));
      
      // Extract user data from JWT payload
      const userData = {
        access_token: response.credential, // ID Token (JWT)
        google_id: payload.sub,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
        device_info: navigator.userAgent
      };

      console.log('Google Sign-In successful:', userData);
      
      if (onSuccess) {
        onSuccess(userData);
      }
    } catch (error) {
      console.error('Error processing Google Sign-In response:', error);
      if (onError) onError(error);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleGoogleSignIn = () => {
    if (!window.google || !window.google.accounts) {
      console.error('Google Identity Services not loaded');
      return;
    }

    if (isSigningIn) {
      console.log('Google Sign-In already in progress');
      return;
    }

    // Check if we're in a proper environment for Google Sign-In
    if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
      console.warn('Google Sign-In requires HTTPS (except for localhost)');
    }

    // Check for common issues that might cause suppression
    if (window.navigator.userAgent.includes('Chrome') && window.navigator.userAgent.includes('Headless')) {
      console.warn('Chrome Headless detected - Google Sign-In may not work properly');
    }

    // Check browser-specific issues
    const userAgent = window.navigator.userAgent;
    if (userAgent.includes('Firefox')) {
      console.log('Firefox detected - checking for privacy settings that might block Google Sign-In');
    } else if (userAgent.includes('Safari')) {
      console.log('Safari detected - checking for Intelligent Tracking Prevention settings');
    } else if (userAgent.includes('Edge')) {
      console.log('Edge detected - checking for privacy settings');
    }

    try {
      // Try to render the button first to ensure it's properly initialized
      if (window.google.accounts.id.renderButton) {
        console.log('Attempting to render Google Sign-In button...');
      }

      // Prompt for Google Sign-In with better error handling
      window.google.accounts.id.prompt((notification) => {
        console.log('Google Sign-In notification:', notification);
        
        if (notification.isNotDisplayed()) {
          // Check specific reasons why it's not displayed
          const reason = notification.getNotDisplayedReason();
          console.warn('Google Sign-In not displayed, reason:', reason);
          
          // Don't treat this as a critical error - it might be temporary
          // Just log it and let the user try again
          if (reason === 'browser_not_supported') {
            console.warn('Browser not supported for Google Sign-In');
          } else if (reason === 'invalid_client') {
            console.warn('Invalid client configuration');
          } else if (reason === 'opt_out_or_no_session') {
            console.warn('User opted out or no active session');
          } else if (reason === 'secure_http_required') {
            console.warn('HTTPS required for Google Sign-In');
          } else if (reason === 'blocked_by_user') {
            console.warn('Google Sign-In blocked by user or browser');
          } else if (reason === 'suppressed_by_user') {
            console.warn('Google Sign-In suppressed by user or browser settings');
            // This is a common issue - provide helpful guidance
            console.log('💡 Tips to fix "suppressed_by_user":');
            console.log('   1. Check if popup blocker is enabled');
            console.log('   2. Allow popups for this site');
            console.log('   3. Check browser privacy settings');
            console.log('   4. Try refreshing the page');
            console.log('   5. Check if you have multiple Google accounts signed in');
            console.log('   6. Try signing out and signing back in to Google');
            console.log('   7. Check if you have any browser extensions blocking Google services');
            console.log('   8. Try using incognito/private browsing mode');
            console.log('   9. Check if your organization has blocked Google Sign-In');
          } else {
            console.warn('Unknown reason for not displaying:', reason);
          }
          
          // Don't call onError for these cases - let user retry
          // Instead, show a user-friendly message
          console.log('Google Sign-In not available at the moment. Please try again or check your browser settings.');
        } else if (notification.isSkippedMoment()) {
          console.log('Google Sign-In skipped - user may have another sign-in method active');
          // Don't treat this as an error
        } else if (notification.isDismissedMoment()) {
          console.log('Google Sign-In prompt dismissed - this is normal behavior');
          // Don't call onError here as it's not necessarily an error
        } else {
          console.log('Google Sign-In notification handled successfully');
        }
      });
    } catch (error) {
      console.error('Error prompting Google Sign-In:', error);
      // Only call onError for actual errors, not for display issues
      if (onError && error.message !== 'Google Sign-In not displayed') {
        onError(error);
      }
    }
  };

  return (
    <button
      type="button"
      onClick={handleGoogleSignIn}
      disabled={disabled || isSigningIn}
      className={`w-full h-11 sm:h-12 rounded-lg sm:rounded-xl font-medium text-center transition-all duration-300 ease-out transform hover:scale-[1.02] hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed interactive-element ${
        theme === 'dark' 
          ? 'bg-white text-black hover:bg-gray-100' 
          : 'bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90'
      } ${className}`}
    >
      <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse">
        <div className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0">
          <GoogleIcon />
        </div>
        <span className="text-sm font-medium">
          {isSigningIn ? t('auth.signingIn') || 'Signing in...' : t('auth.googleButton')}
        </span>
      </div>
    </button>
  );
} 