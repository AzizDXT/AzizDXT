import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import mermaid from 'mermaid';
import { 
  MessageCircle, 
  Loader2, 
  Paintbrush, 
  Eye, 
  Download, 
  ExternalLink,
  FileText,
  Image as ImageIcon,
  ChevronDown,
  Info,
  Search,
  Hash,
  FileType,
  Copy,
  Edit,
  X,
  Play,
  Square,
  AlertCircle,
  CheckCircle,
  Cloud,
  CloudUpload,
  Terminal
} from 'lucide-react';
import { API_BASE_URL, loadImageWithCache, uploadImageFromUrl } from '../utils/api';
import HTMLCodeBlock from './HTMLCodeBlock';
import 'katex/dist/katex.min.css'; // KaTeX styles for math rendering

// Python Code Block Component with integrated runner and auto-operations support
// Example usage in markdown:
// ```python
// import matplotlib.pyplot as plt
// import numpy as np
// 
// # Create data
// x = np.linspace(0, 10, 100)
// y = np.sin(x)
// 
// # Create plot
// plt.figure(figsize=(10, 6))
// plt.plot(x, y, 'b-', linewidth=2, label='sin(x)')
// plt.xlabel('X')
// plt.ylabel('Y')
// plt.title('Sine Wave')
// plt.legend()
// plt.grid(True)
// plt.show()  # This will capture and display the plot
// 
// # Print output
// print("Hello from Python!")
// print(f"Maximum value: {np.max(y):.3f}")
// 
// # Test pandas if available
// try:
//     import pandas as pd
//     df = pd.DataFrame({'x': x[:10], 'y': y[:10]})
//     print("\nFirst 5 rows:")
//     print(df.head())
// except ImportError:
//     print("Pandas not available")
// ```
const PythonCodeBlock = ({ code, autoOperationsActive = false }) => {
  const [showRunner, setShowRunner] = useState(autoOperationsActive); // Only show runner if Auto Operations is active
  const [isCollapsed, setIsCollapsed] = useState(autoOperationsActive);
  const [hasAutoRun, setHasAutoRun] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const runnerRef = useRef(null);
  const codeBlockRef = useRef(null);

  // Intersection Observer for auto-run when visible (only if Auto Operations is enabled)
  useEffect(() => {
    if (!codeBlockRef.current || !autoOperationsActive) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAutoRun && autoOperationsActive) {
          setIsVisible(true);
          console.log('🔍 Python code block is now visible with Auto Operations enabled, preparing auto-run...');
          
          // Auto-run when code becomes visible AND Auto Operations is enabled
          setShowRunner(true);
          setIsCollapsed(true);
          setHasAutoRun(true);
          
          // Trigger auto-run with proper delay for component mounting
          const timer = setTimeout(() => {
            if (runnerRef.current && runnerRef.current.runPython) {
              const message = window.language === 'en' 
                ? '🚀 Auto-running Python code - Auto Operations enabled & code visible'
                : '🚀 تشغيل تلقائي لكود Python - العمليات التلقائية مفعلة والكود ظاهر';
              console.log(message);
              runnerRef.current.runPython();
            } else {
              console.warn('⚠️ Auto-run failed: runnerRef or runPython not available');
              // Retry after a longer delay
              const retryTimer = setTimeout(() => {
                if (runnerRef.current && runnerRef.current.runPython) {
                  console.log('🔄 Retrying auto-run...');
                  runnerRef.current.runPython();
                }
              }, 1000);
              return () => clearTimeout(retryTimer);
            }
          }, 800); // Slightly longer delay for better reliability
          
          return () => clearTimeout(timer);
        }
      },
      { 
        threshold: 0.3, // Trigger when 30% of the code block is visible
        rootMargin: '50px' // Start preparing 50px before it's fully visible
      }
    );

    observer.observe(codeBlockRef.current);

    return () => {
      observer.disconnect();
    };
  }, [hasAutoRun, autoOperationsActive]);

  // Immediate auto-run for autoOperationsActive (when not using intersection observer)
  useEffect(() => {
    if (autoOperationsActive && !hasAutoRun && !isVisible) {
      console.log('🔍 Auto Operations enabled, running code immediately...');
      setShowRunner(true);
      setIsCollapsed(true);
      setHasAutoRun(true);
      
      const timer = setTimeout(() => {
        if (runnerRef.current && runnerRef.current.runPython) {
          console.log('🚀 Auto-running Python code - Auto Operations enabled (immediate)');
          runnerRef.current.runPython();
        }
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [autoOperationsActive, hasAutoRun, isVisible]);

  // Control visibility and collapse state
  useEffect(() => {
    console.log('🔧 Auto Operations state changed:', autoOperationsActive);
    if (autoOperationsActive) {
      // When Auto Operations is active, show runner and collapse
      console.log('✅ Auto Operations enabled - showing runner, collapsing code');
      setShowRunner(true);
      setIsCollapsed(true);
    } else {
      // When Auto Operations is disabled, hide runner completely
      console.log('❌ Auto Operations disabled - hiding runner completely');
      setShowRunner(false);
      setIsCollapsed(false);
    }
  }, [autoOperationsActive]);

  // Handle visibility-based auto-run (only when Auto Operations is active)
  useEffect(() => {
    if (autoOperationsActive && isVisible && !hasAutoRun) {
      setIsCollapsed(true);
    }
  }, [autoOperationsActive, isVisible, hasAutoRun]);
  
  return (
    <div ref={codeBlockRef} className="mb-4 rounded-xl overflow-hidden border border-[var(--border-color)] shadow-sm">
      {/* Header with language and controls */}
      <div className="flex items-center justify-between bg-[var(--background-secondary)] text-[var(--text-primary)] px-4 py-2 text-xs border-b border-[var(--border-color)]">
        <div className="flex items-center gap-2">
          <span className="font-medium">Python</span>
          {showRunner && (
            <span className="px-2 py-1 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 rounded-full text-xs">
              تفاعلي
            </span>
          )}
          {autoOperationsActive && (
            <span className="px-2 py-1 bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300 rounded-full text-xs">
              تلقائي
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isCollapsed && (
            <button
              onClick={() => setIsCollapsed(false)}
              className="flex items-center gap-1 px-2 py-1 rounded transition-colors hover:bg-[var(--background-tertiary)] text-blue-600 dark:text-blue-400"
            >
              <ChevronDown className="w-3 h-3" />
              توسيع الكود
            </button>
          )}
          <button
            onClick={() => setShowRunner(!showRunner)}
            className={`flex items-center gap-1 px-2 py-1 rounded transition-colors ${
              showRunner 
                ? 'bg-green-100 hover:bg-green-200 text-green-700 dark:bg-green-900/30 dark:hover:bg-green-800/40 dark:text-green-300'
                : autoOperationsActive
                ? 'hover:bg-[var(--background-tertiary)]'
                : 'bg-orange-100 hover:bg-orange-200 text-orange-700 dark:bg-orange-900/30 dark:hover:bg-orange-800/40 dark:text-orange-300'
            }`}
          >
            <Play className="w-3 h-3" />
            {showRunner ? 'إخفاء المشغل' : autoOperationsActive ? 'تشغيل' : 'تشغيل يدوي'}
          </button>
          <button
            onClick={() => navigator.clipboard.writeText(code)}
            className="flex items-center gap-1 hover:bg-[var(--background-tertiary)] px-2 py-1 rounded transition-colors"
          >
            <Copy className="w-3 h-3" />
            نسخ
          </button>
        </div>
      </div>
      
      {/* Code Display */}
      {(!isCollapsed || !autoOperationsActive) ? (
        <div className="bg-[var(--background)] text-[var(--text-primary)]">
          <SyntaxHighlighter
            style={{
              ...oneDark,
              'pre[class*="language-"]': {
                ...oneDark['pre[class*="language-"]'],
                background: 'transparent !important',
                color: 'var(--text-primary)'
              },
              'code[class*="language-"]': {
                ...oneDark['code[class*="language-"]'],
                background: 'transparent !important',
                color: 'var(--text-primary)'
              }
            }}
            language="python"
            PreTag="div"
            className="!mt-0 !rounded-none !bg-transparent"
            customStyle={{
              margin: 0,
              backgroundColor: 'transparent',
              color: 'var(--text-primary)',
              borderRadius: 0,
            }}
          >
            {code}
          </SyntaxHighlighter>
        </div>
      ) : (autoOperationsActive && isCollapsed) ? (
        <div className="bg-gradient-to-r from-orange-50 to-green-50 dark:from-orange-900/20 dark:to-green-900/20 text-[var(--text-secondary)] p-4 text-center border border-orange-200 dark:border-orange-700">
          <div className="flex items-center justify-center gap-2">
            <Terminal className="w-4 h-4 text-orange-600 dark:text-orange-400" />
            <span className="text-sm font-medium text-orange-700 dark:text-orange-300">
              {window.language === 'en' 
                ? '🚀 Code executed automatically - Auto Operations enabled'
                : '🚀 تم تشغيل الكود تلقائياً - العمليات التلقائية مفعلة'
              }
            </span>
            <button
              onClick={() => setIsCollapsed(false)}
              className="ml-2 text-blue-600 dark:text-blue-400 hover:underline text-sm font-medium"
            >
              {window.language === 'en' ? 'Show Code' : 'عرض الكود'}
            </button>
          </div>
        </div>
      ) : null}
      
      {/* Python Runner - Show when showRunner is true */}
      {showRunner && (
        <div className="border-t border-[var(--border-color)] bg-[var(--background-secondary)] p-4">
          <PythonRunner ref={runnerRef} code={code} manualMode={!autoOperationsActive} />
        </div>
      )}
    </div>
  );
};

// Python Runner Component using Pyodide
const PythonRunner = React.forwardRef(({ code, onOutput, onError, onPlotGenerated, manualMode = false }, ref) => {
  const [isRunning, setIsRunning] = useState(false);
  const [pyodide, setPyodide] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [initError, setInitError] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');
  const [plots, setPlots] = useState([]);
  const outputRef = useRef('');
  const plotsRef = useRef([]);

      // Initialize Pyodide - Auto init for Auto Operations, manual init for manual mode
  useEffect(() => {
    // Auto-initialize only if Auto Operations is active
    if (!window.autoOperationsActive && !manualMode) {
      console.log('❌ Auto Operations disabled - skipping auto Python initialization');
      return;
    }
    
    // For manual mode, don't auto-initialize, wait for user action
    if (manualMode && !pyodide) {
      console.log('🔧 Manual mode - Python will initialize when user runs code');
      return;
    }
    const initPyodide = async () => {
      if (pyodide) return;
      
      setIsLoading(true);
      try {
        // Load Pyodide from CDN with better error handling
        if (!window.loadPyodide) {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js';
          
          await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = () => reject(new Error('فشل في تحميل مكتبة Python'));
            setTimeout(() => reject(new Error('انتهت مهلة تحميل Python')), 30000);
            document.head.appendChild(script);
          });
        }
        
        // Initialize Pyodide with timeout
        const pyodideInstance = await Promise.race([
          window.loadPyodide({
            indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/',
          }),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('انتهت مهلة تهيئة Python')), 60000)
          )
        ]);
        
        // Smart package loading - only load what's needed
        // Initialize with minimal setup first
        console.log(window.language === 'en' ? '🚀 Initializing Python environment...' : '🚀 تهيئة بيئة Python...');
        
        // Track loaded packages to avoid reloading
        if (!window.pyodideLoadedPackages) {
          window.pyodideLoadedPackages = new Set();
        } else {
          // Clear cache on fresh initialization to ensure accuracy
          window.pyodideLoadedPackages.clear();
          console.log('🧹 Cleared package cache for fresh initialization');
        }
        
        // Add smart package detection and loading function
        await pyodideInstance.runPython(`
import sys
import io
import base64
import traceback
from io import StringIO

# Smart package detection and loading
def detect_and_load_packages(code_text):
    """Detect required packages from code and load them if needed"""
    import re
    
    # Package mapping - common import patterns to package names
    package_mapping = {
        'numpy': ['import numpy', 'from numpy', 'np.'],
        'matplotlib': ['import matplotlib', 'from matplotlib', 'plt.', 'pyplot'],
        'pandas': ['import pandas', 'from pandas', 'pd.'],
        'scipy': ['import scipy', 'from scipy'],
        'scikit-learn': ['import sklearn', 'from sklearn'],
        'seaborn': ['import seaborn', 'sns.'],
        'plotly': ['import plotly', 'from plotly'],
        'requests': ['import requests', 'requests.'],
        'beautifulsoup4': ['from bs4', 'BeautifulSoup'],
        'pillow': ['from PIL', 'import PIL'],
        'sympy': ['import sympy', 'from sympy'],
        'networkx': ['import networkx', 'nx.'],
        'statsmodels': ['import statsmodels', 'from statsmodels'],
        'bokeh': ['import bokeh', 'from bokeh'],
        'altair': ['import altair', 'alt.'],
        'folium': ['import folium'],
        'wordcloud': ['from wordcloud', 'WordCloud'],
    }
    
    needed_packages = []
    
    # Check each package pattern
    for package, patterns in package_mapping.items():
        for pattern in patterns:
            if pattern in code_text:
                needed_packages.append(package)
                break
    
    return list(set(needed_packages))  # Remove duplicates

# Global function to load packages dynamically
async def smart_load_packages(packages_list):
    """Load packages only if not already loaded"""
    loaded_packages = []
    failed_packages = []
    
    for package in packages_list:
        try:
            # Check if already loaded (this will be managed from JavaScript)
            exec(f"import {package}")
            loaded_packages.append(package)
        except ImportError:
            try:
                # Try to load the package
                await pyodide.loadPackage([package])
                loaded_packages.append(package)
            except Exception as e:
                failed_packages.append((package, str(e)))
    
    return loaded_packages, failed_packages
        `);
        
        // Setup basic Python environment
        await pyodideInstance.runPython(`

# Basic output capture
class OutputCapture:
    def __init__(self):
        self.output = []
    
    def write(self, text):
        self.output.append(str(text))
    
    def flush(self):
        pass
    
    def get_output(self):
        return ''.join(self.output)

# Initialize plot outputs list (packages will be loaded on demand)
plot_outputs = []

def display(obj):
    if hasattr(obj, '_repr_html_'):
        print(obj._repr_html_())
    elif hasattr(obj, '__str__'):
        print(str(obj))
    else:
        print(repr(obj))

# Make display available globally - handle both dict and module cases
import builtins
builtins.display = display
        `);
        
        setPyodide(pyodideInstance);
        
        // Test basic functionality
        try {
          const testResult = await pyodideInstance.runPython(`
# Test basic functionality
import sys
print("🐍 Python version:", sys.version.split()[0])
print("📦 Smart package loading enabled")
print("🚀 Ready for code execution")
print("📚 Supported packages: numpy, matplotlib, pandas, scipy, sklearn, seaborn, plotly, requests, beautifulsoup4, pillow, sympy, networkx, statsmodels, bokeh, altair, folium, wordcloud")
print("💡 Packages will be loaded automatically when needed")

"Python environment initialized successfully"
          `);
          console.log('✓ Python environment ready:', testResult);
        } catch (testError) {
          console.warn('⚠ Python setup test failed:', testError);
        }
        
        // Show loaded packages count
        const loadedCount = window.pyodideLoadedPackages ? window.pyodideLoadedPackages.size : 0;
        const packagesMessage = window.language === 'en'
          ? `📦 ${loadedCount} packages cached from previous sessions`
          : `📦 ${loadedCount} مكتبة محفوظة من الجلسات السابقة`;
        console.log(packagesMessage);
        
        const message = window.language === 'en'
          ? '✓ Python initialized successfully'
          : '✓ تم تهيئة Python بنجاح';
        console.log(message);
        
      } catch (err) {
        const errorTitle = window.language === 'en'
          ? 'Python initialization error:'
          : 'خطأ في تهيئة Python:';
        console.error(errorTitle, err);
        
        const detailsTitle = window.language === 'en'
          ? 'Full error details:'
          : 'تفاصيل الخطأ الكاملة:';
        console.error(detailsTitle, {
          message: err.message,
          stack: err.stack,
          name: err.name
        });
        
        let errorMessage = window.language === 'en'
          ? 'Failed to load Python. '
          : 'فشل في تحميل Python. ';
        
        if (err.message.includes('timeout') || err.message.includes('انتهت مهلة')) {
          errorMessage += window.language === 'en'
            ? 'Connection timeout. Check your internet speed.'
            : 'انتهت مهلة الاتصال. تأكد من سرعة الإنترنت.';
        } else if (err.message.includes('network') || err.message.includes('fetch')) {
          errorMessage += window.language === 'en'
            ? 'Internet connection problem.'
            : 'مشكلة في الاتصال بالإنترنت.';
        } else if (err.message.includes('PythonError') || err.message.includes('TypeError')) {
          errorMessage += window.language === 'en'
            ? 'Python setup error. '
            : 'خطأ في إعداد Python. ';
          const setupErrorTitle = window.language === 'en'
            ? 'Python setup error details:'
            : 'تفاصيل خطأ إعداد Python:';
          console.error(setupErrorTitle, err.message);
        } else {
          errorMessage += window.language === 'en'
            ? 'Check your internet connection and try again.'
            : 'تأكد من اتصالك بالإنترنت وأعد المحاولة.';
        }
        
        // Add debug info for developers
        errorMessage += `\n\nDebug Info: ${err.message}`;
        
        setInitError(errorMessage);
      } finally {
        setIsLoading(false);
      }
    };

    initPyodide();
  }, []);

  // Separate initialization function for manual mode
  const initializePyodide = async () => {
    if (pyodide) return pyodide;
    
    try {
      // Load Pyodide from CDN with better error handling
      if (!window.loadPyodide) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js';
        
        await new Promise((resolve, reject) => {
          script.onload = resolve;
          script.onerror = () => reject(new Error('فشل في تحميل مكتبة Python'));
          setTimeout(() => reject(new Error('انتهت مهلة تحميل Python')), 30000);
          document.head.appendChild(script);
        });
      }
      
      // Initialize Pyodide with timeout
      const pyodideInstance = await Promise.race([
        window.loadPyodide({
          indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/',
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('انتهت مهلة تهيئة Python')), 60000)
        )
      ]);
      
      // Setup basic Python environment (simplified for manual mode)
      await pyodideInstance.runPython(`
import sys
import io
import base64
import traceback
from io import StringIO

# Basic output capture
class OutputCapture:
    def __init__(self):
        self.output = []
    
    def write(self, text):
        self.output.append(str(text))
    
    def flush(self):
        pass
    
    def get_output(self):
        return ''.join(self.output)

# Initialize plot outputs list
plot_outputs = []

def display(obj):
    if hasattr(obj, '_repr_html_'):
        print(obj._repr_html_())
    elif hasattr(obj, '__str__'):
        print(str(obj))
    else:
        print(repr(obj))

# Make display available globally
import builtins
builtins.display = display
      `);
      
      setPyodide(pyodideInstance);
      
      const message = window.language === 'en'
        ? '✓ Python initialized successfully (manual mode)'
        : '✓ تم تهيئة Python بنجاح (وضع يدوي)';
      console.log(message);
      
      return pyodideInstance;
      
    } catch (err) {
      console.error('Manual Python initialization error:', err);
      throw err;
    }
  };

  const retryInit = () => {
    setInitError('');
    setPyodide(null);
    setIsLoading(true);
    // Trigger re-initialization
    setTimeout(() => {
      const initPyodide = async () => {
        // Same initialization logic as above
        try {
          if (!window.loadPyodide) {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js';
            
            await new Promise((resolve, reject) => {
              script.onload = resolve;
              script.onerror = () => reject(new Error('فشل في تحميل مكتبة Python'));
              setTimeout(() => reject(new Error('انتهت مهلة تحميل Python')), 30000);
              document.head.appendChild(script);
            });
          }
          
          const pyodideInstance = await Promise.race([
            window.loadPyodide({
              indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/',
            }),
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('انتهت مهلة تهيئة Python')), 60000)
            )
          ]);
          
          const essentialPackages = ['numpy', 'matplotlib'];
          const optionalPackages = ['pandas'];
          let hasEssentials = true;
          
          for (const pkg of essentialPackages) {
            try {
              await pyodideInstance.loadPackage([pkg]);
              console.log(`✓ تم تحميل ${pkg}`);
            } catch (err) {
              console.error(`✗ فشل تحميل ${pkg}:`, err);
              hasEssentials = false;
            }
          }
          
          for (const pkg of optionalPackages) {
            try {
              await pyodideInstance.loadPackage([pkg]);
              console.log(`✓ تم تحميل ${pkg}`);
            } catch (err) {
              console.warn(`⚠ تخطي ${pkg}:`, err);
            }
          }
          
          if (!hasEssentials) {
            throw new Error('فشل في تحميل المكتبات الأساسية (NumPy, Matplotlib)');
          }
          
          await pyodideInstance.runPython(`
import sys
import io
import base64
import traceback
from io import StringIO

class OutputCapture:
    def __init__(self):
        self.output = []
    
    def write(self, text):
        self.output.append(str(text))
    
    def flush(self):
        pass
    
    def get_output(self):
        return ''.join(self.output)

plot_outputs = []
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    def capture_plot():
        global _plot_count
        try:
            if plt.get_fignums():
                # Check plot limit before generating
                _plot_count += 1
                if _plot_count > _max_plots:
                    warning_msg = f"⚠ Maximum chart limit exceeded ({_max_plots})" if _language == 'en' else f"⚠ تم تجاوز الحد الأقصى للرسوم البيانية ({_max_plots})"
                    print(warning_msg)
                    plt.close('all')
                    return None
                
                buf = io.BytesIO()
                plt.savefig(buf, format='png', dpi=150, bbox_inches='tight', 
                           facecolor='white', edgecolor='none')
                buf.seek(0)
                img_base64 = base64.b64encode(buf.read()).decode('utf-8')
                plot_outputs.append(img_base64)
                plt.close('all')
                return img_base64
        except Exception as e:
            error_msg = f"Error saving chart: {e}" if _language == 'en' else f"خطأ في حفظ الرسم: {e}"
            print(error_msg)
        return None

    original_show = plt.show
    def custom_show(*args, **kwargs):
        capture_plot()
    plt.show = custom_show
    
    print("✓ تم تهيئة matplotlib بنجاح")
except ImportError:
    print("⚠ matplotlib غير متاح")

try:
    import numpy as np
    print("✓ تم تهيئة NumPy بنجاح")
except ImportError:
    print("⚠ NumPy غير متاح")

try:
    import pandas as pd
    print("✓ تم تهيئة Pandas بنجاح")
except ImportError:
    print("⚠ Pandas غير متاح")

def display(obj):
    if hasattr(obj, '_repr_html_'):
        print(obj._repr_html_())
    elif hasattr(obj, '__str__'):
        print(str(obj))
    else:
        print(repr(obj))

# Make display available globally - handle both dict and module cases
import builtins
builtins.display = display
          `);
          
          setPyodide(pyodideInstance);
          
          // Test basic functionality
          try {
            const testResult = await pyodideInstance.runPython(`
# Test basic functionality
import sys
print("Python version:", sys.version)

# Test numpy if available
try:
    import numpy as np
    arr = np.array([1, 2, 3])
    print("NumPy test:", arr.sum())
except ImportError:
    print("NumPy not available")

# Test matplotlib if available
try:
    import matplotlib.pyplot as plt
    print("Matplotlib available")
except ImportError:
    print("Matplotlib not available")

"Python retry setup test completed successfully"
            `);
            console.log('✓ Python retry setup test passed:', testResult);
          } catch (testError) {
            console.warn('⚠ Python retry setup test failed:', testError);
          }
          
          const message = window.language === 'en'
            ? '✓ Python initialized successfully'
            : '✓ تم تهيئة Python بنجاح';
          console.log(message);
          
        } catch (err) {
          console.error('Python retry initialization error:', err);
          console.error('Full retry error details:', {
            message: err.message,
            stack: err.stack,
            name: err.name
          });
          
          let errorMessage = 'فشل في تحميل Python. ';
          
          if (err.message.includes('timeout') || err.message.includes('انتهت مهلة')) {
            errorMessage += 'انتهت مهلة الاتصال. تأكد من سرعة الإنترنت.';
          } else if (err.message.includes('network') || err.message.includes('fetch')) {
            errorMessage += 'مشكلة في الاتصال بالإنترنت.';
          } else if (err.message.includes('PythonError') || err.message.includes('TypeError')) {
            errorMessage += 'خطأ في إعداد Python. ';
            console.error('Python retry setup error details:', err.message);
          } else {
            errorMessage += 'تأكد من اتصالك بالإنترنت وأعد المحاولة.';
          }
          
          // Add debug info for developers
          errorMessage += `\n\nDebug Info: ${err.message}`;
          
          setInitError(errorMessage);
        } finally {
          setIsLoading(false);
        }
      };
      
      initPyodide();
    }, 100);
  };

  // Smart package loading function
  const loadRequiredPackages = async (code) => {
    try {
      // Ensure pyodideLoadedPackages exists
      if (!window.pyodideLoadedPackages) {
        window.pyodideLoadedPackages = new Set();
      }
      
      // Check if pyodide is available
      if (!pyodide) {
        console.warn('⚠️ Pyodide not available, skipping package loading');
        return;
      }
      
      console.log('🔍 Analyzing code for required packages...');
      console.log('Code to analyze:', code.substring(0, 100) + '...');
      
      // Detect required packages from code using JavaScript regex (more reliable)
      const detectedPackages = [];
      
      // Package detection patterns
      const packagePatterns = {
        'numpy': [/import\s+numpy/, /from\s+numpy/, /\bnp\./],
        'matplotlib': [/import\s+matplotlib/, /from\s+matplotlib/, /\bplt\./, /pyplot/],
        'pandas': [/import\s+pandas/, /from\s+pandas/, /\bpd\./],
        'scipy': [/import\s+scipy/, /from\s+scipy/],
        'scikit-learn': [/import\s+sklearn/, /from\s+sklearn/],
        'seaborn': [/import\s+seaborn/, /\bsns\./],
        'plotly': [/import\s+plotly/, /from\s+plotly/],
        'requests': [/import\s+requests/, /requests\./],
        'beautifulsoup4': [/from\s+bs4/, /BeautifulSoup/],
        'pillow': [/from\s+PIL/, /import\s+PIL/],
        'sympy': [/import\s+sympy/, /from\s+sympy/],
        'networkx': [/import\s+networkx/, /\bnx\./],
      };
      
      // Check each package pattern
      for (const [packageName, patterns] of Object.entries(packagePatterns)) {
        for (const pattern of patterns) {
          if (pattern.test(code)) {
            detectedPackages.push(packageName);
            console.log(`✓ Detected ${packageName} from pattern: ${pattern}`);
            break;
          }
        }
      }
      
      // Force add essential packages if they appear in common imports
      if (code.includes('import numpy') || code.includes('np.')) {
        if (!detectedPackages.includes('numpy')) {
          detectedPackages.push('numpy');
          console.log('✓ Force added numpy (essential package)');
        }
      }
      
      if (code.includes('import matplotlib') || code.includes('plt.') || code.includes('pyplot')) {
        if (!detectedPackages.includes('matplotlib')) {
          detectedPackages.push('matplotlib');
          console.log('✓ Force added matplotlib (essential package)');
        }
      }
      
      // Remove duplicates
      const uniquePackages = [...new Set(detectedPackages)];
      
      console.log('📦 Detected packages:', uniquePackages);
      console.log('📋 Cached packages:', Array.from(window.pyodideLoadedPackages || []));
      
      if (uniquePackages.length > 0) {
        // Verify which packages are actually available in Pyodide
        const actuallyLoadedPackages = [];
        const packagesToLoad = [];

        for (const pkg of uniquePackages) {
          try {
            // Test if package is actually available by trying to import it
            const importName = pkg === 'beautifulsoup4' ? 'bs4' : 
                             pkg === 'pillow' ? 'PIL' : 
                             pkg === 'scikit-learn' ? 'sklearn' : pkg;
            
            const testResult = await pyodide.runPython(`
try:
    import ${importName}
    True
except ImportError:
    False
            `);
            
            if (testResult) {
              actuallyLoadedPackages.push(pkg);
              window.pyodideLoadedPackages.add(pkg);
              console.log(`✅ ${pkg} is already available`);
            } else {
              packagesToLoad.push(pkg);
              console.log(`📦 ${pkg} needs to be loaded`);
            }
          } catch (error) {
            console.log(`📦 ${pkg} needs to be loaded (test failed)`);
            packagesToLoad.push(pkg);
          }
        }
        
        if (packagesToLoad.length > 0) {
          const loadingMessage = window.language === 'en'
            ? `📦 Loading required packages: ${packagesToLoad.join(', ')}`
            : `📦 تحميل المكتبات المطلوبة: ${packagesToLoad.join(', ')}`;
          console.log(loadingMessage);
          
                    // Load packages one by one with better error handling
          for (const pkg of packagesToLoad) {
            try {
              console.log(`📦 Loading ${pkg}...`);
              
              // Use timeout for package loading
              const loadPromise = pyodide.loadPackage([pkg]);
              const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Package loading timeout')), 30000)
              );
              
              await Promise.race([loadPromise, timeoutPromise]);
              window.pyodideLoadedPackages.add(pkg);
              
              const successMessage = window.language === 'en'
                ? `✅ Successfully loaded ${pkg}`
                : `✅ تم تحميل ${pkg} بنجاح`;
              console.log(successMessage);
              
              // Setup package-specific configurations
              await setupPackageConfiguration(pkg);
              
            } catch (err) {
              const errorMessage = window.language === 'en'
                ? `❌ Failed to load ${pkg}: ${err.message}`
                : `❌ فشل تحميل ${pkg}: ${err.message}`;
              console.error(errorMessage);
              
              // Don't stop execution for failed packages, just warn
              console.warn(`Continuing without ${pkg}...`);
            }
          }
        } else {
          const cachedMessage = window.language === 'en'
            ? '✓ All required packages already loaded'
            : '✓ جميع المكتبات المطلوبة محملة مسبقاً';
          console.log(cachedMessage);
        }
      } else {
        console.log('ℹ️ No packages detected in code');
      }
    } catch (err) {
      console.error('Package detection failed:', err);
      
      // Fallback: try to load essential packages if code contains common patterns
      console.log('🔄 Attempting fallback package loading...');
      try {
        const essentialPackages = [];
        if (code.includes('numpy') || code.includes('np.')) {
          essentialPackages.push('numpy');
        }
        if (code.includes('matplotlib') || code.includes('plt.')) {
          essentialPackages.push('matplotlib');
        }
        
                 for (const pkg of essentialPackages) {
           if (!window.pyodideLoadedPackages.has(pkg)) {
             try {
               console.log(`🔄 Fallback loading ${pkg}...`);
               await pyodide.loadPackage([pkg]);
               window.pyodideLoadedPackages.add(pkg);
               await setupPackageConfiguration(pkg);
               console.log(`✅ Fallback loaded ${pkg}`);
             } catch (fallbackErr) {
               console.error(`❌ Fallback failed for ${pkg}:`, fallbackErr.message);
               console.error('Full fallback error:', fallbackErr);
             }
           } else {
             console.log(`ℹ️ ${pkg} already loaded (cached)`);
           }
         }
      } catch (fallbackError) {
        console.error('Fallback loading failed:', fallbackError);
      }
    }
  };

  // Setup package-specific configurations
  const setupPackageConfiguration = async (pkg) => {
    console.log(`🔧 Setting up configuration for ${pkg}...`);
    
    if (pkg === 'matplotlib') {
      await pyodide.runPython(`
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    # Define capture_plot function globally
    def capture_plot():
        global _plot_count
        try:
            if plt.get_fignums():
                # Check plot limit before generating
                _plot_count += 1
                if _plot_count > _max_plots:
                    warning_msg = f"⚠ Maximum chart limit exceeded ({_max_plots})" if _language == 'en' else f"⚠ تم تجاوز الحد الأقصى للرسوم البيانية ({_max_plots})"
                    print(warning_msg)
                    plt.close('all')
                    return None
                
                buf = io.BytesIO()
                plt.savefig(buf, format='png', dpi=150, bbox_inches='tight', 
                           facecolor='white', edgecolor='none')
                buf.seek(0)
                img_base64 = base64.b64encode(buf.read()).decode('utf-8')
                plot_outputs.append(img_base64)
                plt.close('all')
                return img_base64
        except Exception as e:
            error_msg = f"Error saving chart: {e}" if _language == 'en' else f"خطأ في حفظ الرسم: {e}"
            print(error_msg)
        return None
    
    # Make capture_plot available globally
    globals()['capture_plot'] = capture_plot

    # Override plt.show for immediate display
    _original_show = plt.show
    def custom_show(*args, **kwargs):
        plot_data = capture_plot()
        if plot_data:
            chart_msg = "📊 New chart created" if _language == 'en' else "📊 تم إنشاء رسم بياني جديد"
            print(chart_msg)
        return plot_data
    plt.show = custom_show
    
    # Also override savefig to capture plots automatically
    _original_savefig = plt.savefig
    def custom_savefig(*args, **kwargs):
        result = _original_savefig(*args, **kwargs)
        # Don't capture again if already captured to avoid infinite loops
        # Just print a message that savefig was called
        save_msg = "📊 Chart saved" if _language == 'en' else "📊 تم حفظ رسم بياني"
        print(save_msg)
        return result
    plt.savefig = custom_savefig
    
    print("✓ تم تهيئة matplotlib بنجاح")
except ImportError:
    print("⚠ matplotlib غير متاح")
      `);
    } else if (pkg === 'numpy') {
      await pyodide.runPython(`
try:
    import numpy as np
    print("✓ تم تهيئة NumPy بنجاح")
except ImportError:
    print("⚠ NumPy غير متاح")
      `);
    } else if (pkg === 'pandas') {
      await pyodide.runPython(`
try:
    import pandas as pd
    print("✓ تم تهيئة Pandas بنجاح")
except ImportError:
    print("⚠ Pandas غير متاح")
      `);
    }
    
    console.log(`✅ Configuration completed for ${pkg}`);
  };

  const runPython = async () => {
    if (isRunning) return;
    
    // If in manual mode and pyodide not initialized, initialize it first
    if (manualMode && !pyodide) {
      console.log('🔧 Manual mode: Initializing Python on demand...');
      setIsLoading(true);
      setError(''); // Clear any previous errors
      
      try {
        const pyodideInstance = await initializePyodide();
        if (!pyodideInstance) {
          throw new Error('Failed to initialize Pyodide');
        }
        console.log('✅ Python initialized successfully in manual mode');
      } catch (error) {
        console.error('Failed to initialize Python in manual mode:', error);
        setInitError(error.message || 'فشل في تهيئة Python');
        setIsLoading(false);
        return;
      }
      
      setIsLoading(false);
    }
    
    if (!pyodide) return;
    
    setIsRunning(true);
    setOutput('');
    setError('');
    setPlots([]);
    outputRef.current = '';
    plotsRef.current = [];
    
    // Set up timeout for execution (30 seconds max)
    const executionTimeout = setTimeout(() => {
      setIsRunning(false);
      const timeoutMessage = window.language === 'en'
        ? 'Python execution timeout (30 seconds). Code may contain infinite loops.'
        : 'انتهت مهلة تنفيذ Python (30 ثانية). قد يحتوي الكود على حلقات لا نهائية.';
      setError(timeoutMessage);
    }, 30000); // 30 seconds timeout
    
    try {
      console.log('🚀 Starting Python execution...');
      console.log('📝 Code to execute:', code.substring(0, 200) + '...');
      
      // Ensure pyodideLoadedPackages exists
      if (!window.pyodideLoadedPackages) {
        window.pyodideLoadedPackages = new Set();
        console.log('🔧 Initialized pyodideLoadedPackages');
      }
      
      // Check if pyodide is ready
      if (!pyodide) {
        throw new Error('Pyodide is not initialized');
      }
      console.log('✅ Pyodide is ready');
      
      // First, load required packages based on code analysis
      console.log('📦 Loading required packages...');
      await loadRequiredPackages(code);
      console.log('✅ Package loading completed');
      
            // Verify packages are actually loaded
      console.log('🔍 Verifying loaded packages...');
      console.log('Cached packages:', Array.from(window.pyodideLoadedPackages || []));
      
      // Test if packages are actually available in Python
      try {
        const verificationResult = await pyodide.runPython(`
import sys
verification_results = {}

test_packages = {
    'numpy': 'numpy',
    'matplotlib': 'matplotlib.pyplot',
    'pandas': 'pandas',
    'scipy': 'scipy',
    'sklearn': 'sklearn'
}

for pkg_name, import_path in test_packages.items():
    try:
        exec(f"import {import_path}")
        verification_results[pkg_name] = True
        print(f"✅ {pkg_name} is available")
    except ImportError as e:
        verification_results[pkg_name] = False
        print(f"❌ {pkg_name} not available: {e}")

verification_results
        `);
        
        // Update cache based on actual availability
        const actuallyAvailable = Object.entries(verificationResult)
          .filter(([pkg, available]) => available)
          .map(([pkg]) => pkg === 'sklearn' ? 'scikit-learn' : pkg);
        
        // Clear and update cache
        window.pyodideLoadedPackages.clear();
        actuallyAvailable.forEach(pkg => window.pyodideLoadedPackages.add(pkg));
        
        console.log('✅ Actually available packages:', actuallyAvailable);
        console.log('📋 Updated cache:', Array.from(window.pyodideLoadedPackages));
        
      } catch (testErr) {
        console.error('Package verification failed:', testErr);
         
         // Emergency fallback: force load essential packages
         console.log('🚨 Emergency fallback: loading essential packages...');
         try {
           if (code.includes('numpy') || code.includes('np.')) {
             console.log('🔧 Force loading numpy...');
             await pyodide.loadPackage(['numpy']);
             window.pyodideLoadedPackages.add('numpy');
             console.log('✅ Emergency loaded numpy');
           }
           
           if (code.includes('matplotlib') || code.includes('plt.')) {
             console.log('🔧 Force loading matplotlib...');
             await pyodide.loadPackage(['matplotlib']);
             window.pyodideLoadedPackages.add('matplotlib');
             await setupPackageConfiguration('matplotlib');
             console.log('✅ Emergency loaded matplotlib');
           }
         } catch (emergencyErr) {
           console.error('❌ Emergency loading failed:', emergencyErr);
         }
       }
      
      // Clear previous outputs
      await pyodide.runPython(`
plot_outputs.clear()
output_capture = OutputCapture()
sys.stdout = output_capture
sys.stderr = output_capture

# Add execution monitoring
import time
import threading
_start_time = time.time()
_max_execution_time = 25  # 25 seconds before we force stop
_should_stop = False
_execution_count = 0
_plot_count = 0  # Track plot generation and reset for each run
_max_plots = 5   # Maximum plots per execution
_print_count = 0  # Reset print counter
_language = "${window.language || 'ar'}"  # Set language for error messages

def _check_execution_time():
    global _execution_count, _should_stop, _plot_count
    _execution_count += 1
    
    # Check every 50 operations (more frequent)
    if _execution_count % 50 == 0:
        if time.time() - _start_time > _max_execution_time or _should_stop:
            timeout_msg = "Execution stopped to avoid infinite loops" if globals().get('_language') == 'en' else "تم إيقاف التنفيذ لتجنب الحلقات اللا نهائية"
            raise TimeoutError(timeout_msg)
        
        # Check for excessive plot generation
        if _plot_count > _max_plots:
            plot_error_msg = f"Execution stopped: generated more than {_max_plots} charts" if globals().get('_language') == 'en' else f"تم إيقاف التنفيذ: تم توليد أكثر من {_max_plots} رسوم بيانية"
            raise RuntimeError(plot_error_msg)

# Override print to check execution time and show progress
_original_print = print
_print_count = 0
_max_prints = 1000  # Maximum prints per execution

def _monitored_print(*args, **kwargs):
    global _print_count
    _print_count += 1
    
    # Check for excessive printing (possible infinite loop)
    if _print_count > _max_prints:
        error_msg = f"Execution stopped: printed more than {_max_prints} messages" if globals().get('_language') == 'en' else f"تم إيقاف التنفيذ: تم طباعة أكثر من {_max_prints} رسالة"
        raise RuntimeError(error_msg)
    
    _check_execution_time()
    result = _original_print(*args, **kwargs)
    
    # Force output display immediately for interactive feedback
    try:
        import sys
        sys.stdout.flush()
        # Capture output immediately for real-time display
        if hasattr(output_capture, 'output') and output_capture.output:
            # This allows real-time output viewing
            pass
    except:
        pass
    
    return result

import builtins
builtins.print = _monitored_print

# Override range and other loop functions for monitoring
_original_range = range
def _monitored_range(*args, **kwargs):
    _check_execution_time()
    return _original_range(*args, **kwargs)

builtins.range = _monitored_range
      `);
      
             // Run the user code with error handling and monitoring
       try {
         // Execute user code directly with proper escaping
         const escapedCode = code.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
         
         await pyodide.runPython(`
# Check for potential infinite loops patterns
_user_code = "${escapedCode}"
infinite_loop_patterns = ['while True:', 'while 1:', 'while (True)', 'while (1)']
has_infinite_loop = any(pattern in _user_code for pattern in infinite_loop_patterns)

if has_infinite_loop:
    print("⚠ تحذير: تم اكتشاف حلقة لا نهائية محتملة - سيتم إيقاف التنفيذ تلقائياً بعد 25 ثانية")

# Check for large ranges
import re
if 'range(' in _user_code:
    large_ranges = re.findall(r'range\\s*\\(\\s*(\\d+)\\s*\\)', _user_code)
    for range_val in large_ranges:
        if int(range_val) > 1000000:
            print(f"⚠ تحذير: تم اكتشاف حلقة كبيرة range({range_val}) - قد تستغرق وقتاً طويلاً")
         `);
         
         // Execute the actual user code
         console.log('🎯 Executing user code...');
         
         // Add safety information (only for complex code)
         const isComplexCode = code.length > 200 || 
                              code.includes('while') || 
                              code.includes('for') || 
                              code.includes('import') ||
                              code.split('\n').length > 10;
         
         if (isComplexCode) {
           const safetyMessage = window.language === 'en' 
             ? `
print("🚀 Starting execution with infinite loop protection")
print(f"⏱️ Max execution time: {_max_execution_time} seconds")
print(f"📊 Max plots: {_max_plots} charts")
print(f"📝 Max prints: {_max_prints} messages")
print("─" * 50)
             `
             : `
print("🚀 بدء التنفيذ مع حماية من الحلقات اللا نهائية")
print(f"⏱️ الحد الأقصى للوقت: {_max_execution_time} ثانية")
print(f"📊 الحد الأقصى للرسوم: {_max_plots} رسوم")
print(f"📝 الحد الأقصى للطباعة: {_max_prints} رسالة")
print("─" * 50)
             `;
           await pyodide.runPython(safetyMessage);
         }
         
         await pyodide.runPython(code);
         console.log('✅ User code executed successfully');
         
         // Add completion message (only for complex code or when there are plots)
         if (isComplexCode) {
           const completionMessage = window.language === 'en'
             ? `
print("─" * 50)
print(f"✅ Execution completed successfully")
print(f"📊 Created {_plot_count} chart(s)")
print(f"📝 Printed {_print_count} message(s)")
print(f"⏱️ Execution time: {time.time() - _start_time:.2f} seconds")
             `
             : `
print("─" * 50)
print(f"✅ تم إكمال التنفيذ بنجاح")
print(f"📊 تم إنشاء {_plot_count} رسم بياني")
print(f"📝 تم طباعة {_print_count} رسالة")
print(f"⏱️ وقت التنفيذ: {time.time() - _start_time:.2f} ثانية")
             `;
           await pyodide.runPython(completionMessage);
         } else {
           // For simple code, just show a simple success message
           const simpleMessage = window.language === 'en'
             ? 'print("✓ تم إنتاج النتائج بنجاح")'
             : 'print("✓ تم إنتاج النتائج بنجاح")';
           await pyodide.runPython(simpleMessage);
         }
         
         // Check for plots after execution
         await pyodide.runPython(`
# Force capture any remaining plots
try:
    if 'matplotlib' in sys.modules:
        import matplotlib.pyplot as plt
        if plt.get_fignums():
            plot_data = capture_plot()
            if plot_data:
                print("📊 تم إنشاء رسم بياني - جاري العرض...")
except Exception as plot_err:
    print(f"تحذير: مشكلة في حفظ الرسم البياني: {plot_err}")

# Final check for any output
current_output = output_capture.get_output()
if current_output and current_output.strip():
    print("✓ تم إنتاج النتائج بنجاح")
         `);
              } catch (pythonError) {
          console.error('Python execution error:', pythonError);
          
          // Try to get detailed error information
          let errorMessage = pythonError.message || 'خطأ غير معروف في Python';
          
          try {
            // Get Python traceback if available
            const traceback = await pyodide.runPython(`
import traceback
import sys
try:
    traceback.format_exc()
except:
    str(sys.exc_info()[1]) if sys.exc_info()[1] else "خطأ في التنفيذ"
            `);
            
            if (traceback && traceback.trim() && traceback !== 'NoneType: None') {
              errorMessage = traceback;
              console.error('Python traceback:', traceback);
            }
          } catch (tracebackError) {
            console.error('Failed to get traceback:', tracebackError);
          }
          
          // Clean up the error message
          if (errorMessage.includes('IndentationError')) {
            errorMessage = 'خطأ في المسافات البادئة (Indentation). تأكد من صحة ترتيب الأسطر والمسافات.';
          } else if (errorMessage.includes('SyntaxError')) {
            errorMessage = 'خطأ في بناء الجملة (Syntax Error). تحقق من صحة كتابة الكود.';
          } else if (errorMessage.includes('NameError')) {
            errorMessage = 'خطأ: متغير أو دالة غير معرفة. تأكد من تعريف جميع المتغيرات المستخدمة.';
          } else if (errorMessage.includes('ImportError') || errorMessage.includes('ModuleNotFoundError')) {
            errorMessage = 'خطأ: مكتبة غير متاحة. تحقق من أن المكتبة مدعومة في البيئة.';
          }
          
          throw new Error(errorMessage);
        }
      
      // Get the output
      const capturedOutput = await pyodide.runPython(`
sys.stdout = sys.__stdout__  # Restore stdout
sys.stderr = sys.__stderr__  # Restore stderr
output_capture.get_output()
      `);
      
      // Get any plots
      const capturedPlots = await pyodide.runPython(`plot_outputs.copy()`);
      
      // Clear timeout since execution completed
      clearTimeout(executionTimeout);
      
      setOutput(capturedOutput || '');
      setPlots(capturedPlots || []);
      
      // Call callbacks
      if (onOutput) onOutput(capturedOutput || '');
      if (onPlotGenerated && capturedPlots && capturedPlots.length > 0) {
        onPlotGenerated(capturedPlots);
      }
      
      // Show success message if we have output or plots
      if ((capturedOutput && capturedOutput.trim()) || (capturedPlots && capturedPlots.length > 0)) {
        const successMessage = window.language === 'en'
          ? '✓ Python execution completed successfully'
          : '✓ تم تنفيذ كود Python بنجاح';
        console.log(successMessage);
        
        // Show summary of results
        if (capturedOutput && capturedOutput.trim()) {
          const outputLines = capturedOutput.trim().split('\n').length;
          const outputMessage = window.language === 'en'
            ? `📄 Generated ${outputLines} lines of output`
            : `📄 تم إنتاج ${outputLines} سطر من النتائج`;
          console.log(outputMessage);
        }
        
        if (capturedPlots && capturedPlots.length > 0) {
          const plotsMessage = window.language === 'en'
            ? `📊 Generated ${capturedPlots.length} plot(s)`
            : `📊 تم إنتاج ${capturedPlots.length} رسم بياني`;
          console.log(plotsMessage);
        }
        
        // Show package loading stats
        const totalPackages = window.pyodideLoadedPackages ? window.pyodideLoadedPackages.size : 0;
        const statsMessage = window.language === 'en'
          ? `📦 Total packages loaded: ${totalPackages} (cached for future use)`
          : `📦 إجمالي المكتبات المحملة: ${totalPackages} (محفوظة للاستخدام المستقبلي)`;
        console.log(statsMessage);
        
      } else {
        // No output - might be just variable assignments
        const noOutputMessage = window.language === 'en'
          ? '✓ Code executed successfully (no output to display)'
          : '✓ تم تنفيذ الكود بنجاح (لا توجد نتائج للعرض)';
        console.log(noOutputMessage);
      }
      
    } catch (err) {
      // Clear timeout
      clearTimeout(executionTimeout);
      
      // Restore stdout/stderr in case of error
      try {
        await pyodide.runPython(`
# Restore stdout/stderr and original print
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
try:
    if '_original_print' in globals():
        builtins.print = _original_print
except:
    pass
        `);
      } catch (restoreErr) {
        console.error('Failed to restore stdout/stderr:', restoreErr);
      }
      
      const errorMessage = err.message || (window.language === 'en' ? 'Python execution error' : 'خطأ في تشغيل الكود');
      setError(errorMessage);
      if (onError) onError(errorMessage);
    } finally {
      setIsRunning(false);
    }
  };

  const stopExecution = () => {
    setIsRunning(false);
    
    // Try to interrupt the execution
    try {
      if (pyodide) {
        pyodide.runPython(`
# Try to interrupt execution
import sys

# Set a flag to stop execution
_should_stop = True

# Restore stdout/stderr
try:
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    if '_original_print' in globals():
        builtins.print = _original_print
except:
    pass

print("⚠ تم إيقاف التنفيذ بواسطة المستخدم")
        `);
      }
    } catch (err) {
      console.log('Execution stopped by user');
    }
    
    const stopMessage = window.language === 'en'
      ? '⚠ Execution stopped by user'
      : '⚠ تم إيقاف التنفيذ بواسطة المستخدم';
    setError(stopMessage);
  };

  const clearPackageCache = () => {
    if (window.pyodideLoadedPackages) {
      const clearedCount = window.pyodideLoadedPackages.size;
      window.pyodideLoadedPackages.clear();
      console.log('🧹 Package cache cleared');
      
      const clearMessage = window.language === 'en'
        ? `🧹 Cleared ${clearedCount} cached packages - they will be reloaded when needed`
        : `🧹 تم مسح ${clearedCount} مكتبة من الكاش - سيتم إعادة تحميلها عند الحاجة`;
      setOutput(prev => prev + '\n' + clearMessage + '\n');
    }
  };

  // Expose runPython function to parent via ref
  React.useImperativeHandle(ref, () => ({
    runPython
  }));

  // Show manual mode interface when Auto Operations is disabled
  if (manualMode && !pyodide && !isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
          <Terminal className="w-4 h-4 text-blue-600" />
          <span className="text-sm text-blue-700 dark:text-blue-300">
            {window.language === 'en' ? 'Manual Python mode - Ready to initialize' : 'وضع Python اليدوي - جاهز للتهيئة'}
          </span>
        </div>
        
        {/* Manual Run Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={runPython}
            disabled={isRunning}
            className="flex items-center gap-2 px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 dark:bg-blue-900/30 dark:hover:bg-blue-800/40 dark:text-blue-300 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4" />
            {window.language === 'en' ? 'Initialize & Run Python' : 'تهيئة وتشغيل Python'}
          </button>
          
          <div className="text-xs text-blue-600 dark:text-blue-400">
            💡 {window.language === 'en' ? 'Will initialize Python and run your code' : 'سيتم تهيئة Python وتشغيل الكود'}
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          <span className="text-sm text-blue-700 dark:text-blue-300">
            {window.language === 'en' ? 'Initializing Python environment...' : 'تهيئة بيئة Python...'}
          </span>
        </div>
        <div className="text-xs text-gray-600 dark:text-gray-400 px-3">
          🚀 تحميل ذكي - المكتبات ستحمل حسب الحاجة
        </div>
        <div className="text-xs text-green-600 dark:text-green-400 px-3">
          ✓ أسرع وأخف - لا إعادة تحميل للمكتبات المحملة
        </div>
      </div>
    );
  }

  if (initError) {
    return (
      <div className="space-y-3">
        <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-700">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-4 h-4 text-red-600" />
            <span className="text-sm font-medium text-red-700 dark:text-red-300">فشل تحميل Python</span>
          </div>
          <p className="text-sm text-red-600 dark:text-red-400 mb-3">{initError}</p>
          <button
            onClick={retryInit}
            className="flex items-center gap-2 px-3 py-1.5 bg-red-100 hover:bg-red-200 dark:bg-red-800/30 dark:hover:bg-red-700/40 text-red-700 dark:text-red-300 rounded-lg text-sm font-medium transition-colors"
          >
            <Play className="w-3 h-3" />
            إعادة المحاولة
          </button>
        </div>
        <div className="text-xs text-gray-600 dark:text-gray-400 px-3">
          💡 نصائح: تأكد من اتصال إنترنت مستقر، أو جرب إعادة تحميل الصفحة
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Control Buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={isRunning ? stopExecution : runPython}
          disabled={!pyodide && !manualMode}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
            isRunning 
              ? 'bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-900/30 dark:hover:bg-red-800/40 dark:text-red-300'
              : manualMode && !pyodide
              ? 'bg-blue-100 hover:bg-blue-200 text-blue-700 dark:bg-blue-900/30 dark:hover:bg-blue-800/40 dark:text-blue-300'
              : 'bg-green-100 hover:bg-green-200 text-green-700 dark:bg-green-900/30 dark:hover:bg-green-800/40 dark:text-green-300'
          } ${!pyodide && !manualMode ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {isRunning ? (
            <>
              <Square className="w-3 h-3" />
              {window.language === 'en' ? 'Stop' : 'إيقاف'}
            </>
          ) : manualMode && !pyodide ? (
            <>
              <Play className="w-3 h-3" />
              {window.language === 'en' ? 'Initialize & Run' : 'تهيئة وتشغيل'}
            </>
          ) : (
            <>
              <Play className="w-3 h-3" />
              {window.language === 'en' ? 'Run' : 'تشغيل'}
            </>
          )}
        </button>
        
        {isRunning && (
          <div className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400">
            <Loader2 className="w-3 h-3 animate-spin" />
            <span>{manualMode && !pyodide ? 'جاري التهيئة والتشغيل...' : 'جاري التشغيل...'}</span>
            <span className="text-xs text-gray-500">
              📦 تحميل المكتبات حسب الحاجة
            </span>
            <span className="text-xs text-orange-500">
              (إيقاف تلقائي بعد 30 ثانية)
            </span>
          </div>
        )}
        
        {/* Manual mode status */}
        {manualMode && !isRunning && (
          <div className="flex items-center gap-2 text-sm">
            {pyodide ? (
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                <CheckCircle className="w-3 h-3" />
                <span>Python جاهز - وضع يدوي</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                <Terminal className="w-3 h-3" />
                <span>اضغط تشغيل لتهيئة Python وتنفيذ الكود</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Output Display */}
      {(output || error || plots.length > 0) && (
        <div className="space-y-3">
          {/* Text Output */}
          {output && (
            <div className="bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between p-2 bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 rounded-t-lg">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">النتيجة</span>
                </div>
                <button
                  onClick={() => navigator.clipboard.writeText(output)}
                  className="flex items-center gap-1 text-xs text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 px-2 py-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  نسخ
                </button>
              </div>
              <pre className="p-3 text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap font-mono overflow-x-auto max-h-64">
                {output}
              </pre>
            </div>
          )}

          {/* Error Output */}
          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-700">
              <div className="flex items-center justify-between p-2 bg-red-100 dark:bg-red-800/30 border-b border-red-200 dark:border-red-700 rounded-t-lg">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="text-sm font-medium text-red-700 dark:text-red-300">خطأ في التشغيل</span>
                </div>
                <button
                  onClick={() => navigator.clipboard.writeText(error)}
                  className="flex items-center gap-1 text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-200 px-2 py-1 rounded hover:bg-red-200 dark:hover:bg-red-800/40 transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  نسخ الخطأ
                </button>
              </div>
              <pre className="p-3 text-sm text-red-800 dark:text-red-200 whitespace-pre-wrap font-mono overflow-x-auto max-h-48">
                {error}
              </pre>
            </div>
          )}

          {/* Plot Outputs */}
          {plots.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <ImageIcon className="w-4 h-4" />
                الرسوم البيانية ({plots.length})
              </div>
              <div className="grid gap-3">
                {plots.map((plot, index) => (
                  <div key={index} className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                    <div className="p-2 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        رسم بياني {index + 1}
                      </span>
                    </div>
                    <div className="p-3">
                      <img 
                        src={`data:image/png;base64,${plot}`}
                        alt={`Python plot ${index + 1}`}
                        className="max-w-full h-auto rounded border border-gray-200 dark:border-gray-600"
                      />
                    </div>
                    <div className="p-2 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
                      <button
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = `data:image/png;base64,${plot}`;
                          link.download = `python-plot-${index + 1}.png`;
                          link.click();
                        }}
                        className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        <Download className="w-3 h-3" />
                        تحميل الصورة
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
});

// Set display name for debugging
PythonRunner.displayName = 'PythonRunner';

// Function to handle image loading with redirect support and token preservation
const loadImageWithRedirectSupport = async (imageUrl) => {
  try {
    // Get the auth token
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    
    if (!token) {
      console.warn('No authentication token found, trying without auth');
      // Try without token as fallback
      const response = await fetch(imageUrl);
      if (response.ok) {
        const blob = await response.blob();
        return URL.createObjectURL(blob);
      }
      throw new Error('No authentication token and request failed');
    }

    console.log('Loading image with redirect support:', imageUrl);

    // Method 1: Try to follow redirects manually with token
    let currentUrl = imageUrl;
    let redirectCount = 0;
    const maxRedirects = 5;

    while (redirectCount < maxRedirects) {
      const response = await fetch(currentUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'image/*',
        },
        redirect: 'manual' // Handle redirects manually
      });

      console.log(`Request to ${currentUrl} returned status: ${response.status}`);

      // Success - we got the image
      if (response.ok && response.status === 200) {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.startsWith('image/')) {
          const blob = await response.blob();
          const objectUrl = URL.createObjectURL(blob);
          console.log('Successfully loaded image with token');
          return objectUrl;
        }
      }

      // Handle redirects (3xx status codes)
      if (response.status >= 300 && response.status < 400) {
        const location = response.headers.get('Location');
        if (location) {
          // Handle relative URLs
          if (location.startsWith('/')) {
            const url = new URL(currentUrl);
            currentUrl = `${url.protocol}//${url.host}${location}`;
          } else if (location.startsWith('http')) {
            currentUrl = location;
          } else {
            // Relative to current path
            const url = new URL(currentUrl);
            currentUrl = new URL(location, url).href;
          }
          
          console.log(`Following redirect ${redirectCount + 1} to: ${currentUrl}`);
          redirectCount++;
          continue;
        }
      }

      // If we get here, the request failed
      throw new Error(`Request failed with status: ${response.status}`);
    }

    throw new Error(`Too many redirects (${maxRedirects})`);
    
  } catch (error) {
    console.error('Error loading image with redirect support:', error);
    
    // Fallback to the original method
    try {
      console.log('Trying fallback method...');
      return await loadImageWithCache(imageUrl, 'image');
    } catch (fallbackError) {
      console.error('Fallback method also failed:', fallbackError);
      throw new Error(`Both methods failed. Original: ${error.message}, Fallback: ${fallbackError.message}`);
    }
  }
};

// Helper function to convert relative URLs to absolute URLs using API_BASE_URL
const getAbsoluteImageUrl = (imageUrl) => {
  if (!imageUrl) return null;
  
  // If it's already an absolute URL, return as is
  if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
    return imageUrl;
  }
  
  // If it's a relative URL starting with /api/, prepend the API_BASE_URL
  if (imageUrl.startsWith('/api/')) {
    return `${API_BASE_URL}${imageUrl}`;
  }
  
  // If it's any other relative URL, also prepend API_BASE_URL
  return `${API_BASE_URL}${imageUrl}`;
};

// Helper function to format time in Arabic with i18n support
const formatTimeArabic = (timestamp, t) => {
  if (!timestamp) return '';
  
  const now = Date.now();
  const messageTime = timestamp * 1000; // Convert to milliseconds
  const diffInSeconds = Math.floor((now - messageTime) / 1000);
  
  if (diffInSeconds < 60) {
    return t ? t('chat.now') : 'الآن';
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return t ? t('chat.minutesAgo', { count: minutes }) : `منذ ${minutes} ${minutes === 1 ? 'دقيقة' : 'دقائق'}`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return t ? t('chat.hoursAgo', { count: hours }) : `منذ ${hours} ${hours === 1 ? 'ساعة' : 'ساعات'}`;
  } else if (diffInSeconds < 2592000) {
    const days = Math.floor(diffInSeconds / 86400);
    return t ? t('chat.daysAgo', { count: days }) : `منذ ${days} ${days === 1 ? 'يوم' : 'أيام'}`;
  } else if (diffInSeconds < 31536000) {
    const months = Math.floor(diffInSeconds / 2592000);
    return t ? t('chat.monthsAgo', { count: months }) : `منذ ${months} ${months === 1 ? 'شهر' : 'أشهر'}`;
  } else {
    const years = Math.floor(diffInSeconds / 31536000);
    return t ? t('chat.yearsAgo', { count: years }) : `منذ ${years} ${years === 1 ? 'سنة' : 'سنوات'}`;
  }
};

// Helper function to format time as HH:MM
const formatMessageTime = (timestamp) => {
  if (!timestamp) return '';
  
  const date = new Date(timestamp * 1000); // Convert to milliseconds
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  
  return `${hours}:${minutes}`;
};

// Enhanced Authenticated Markdown Image Component with retry logic
const AuthenticatedMarkdownImage = ({ src, alt, title, isGallery = false }) => {
  const [imageSrc, setImageSrc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [retryAfterMinute, setRetryAfterMinute] = useState(false);

  useEffect(() => {
    const loadAuthenticatedImage = async () => {
      if (!src) return;
      
      try {
        setLoading(true);
        setError(false);
        
        console.log(`Loading image (attempt ${retryCount + 1}):`, src);
        
        // Try different methods based on the URL pattern
        let authenticatedUrl = null;
        
        // Method 1: Check if it's a file ID (for attached images)
        if (src.match(/^[a-f0-9-]{36}$/i)) {
          // This looks like a file ID, use getFileDownloadUrl approach
          const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
          if (token) {
            const fileUrl = `${API_BASE_URL}/api/v1/storage/files/${src}/download`;
            authenticatedUrl = await loadImageWithRedirectSupport(fileUrl);
          }
        } 
        // Method 2: Check if it's already an absolute URL (for generated images)
        else if (src.startsWith('http')) {
          // Use the same logic as GeneratedImageDisplay
          const absoluteUrl = getAbsoluteImageUrl(src);
          authenticatedUrl = await loadImageWithRedirectSupport(absoluteUrl);
        }
        // Method 3: Relative URL, make it absolute
        else {
          const absoluteUrl = getAbsoluteImageUrl(src);
          authenticatedUrl = await loadImageWithRedirectSupport(absoluteUrl);
        }
        
        if (authenticatedUrl) {
          setImageSrc(authenticatedUrl);
          setRetryCount(0); // Reset retry count on success
          setRetryAfterMinute(false);
        } else {
          throw new Error('Failed to load authenticated image');
        }
      } catch (err) {
        console.error(`Error loading image (attempt ${retryCount + 1}):`, err);
        
        // Retry logic: 2 attempts, then wait 1 minute
        if (retryCount < 2) {
          console.log(`Retrying in 2 seconds... (attempt ${retryCount + 2})`);
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
          }, 2000);
        } else if (!retryAfterMinute) {
          console.log('Max retries reached, waiting 1 minute before next attempt');
          setRetryAfterMinute(true);
          setTimeout(() => {
            console.log('Retrying after 1 minute wait');
            setRetryCount(0);
            setRetryAfterMinute(false);
          }, 60000); // 1 minute
        } else {
          setError(true);
        }
      } finally {
        if (retryCount >= 2 && !retryAfterMinute) {
          // Don't set loading to false if we're going to retry after a minute
        } else {
          setLoading(false);
        }
      }
    };

    loadAuthenticatedImage();
  }, [src, retryCount]);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8 bg-[var(--background-secondary)] rounded-lg mb-4">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)] mx-auto mb-2" />
          <p className="text-sm text-[var(--text-secondary)]">
            {retryAfterMinute 
              ? 'انتظار دقيقة قبل المحاولة التالية...'
              : retryCount > 0 
                ? `محاولة ${retryCount + 1} من 3...`
                : 'جاري تحميل الصورة...'
            }
          </p>
        </div>
      </div>
    );
  }

  if (error || !imageSrc) {
    return (
      <div className="flex items-center justify-center p-8 bg-[var(--background-secondary)] rounded-lg mb-4 border-2 border-dashed border-[var(--border-color)]">
        <div className="text-center">
          <ImageIcon className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-2" />
          <p className="text-sm text-[var(--text-secondary)]">فشل تحميل الصورة</p>
          <p className="text-xs text-[var(--text-secondary)] mt-1">تم المحاولة 3 مرات</p>
          {src && <p className="text-xs text-[var(--text-secondary)] mt-1 break-all">{src}</p>}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className={`relative group ${isGallery ? 'mb-0' : 'mb-4'}`}>
        <img
          src={imageSrc}
          alt={alt}
          title={title}
          className={`${isGallery ? 'w-full h-full object-cover' : 'max-w-full h-auto'} rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow duration-200`}
          onClick={() => setShowFullscreen(true)}
          loading="lazy"
        />
        
        {/* Hover overlay with actions */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex gap-2">
            <button
              onClick={() => setShowFullscreen(true)}
              className="p-2 bg-white/90 hover:bg-white rounded-full shadow-lg transition-colors"
              title="عرض مكبر"
            >
              <Eye className="w-4 h-4 text-gray-700" />
            </button>
            <button
              onClick={() => {
                const link = document.createElement('a');
                link.href = imageSrc;
                link.download = alt || 'image';
                link.click();
              }}
              className="p-2 bg-white/90 hover:bg-white rounded-full shadow-lg transition-colors"
              title="تحميل الصورة"
            >
              <Download className="w-4 h-4 text-gray-700" />
            </button>
          </div>
        </div>
      </div>

      {/* Fullscreen modal */}
      <AnimatePresence>
        {showFullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setShowFullscreen(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="relative max-w-full max-h-full"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={imageSrc}
                alt={alt}
                className="max-w-full max-h-full object-contain rounded-lg"
              />
              <button
                onClick={() => setShowFullscreen(false)}
                className="absolute top-4 right-4 p-2 bg-white/90 hover:bg-white rounded-full shadow-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-700" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

const ChatContent = ({ 
  selectedChat, 
  messages, 
  chatLoading, 
  getFileDownloadUrl,
  handleImageRegenerate,
  handleImageEdit,
  handleImageInfo,
  handleImageCopy,
  handleFileDownload,
  onEditMessage,
  isNewChat = false, // New prop to indicate if this is a new chat
  t
}) => {
  const [fileInfoModal, setFileInfoModal] = useState({ isOpen: false, attachment: null });
  const messagesEndRef = useRef(null);
  
  // Optimize modal opening with useCallback to prevent re-renders
  const openFileInfoModal = React.useCallback((attachment) => {
    requestAnimationFrame(() => {
      setFileInfoModal({ isOpen: true, attachment });
    });
  }, []);
  
  const closeFileInfoModal = React.useCallback(() => {
    setFileInfoModal({ isOpen: false, attachment: null });
  }, []);

  // Handle message editing
  const handleEditMessage = React.useCallback((message) => {
    if (onEditMessage) {
      onEditMessage(message);
    }
  }, [onEditMessage]);

  // Smart scroll management - only auto-scroll if user is at bottom
  const [userScrolledUp, setUserScrolledUp] = useState(false);
  const scrollContainerRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const checkScrollPosition = () => {
    const container = scrollContainerRef.current;
    if (container) {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 100; // 100px threshold
      setUserScrolledUp(!isAtBottom);
    }
  };

  useEffect(() => {
    // Only auto-scroll if user hasn't scrolled up manually AND no message is currently streaming
    const hasStreamingMessage = messages.some(msg => msg.streaming);
    if (messages.length > 0 && !chatLoading && !userScrolledUp && !hasStreamingMessage) {
      setTimeout(scrollToBottom, 10);
    }
  }, [messages, selectedChat?.id, chatLoading, userScrolledUp]);
  if (chatLoading) {
    return (
      <div className="flex-1 flex items-center justify-center h-full">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[var(--text-secondary)] mx-auto mb-4" />
          <p className="text-[var(--text-secondary)]">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  // Show new chat interface when no chat is selected or when it's a new chat
  if (!selectedChat || isNewChat || (selectedChat && messages.length === 0)) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <motion.div 
          className="text-center max-w-2xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-20 h-20 bg-[var(--background-secondary)] rounded-3xl flex items-center justify-center mx-auto mb-6">
            <MessageCircle className="w-10 h-10 text-[var(--text-secondary)]" />
          </div>
          
          <h3 className="text-2xl font-bold text-[var(--text-primary)] mb-3">
            {t ? t('chat.startConversation') : 'ابدأ محادثة جديدة'}
          </h3>
          <p className="text-[var(--text-secondary)] mb-8">
            {t ? t('chat.chooseTopicBelow') : 'اختر موضوعاً من الاقتراحات أدناه أو اكتب سؤالك مباشرة'}
          </p>
          
          {/* Suggestion Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {[
              {
                icon: '💡',
                title: t ? t('chat.explainConcept') : 'شرح مفهوم',
                description: t ? t('chat.explainConceptDesc') : 'اشرح لي مفهوم الذكاء الاصطناعي بطريقة مبسطة',
                prompt: t ? t('chat.explainConceptDesc') : 'اشرح لي مفهوم الذكاء الاصطناعي بطريقة مبسطة'
              },
              {
                icon: '📝',
                title: t ? t('chat.helpWriting') : 'مساعدة في الكتابة',
                description: t ? t('chat.helpWritingDesc') : 'ساعدني في كتابة مقال عن أهمية التعليم',
                prompt: t ? t('chat.helpWritingDesc') : 'ساعدني في كتابة مقال عن أهمية التعليم'
              },
              {
                icon: '🔍',
                title: t ? t('chat.research') : 'البحث والاستكشاف',
                description: t ? t('chat.researchDesc') : 'أريد معلومات شاملة عن تغير المناخ',
                prompt: t ? t('chat.researchDesc') : 'أريد معلومات شاملة عن تغير المناخ'
              },
              {
                icon: '🎨',
                title: t ? t('chat.createImage') : 'إنشاء صورة',
                description: t ? t('chat.createImageDesc') : 'أنشئ صورة لمنظر طبيعي جميل مع شلال',
                prompt: t ? t('chat.createImageDesc') : 'أنشئ صورة لمنظر طبيعي جميل مع شلال'
              },
              {
                icon: '💻',
                title: t ? t('chat.programming') : 'البرمجة والتطوير',
                description: t ? t('chat.programmingDesc') : 'اكتب لي دالة JavaScript لحساب المتوسط الحسابي',
                prompt: t ? t('chat.programmingDesc') : 'اكتب لي دالة JavaScript لحساب المتوسط الحسابي'
              },
              {
                icon: '🧮',
                title: t ? t('chat.math') : 'الرياضيات والحسابات',
                description: t ? t('chat.mathDesc') : 'ساعدني في حل معادلة تربيعية خطوة بخطوة',
                prompt: t ? t('chat.mathDesc') : 'ساعدني في حل معادلة تربيعية خطوة بخطوة'
              }
            ].map((suggestion, index) => (
              <motion.div
                key={index}
                className="p-4 bg-[var(--background-secondary)] rounded-xl border border-[var(--border-color)] hover:bg-[var(--background-tertiary)] transition-all duration-200 cursor-pointer group"
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  // Trigger suggestion click - this will be handled by parent component
                  if (window.handleSuggestionClick) {
                    window.handleSuggestionClick(suggestion.prompt);
                  }
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-200">
                    {suggestion.icon}
                  </div>
                  <div className="flex-1 text-right">
                    <h4 className="text-lg font-semibold text-[var(--text-primary)] mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {suggestion.title}
                    </h4>
                    <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                      {suggestion.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center">
            <p className="text-sm text-[var(--text-secondary)]">
              {t ? t('chat.orTypeBelow') : 'أو اكتب سؤالك في الصندوق أدناه'}
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  if (selectedChat && (messages.length > 0 || isNewChat)) {
    return (
      <div 
        ref={scrollContainerRef}
        className="flex-1 h-full overflow-y-auto overflow-x-hidden"
        onScroll={checkScrollPosition}
      >
        <div className="p-6 space-y-4 max-w-full">
          {/* Chat Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-4 p-4 bg-[var(--background-secondary)] rounded-2xl border border-[var(--border-color)]"
          >
            <div className="p-3 bg-[var(--background-tertiary)] rounded-xl">
              <MessageCircle className="w-6 h-6 text-[var(--text-primary)]" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-[var(--text-primary)]">
                {selectedChat.title || (t ? t('ai.newChat') : 'محادثة جديدة')}
              </h2>
              <p className="text-sm text-[var(--text-secondary)]">
                {isNewChat ? (
                  t ? t('chat.newChatReady') : 'محادثة جديدة جاهزة'
                ) : (
                  <>
                    {messages.length} {t ? t('chat.messages') : 'رسالة'} • {formatTimeArabic(selectedChat.updated_at || selectedChat.created_at, t)}
                  </>
                )}
              </p>
            </div>
          </motion.div>

          {/* Messages */}
          {messages.map((message, index) => (
            <ChatMessage 
              key={message.id || index}
              message={message}
              index={index}
              formatTime={(timestamp) => formatTimeArabic(timestamp, t)}
              getFileDownloadUrl={getFileDownloadUrl}
              handleImageRegenerate={handleImageRegenerate}
              handleImageEdit={handleImageEdit}
              handleImageCopy={handleImageCopy}
              handleFileDownload={handleFileDownload}
              setFileInfoModal={openFileInfoModal}
              onEdit={handleEditMessage}
              t={t}
            />
          ))}

          {/* New Chat Welcome Message */}
          {isNewChat && messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12"
            >
              <div className="w-20 h-20 bg-[var(--background-secondary)] rounded-3xl flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="w-10 h-10 text-[var(--text-secondary)]" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">
                {t ? t('chat.newChatWelcome') : 'مرحباً! محادثة جديدة'}
              </h3>
              <p className="text-[var(--text-secondary)] mb-6 max-w-md mx-auto">
                {t ? t('chat.newChatDescription') : 'ابدأ بكتابة رسالتك أدناه وسيتم إنشاء المحادثة تلقائياً'}
              </p>
              
              {/* Example prompts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl mx-auto">
                {[
                  { icon: '💡', text: t ? t('chat.examplePrompt1') : 'اشرح لي مفهوماً معقداً' },
                  { icon: '📝', text: t ? t('chat.examplePrompt2') : 'ساعدني في كتابة نص' },
                  { icon: '🔍', text: t ? t('chat.examplePrompt3') : 'ابحث عن معلومات حول موضوع' },
                  { icon: '🎨', text: t ? t('chat.examplePrompt4') : 'أنشئ صورة أو تصميم' }
                ].map((prompt, index) => (
                  <div
                    key={index}
                    className="p-4 bg-[var(--background-secondary)] rounded-xl border border-[var(--border-color)] hover:bg-[var(--background-tertiary)] transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{prompt.icon}</span>
                      <span className="text-sm text-[var(--text-primary)]">{prompt.text}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
          
          {/* Invisible element to scroll to */}
          <div ref={messagesEndRef} />
          

          
          {/* File Info Modal */}
          <FileInfoModal 
            attachment={fileInfoModal.attachment}
            isOpen={fileInfoModal.isOpen}
            onClose={closeFileInfoModal}
            t={t}
          />
        </div>
      </div>
    );
  }

  // This case is now handled at the beginning of the function - no duplicate needed
};

// ChatMessage component
const ChatMessage = ({ 
  message, 
  index, 
  formatTime, 
  getFileDownloadUrl,
  handleImageRegenerate,
  handleImageEdit,
  handleImageInfo,
  handleImageCopy,
  handleFileDownload,
  setFileInfoModal,
  onEdit,
  t
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        delay: 0, // Remove delay for immediate appearance
        type: "spring",
        stiffness: 400,
        damping: 30
      }}
      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`max-w-[85%] space-y-3 min-w-0 break-words overflow-wrap-anywhere`}>
        
        {/* User Attachments - Show before message */}
        {message.role === 'user' && message.attachments && message.attachments.length > 0 && (
          <div className="space-y-3">
            {message.attachments.map((attachment, attIndex) => (
              <AttachmentDisplay 
                key={attIndex} 
                attachment={attachment} 
                userInput={null} // Don't pass userInput to avoid duplication
                getFileDownloadUrl={getFileDownloadUrl}
                handleImageRegenerate={handleImageRegenerate}
                handleImageEdit={handleImageEdit}
                handleImageCopy={handleImageCopy}
                handleFileDownload={handleFileDownload}
                setFileInfoModal={setFileInfoModal}
                t={t}
              />
            ))}
          </div>
        )}

        {/* Web Search Results - Show at the beginning of assistant responses */}
        {message.role === 'assistant' && message.websearch === true && (
          (message.search_urls && message.search_urls.length > 0) || 
          (message.streaming && message.websearch)
        ) && (
          <WebSearchResults 
            searchUrls={message.search_urls}
            searchQuery={message.search_query}
            isStreaming={message.streaming && message.websearch}
            hasContent={message.content && message.content.trim().length > 0}
            t={t}
          />
        )}

        {/* Image Generation Display - عرض حالة توليد الصور */}
        {message.role === 'assistant' && (
          message.image_gen === true || 
          message.image_generation_progress || 
          message.generated_images ||
          (message.streaming && (message.image_gen === true || message.image_generation_progress || message.generated_images))
        ) && (
          <ImageGenerationDisplay 
            imageGenData={message}
            isStreaming={message.streaming && (message.image_gen === true || message.image_generation_progress || message.generated_images)}
            t={t}
          />
        )}

        {/* Message Content - فقط إذا لم يكن هناك توليد صور وكان هناك محتوى فعلي */}
        {(() => {
          // تنظيف المحتوى من رسائل توليد الصور
          let cleanContent = message.content || '';
          cleanContent = cleanContent.replace(/🎨 Generating images\.\.\. \d+% complete \(\d+\/\d+\)/g, '').trim();
          cleanContent = cleanContent.replace(/✅ All \d+ images generated successfully!/g, '').trim();
          
          // عرض المحتوى فقط إذا كان هناك نص فعلي وليس توليد صور
          return cleanContent && 
                 !(message.image_gen === true || message.image_generation_progress || message.generated_images);
        })() && (
          <MessageBubble 
            message={message} 
            formatTime={(timestamp) => formatTimeArabic(timestamp, t)} 
            t={t}
            onEdit={onEdit}
          />
        )}

        {/* Show timestamp only for messages without content */}
        {(!message.content || !message.content.trim()) && (
          <div className="text-center">
            <p className="text-xs text-[var(--text-secondary)]">
              {formatTime ? formatTime(message.timestamp) : formatTimeArabic(message.timestamp, t)}
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
};

// Mermaid Chart Component
const MermaidChart = ({ chart }) => {
  const [svg, setSvg] = useState('');
  const [error, setError] = useState(false);
  const chartRef = useRef(null);

  useEffect(() => {
    const renderChart = async () => {
      try {
        const id = `mermaid-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const { svg } = await mermaid.render(id, chart);
        setSvg(svg);
        setError(false);
      } catch (err) {
        console.error('Mermaid rendering error:', err);
        setError(true);
      }
    };

    if (chart) {
      renderChart();
    }
  }, [chart]);

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-4">
        <p className="text-red-600 text-sm">خطأ في عرض الرسم البياني</p>
      </div>
    );
  }

  return (
    <div className="mermaid-container bg-[var(--background)] rounded-lg border border-[var(--border-color)] mb-4 overflow-hidden">
      <div className="flex items-center justify-between p-3 bg-[var(--background-secondary)] border-b border-[var(--border-color)]">
        <span className="text-sm font-medium text-[var(--text-primary)]">Mermaid Diagram</span>
        <button
          onClick={() => navigator.clipboard.writeText(chart)}
          className="flex items-center gap-1 hover:bg-[var(--background-tertiary)] px-2 py-1 rounded transition-colors text-xs"
          title="نسخ كود المخطط"
        >
          <Copy className="w-3 h-3" />
          نسخ الكود
        </button>
      </div>
      <div className="p-4 overflow-x-auto">
        {svg ? (
          <div dangerouslySetInnerHTML={{ __html: svg }} />
        ) : (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="w-6 h-6 animate-spin text-[var(--text-secondary)]" />
          </div>
        )}
      </div>
    </div>
  );
};

// JSON Viewer Component
const JsonViewer = ({ data }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  try {
    const jsonData = typeof data === 'string' ? JSON.parse(data) : data;
    const jsonString = JSON.stringify(jsonData, null, 2);
    
    return (
      <div className="bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-lg mb-4 overflow-hidden">
        <div 
          className="flex items-center justify-between p-3 bg-[var(--background-tertiary)] cursor-pointer hover:bg-[var(--background-secondary)] transition-colors"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <span className="text-sm font-medium text-[var(--text-primary)]">JSON Data</span>
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                navigator.clipboard.writeText(jsonString);
              }}
              className="flex items-center gap-1 hover:bg-[var(--background-secondary)] px-2 py-1 rounded transition-colors text-xs"
              title="نسخ JSON"
            >
              <Copy className="w-3 h-3" />
              نسخ
            </button>
            <ChevronDown className={`w-4 h-4 text-[var(--text-secondary)] transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
          </div>
        </div>
        {isExpanded && (
          <pre className="p-4 text-xs overflow-x-auto bg-[var(--background)] text-[var(--text-primary)] font-mono border-t border-[var(--border-color)]">
            {jsonString}
          </pre>
        )}
      </div>
    );
  } catch (err) {
    return (
      <div className="p-3 bg-red-50 border border-red-200 rounded-lg mb-4">
        <p className="text-red-600 text-sm">خطأ في تحليل JSON</p>
      </div>
    );
  }
};

// LIVE Markdown Streaming - Markdown rendering during streaming
const StreamingText = ({ content, isStreaming, isSending = false }) => {
  const [displayedContent, setDisplayedContent] = useState('');
  const [showCursor, setShowCursor] = useState(isStreaming);

  useEffect(() => {
    // Clean content - remove [DONE] markers and image generation progress text
    let cleanContent = content || '';
    cleanContent = cleanContent.replace(/\[DONE\]/gi, '').trim();
    
    // Remove image generation progress messages
    cleanContent = cleanContent.replace(/🎨 Generating images\.\.\. \d+% complete \(\d+\/\d+\)/g, '').trim();
    cleanContent = cleanContent.replace(/✅ All \d+ images generated successfully!/g, '').trim();
    
    // Update displayed content immediately for real-time streaming
    setDisplayedContent(cleanContent);
    // Always show cursor when streaming, even with empty content
    setShowCursor(isStreaming);
  }, [content, isStreaming]);

  // Always render with markdown support - both during streaming and when complete
  return (
    <div className="text-sm leading-relaxed break-words" style={{ whiteSpace: 'pre-wrap' }}>
      <ReactMarkdown 
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          // Basic components
          h1: ({ children }) => <h1 className="text-xl font-bold mb-3 mt-4 first:mt-0">{children}</h1>,
          h2: ({ children }) => <h2 className="text-lg font-bold mb-2 mt-3 first:mt-0">{children}</h2>,
          h3: ({ children }) => <h3 className="text-base font-bold mb-2 mt-3 first:mt-0">{children}</h3>,
          
          // Lists
          ul: ({ children }) => <ul className="list-disc ml-4 mb-2 space-y-1">{children}</ul>,
          ol: ({ children }) => <ol className="list-decimal ml-4 mb-2 space-y-1">{children}</ol>,
          li: ({ children }) => <li className="leading-relaxed">{children}</li>,
          
          // Code blocks with VS Code styling and Python runner
          code: ({ children, className }) => {
            const match = /language-(\w+)/.exec(className || '');
            const language = match ? match[1] : '';
            const codeContent = String(children).replace(/\n$/, '');
            
            // Handle special cases
            if (language === 'mermaid') {
              return <MermaidChart chart={codeContent} />;
            }
            
            if (language === 'json') {
              return <JsonViewer data={codeContent} />;
            }
            
            // Python code block with runner
            if (language === 'python' || language === 'py') {
              return <PythonCodeBlock code={codeContent} autoOperationsActive={window.autoOperationsActive || false} />;
            }
            
            // HTML code block with preview
            if (language === 'html') {
              return <HTMLCodeBlock code={codeContent} autoOperationsActive={window.autoOperationsActive || false} />;
            }
            
            // Regular code blocks with VS Code styling
            if (match) {
              return (
                <div className="mb-4 rounded-xl overflow-hidden border border-[var(--border-color)] shadow-sm">
                  <div className="flex items-center justify-between bg-[var(--background-secondary)] text-[var(--text-primary)] px-4 py-2 text-xs border-b border-[var(--border-color)]">
                    <span className="font-medium">{language}</span>
                    <button
                      onClick={() => navigator.clipboard.writeText(codeContent)}
                      className="flex items-center gap-1 hover:bg-[var(--background-tertiary)] px-2 py-1 rounded transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      نسخ
                    </button>
                  </div>
                  <div className="bg-[var(--background)] text-[var(--text-primary)]">
                    <SyntaxHighlighter
                      style={{
                        ...oneDark,
                        'pre[class*="language-"]': {
                          ...oneDark['pre[class*="language-"]'],
                          background: 'transparent !important',
                          color: 'var(--text-primary)'
                        },
                        'code[class*="language-"]': {
                          ...oneDark['code[class*="language-"]'],
                          background: 'transparent !important',
                          color: 'var(--text-primary)'
                        }
                      }}
                      language={language}
                      PreTag="div"
                      className="!mt-0 !rounded-none !bg-transparent"
                      customStyle={{
                        margin: 0,
                        backgroundColor: 'transparent',
                        color: 'var(--text-primary)',
                        borderRadius: 0,
                      }}
                    >
                      {codeContent}
                    </SyntaxHighlighter>
                  </div>
                </div>
              );
            }
            
            // Inline code
            return (
              <span className="inline-flex items-center gap-1 group">
                <code className="bg-[var(--background-secondary)] text-[var(--text-primary)] px-2 py-1 rounded text-xs font-mono border border-[var(--border-color)]">
                  {children}
                </code>
                <button
                  onClick={() => navigator.clipboard.writeText(String(children))}
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-[var(--background-tertiary)] rounded"
                  title="نسخ الكود"
                >
                  <Copy className="w-3 h-3 text-[var(--text-secondary)]" />
                </button>
              </span>
            );
          },
          
          // Tables with rounded corners and copy functionality
          table: ({ children }) => {
            const [showCopyButton, setShowCopyButton] = useState(false);
            
            const copyTableAsHTML = () => {
              const tableElement = document.querySelector('.table-container table');
              if (tableElement) {
                const tableHTML = tableElement.outerHTML;
                const htmlBlob = new Blob([tableHTML], { type: 'text/html' });
                const textBlob = new Blob([tableElement.innerText], { type: 'text/plain' });
                
                if (navigator.clipboard && window.ClipboardItem) {
                  const clipboardItem = new ClipboardItem({
                    'text/html': htmlBlob,
                    'text/plain': textBlob
                  });
                  navigator.clipboard.write([clipboardItem]).catch(() => {
                    navigator.clipboard.writeText(tableElement.innerText);
                  });
                } else {
                  navigator.clipboard.writeText(tableElement.innerText);
                }
              }
              };
            
            return (
              <div 
                className="table-container overflow-hidden mb-4 rounded-xl border border-[var(--border-color)] shadow-sm relative group"
                onMouseEnter={() => setShowCopyButton(true)}
                onMouseLeave={() => setShowCopyButton(false)}
              >
                {/* Copy button for table */}
                <AnimatePresence>
                  {showCopyButton && (
                    <motion.button
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      onClick={copyTableAsHTML}
                      className="absolute top-2 right-2 z-10 p-2 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-lg border border-[var(--border-color)] transition-colors shadow-sm"
                      title="نسخ الجدول"
                    >
                      <Copy className="w-4 h-4 text-[var(--text-primary)]" />
                    </motion.button>
                  )}
                </AnimatePresence>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full border-collapse">
                    {children}
                  </table>
                </div>
              </div>
            );
          },
          thead: ({ children }) => (
            <thead className="bg-[var(--background-secondary)]">
              {children}
            </thead>
          ),
          tbody: ({ children }) => (
            <tbody className="bg-[var(--background)] divide-y divide-[var(--border-color)]">
              {children}
            </tbody>
          ),
          tr: ({ children }) => (
            <tr className="hover:bg-[var(--background-secondary)] transition-colors border-b border-[var(--border-color)]">
              {children}
            </tr>
          ),
          th: ({ children }) => (
            <th className="px-4 py-3 text-left text-xs font-semibold text-[var(--text-primary)] uppercase tracking-wider border-b border-[var(--border-color)] border-r border-[var(--border-color)] last:border-r-0">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="px-4 py-3 text-sm text-[var(--text-primary)] border-b border-[var(--border-color)] border-r border-[var(--border-color)] last:border-r-0">
              {children}
            </td>
          ),
          
          // Other elements
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-blue-500 pl-4 italic mb-2 bg-blue-50 dark:bg-blue-900/20 py-2">
              {children}
            </blockquote>
          ),
          strong: ({ children }) => <strong className="font-bold">{children}</strong>,
          em: ({ children }) => <em className="italic">{children}</em>,
          a: ({ children, href }) => (
            <a 
              href={href} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 dark:text-blue-400 underline"
            >
              {children}
            </a>
          ),
          
          // Authenticated images with token support and gallery
          img: ({ src, alt, title }) => {
            return (
              <AuthenticatedMarkdownImage 
                src={src} 
                alt={alt || 'صورة'} 
                title={title}
              />
            );
          },
          
          // Custom component for image galleries and paragraphs
          p: ({ children }) => {
            // Check if this paragraph contains multiple images (image gallery)
            const images = React.Children.toArray(children).filter(child => 
              child?.type === 'img' || (child?.props?.children && 
              React.Children.toArray(child.props.children).some(grandchild => grandchild?.type === 'img'))
            );
            
            if (images.length > 1) {
              return (
                <div className="mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {React.Children.map(children, (child, index) => {
                      if (child?.type === 'img') {
                        return (
                          <div key={index} className="aspect-square overflow-hidden rounded-lg">
                            <AuthenticatedMarkdownImage 
                              src={child.props.src} 
                              alt={child.props.alt || `صورة ${index + 1}`} 
                              title={child.props.title}
                              isGallery={true}
                            />
                          </div>
                        );
                      }
                      return child;
                    })}
                  </div>
                </div>
              );
            }
            
            // Regular paragraph
            return <p className="mb-2 leading-relaxed">{children}</p>;
          }
        }}
      >
        {displayedContent}
      </ReactMarkdown>
      
      {/* Typing cursor for streaming - Circular blinking dot */}
      {(showCursor || isSending || (isStreaming && displayedContent === '')) && (
        <motion.span
          className="inline-block w-3 h-3 bg-[var(--text-primary)] ml-2 rounded-full"
          animate={{ 
            scale: [0.8, 1.2, 0.8]
          }}
          transition={{ 
            duration: 1.5, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
        />
      )}
    </div>
  );
};

// Message bubble component - Redesigned with Markdown support and inline editing
const MessageBubble = ({ message, formatTime, t, onEdit, onCopy }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);
  const textareaRef = useRef(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    // You can add a toast notification here
  };

  const handleEditStart = () => {
    setIsEditing(true);
    setEditContent(message.content);
    // Focus textarea after state update
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.select();
      }
    }, 0);
  };

  const handleEditSave = () => {
    if (onEdit && editContent.trim() !== message.content) {
      onEdit({ ...message, content: editContent.trim() });
    }
    setIsEditing(false);
  };

  const handleEditCancel = () => {
    setEditContent(message.content);
    setIsEditing(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleEditSave();
    } else if (e.key === 'Escape') {
      handleEditCancel();
    }
  };

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  };

  useEffect(() => {
    if (isEditing) {
      adjustTextareaHeight();
    }
  }, [isEditing, editContent]);

  return (
    <div className="space-y-2">
      <motion.div 
        className={`relative ${
          message.role === 'user'
            ? 'bg-[var(--text-primary)] text-white rounded-3xl px-6 py-4'
            : 'bg-[var(--background)] text-[var(--text-primary)] rounded-2xl px-6 py-4'
        }`}
        // Animation removed as requested
      >
        {isEditing ? (
          // Edit mode
          <div className="space-y-3">
            <textarea
              ref={textareaRef}
              value={editContent}
              onChange={(e) => {
                setEditContent(e.target.value);
                adjustTextareaHeight();
              }}
              onKeyDown={handleKeyDown}
              className={`resize-none border-none outline-none bg-transparent text-sm leading-relaxed font-inherit block ${
                message.role === 'user' ? 'text-white placeholder-gray-300' : 'text-[var(--text-primary)] placeholder-gray-500'
              }`}
              placeholder={t ? t('chat.editPlaceholder') : 'اكتب رسالتك هنا...'}
              style={{ 
                minHeight: '60px',
                width: '100%',
                maxWidth: 'none',
                wordWrap: 'break-word',
                whiteSpace: 'pre-wrap',
                boxSizing: 'border-box'
              }}
            />
            <div className="flex items-center gap-2 justify-end">
              <button
                onClick={handleEditCancel}
                className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                  message.role === 'user' 
                    ? 'border-white/30 text-white/70 hover:bg-white/10' 
                    : 'border-[var(--border-color)] text-[var(--text-secondary)] hover:bg-[var(--background-secondary)]'
                }`}
              >
                {t ? t('common.cancel') : 'إلغاء'}
              </button>
              <button
                onClick={handleEditSave}
                className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                  message.role === 'user' 
                    ? 'bg-white text-[var(--text-primary)] hover:bg-gray-100' 
                    : 'bg-[var(--text-primary)] text-white hover:bg-[var(--text-primary)]/90'
                }`}
              >
                {t ? t('common.save') : 'حفظ'}
              </button>
            </div>
          </div>
        ) : (
          // Display mode
          <StreamingText 
            content={message.content} 
            isStreaming={message.streaming || false}
            isSending={message.isSending || false}
          />
        )}
      </motion.div>

      {/* Message timestamp and actions */}
      <div className={`flex items-center gap-2 ${
        message.role === 'user' ? 'justify-end' : 'justify-start'
      }`}>
        {/* Timestamp */}
        <span className="text-xs text-[var(--text-secondary)]">
          {formatMessageTime(message.timestamp || message.created_at)}
        </span>

        {/* Action buttons - Always visible as simple icons */}
        <div className="flex items-center gap-1">
          {/* Copy button */}
          <button
            onClick={handleCopy}
            className="p-1 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
            title={t ? t('common.copy') : 'نسخ'}
          >
            <Copy className="w-3 h-3" />
          </button>

          {/* Edit button */}
          {onEdit && !isEditing && (
            <button
              onClick={handleEditStart}
              className="p-1 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
              title={t ? t('common.edit') : 'تحرير'}
            >
              <Edit className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// Enhanced attachment display
const AttachmentDisplay = ({ 
  attachment, 
  userInput, 
  getFileDownloadUrl,
  handleImageRegenerate,
  handleImageEdit,
  handleImageCopy,
  handleFileDownload,
  setFileInfoModal,
  t
}) => {
  // Handle image attachments
  if (attachment.content?.type === 'image') {
    return (
      <ChatImageDisplay
        imageId={attachment.id}
        imageName={attachment.name}
        imageSize={attachment.size}
        userInput={userInput}
        getFileDownloadUrl={getFileDownloadUrl}
        onRegenerate={() => handleImageRegenerate && handleImageRegenerate(attachment.id)}
        onEdit={() => handleImageEdit && handleImageEdit(attachment.id)}
                        onInfo={() => setFileInfoModal(attachment)}
      />
    );
  }

  // Handle document attachments
  if (attachment.content?.type === 'document') {
    return (
      <FileAttachmentDisplay
        attachment={attachment}
        onDownload={() => handleFileDownload && handleFileDownload(attachment.id, attachment.name)}
        onInfo={() => setFileInfoModal(attachment)}
        t={t}
      />
    );
  }

  // Fallback for unknown attachment types
  return (
    <div className="p-3 bg-[var(--background-secondary)] rounded-lg border border-[var(--border-color)]">
      <p className="text-sm text-[var(--text-secondary)]">
        {t ? t('chat.unsupportedFileType') : 'نوع ملف غير مدعوم'}: {attachment.name}
      </p>
    </div>
  );
};

// Chat Image Display Component - Enhanced
const ChatImageDisplay = ({ 
  imageId, 
  imageName, 
  userInput, 
  getFileDownloadUrl,
  onInfo,
  t
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showActions, setShowActions] = useState(false);
  const [imageError, setImageError] = useState(false);

  const imageUrl = getFileDownloadUrl ? getFileDownloadUrl(imageId) : null;

  return (
    <motion.div
      className="relative max-w-md mx-auto"
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
    >
      <div className="flex gap-3 items-start">
        {/* Image Container */}
        <div className="relative rounded-3xl overflow-hidden bg-[var(--background-secondary)] shadow-lg flex-1">
          {imageUrl && !imageError ? (
            <img
              src={imageUrl}
              alt={imageName || 'مرفق صورة'}
              className="w-full h-auto object-cover"
              onLoad={() => setImageLoaded(true)}
              onError={() => setImageError(true)}
              loading="lazy"
            />
          ) : (
            <div className="w-full h-48 flex items-center justify-center bg-[var(--background-tertiary)]">
              <div className="text-center">
                <ImageIcon className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-2" />
                <p className="text-sm text-[var(--text-secondary)]">
                  {imageError 
                    ? (t ? t('common.error') : 'فشل تحميل الصورة')
                    : (t ? t('common.loading') : 'جاري التحميل...')
                  }
                </p>
              </div>
            </div>
          )}
          
          {!imageLoaded && !imageError && imageUrl && (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
            </div>
          )}
        </div>

        {/* Action Buttons - Side by side */}
        <AnimatePresence>
          {showActions && (imageLoaded || imageError) && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ 
                duration: 0.25, 
                ease: "easeOut",
                type: "spring",
                stiffness: 300
              }}
              className="flex flex-col gap-2"
            >
            {onInfo && (
              <motion.button
                onClick={onInfo}
                className="p-3 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                title="معلومات الملف"
              >
                <Info className="w-4 h-4 text-[var(--text-primary)]" />
              </motion.button>
            )}
            
            <motion.button
              onClick={() => {
                const link = document.createElement('a');
                link.href = imageUrl;
                link.download = imageName || `image-${Date.now()}.png`;
                link.click();
              }}
              className="p-3 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title="تحميل الصورة"
            >
              <Download className="w-4 h-4 text-[var(--text-primary)]" />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
      </div>

      {/* User Input Text - Only show if it's different from the message content */}
      {userInput && userInput.trim() !== '' && (
        <div className="mt-3 p-4 bg-[var(--text-primary)] text-white rounded-3xl shadow-lg">
          <p className="text-sm leading-relaxed">
            {userInput}
          </p>
        </div>
      )}
    </motion.div>
  );
};

// File Attachment Display Component - Enhanced
const FileAttachmentDisplay = ({ attachment, onDownload, onInfo, t }) => {
  const getFileIcon = (fileName) => {
    const extension = fileName?.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return <FileText className="w-6 h-6 text-red-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="w-6 h-6 text-blue-500" />;
      case 'txt':
        return <FileText className="w-6 h-6 text-gray-500" />;
      default:
        return <FileText className="w-6 h-6 text-gray-500" />;
    }
  };

  return (
    <motion.div
      className="inline-flex items-center gap-4 p-4 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-3xl max-w-sm shadow-lg"
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
    >
      <div className="p-3 rounded-2xl bg-[var(--background-tertiary)]">
        {getFileIcon(attachment.name)}
      </div>
      
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-[var(--text-primary)] truncate">
          {attachment.name}
        </p>
        <p className="text-xs text-[var(--text-secondary)] font-medium">
          {attachment.size || '0 KB'}
        </p>
        {attachment.content?.text && (
          <p className="text-xs text-[var(--text-secondary)] mt-1">
            {t ? t('chat.contentAvailable') : 'محتوى متاح للعرض'}
          </p>
        )}
      </div>
      
      <div className="flex gap-2">
        {onInfo && (
          <motion.button
            onClick={onInfo}
            className="p-2.5 hover:bg-[var(--background-tertiary)] rounded-full transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="معلومات الملف"
          >
            <Info className="w-4 h-4 text-[var(--text-secondary)]" />
          </motion.button>
        )}
        
        {onDownload && (
          <motion.button
            onClick={onDownload}
            className="p-2.5 hover:bg-[var(--background-tertiary)] rounded-full transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="تحميل الملف"
          >
            <Download className="w-4 h-4 text-[var(--text-secondary)]" />
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};

// Generated image display component - Optimized for performance
const GeneratedImageDisplay = ({ generatedImage, t }) => {
  const [imageError, setImageError] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [hasAutoUploaded, setHasAutoUploaded] = useState(false);
  
  // Convert the image URL to use the correct API base URL
  const absoluteImageUrl = getAbsoluteImageUrl(generatedImage.image_url);

  // Auto-upload when auto operations is active
  useEffect(() => {
    if (window.autoOperationsActive && absoluteImageUrl && !hasAutoUploaded && !isUploading) {
      setHasAutoUploaded(true);
      handleUploadToCloud();
    }
  }, [absoluteImageUrl, hasAutoUploaded, isUploading]);

  const handleUploadToCloud = async () => {
    if (!absoluteImageUrl || isUploading) return;
    
    setIsUploading(true);
    try {
      const filename = `ai-generated-${Date.now()}.png`;
      const description = generatedImage.prompt || 'AI Generated Image';
      const tags = ['ai-generated', 'chat-image'];
      
      await uploadImageFromUrl(absoluteImageUrl, filename, description, tags);
      setUploadSuccess(true);
      
      // Show success message briefly
      setTimeout(() => setUploadSuccess(false), 3000);
      
              const successMessage = window.language === 'en'
          ? '✓ Image uploaded to cloud storage successfully'
          : '✓ تم رفع الصورة للسحابة التخزينية بنجاح';
        console.log(successMessage);
        
        // Show auto-upload notification if it was automatic
        if (window.autoOperationsActive) {
          const autoMessage = window.language === 'en'
            ? '🚀 Image automatically uploaded to cloud storage - Auto Operations enabled'
            : '🚀 تم رفع الصورة تلقائياً للسحابة التخزينية - العمليات التلقائية مفعلة';
          console.log(autoMessage);
        }
    } catch (error) {
      console.error('Failed to upload image to cloud:', error);
      // You can add toast notification here
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="relative max-w-md mx-auto">
      <div className="relative rounded-3xl overflow-hidden bg-[var(--background-secondary)] shadow-lg hover:shadow-xl transition-shadow duration-200">
        {absoluteImageUrl ? (
          <img
            src={absoluteImageUrl}
            alt="صورة مولدة بالذكاء الاصطناعي"
            className="w-full h-auto object-cover"
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <div className="w-full h-48 flex items-center justify-center bg-[var(--background-tertiary)]">
            <div className="text-center">
              <Paintbrush className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-2" />
              <p className="text-sm text-[var(--text-secondary)]">
                {t ? t('chat.generatedImage') : 'صورة مولدة'}
              </p>
            </div>
          </div>
        )}
        
        {generatedImage.status === 'processing' && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-3xl">
            <div className="text-center text-white">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
              <p className="text-sm">{t ? t('chat.generatingImage') : 'جاري توليد الصورة...'}</p>
            </div>
          </div>
        )}

        {imageError && (
          <div className="absolute inset-0 flex items-center justify-center bg-[var(--background-tertiary)]">
            <div className="text-center">
              <ImageIcon className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-2" />
              <p className="text-sm text-[var(--text-secondary)]">
                {t ? t('chat.imageGenerationFailed') : 'فشل تحميل الصورة المولدة'}
              </p>
            </div>
          </div>
        )}
      </div>

      {absoluteImageUrl && (
        <div className="flex items-center justify-center gap-2 mt-3">
          <button
            onClick={() => window.open(absoluteImageUrl, '_blank')}
            className="p-3 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm hover:scale-105 active:scale-95 transform duration-150"
            title={t ? t('chat.viewLarger') : 'عرض مكبر'}
          >
            <Eye className="w-4 h-4 text-[var(--text-primary)]" />
          </button>
          
          <button
            onClick={() => {
              const link = document.createElement('a');
              link.href = absoluteImageUrl;
              link.download = `generated-image-${Date.now()}.png`;
              link.click();
            }}
            className="p-3 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm hover:scale-105 active:scale-95 transform duration-150"
            title={t ? t('chat.downloadImage') : 'تحميل الصورة'}
          >
            <Download className="w-4 h-4 text-[var(--text-primary)]" />
          </button>
          
          <button
            onClick={handleUploadToCloud}
            disabled={isUploading}
            className={`p-3 rounded-full border border-[var(--border-color)] transition-colors shadow-sm hover:scale-105 active:scale-95 transform duration-150 ${
              uploadSuccess 
                ? 'bg-green-100 hover:bg-green-200 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                : isUploading
                ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 cursor-not-allowed'
                : 'bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] text-[var(--text-primary)]'
            }`}
            title={
              uploadSuccess 
                ? (t ? t('chat.uploadedToCloud') : 'تم الرفع للسحابة') 
                : isUploading 
                ? (t ? t('chat.uploadingToCloud') : 'جاري الرفع للسحابة')
                : (t ? t('chat.uploadToCloud') : 'رفع للسحابة التخزينية')
            }
          >
            {isUploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : uploadSuccess ? (
              <CheckCircle className="w-4 h-4" />
            ) : (
              <CloudUpload className="w-4 h-4" />
            )}
          </button>
        </div>
      )}
    </div>
  );
};

// Web search results component - Enhanced with animated loading state
const WebSearchResults = ({ searchUrls, searchQuery, t, isStreaming = false, hasContent = false }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchCompleted, setSearchCompleted] = useState(false);
  
  // Handle search completion - either when URLs are received or content starts
  useEffect(() => {
    if ((searchUrls && searchUrls.length > 0) || hasContent) {
      setSearchCompleted(true);
    }
  }, [searchUrls, hasContent]);

  // Show if we're streaming web search OR if we have URLs
  if (!isStreaming && (!searchUrls || searchUrls.length === 0)) return null;

  console.log('🔍 WebSearchResults render:', { 
    searchUrls, 
    isStreaming, 
    shouldShow: isStreaming || (searchUrls && searchUrls.length > 0) 
  });

  const resultsText = searchUrls?.length === 1 
    ? t ? t('chat.searchResult') : 'نتيجة بحث'
    : t ? t('chat.searchResults') : 'نتائج بحث';

  return (
    <div className={`rounded-2xl border overflow-hidden shadow-sm mb-4 min-w-[400px] w-full max-w-lg ${
      isStreaming 
        ? 'bg-gradient-to-r from-blue-50 via-blue-100 to-blue-50 dark:from-blue-900/20 dark:via-blue-800/30 dark:to-blue-900/20 border-blue-200 dark:border-blue-700 animate-pulse'
        : 'bg-[var(--background-secondary)] border-[var(--border-color)]'
    }`}>
      {/* Search Header - Enhanced with streaming animation */}
      <div
        className={`flex items-center justify-between p-4 h-[90px] transition-colors ${
          isStreaming 
            ? 'bg-gradient-to-r from-blue-100 via-blue-200 to-blue-100 dark:from-blue-800/40 dark:via-blue-700/50 dark:to-blue-800/40'
            : searchCompleted 
            ? 'cursor-pointer hover:bg-[var(--background-tertiary)]'
            : 'hover:bg-[var(--background-tertiary)]'
        }`}
        onClick={() => searchCompleted && setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-full relative ${
            isStreaming 
              ? 'bg-blue-200 dark:bg-blue-700' 
              : 'bg-[var(--background)] border border-[var(--border-color)]'
          }`}>
            {/* Animated search icon for streaming */}
            {isStreaming ? (
              <div className="relative">
                <Search className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                {/* Rotating border animation */}
                <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-blue-500 dark:border-t-blue-400 animate-spin"></div>
              </div>
            ) : (
              <Search className="w-4 h-4 text-[var(--text-primary)]" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-medium ${
                isStreaming 
                  ? 'text-blue-700 dark:text-blue-300' 
                  : 'text-[var(--text-primary)]'
              }`}>
                {isStreaming ? (
                  <span className="flex items-center gap-2">
                    <span className="relative">
                      Web Search
                      {/* Animated underline */}
                      <div className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-blue-400 via-blue-600 to-blue-400 animate-pulse"></div>
                      {/* Wave effect */}
                      <div className="absolute -bottom-1 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-ping"></div>
                    </span>
                    {/* Searching dots animation */}
                    <div className="flex gap-1">
                      {[0, 1, 2].map((i) => (
                        <motion.div
                          key={i}
                          className="w-1 h-1 bg-blue-600 dark:bg-blue-400 rounded-full"
                          animate={{ 
                            scale: [1, 1.5, 1],
                            opacity: [0.5, 1, 0.5]
                          }}
                          transition={{
                            duration: 0.8,
                            repeat: Infinity,
                            delay: i * 0.2,
                            ease: "easeInOut"
                          }}
                        />
                      ))}
                    </div>
                  </span>
                ) : (
                  t ? t('chat.webSearch') : 'بحث في الويب'
                )}
              </span>
            </div>
            <p className={`text-xs mt-0.5 ${
              isStreaming 
                ? 'text-blue-600 dark:text-blue-400' 
                : searchCompleted && !isExpanded
                ? 'text-green-600 dark:text-green-400'
                : 'text-[var(--text-secondary)]'
            }`}>
              {isStreaming ? (
                <motion.span
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  {t ? t('chat.searching') : 'جاري البحث في الويب...'}
                </motion.span>
              ) : searchCompleted && !isExpanded ? (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-green-600 dark:text-green-400 font-medium"
                >
                  {t ? t('chat.searchCompleted') : 'تم اكتمال البحث'}
                </motion.span>
              ) : (
                `${searchUrls?.length || 0} ${resultsText}`
              )}
            </p>
          </div>
        </div>
        
        {!isStreaming && searchCompleted && (
          <div
            className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}
          >
            <ChevronDown className="w-5 h-5 text-[var(--text-secondary)]" />
          </div>
        )}
      </div>
      
      {/* Expandable Content - Show during streaming if we have URLs */}
      {(isExpanded || (isStreaming && searchUrls && searchUrls.length > 0)) && (
        <div className="border-t border-[var(--border-color)] animate-in slide-in-from-top-2 duration-200">

          
          <div className="p-4 space-y-3">
            {isStreaming && (!searchUrls || searchUrls.length === 0) ? (
              // Loading state for web search
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <motion.div
                    key={i}
                    className="flex items-center gap-3 p-3 bg-blue-50/50 dark:bg-blue-900/10 rounded-xl border border-blue-200/50 dark:border-blue-700/50"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <div className="p-2 bg-blue-100 dark:bg-blue-800 rounded-lg">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        <Search className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                      </motion.div>
                    </div>
                    <div className="flex-1">
                      <div className="h-4 bg-blue-200 dark:bg-blue-700 rounded animate-pulse mb-2"></div>
                      <div className="h-3 bg-blue-100 dark:bg-blue-800 rounded animate-pulse w-2/3"></div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : searchUrls?.length > 0 ? (
              // Show URLs immediately as they arrive during streaming
              searchUrls.map((url, index) => {
                let hostname = '';
                
                try {
                  const urlObj = new URL(url);
                  hostname = urlObj.hostname;
                } catch {
                  hostname = t ? t('common.link') || 'رابط' : 'رابط';
                }
                
                return (
                  <motion.a
                    key={index}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-3 p-3 rounded-xl transition-colors border group ${
                      'bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-800/30 border-blue-200 dark:border-blue-700'
                    }`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className={`p-2 rounded-lg transition-colors ${
                      'bg-blue-100 dark:bg-blue-800 group-hover:bg-blue-200 dark:group-hover:bg-blue-700'
                    }`}>
                      <ExternalLink className={`w-4 h-4 ${
                        'text-blue-600 dark:text-blue-300'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium truncate ${
                        'text-blue-700 dark:text-blue-300'
                      }`}>
                        {hostname}
                      </p>
                      <p className={`text-xs truncate ${
                        'text-blue-600 dark:text-blue-400'
                      }`}>
                        {url}
                      </p>
                    </div>
                  </motion.a>
                );
              })
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};

// File Info Modal Component
const FileInfoModal = ({ attachment, isOpen, onClose, t }) => {
  if (!isOpen || !attachment) return null;

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2, ease: "easeInOut" }}
      onClick={onClose}
    >
      <motion.div
        className="bg-[var(--background)] rounded-2xl p-6 max-w-md w-full shadow-2xl"
        initial={{ scale: 0.8, y: 50, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.8, y: 50, opacity: 0 }}
        transition={{ 
          type: "spring", 
          stiffness: 300, 
          damping: 25,
          duration: 0.3
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[var(--text-primary)]">
            {t ? t('chat.fileInfo') : 'معلومات الملف'}
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[var(--background-secondary)] rounded-full transition-colors"
          >
            ×
          </button>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <FileType className="w-5 h-5 text-[var(--text-secondary)]" />
            <div>
              <p className="text-sm font-medium text-[var(--text-primary)]">
                {t ? t('chat.fileName') : 'اسم الملف'}
              </p>
              <p className="text-sm text-[var(--text-secondary)]">{attachment.name}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Hash className="w-5 h-5 text-[var(--text-secondary)]" />
            <div>
              <p className="text-sm font-medium text-[var(--text-primary)]">
                {t ? t('chat.fileId') : 'معرف الملف'}
              </p>
              <p className="text-sm text-[var(--text-secondary)] font-mono">{attachment.id}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Download className="w-5 h-5 text-[var(--text-secondary)]" />
            <div>
              <p className="text-sm font-medium text-[var(--text-primary)]">
                {t ? t('chat.fileSize') : 'حجم الملف'}
              </p>
              <p className="text-sm text-[var(--text-secondary)]">{attachment.size}</p>
            </div>
          </div>
          
          {attachment.content?.text && (
            <div className="mt-4">
              <p className="text-sm font-medium text-[var(--text-primary)] mb-2">
                {t ? t('chat.extractedText') : 'النص المستخرج'}
              </p>
              <div className="p-3 bg-[var(--background-secondary)] rounded-lg max-h-40 overflow-y-auto">
                <p className="text-xs text-[var(--text-secondary)] leading-relaxed whitespace-pre-wrap">
                  {attachment.content.text.length > 500 
                    ? attachment.content.text.substring(0, 500) + '...' 
                    : attachment.content.text
                  }
                </p>
              </div>
            </div>
          )}
          
          <div className="flex gap-2 pt-4">
            <button
              onClick={() => {
                navigator.clipboard.writeText(attachment.id);
                // You can add a toast notification here
              }}
              className="flex-1 flex items-center justify-center gap-2 p-3 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-xl transition-colors"
            >
              <Copy className="w-4 h-4" />
              <span className="text-sm">{t ? t('chat.copyId') : 'نسخ المعرف'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// Image Generation Display Component - نص متموج بسيط لتوليد الصور
const ImageGenerationDisplay = ({ imageGenData, isStreaming = false, t }) => {
  const [completedImages, setCompletedImages] = useState([]);
  const [isCompleted, setIsCompleted] = useState(false);
  
  // تحديث البيانات عند وصول معلومات جديدة
  useEffect(() => {
    // إضافة الصور المكتملة
    if (imageGenData?.generated_images) {
      const completed = imageGenData.generated_images.filter(img => 
        img.status === 'completed' && img.image_url
      );
      setCompletedImages(completed);
      
      // إذا كانت هناك صور مكتملة، قم بتحديث الحالة
      if (completed.length > 0) {
        setIsCompleted(true);
      }
    }
  }, [imageGenData]);

  // إذا كانت هناك صور مكتملة، اعرض رسالة الإكمال والصور
  if (completedImages.length > 0) {
    return (
      <div className="space-y-4">
        {/* رسالة الإكمال */}
        <motion.div
          className="text-center py-4"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-full border border-green-200 dark:border-green-700">
            <CheckCircle className="w-4 h-4" />
            <span className="font-medium">
              {window.language === 'en' ? 'Generation Complete!' : 'تم التوليد!'}
            </span>
          </div>
        </motion.div>
        
        {/* عرض الصور */}
        <div className="space-y-3">
          {completedImages.map((image, index) => (
            <GeneratedImageDisplay 
              key={image.request_id || index}
              generatedImage={image}
              t={t}
            />
          ))}
        </div>
      </div>
    );
  }

  // النص المتموج أثناء التوليد
  const generateText = window.language === 'en' ? 'Drawing...' : 'جار الرسم...';
  
  return (
    <div className="py-2">
      <div className="flex items-center justify-start space-x-1 rtl:space-x-reverse">
        {generateText.split('').map((char, index) => (
          <motion.span
            key={index}
            className="text-sm text-gray-600 dark:text-gray-300"
            animate={{
              color: [
                'rgb(156, 163, 175)', // gray-400
                'rgb(75, 85, 99)',   // gray-600  
                'rgb(156, 163, 175)', // gray-400
              ],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: index * 0.1,
              ease: "easeInOut"
            }}
          >
            {char === ' ' ? '\u00A0' : char}
          </motion.span>
        ))}
      </div>
    </div>
  );
};

export default ChatContent;