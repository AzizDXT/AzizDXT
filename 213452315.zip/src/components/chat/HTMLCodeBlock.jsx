import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { 
  Copy, 
  Eye, 
  EyeOff, 
  ExternalLink,
  ChevronDown,
  Globe
} from 'lucide-react';

// HTML Code Block Component with integrated preview
const HTMLCodeBlock = ({ code, autoOperationsActive = false }) => {
  const [showPreview, setShowPreview] = useState(autoOperationsActive);
  const [isCollapsed, setIsCollapsed] = useState(autoOperationsActive);

  // Control preview visibility based on Auto Operations state
  useEffect(() => {
    console.log('🔧 Auto Operations state changed for HTML:', autoOperationsActive);
    if (autoOperationsActive) {
      const message = window.language === 'en'
        ? '🌐 Auto-previewing HTML code - Auto Operations enabled'
        : '🌐 معاينة تلقائية لكود HTML - العمليات التلقائية مفعلة';
      console.log(message);
      setShowPreview(true);
      setIsCollapsed(true);
    } else {
      // When Auto Operations is disabled, allow manual preview but don't auto-show
      console.log('🔧 Auto Operations disabled - manual preview mode enabled');
      setShowPreview(false);
      setIsCollapsed(false);
    }
  }, [autoOperationsActive]);

  const handlePreviewToggle = () => {
    setShowPreview(!showPreview);
  };

  const handleOpenInNewTab = () => {
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    // Clean up the URL after a delay
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="mb-4 rounded-xl overflow-hidden border border-[var(--border-color)] shadow-sm">
      {/* Header with language and controls */}
      <div className="flex items-center justify-between bg-[var(--background-secondary)] text-[var(--text-primary)] px-4 py-2 text-xs border-b border-[var(--border-color)]">
        <div className="flex items-center gap-2">
          <span className="font-medium">HTML</span>
          {showPreview && (
            <span className="px-2 py-1 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 rounded-full text-xs">
              معاينة
            </span>
          )}
          {autoOperationsActive && (
            <span className="px-2 py-1 bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300 rounded-full text-xs">
              تلقائي
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isCollapsed && (
            <button
              onClick={() => setIsCollapsed(false)}
              className="flex items-center gap-1 px-2 py-1 rounded transition-colors hover:bg-[var(--background-tertiary)] text-blue-600 dark:text-blue-400"
            >
              <ChevronDown className="w-3 h-3" />
              توسيع الكود
            </button>
          )}
          <button
            onClick={handlePreviewToggle}
            className={`flex items-center gap-1 px-2 py-1 rounded transition-colors ${
              showPreview 
                ? 'bg-blue-100 hover:bg-blue-200 text-blue-700 dark:bg-blue-900/30 dark:hover:bg-blue-800/40 dark:text-blue-300'
                : autoOperationsActive
                ? 'hover:bg-[var(--background-tertiary)]'
                : 'bg-orange-100 hover:bg-orange-200 text-orange-700 dark:bg-orange-900/30 dark:hover:bg-orange-800/40 dark:text-orange-300'
            }`}
          >
            {showPreview ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            {showPreview ? 'إخفاء المعاينة' : autoOperationsActive ? 'معاينة' : 'معاينة يدوية'}
          </button>
          <button
            onClick={handleOpenInNewTab}
            className="flex items-center gap-1 hover:bg-[var(--background-tertiary)] px-2 py-1 rounded transition-colors"
          >
            <ExternalLink className="w-3 h-3" />
            فتح في تبويب جديد
          </button>
          <button
            onClick={() => navigator.clipboard.writeText(code)}
            className="flex items-center gap-1 hover:bg-[var(--background-tertiary)] px-2 py-1 rounded transition-colors"
          >
            <Copy className="w-3 h-3" />
            نسخ
          </button>
        </div>
      </div>
      
      {/* Code Display */}
      {!isCollapsed ? (
        <div className="bg-[var(--background)] text-[var(--text-primary)]">
          <SyntaxHighlighter
            style={{
              ...oneDark,
              'pre[class*="language-"]': {
                ...oneDark['pre[class*="language-"]'],
                background: 'transparent !important',
                color: 'var(--text-primary)'
              },
              'code[class*="language-"]': {
                ...oneDark['code[class*="language-"]'],
                background: 'transparent !important',
                color: 'var(--text-primary)'
              }
            }}
            language="html"
            PreTag="div"
            className="!mt-0 !rounded-none !bg-transparent"
            customStyle={{
              margin: 0,
              backgroundColor: 'transparent',
              color: 'var(--text-primary)',
              borderRadius: 0,
            }}
          >
            {code}
          </SyntaxHighlighter>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 text-[var(--text-secondary)] p-4 text-center border border-blue-200 dark:border-blue-700">
          <div className="flex items-center justify-center gap-2">
            <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span className="text-sm font-medium text-blue-700 dark:text-blue-300">🌐 معاينة HTML تلقائية - العمليات التلقائية مفعلة</span>
            <button
              onClick={() => setIsCollapsed(false)}
              className="ml-2 text-blue-600 dark:text-blue-400 hover:underline text-sm font-medium"
            >
              عرض الكود
            </button>
          </div>
        </div>
      )}
      
      {/* HTML Preview - Show when preview is enabled (auto or manual) */}
      {showPreview && (
        <div className="border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="flex items-center justify-between p-3 bg-[var(--background-tertiary)] border-b border-[var(--border-color)]">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-[var(--text-primary)]" />
              <span className="text-sm font-medium text-[var(--text-primary)]">معاينة HTML</span>
            </div>
            <button
              onClick={handleOpenInNewTab}
              className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 px-2 py-1 rounded hover:bg-[var(--background-secondary)] transition-colors"
            >
              <ExternalLink className="w-3 h-3" />
              فتح في تبويب جديد
            </button>
          </div>
          <div className="p-4">
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
              <iframe
                srcDoc={code}
                className="w-full h-64 border-0"
                title="HTML Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HTMLCodeBlock; 