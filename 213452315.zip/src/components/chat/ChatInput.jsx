
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Send, Mic, Paperclip, Image, ArrowUp,
  Paintbrush, Camera, File, ChevronDown, Globe,
  Loader2, Square, Bot, Cpu, X, FileText, Zap, Plus,
  Terminal
} from 'lucide-react';
import { getModels, chatAPI, chatUtils } from '../utils/api';

// Model Selector Component with animated glass effect
const ModelSelector = ({ 
  selectedModel, 
  onModelSelect, 
  isRTL = false,
  t 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef(null);
  const buttonRef = useRef(null);

  // Load models when component mounts
  useEffect(() => {
    loadModels();
  }, []);

  // Get default model from localStorage
  const getDefaultModel = () => {
    try {
      const defaultModel = localStorage.getItem('defaultModel');
      return defaultModel ? JSON.parse(defaultModel) : null;
    } catch (error) {
      console.error('Error parsing default model:', error);
      return null;
    }
  };

  // Auto-select default model if none selected
  useEffect(() => {
    if (!selectedModel && models.length > 0) {
      const defaultModel = getDefaultModel();
      if (defaultModel) {
        const foundModel = models.find(m => m.id === defaultModel.id);
        if (foundModel) {
          onModelSelect(foundModel);
        } else {
          // Default model not found, select first available
          onModelSelect(models[0]);
        }
      } else {
        // No default model set, select first available
        onModelSelect(models[0]);
      }
    }
  }, [models, selectedModel, onModelSelect]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        isOpen &&
        dropdownRef.current &&
        buttonRef.current &&
        !dropdownRef.current.contains(event.target) &&
        !buttonRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const loadModels = async () => {
    setLoading(true);
    try {
      const modelsData = await getModels(0, 50, null, true); // Get active models only
      setModels(modelsData);
    } catch (error) {
      console.error('Error loading models:', error);
      toast.error('فشل في تحميل النماذج');
    } finally {
      setLoading(false);
    }
  };

  const handleModelSelect = (model) => {
    onModelSelect(model);
    setIsOpen(false);
    
    // Save to session storage
    sessionStorage.setItem('selectedModel', JSON.stringify(model));
    toast.success(`تم اختيار النموذج: ${model.name}`);
  };

  const setAsDefault = (model) => {
    localStorage.setItem('defaultModel', JSON.stringify(model));
    // Also set as current selected model
    onModelSelect(model);
    toast.success(`تم تعيين ${model.name} كنموذج افتراضي`);
  };

  return (
    <div className="relative">
      {/* Model Selector Button */}
      <motion.button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className="relative rounded-full overflow-hidden border border-black dark:border-gray-300 backdrop-blur-md transition-all duration-300 group bg-white dark:bg-gray-800"
        animate={{
          width: selectedModel ? 'auto' : 48,
          paddingLeft: selectedModel ? 16 : 12,
          paddingRight: selectedModel ? 16 : 12,
          paddingTop: 12,
          paddingBottom: 12
        }}
        transition={{
          duration: 0.3,
          ease: "easeOut"
        }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        title={selectedModel 
          ? `${t('ai.currentModel')}: ${selectedModel.name} (${models.length} ${t('ai.modelsAvailable') || 'نموذج متاح'})` 
          : `${t('ai.selectModel') || 'اختيار النموذج'} (${models.length} ${t('ai.available') || 'متاح'})`
        }
      >
        {/* Lightning Icon and Model Name */}
        <div className="relative z-10 flex items-center justify-center gap-2 px-2">
          <Zap size={18} className="text-black dark:text-white" />
          
          {/* Model Name */}
          {selectedModel && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: 'auto' }}
              exit={{ opacity: 0, width: 0 }}
              className="text-black dark:text-white text-sm font-medium truncate max-w-32"
            >
              {selectedModel.name}
            </motion.span>
          )}
          
          <ChevronDown 
            size={12} 
            className={`text-black dark:text-white transition-transform duration-300 ${
              isOpen ? 'rotate-180' : ''
            }`} 
          />
        </div>
      </motion.button>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            ref={dropdownRef}
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{
              type: "spring",
              stiffness: 400,
              damping: 30,
              mass: 0.8
            }}
            className={`absolute bottom-full mb-2 ${isRTL ? 'right-0' : 'left-0'} z-50 w-60 max-h-72 overflow-hidden rounded-2xl shadow-2xl backdrop-blur-2xl bg-white dark:bg-black border border-gray-200 dark:border-gray-700`}
          >
            {/* Header */}
            <div className="relative px-4 py-3 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center shadow-md border border-gray-200 dark:border-gray-700">
                  <Zap className="h-4 w-4 text-black dark:text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-800 dark:text-white">
                    اختيار النموذج
                  </h3>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    {models.length} نموذج متاح
                  </p>
                </div>
              </div>
            </div>

            {/* Models List */}
            <div className="max-h-60 overflow-y-auto custom-scrollbar">
              {loading ? (
                <div className="flex items-center justify-center py-6">
                  <Loader2 className="w-5 h-5 animate-spin text-gray-500" />
                  <span className="ml-2 text-gray-500 text-sm">جاري التحميل...</span>
                </div>
              ) : models.length > 0 ? (
                <div className="p-3 space-y-1.5">
                  {models.map((model) => (
                    <motion.div
                      key={model.id}
                      className={`group relative p-3 rounded-xl border transition-all duration-300 cursor-pointer ${
                        selectedModel?.id === model.id
                          ? 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-600'
                          : 'bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700'
                      }`}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => handleModelSelect(model)}
                    >
                      <div className="flex items-start gap-2.5">
                        {/* Model Icon */}
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600">
                          <Cpu className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                        </div>

                        {/* Model Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <h4 className="text-sm font-semibold text-gray-800 dark:text-white truncate">
                              {model.name}
                            </h4>
                            {model.meta?.local_model && (
                              <span className="px-1.5 py-0.5 text-xs bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-md border border-green-200 dark:border-green-700">
                                محلي
                              </span>
                            )}
                          </div>
                          
                          <p className="text-xs text-gray-600 dark:text-gray-300 mb-1.5 line-clamp-1">
                            {model.meta?.description || `نموذج ${model.source_type}`}
                          </p>

                          {/* Capabilities */}
                          {model.meta?.capabilities && (
                            <div className="flex flex-wrap gap-1">
                              {model.meta.capabilities.text && (
                                <span className="px-1.5 py-0.5 text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-md">
                                  نص
                                </span>
                              )}
                              {model.meta.capabilities.vision && (
                                <span className="px-1.5 py-0.5 text-xs bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 rounded-md">
                                  رؤية
                                </span>
                              )}
                              {model.meta.capabilities.image_generation && (
                                <span className="px-1.5 py-0.5 text-xs bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-400 rounded-md">
                                  إنشاء صور
                                </span>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-1 items-end">
                          {selectedModel?.id === model.id && (
                            <motion.div 
                              className="w-2.5 h-2.5 bg-gray-600 dark:bg-gray-400 rounded-full shadow-sm"
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ duration: 2, repeat: Infinity }}
                            />
                          )}
                          
                          {/* Default model indicator */}
                          {getDefaultModel()?.id === model.id && (
                            <motion.div
                              className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 rounded-md border border-blue-200 dark:border-blue-700"
                              animate={{ 
                                boxShadow: [
                                  '0 0 3px rgba(59,130,246,0.3)',
                                  '0 0 8px rgba(59,130,246,0.6)',
                                  '0 0 3px rgba(59,130,246,0.3)'
                                ]
                              }}
                              transition={{ duration: 2, repeat: Infinity }}
                            >
                              <span className="text-xs text-blue-600 dark:text-blue-400">●</span>
                            </motion.div>
                          )}
                          
                          <motion.button
                            onClick={(e) => {
                              e.stopPropagation();
                              setAsDefault(model);
                            }}
                            className={`px-2 py-0.5 text-xs rounded-md transition-all duration-300 font-medium shadow-sm ${
                              getDefaultModel()?.id === model.id
                                ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border border-blue-300 dark:border-blue-700'
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-200 dark:hover:bg-gray-600'
                            }`}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            {getDefaultModel()?.id === model.id ? 'افتراضي' : 'تعيين افتراضي'}
                          </motion.button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-gray-500">
                  <Bot className="w-8 h-8 mb-2" />
                  <p className="text-sm">لا توجد نماذج متاحة</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Attachment Preview Component
const AttachmentPreview = ({ attachment, onRemove, isRTL }) => {
  const getFileIcon = (fileName) => {
    const extension = fileName?.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return { icon: FileText, color: 'text-red-500', bg: 'bg-red-100 dark:bg-red-900/30' };
      case 'doc':
      case 'docx':
        return { icon: FileText, color: 'text-blue-500', bg: 'bg-blue-100 dark:bg-blue-900/30' };
      case 'xls':
      case 'xlsx':
        return { icon: FileText, color: 'text-green-500', bg: 'bg-green-100 dark:bg-green-900/30' };
      case 'ppt':
      case 'pptx':
        return { icon: FileText, color: 'text-orange-500', bg: 'bg-orange-100 dark:bg-orange-900/30' };
      case 'txt':
        return { icon: FileText, color: 'text-gray-500', bg: 'bg-gray-100 dark:bg-gray-900/30' };
      default:
        return { icon: File, color: 'text-gray-500', bg: 'bg-gray-100 dark:bg-gray-900/30' };
    }
  };

  if (attachment.isImage) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="relative inline-block group"
      >
        <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          <img
            src={attachment.preview}
            alt={attachment.name}
            className="w-full h-full object-cover"
          />
          
          {/* Remove button */}
          <motion.button
            onClick={() => onRemove(attachment.id)}
            className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-colors duration-200"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="حذف المرفق"
          >
            <X size={12} />
          </motion.button>
          
          {/* File name overlay */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-1">
            <p className="text-white text-xs truncate font-medium">
              {attachment.name}
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  // File attachment
  const { icon: IconComponent, color, bg } = getFileIcon(attachment.name);
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="relative inline-block group"
    >
      <div className={`relative w-20 h-20 rounded-xl ${bg} border border-gray-200 dark:border-gray-700 flex flex-col items-center justify-center p-2`}>
        <IconComponent className={`w-6 h-6 ${color} mb-1`} />
        <p className="text-xs text-gray-600 dark:text-gray-300 truncate w-full text-center font-medium">
          {attachment.name.length > 8 ? attachment.name.substring(0, 8) + '...' : attachment.name}
        </p>
        
        {/* Remove button */}
        <motion.button
          onClick={() => onRemove(attachment.id)}
          className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-colors duration-200"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          title="حذف المرفق"
        >
          <X size={12} />
        </motion.button>
      </div>
    </motion.div>
  );
};

const ChatInput = ({
  message,
  setMessage,
  handleSendMessage,
  textareaRef,
  direction,
  textInputDir,
  isMobile,
  t,
  isSending = false,
  isGenerating = false,
  onStopGeneration,
  webSearchActive = false,
  imageGenActive = false,
  autoOperationsActive = false,
  setWebSearchActive,
  setImageGenActive,
  setAutoOperationsActive,
  selectedModel,
  onModelSelect,
  // New props for streaming
  selectedChat,
  onStreamingMessage,
  onStreamingComplete,
  onStreamingError,
  onNewConversation
}) => {
  const [attachmentsMenuOpen, setAttachmentsMenuOpen] = useState(false);
  const [imageGenExpanded, setImageGenExpanded] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const attachmentsMenuRef = useRef(null);
  const attachmentsBtnRef = useRef(null);
  const streamingAbortRef = useRef(null);

  const toggleAttachmentsMenu = () => {
    setAttachmentsMenuOpen(!attachmentsMenuOpen);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        attachmentsMenuOpen &&
        attachmentsMenuRef.current &&
        attachmentsBtnRef.current &&
        !attachmentsMenuRef.current.contains(event.target) &&
        !attachmentsBtnRef.current.contains(event.target)
      ) {
        setAttachmentsMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [attachmentsMenuOpen]);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      attachments.forEach(att => {
        if (att.preview) {
          URL.revokeObjectURL(att.preview);
        }
      });
    };
  }, []);

  // File input refs
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);

  const handleFileUpload = () => {
    fileInputRef.current?.click();
    setAttachmentsMenuOpen(false);
  };

  const handleImageUpload = () => {
    imageInputRef.current?.click();
    setAttachmentsMenuOpen(false);
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      // Create a simple camera capture interface
      const video = document.createElement('video');
      video.srcObject = stream;
      video.play();
      
      // For now, show a message that camera feature is in development
      toast.info('ميزة الكاميرا قيد التطوير');
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      toast.error('لا يمكن الوصول للكاميرا');
    }
    setAttachmentsMenuOpen(false);
  };

  // Handle file selection
  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast.error('حجم الملف كبير جداً (الحد الأقصى 10 ميجابايت)');
        return;
      }
      
      // Add file to attachments
      const fileAttachment = {
        id: Date.now(),
        name: file.name,
        size: formatFileSize(file.size),
        type: file.type,
        file: file,
        isImage: false
      };
      
      setAttachments(prev => [...prev, fileAttachment]);
      console.log('File selected:', fileAttachment);
      toast.success(`تم إرفاق الملف: ${file.name}`);
    }
    event.target.value = ''; // Reset input
  };

  // Handle image selection
  const handleImageSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Check if it's an image
      if (!file.type.startsWith('image/')) {
        toast.error('يرجى اختيار ملف صورة صحيح');
        return;
      }
      
      // Check file size (max 5MB for images)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('حجم الصورة كبير جداً (الحد الأقصى 5 ميجابايت)');
        return;
      }
      
      // Add image to attachments
      const imageAttachment = {
        id: Date.now(),
        name: file.name,
        size: formatFileSize(file.size),
        type: file.type,
        file: file,
        preview: URL.createObjectURL(file),
        isImage: true
      };
      
      setAttachments(prev => [...prev, imageAttachment]);
      console.log('Image selected:', imageAttachment);
      toast.success(`تم إرفاق الصورة: ${file.name}`);
    }
    event.target.value = ''; // Reset input
  };

  // Format file size
  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Remove attachment
  const removeAttachment = (attachmentId) => {
    setAttachments(prev => {
      const updated = prev.filter(att => att.id !== attachmentId);
      // Clean up object URLs to prevent memory leaks
      const toRemove = prev.find(att => att.id === attachmentId);
      if (toRemove && toRemove.preview) {
        URL.revokeObjectURL(toRemove.preview);
      }
      return updated;
    });
    toast.success('تم حذف المرفق');
  };

  const toggleWebSearchButton = () => {
    console.log('🔍 Toggling Web Search:', {
      currentState: webSearchActive,
      willBecome: !webSearchActive
    });
    
    // Simply toggle web search active state
    if (setWebSearchActive) {
      setWebSearchActive(!webSearchActive);
    }
    
    // Close image gen if it's open
    if (imageGenExpanded) setImageGenExpanded(false);
  };

  const toggleImageGenButton = () => {
    // Toggle the image generation active state
    if (setImageGenActive) {
      setImageGenActive(!imageGenActive);
    }
    
    // Also toggle the expanded state for visual feedback
    setImageGenExpanded(!imageGenExpanded);
    
    console.log('🎨 Toggling Image Generation:', {
      currentState: imageGenActive,
      willBecome: !imageGenActive
    });
  };

  const toggleAutoOperationsButton = () => {
    if (setAutoOperationsActive) {
      setAutoOperationsActive(!autoOperationsActive);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessageWithAttachments();
    }
  };

  // Handle sending message with attachments
  const handleSendMessageWithAttachments = async () => {
    if ((!message.trim() && attachments.length === 0) || !selectedModel || isSending) {
      return;
    }

    try {
      // If no chat is selected, create a new one first
      let currentChatId = selectedChat?.id;
      
      if (!currentChatId) {
        console.log('No chat selected, creating new chat...');
        
        // Create new chat using API
        const newChatResponse = await chatAPI.createNewChat(message.trim().substring(0, 50) || 'محادثة جديدة');
        console.log('New chat created:', newChatResponse);
        
        currentChatId = newChatResponse.id;
        
        // Update localStorage with new chat ID
        chatUtils.setCurrentChatId(currentChatId);
        
        // Notify parent component about new conversation
        if (onNewConversation) {
          onNewConversation(currentChatId);
        }
        
        // Small delay to ensure navigation is complete
        await new Promise(resolve => setTimeout(resolve, 100));
      } else {
        // Save current chat_id to localStorage
        chatUtils.setCurrentChatId(currentChatId);
      }

      // Create user message
      const userMessage = {
        role: 'user',
        content: message.trim(),
        attachments: attachments.length > 0 ? attachments : undefined
      };

      // Add user message to chat immediately
      if (onStreamingMessage) {
        onStreamingMessage(userMessage, 'user');
      }

      // Prepare messages array for API
      const messages = [
        {
          role: 'user',
          content: message.trim()
        }
      ];

      // Clear input and attachments
      setMessage('');
      attachments.forEach(att => {
        if (att.preview) {
          URL.revokeObjectURL(att.preview);
        }
      });
      setAttachments([]);

      // Send streaming request
      const response = await chatAPI.sendCompletions(messages, selectedModel.id, {
        stream: true,
        webSearch: webSearchActive,
        imageGen: imageGenActive,
        chatId: currentChatId,
        temperature: 0.7
      });

      console.log('🔍 Web Search Debug:', {
        webSearchActive,
        requestOptions: {
          webSearch: webSearchActive,
          imageGen: imageGenActive
        }
      });

      console.log('🎨 Image Generation Debug:', {
        imageGenActive,
        imageGenExpanded,
        requestWillInclude: {
          imageGen: imageGenActive
        }
      });

      // Handle streaming response
      let accumulatedContent = '';
      let assistantMessage = null;
      let messageAdded = false;
      let webSearchUrls = [];
      let imageGenData = null;
      
      // If web search is active, create the message immediately to show the search box
      if (webSearchActive && onStreamingMessage) {
        assistantMessage = {
          id: Date.now(),
          role: 'assistant',
          content: '',
          timestamp: Date.now() / 1000,
          streaming: true,
          websearch: true, // Always true when web search is active
          search_urls: [],
          search_query: message.trim()
        };
        console.log('🔍 Created initial web search message:', assistantMessage);
        onStreamingMessage(assistantMessage, 'assistant');
        messageAdded = true;
      }
      
      // If image generation is active, create the message immediately to show the generation UI
      if (imageGenActive && onStreamingMessage) {
        assistantMessage = {
          id: Date.now(),
          role: 'assistant',
          content: '',
          timestamp: Date.now() / 1000,
          streaming: true,
          image_gen: true, // Set to true immediately to show the drawing text
          image_generation_progress: null,
          generated_images: []
        };
        console.log('🎨 Created initial image generation message:', assistantMessage);
        onStreamingMessage(assistantMessage, 'assistant');
        messageAdded = true;
      }
      
      const abortStreaming = chatAPI.createStreamingReader(
        response,
        // onChunk - Enhanced for web search and image generation
        (chunk, type, metadata) => {
          console.log('📥 Received chunk:', { 
            chunkLength: chunk?.length, 
            chunkPreview: chunk?.substring(0, 50), 
            type, 
            hasMetadata: !!metadata,
            webSearchActive,
            imageGenActive,
            messageAdded
          });
          
          if (type === 'websearch_url') {
            // Handle web search URL
            webSearchUrls = metadata.urls;
            console.log('🔍 Web search URLs updated:', webSearchUrls);
            console.log('🔍 webSearchActive state:', webSearchActive);
            
            // Update existing message with URLs (message should already exist)
            if (onStreamingMessage && assistantMessage) {
              onStreamingMessage({
                ...assistantMessage,
                search_urls: webSearchUrls,
                streaming: true
              }, 'update');
            }
          } else if (type === 'websearch_complete') {
            // Web search complete, prepare for content
            console.log('🔍 Web search complete, starting content stream');
            if (onStreamingMessage && assistantMessage) {
              onStreamingMessage({
                ...assistantMessage,
                search_urls: metadata.searchUrls || webSearchUrls,
                websearch: true, // Keep websearch true
                streaming: true
              }, 'update');
            }
          } else if (type === 'image_generation' || type === 'image_gen') {
            // Handle image generation data
            console.log('🎨 Image generation data received:', metadata);
            imageGenData = metadata;
            
            // Update existing message with image generation data
            if (onStreamingMessage && assistantMessage) {
              const updatedMessage = {
                ...assistantMessage,
                streaming: true
              };
              
              // Add image generation progress if available
              if (metadata.image_generation_progress) {
                updatedMessage.image_generation_progress = metadata.image_generation_progress;
              }
              
              // Add generated images if available
              if (metadata.generated_images) {
                updatedMessage.generated_images = metadata.generated_images;
              }
              
              // Set image_gen flag
              if (metadata.image_gen !== undefined) {
                updatedMessage.image_gen = metadata.image_gen;
              }
              
              console.log('🎨 Updating message with image generation data:', updatedMessage);
              onStreamingMessage(updatedMessage, 'update');
            }
          } else if (type === 'content' || !type) {
            // Regular content streaming (type can be undefined for backward compatibility)
            accumulatedContent += chunk;
            
            // Create message on first content chunk if not created yet (for non-web-search and non-image-gen)
            if (!messageAdded && onStreamingMessage) {
              assistantMessage = {
                id: Date.now(),
                role: 'assistant',
                content: accumulatedContent,
                timestamp: Date.now() / 1000,
                streaming: true,
                // Set websearch based on whether we have URLs from web search
                websearch: webSearchUrls.length > 0,
                search_urls: webSearchUrls.length > 0 ? webSearchUrls : undefined,
                search_query: webSearchUrls.length > 0 ? message.trim() : undefined,
                // Set image generation data if available
                image_gen: imageGenData?.image_gen !== undefined ? imageGenData.image_gen : (imageGenActive ? true : undefined),
                image_generation_progress: imageGenData?.image_generation_progress || null,
                generated_images: imageGenData?.generated_images || []
              };
              onStreamingMessage(assistantMessage, 'assistant');
              messageAdded = true;
            } else if (onStreamingMessage && assistantMessage) {
              // Update message with new content, preserve websearch and image gen state
              const updatedMessage = {
                ...assistantMessage,
                content: accumulatedContent,
                streaming: true
              };
              
              // Preserve image generation data if it exists
              if (imageGenData) {
                if (imageGenData.image_gen !== undefined) {
                  updatedMessage.image_gen = imageGenData.image_gen;
                }
                if (imageGenData.image_generation_progress) {
                  updatedMessage.image_generation_progress = imageGenData.image_generation_progress;
                }
                if (imageGenData.generated_images) {
                  updatedMessage.generated_images = imageGenData.generated_images;
                }
              }
              
              onStreamingMessage(updatedMessage, 'update');
            }
          }
        },
        // onComplete
        (metadata) => {
          streamingAbortRef.current = null;
          console.log('🔍 Stream completed with metadata:', metadata);
          console.log('🔍 Final webSearchUrls:', webSearchUrls);
          console.log('🎨 Final imageGenData:', imageGenData);
          console.log('🔍 Final accumulatedContent length:', accumulatedContent.length);
          
          if (onStreamingComplete && assistantMessage) {
            const finalMessage = {
              ...assistantMessage,
              content: accumulatedContent,
              streaming: false,
              // Keep websearch true if we have URLs
              websearch: webSearchUrls.length > 0,
              search_urls: webSearchUrls.length > 0 ? webSearchUrls : undefined,
              search_query: webSearchUrls.length > 0 ? message.trim() : undefined
            };
            
            // Add final image generation data if available
            if (imageGenData) {
              if (imageGenData.image_gen !== undefined) {
                finalMessage.image_gen = imageGenData.image_gen;
              }
              if (imageGenData.image_generation_progress) {
                finalMessage.image_generation_progress = imageGenData.image_generation_progress;
              }
              if (imageGenData.generated_images) {
                finalMessage.generated_images = imageGenData.generated_images;
              }
            }
            
            console.log('🔍 Final message:', finalMessage);
            onStreamingComplete(finalMessage);
          }
        },
        // onError
        (error) => {
          streamingAbortRef.current = null;
          console.error('Streaming error:', error);
          if (onStreamingError) {
            onStreamingError(error);
          }
          toast.error('حدث خطأ أثناء إرسال الرسالة');
        }
      );

      // Store abort function for potential cancellation
      streamingAbortRef.current = abortStreaming;

    } catch (error) {
      console.error('Send message error:', error);
      if (onStreamingError) {
        onStreamingError(error);
      }
      toast.error('فشل في إرسال الرسالة');
    }
  };

  // Handle stopping streaming
  const handleStopStreaming = () => {
    if (streamingAbortRef.current) {
      streamingAbortRef.current();
      streamingAbortRef.current = null;
      if (onStopGeneration) {
        onStopGeneration();
      }
      toast.info('تم إيقاف التوليد');
    }
  };

  // Handle starting new conversation
  const handleNewConversation = () => {
    // Generate new chat_id
    const newChatId = chatUtils.generateChatId();
    
    // Clear current messages if callback provided
    if (onStreamingMessage) {
      onStreamingMessage(null, 'clear');
    }
    
    // Notify parent component about new conversation
    if (onNewConversation) {
      onNewConversation(newChatId);
    }
    
    // Clear input
    setMessage('');
    
    // Clear attachments
    attachments.forEach(att => {
      if (att.preview) {
        URL.revokeObjectURL(att.preview);
      }
    });
    setAttachments([]);
    
    toast.success('بدأت محادثة جديدة');
  };

  return (
    <div className="w-full max-w-3xl relative">
      <div
        className="
          backdrop-blur-xl
          bg-transparent
          border border-gray-200/60 dark:border-gray-700/60
          rounded-3xl
          shadow-lg shadow-gray-200/50 dark:shadow-black/30
          flex flex-col
          px-4 sm:px-5 pt-3 pb-2.5 sm:pb-3
          transition-all duration-300
          hover:bg-white/10 dark:hover:bg-gray-900/10
          hover:shadow-xl hover:shadow-gray-200/60 dark:hover:shadow-black/40
          focus-within:border-gray-400/70 dark:focus-within:border-gray-500/70
          focus-within:ring-4 focus-within:ring-gray-400/20 dark:focus-within:ring-gray-500/30
        "
      >
        {/* Attachments Preview */}
        <AnimatePresence>
          {attachments.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex flex-wrap gap-2 mb-3 p-2"
            >
              {attachments.map((attachment) => (
                <AttachmentPreview
                  key={attachment.id}
                  attachment={attachment}
                  onRemove={removeAttachment}
                  isRTL={direction === 'rtl'}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Web Search Status Indicator */}
        <AnimatePresence>
          {webSearchActive && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2 mb-3 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700"
            >
              <div className="p-1 bg-blue-100 dark:bg-blue-800 rounded-full">
                <Globe className="w-3 h-3 text-blue-600 dark:text-blue-400" />
              </div>
              <span className="text-xs text-blue-700 dark:text-blue-300 font-medium">
                {direction === 'rtl' 
                  ? 'البحث عبر الويب مفعل - سيتم البحث في الإنترنت للحصول على معلومات حديثة'
                  : 'Web Search is active - will search the internet for up-to-date information'
                }
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Text Area */}
        <div className="relative">
          <textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={direction === 'rtl' ? "اسألني عن أي شيء" : "Ask me anything"}
            dir={textInputDir}
            className={`
              w-full
              bg-transparent
              border-none
              focus:ring-0
              resize-none
              outline-none
              px-0 py-1.5
              mb-2 sm:mb-2.5
              min-h-[27px] sm:min-h-[31px]
              max-h-[63px] sm:max-h-[81px]
              overflow-y-auto
              text-gray-900 dark:text-white
              placeholder:text-gray-500/80 dark:placeholder:text-gray-400/80
              text-sm sm:text-base
              leading-snug
              ${direction === 'rtl' ? 'text-right placeholder:text-right' : ''}
            `}
            rows={isMobile ? 1 : 1}
          />
          
          {/* Character/Word count */}
          {message.trim() && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute bottom-0 left-0 text-xs text-gray-400 dark:text-gray-500"
            >
              {message.trim().split(' ').length} {direction === 'rtl' ? 'كلمة' : 'words'}
            </motion.div>
          )}
        </div>

        {/* Divider Line */}
        <div className="w-full h-px bg-gray-300/60 dark:bg-gray-600/60 mb-2.5 transition-colors duration-200"></div>

        {/* Buttons Row */}
        <div className="flex items-center justify-between">
          {/* Left Side Buttons */}
          <div className="flex space-x-1.5 rtl:space-x-reverse sm:space-x-2.5 sm:rtl:space-x-reverse">
            {/* Attachment Button with Dropdown */}
            <div className="relative">
              <button
                ref={attachmentsBtnRef}
                className={`
                  relative p-2 sm:p-2.5
                  rounded-full
                  flex items-center
                  transition-all duration-200
                  ${attachmentsMenuOpen || attachments.length > 0
                    ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 shadow-md'
                    : 'text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white hover:bg-gray-100/80 dark:hover:bg-gray-800/80'}
                `}
                onClick={toggleAttachmentsMenu}
              >
                <Paperclip size={16} />
                <ChevronDown size={12} className={`ml-0.5 transition-transform duration-300 ${attachmentsMenuOpen ? 'rotate-180' : ''}`} />
                
                {/* Attachments count badge */}
                {attachments.length > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 text-white text-xs rounded-full flex items-center justify-center font-bold shadow-lg"
                  >
                    {attachments.length}
                  </motion.div>
                )}
              </button>

              {/* Enhanced Attachments Dropdown Menu */}
              <AnimatePresence>
                {attachmentsMenuOpen && (
                  <motion.div
                    ref={attachmentsMenuRef}
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    transition={{
                      type: "spring",
                      stiffness: 400,
                      damping: 30,
                      mass: 0.8
                    }}
                    className="absolute bottom-full mb-2 left-0 rtl:left-auto rtl:right-0 z-50 w-60 overflow-hidden rounded-2xl shadow-2xl backdrop-blur-2xl bg-white dark:bg-black border border-gray-200 dark:border-gray-700"
                  >
                    {/* Header */}
                    <div className="relative px-4 py-3 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900 flex items-center justify-center shadow-md border border-blue-200 dark:border-blue-700">
                          <Paperclip className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-gray-800 dark:text-white">
                            إرفاق ملفات
                          </h3>
                          <p className="text-xs text-gray-600 dark:text-gray-300">
                            اختر نوع المرفق المطلوب
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Options Grid */}
                    <div className="p-3 space-y-1.5">
                      {/* Upload File */}
                      <button
                        onClick={handleFileUpload}
                        className="w-full group flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
                      >
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
                          <File className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 text-right">
                          <h4 className="text-sm font-semibold text-gray-800 dark:text-white">
                            رفع ملف
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-300">
                            PDF, DOC, TXT, Excel وأكثر
                          </p>
                          <p className="text-xs text-green-600 dark:text-green-400 font-medium">
                            حتى 10 ميجابايت
                          </p>
                        </div>
                      </button>

                      {/* Upload Image */}
                      <button
                        onClick={handleImageUpload}
                        className="w-full group flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
                      >
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
                          <Image className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 text-right">
                          <h4 className="text-sm font-semibold text-gray-800 dark:text-white">
                            رفع صورة
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-300">
                            JPG, PNG, GIF, WebP
                          </p>
                          <p className="text-xs text-purple-600 dark:text-purple-400 font-medium">
                            حتى 5 ميجابايت
                          </p>
                        </div>
                      </button>

                      {/* Camera Capture */}
                      <button
                        onClick={handleCameraCapture}
                        className="w-full group flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-md hover:scale-[1.01]"
                      >
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
                          <Camera className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 text-right">
                          <h4 className="text-sm font-semibold text-gray-800 dark:text-white">
                            التقاط صورة
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-300">
                            استخدم كاميرا الجهاز
                          </p>
                          <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                            قيد التطوير
                          </p>
                        </div>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Web Search Button */}
            <motion.button
              className={`
                p-0
                rounded-full
                overflow-hidden
                flex items-center justify-center
                transition-all duration-300
                relative
                ${webSearchActive
                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-700 shadow-md'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50'
                }
              `}
              title={webSearchActive ? "إلغاء بحث الويب (مفعل)" : "تفعيل بحث الويب"}
              onClick={toggleWebSearchButton}
              animate={{
                width: !isMobile && webSearchActive ? (direction === 'rtl' ? 140 : 150) : (isMobile ? 36 : 40),
              }}
              transition={{
                duration: 0.2,
                ease: "easeOut"
              }}
            >
              {/* Active indicator */}
              {webSearchActive && (
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white dark:border-gray-800"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                />
              )}
              
              <div className={`
                flex items-center justify-center
                ${!webSearchActive || isMobile ? 'w-full px-2' : 'pl-3 pr-1'}
              `}>
                <Globe
                  size={isMobile ? 18 : 20}
                  className={`
                    transition-colors duration-200
                    ${webSearchActive
                      ? 'text-blue-600 dark:text-blue-400'
                      : 'text-gray-600 dark:text-gray-300'
                    }
                  `}
                />
              </div>

              <AnimatePresence>
                {!isMobile && webSearchActive && (
                  <motion.span
                    className="text-sm whitespace-nowrap font-medium text-blue-600 dark:text-blue-400 pr-3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                                   {t ? t('chat.webSearch') : (direction === 'rtl' ? "بحث الويب" : "Web Search")}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>

            {/* Image Gen Button */}
            <motion.button
              className={`
                p-0
                rounded-full
                overflow-hidden
                flex items-center justify-center
                transition-all duration-300
                ${imageGenActive
                  ? 'bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-700 shadow-md'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50'
                }
              `}
              title={imageGenActive ? (t ? t('chat.imageGeneration') + ' (مفعل)' : 'إنشاء صورة (مفعل)') : (t ? t('chat.imageGeneration') : 'إنشاء صورة')}
              onClick={toggleImageGenButton}
              animate={{
                width: !isMobile && imageGenActive ? (direction === 'rtl' ? 140 : 150) : (isMobile ? 36 : 40),
              }}
              transition={{
                duration: 0.2,
                ease: "easeOut"
              }}
            >
              {/* Active indicator */}
              {imageGenActive && (
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-purple-500 rounded-full border-2 border-white dark:border-gray-800"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                />
              )}
              <div className={`
                flex items-center justify-center
                ${!imageGenActive || isMobile ? 'w-full px-2' : 'pl-3 pr-1'}
              `}>
                <Paintbrush
                  size={isMobile ? 18 : 20}
                  className={`
                    transition-colors duration-200
                    ${imageGenActive
                      ? 'text-purple-600 dark:text-purple-400'
                      : 'text-gray-600 dark:text-gray-300'
                    }
                  `}
                />
              </div>

              <AnimatePresence>
                {!isMobile && imageGenActive && (
                  <motion.span
                    className="text-sm whitespace-nowrap font-medium text-purple-600 dark:text-purple-400 pr-3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    {direction === 'rtl' ? "إنشاء صورة" : "Create Image"}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>

            {/* Auto Operations Button */}
            <motion.button
              className={`
                p-0
                rounded-full
                overflow-hidden
                flex items-center justify-center
                transition-all duration-300
                relative
                ${autoOperationsActive
                  ? 'bg-orange-50 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 border border-orange-200 dark:border-orange-700 shadow-md'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50'
                }
              `}
              title={autoOperationsActive ? (t ? t('chat.autoOperations') + ' (مفعل)' : 'العمليات التلقائية (مفعل)') : (t ? t('chat.autoOperations') : 'العمليات التلقائية')}
              onClick={toggleAutoOperationsButton}
              animate={{
                width: !isMobile && autoOperationsActive ? (direction === 'rtl' ? 160 : 170) : (isMobile ? 36 : 40),
              }}
              transition={{
                duration: 0.2,
                ease: "easeOut"
              }}
            >
              {/* Active indicator */}
              {autoOperationsActive && (
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-orange-500 rounded-full border-2 border-white dark:border-gray-800"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                />
              )}
              
              <div className={`
                flex items-center justify-center
                ${!autoOperationsActive || isMobile ? 'w-full px-2' : 'pl-3 pr-1'}
              `}>
                <Terminal
                  size={isMobile ? 18 : 20}
                  className={`
                    transition-colors duration-200
                    ${autoOperationsActive
                      ? 'text-orange-600 dark:text-orange-400'
                      : 'text-gray-600 dark:text-gray-300'
                    }
                  `}
                />
              </div>

              <AnimatePresence>
                {!isMobile && autoOperationsActive && (
                  <motion.span
                    className="text-sm whitespace-nowrap font-medium text-orange-600 dark:text-orange-400 pr-3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    {t ? t('chat.autoOperations') : 'العمليات التلقائية'}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          </div>

          {/* Right Side - Model Selector and Send Button */}
          <div className="flex items-center gap-2">
            {/* Model Selector */}
            <ModelSelector
              selectedModel={selectedModel}
              onModelSelect={onModelSelect}
              isRTL={direction === 'rtl'}
              t={t}
            />

            {/* Send Button or Stop Button */}
            {(isGenerating || streamingAbortRef.current) ? (
              <button
                onClick={handleStopStreaming}
                className="p-2.5 sm:p-3 rounded-full bg-gradient-to-r from-red-500 to-red-600 dark:from-red-600 dark:to-red-700 text-white shadow-lg shadow-red-500/30 dark:shadow-red-700/30 transition-all duration-200 flex items-center justify-center transform-gpu scale-105"
                title="إيقاف التوليد"
                disabled={!isGenerating && !streamingAbortRef.current}
              >
                <Square size={isMobile ? 16 : 18} className="text-white" />
              </button>
            ) : (
              <button
                onClick={handleSendMessageWithAttachments}
                disabled={(!message.trim() && attachments.length === 0) || isSending || streamingAbortRef.current}
                className={`p-2.5 sm:p-3 rounded-full flex items-center justify-center transition-all duration-300 ${
                  (message.trim() || attachments.length > 0) && !streamingAbortRef.current
                    ? 'bg-gradient-to-r from-gray-800 to-black dark:from-gray-700 dark:to-gray-900 shadow-lg shadow-gray-800/30 dark:shadow-black/30 scale-105 transform-gpu'
                    : 'bg-gray-200 dark:bg-gray-700 border border-gray-300 dark:border-gray-600'
                }`}
                title="إرسال"
                aria-label="إرسال"
              >
                {isSending || streamingAbortRef.current ? (
                  <Loader2 size={isMobile ? 18 : 20} className="animate-spin text-white dark:text-white" />
                ) : (
                  <ArrowUp
                    size={isMobile ? 18 : 20}
                    strokeWidth={2.5}
                    className={(message.trim() || attachments.length > 0) && !streamingAbortRef.current ? 'text-white dark:text-white' : 'text-gray-500 dark:text-gray-400'}
                  />
                )}
              </button>
            )}
          </div>
        </div>
      </div>
      
      {/* Hidden file inputs */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".pdf,.doc,.docx,.txt,.rtf,.odt,.xls,.xlsx,.ppt,.pptx"
        style={{ display: 'none' }}
      />
      <input
        type="file"
        ref={imageInputRef}
        onChange={handleImageSelect}
        accept="image/*"
        style={{ display: 'none' }}
      />
    </div>
  );
};

export default ChatInput;
