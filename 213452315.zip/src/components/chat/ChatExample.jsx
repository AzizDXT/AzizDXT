import React, { useState, useRef, useEffect } from 'react';
import { toast } from 'sonner';
import ChatInput from './ChatInput';
import ChatContent from './ChatContent';
import { chatUtils } from '../utils/api';

const ChatExample = () => {
  const [messages, setMessages] = useState([]);
  const [selectedModel, setSelectedModel] = useState(null);
  const [selectedChat, setSelectedChat] = useState(null); // Will be set dynamically
  const [webSearchActive, setWebSearchActive] = useState(false);
  const [imageGenActive, setImageGenActive] = useState(false);
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const textareaRef = useRef(null);

  // Initialize chat on component mount
  useEffect(() => {
    const currentChatId = chatUtils.getCurrentChatId();
    setSelectedChat({ id: currentChatId });
    console.log('Initialized chat with ID:', currentChatId);
  }, []);

  // Handle streaming message updates
  const handleStreamingMessage = (messageData, type) => {
    if (type === 'user') {
      // Add user message immediately
      const userMsg = {
        ...messageData,
        id: Date.now(),
        timestamp: Date.now() / 1000
      };
      setMessages(prev => [...prev, userMsg]);
      setIsSending(true);
    } else if (type === 'assistant') {
      // Add assistant message placeholder
      setMessages(prev => [...prev, messageData]);
      setIsSending(false);
      setIsGenerating(true);
    } else if (type === 'update') {
      // Update streaming assistant message
      setMessages(prev => 
        prev.map(msg => 
          msg.id === messageData.id ? messageData : msg
        )
      );
    } else if (type === 'clear') {
      // Clear messages for new conversation
      setMessages([]);
      setIsSending(false);
      setIsGenerating(false);
    }
  };

  // Handle streaming completion
  const handleStreamingComplete = (finalMessage) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === finalMessage.id ? finalMessage : msg
      )
    );
    setIsGenerating(false);
    
    // Play notification sound (optional)
    try {
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBzaH0fPTgjMGHm7A7+OZURE');
      audio.volume = 0.3;
      audio.play().catch(() => {}); // Ignore errors if audio fails
    } catch (error) {
      // Ignore audio errors
    }
    
    toast.success('تم إكمال الرد');
  };

  // Handle streaming errors
  const handleStreamingError = (error) => {
    setIsSending(false);
    setIsGenerating(false);
    console.error('Streaming error:', error);
    toast.error('حدث خطأ في الاتصال');
  };

  // Handle stopping generation
  const handleStopGeneration = () => {
    setIsGenerating(false);
    toast.info('تم إيقاف التوليد');
  };

  // Handle new conversation
  const handleNewConversation = (newChatId) => {
    setSelectedChat({ id: newChatId });
    console.log('Started new conversation with ID:', newChatId);
  };

  // Legacy handleSendMessage for compatibility (not used with new streaming)
  const handleSendMessage = (attachments) => {
    console.log('Legacy send message called with attachments:', attachments);
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--background)]">
      {/* Chat Content */}
      <div className="flex-1 overflow-hidden">
        <ChatContent
          selectedChat={selectedChat}
          messages={messages}
          chatLoading={false}
          getFileDownloadUrl={(fileId) => `https://api.taleb.run/api/v1/storage/files/${fileId}/download`}
          handleImageRegenerate={(imageId) => console.log('Regenerate image:', imageId)}
          handleImageEdit={(imageId) => console.log('Edit image:', imageId)}
          handleImageInfo={(imageId) => console.log('Image info:', imageId)}
          handleImageCopy={(imageId) => console.log('Copy image:', imageId)}
          handleFileDownload={(fileId, fileName) => console.log('Download file:', fileId, fileName)}
          onEditMessage={(message) => console.log('Edit message:', message)}
          t={(key) => key} // Simple translation function
        />
      </div>

      {/* Chat Input */}
      <div className="p-4 border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
        <div className="max-w-4xl mx-auto">
          <ChatInput
            message={message}
            setMessage={setMessage}
            handleSendMessage={handleSendMessage}
            textareaRef={textareaRef}
            direction="rtl"
            textInputDir="auto"
            isMobile={false}
            t={(key) => key} // Simple translation function
            isSending={isSending}
            isGenerating={isGenerating}
            onStopGeneration={handleStopGeneration}
            webSearchActive={webSearchActive}
            imageGenActive={imageGenActive}
            setWebSearchActive={setWebSearchActive}
            setImageGenActive={setImageGenActive}
            selectedModel={selectedModel}
            onModelSelect={setSelectedModel}
            // New streaming props
            selectedChat={selectedChat}
            onStreamingMessage={handleStreamingMessage}
            onStreamingComplete={handleStreamingComplete}
            onStreamingError={handleStreamingError}
            onNewConversation={handleNewConversation}
          />
        </div>
      </div>
    </div>
  );
};

export default ChatExample; 