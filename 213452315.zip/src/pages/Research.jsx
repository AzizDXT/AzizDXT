
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Search,
  Loader2,
  CheckCircle,
  AlertCircle,
  FileText,
  Eye,
  Home,
  ChevronRight,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';

const mockAPI = {
  getResearchHistory: () => Promise.resolve([
    {
      id: 1,
      topic: 'AI applications in Cybersecurity',
      status: 'completed',
      created_at: new Date(Date.now() - 86400000).toISOString(),
      results: { summary: 'AI is pivotal in threat detection, using machine learning to identify anomalies...', detailed: 'This is a much more detailed summary of AI applications in cybersecurity, covering various subfields like network intrusion detection, malware analysis, and secure coding practices. Machine learning models such as neural networks, support vector machines, and decision trees are employed to analyze vast amounts of data, detect sophisticated threats, and predict potential vulnerabilities. The integration of AI enhances the efficiency and accuracy of security operations, moving from reactive responses to proactive threat intelligence. Furthermore, AI contributes to automated incident response and forensics, significantly reducing the time to detect and mitigate attacks.' }
    },
    {
      id: 2,
      topic: 'Quantum Computing resistance algorithms',
      status: 'in_progress',
      created_at: new Date().toISOString(),
      results: null
    },
    {
      id: 3,
      topic: 'Impact of AI on creative industries',
      status: 'completed',
      created_at: new Date(Date.now() - 2 * 86400000).toISOString(),
      results: { summary: 'AI is transforming creative industries by automating repetitive tasks, assisting with content generation, and enabling new forms of artistic expression...', detailed: 'The impact of AI on creative industries, including music, visual arts, literature, and film, is multifaceted. AI tools can assist artists in generating new ideas, automating tedious tasks like color correction or audio mastering, and even creating entire pieces of art, music, or text. This raises questions about intellectual property, originality, and the future role of human creators. While some fear job displacement, others see AI as a powerful collaborative tool that can unlock new creative possibilities and democratize access to sophisticated production techniques. The debate continues on how to best integrate AI while preserving the unique human element in creativity.' }
    },
    {
      id: 4,
      topic: 'Renewable energy storage solutions',
      status: 'failed',
      created_at: new Date(Date.now() - 3 * 86400000).toISOString(),
      results: null
    },
  ]),
  startResearch: (topic) => {
    console.log(`Starting research for: ${topic}`);
    return new Promise(resolve => setTimeout(() => {
      // Simulate success or failure
      const success = Math.random() > 0.1; // 90% success rate
      resolve({ success: success, message: success ? 'Research started successfully.' : 'Failed to start research.' });
    }, 2000));
  }
};

export default function Research() {
  const { t } = useI18n();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [researchHistory, setResearchHistory] = useState([]);
  const [newResearchTopic, setNewResearchTopic] = useState('');
  const [isResearching, setIsResearching] = useState(false);
  const [viewingResults, setViewingResults] = useState(null);
  const [researchStatusMessage, setResearchStatusMessage] = useState('');
  const [researchStatusType, setResearchStatusType] = useState(''); // 'success', 'error'


  useEffect(() => {
    mockAPI.getResearchHistory().then(data => {
      setResearchHistory(data);
      setLoading(false);
    });
  }, []);

  const handleStartResearch = async () => {
    if (!newResearchTopic.trim()) {
      setResearchStatusMessage(t('research.enterTopic'));
      setResearchStatusType('error');
      return;
    }

    setIsResearching(true);
    setResearchStatusMessage('');
    setResearchStatusType('');
    
    try {
      const result = await mockAPI.startResearch(newResearchTopic.trim());
      if (result.success) {
        setResearchStatusMessage(t('research.startedSuccessfully'));
        setResearchStatusType('success');
        const updatedHistory = await mockAPI.getResearchHistory();
        setResearchHistory(updatedHistory);
      } else {
        setResearchStatusMessage(result.message || t('research.startFailed'));
        setResearchStatusType('error');
      }
    } catch (error) {
      setResearchStatusMessage(t('research.errorStarting') + `: ${error.message}`);
      setResearchStatusType('error');
    } finally {
      setNewResearchTopic('');
      setIsResearching(false);
    }
  };

  const handleViewResults = (item) => {
    setViewingResults(item);
  };

  const handleBackToResearchList = () => {
    setViewingResults(null);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'in_progress':
        return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return null;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="w-8 h-8 animate-spin text-[var(--accent-color)]" />
      </div>
    );
  }

  if (viewingResults) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
          <button 
            onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
            className="hover:text-[var(--text-primary)] transition-colors flex items-center gap-1"
          >
            <Home className="w-4 h-4" />
            {t('breadcrumb.library')}
          </button>
          <ChevronRight className="w-4 h-4" />
          <button 
            onClick={handleBackToResearchList}
            className="hover:text-[var(--text-primary)] transition-colors"
          >
            {t('breadcrumb.research')}
          </button>
          <ChevronRight className="w-4 h-4" />
          <span className="text-[var(--text-primary)]">{viewingResults.topic}</span>
        </div>

        <h1 className="text-3xl font-bold text-[var(--text-primary)]">{viewingResults.topic}</h1>
        <p className="text-[var(--text-secondary)]">
          {t('research.status')}: <span className="font-semibold">{t(`research.status.${viewingResults.status}`)}</span>
        </p>

        {viewingResults.results?.detailed ? (
          <Card className="bg-[var(--card-bg)] border-[var(--border-color)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">{t('research.results')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-[var(--text-secondary)]">
              <p>{viewingResults.results.detailed}</p>
            </CardContent>
          </Card>
        ) : (
          <p className="text-[var(--text-secondary)]">{t('research.noDetailedResults')}</p>
        )}
        
        <Button onClick={handleBackToResearchList} variant="outline" className="bg-[var(--button-secondary-bg)] text-[var(--button-secondary-text)] hover:bg-[var(--button-secondary-hover-bg)] border-[var(--button-secondary-border)]">
          {t('research.backToList')}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
       {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <button 
          onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
          className="hover:text-[var(--text-primary)] transition-colors flex items-center gap-1"
        >
          <Home className="w-4 h-4" />
          {t('breadcrumb.library')}
        </button>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[var(--text-primary)]">{t('breadcrumb.research')}</span>
      </div>

      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--text-primary)]">{t('research.title')}</h1>
        <p className="text-[var(--text-secondary)]">{t('research.description')}</p>
      </div>

      <Card className="bg-[var(--card-bg)] border-[var(--border-color)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)]">{t('research.newResearch')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder={t('research.placeholder')}
              value={newResearchTopic}
              onChange={(e) => setNewResearchTopic(e.target.value)}
              className="flex-grow bg-[var(--input-bg)] text-[var(--text-primary)] border-[var(--input-border)] placeholder-[var(--input-placeholder)] focus-visible:ring-[var(--accent-color)]"
              disabled={isResearching}
            />
            <Button onClick={handleStartResearch} disabled={isResearching} className="bg-[var(--accent-color)] text-white hover:bg-[var(--accent-hover-color)]">
              {isResearching ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Search className="mr-2 h-4 w-4" />
              )}
              {isResearching ? t('research.researching') : t('research.start')}
            </Button>
          </div>
          {researchStatusMessage && (
            <div className={`mt-2 text-sm flex items-center ${researchStatusType === 'success' ? 'text-green-500' : 'text-red-500'}`}>
              {researchStatusType === 'success' ? <CheckCircle className="mr-1 h-4 w-4" /> : <AlertCircle className="mr-1 h-4 w-4" />}
              {researchStatusMessage}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-[var(--card-bg)] border-[var(--border-color)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)]">{t('research.history')}</CardTitle>
        </CardHeader>
        <CardContent>
          {researchHistory.length === 0 ? (
            <p className="text-[var(--text-secondary)]">{t('research.noHistory')}</p>
          ) : (
            <div className="space-y-4">
              {researchHistory.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border border-[var(--border-color)] bg-[var(--card-inner-bg)]">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(item.status)}
                    <div>
                      <p className="font-semibold text-[var(--text-primary)]">{item.topic}</p>
                      <p className="text-sm text-[var(--text-secondary)]">
                        {t('research.started')}: {formatDate(item.created_at)}
                      </p>
                      {item.status === 'completed' && item.results?.summary && (
                        <p className="text-sm text-[var(--text-secondary)] line-clamp-1">
                          {t('research.summary')}: {item.results.summary}
                        </p>
                      )}
                    </div>
                  </div>
                  {item.status === 'completed' && item.results ? (
                    <Button 
                      onClick={() => handleViewResults(item)} 
                      variant="outline" 
                      size="sm" 
                      className="bg-[var(--button-secondary-bg)] text-[var(--button-secondary-text)] hover:bg-[var(--button-secondary-hover-bg)] border-[var(--button-secondary-border)]"
                    >
                      <Eye className="mr-2 h-4 w-4" />
                      {t('research.viewResults')}
                    </Button>
                  ) : (
                    <span className="text-sm text-[var(--text-secondary)]">
                      {t(`research.status.${item.status}`)}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
