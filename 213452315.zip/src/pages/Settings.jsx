import React from 'react';
import Settings from '../components/dashboard/Settings';

export default function SettingsPage() {
  return <Settings />;
} 