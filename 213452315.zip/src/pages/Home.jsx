import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  Flame, 
  Star, 
  TrendingUp, 
  BookOpen, 
  Users, 
  Zap,
  Heart,
  MessageCircle,
  Share2,
  Plus,
  Play,
  Clock,
  Target,
  FileText,
  CheckSquare,
  Search,
  FileDown,
  Brain,
  Lightbulb,
  BookMarked,
  Calendar,
  BarChart3,
  CheckCircle,
  Circle
} from 'lucide-react';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import StoryRing from '../components/StoryRing';
import StoriesViewer from '../components/StoriesViewer';
import StoryCreator from '../components/StoryCreator';
import { StatsSkeleton, StoriesSkeleton, ChallengesSkeleton, PostsSkeleton, ComingSoon, ComingSoonAR } from '../components/LoadingSkeleton';
import api, { storiesAPI } from '../components/utils/api';

export default function Home() {
  const { t, isRTL, language } = useI18n();
  const { theme } = useTheme();
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [currentPostIndex, setCurrentPostIndex] = useState(0);
  const [dailyProgress, setDailyProgress] = useState(0);
  const [streak, setStreak] = useState(0);
  const [totalPoints, setTotalPoints] = useState(0);
  const [level, setLevel] = useState(0);
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [showStoriesViewer, setShowStoriesViewer] = useState(false);
  const [viewedStories, setViewedStories] = useState([]);
  const [myStories, setMyStories] = useState([]);
  const [allStories, setAllStories] = useState([]);
  const [showStoryCreator, setShowStoryCreator] = useState(false);
  
  // New state for user data and daily tasks
  const [userProfile, setUserProfile] = useState(null);
  const [dailyTasks, setDailyTasks] = useState(null);
  const [isLoadingTasks, setIsLoadingTasks] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  const postIntervalRef = useRef(null);
  const storyIntervalRef = useRef(null);
  const tasksIntervalRef = useRef(null);

  // Real data will be loaded from API
  const [stories, setStories] = useState([]);
  const [posts, setPosts] = useState([]);
  const [isLoadingStories, setIsLoadingStories] = useState(true);
  const [isLoadingPosts, setIsLoadingPosts] = useState(true);

  // Daily challenges will be loaded from API

  // Quick actions with new features
  const quickActions = [
    {
      id: 'ai',
      title: t('home.aiAssistant'),
      description: t('home.aiAssistantDesc'),
      icon: <Zap className="w-8 h-8" />,
      color: 'from-blue-500 to-blue-600',
      action: () => console.log('AI Assistant clicked')
    },
    {
      id: 'library',
      title: t('home.library'),
      description: t('home.libraryDesc'),
      icon: <BookOpen className="w-8 h-8" />,
      color: 'from-purple-500 to-purple-600',
      action: () => console.log('Library clicked')
    },
    {
      id: 'communities',
      title: t('home.communities'),
      description: t('home.communitiesDesc'),
      icon: <Users className="w-8 h-8" />,
      color: 'from-green-500 to-green-600',
      action: () => console.log('Communities clicked')
    },
    {
      id: 'notes',
      title: t('home.notes'),
      description: t('home.notesDesc'),
      icon: <FileText className="w-8 h-8" />,
      color: 'from-orange-500 to-orange-600',
      action: () => console.log('Notes clicked')
    },
    {
      id: 'tasks',
      title: t('home.tasks'),
      description: t('home.tasksDesc'),
      icon: <CheckSquare className="w-8 h-8" />,
      color: 'from-red-500 to-red-600',
      action: () => console.log('Tasks clicked')
    },
    {
      id: 'research',
      title: t('home.research'),
      description: t('home.researchDesc'),
      icon: <Search className="w-8 h-8" />,
      color: 'from-indigo-500 to-indigo-600',
      action: () => console.log('Research clicked')
    },
    {
      id: 'summarize',
      title: t('home.summarize'),
      description: t('home.summarizeDesc'),
      icon: <Brain className="w-8 h-8" />,
      color: 'from-pink-500 to-pink-600',
      action: () => console.log('Summarize clicked')
    }
  ];

  // Calculate post display duration based on content length
  const getPostDuration = (content) => {
    const baseTime = 5000; // 5 seconds base
    const charTime = content.length * 100; // 100ms per character
    return Math.min(baseTime + charTime, 15000); // Max 15 seconds
  };

  // Auto-rotate posts with dynamic timing
  useEffect(() => {
    if (posts.length > 1) {
      const currentPost = posts[currentPostIndex];
      const duration = getPostDuration(currentPost.content);
      
      postIntervalRef.current = setTimeout(() => {
        setCurrentPostIndex((prev) => (prev + 1) % posts.length);
      }, duration);

      return () => {
        if (postIntervalRef.current) {
          clearTimeout(postIntervalRef.current);
        }
      };
    }
  }, [currentPostIndex, posts]);

  // Auto-rotate stories
  useEffect(() => {
    if (stories.length > 1) {
      storyIntervalRef.current = setInterval(() => {
        setCurrentStoryIndex((prev) => (prev + 1) % stories.length);
      }, 4000); // 4 seconds per story

      return () => {
        if (storyIntervalRef.current) {
          clearInterval(storyIntervalRef.current);
        }
      };
    }
  }, [stories.length]);

  // Load user profile and daily tasks
  useEffect(() => {
    const loadUserData = async () => {
      try {
        // Load user profile
        const profile = await api.getProfile();
        setUserProfile(profile);
        
        // Load my stories
        const myStoriesData = await storiesAPI.getMyStories(false, 1, 20);
        setMyStories(myStoriesData.active_stories || []);
        
        // Load all stories
        const allStoriesData = await storiesAPI.getStories(1, 20);
        setAllStories(allStoriesData.stories || []);
        setStories(allStoriesData.stories || []);
        setIsLoadingStories(false);
        
        // Load daily tasks
        const tasks = await api.getDailyTasks(language);
        setDailyTasks(tasks);
        
        // Update stats from API data
        if (tasks) {
          setDailyProgress(tasks.goal_progress || 0);
          setStreak(tasks.login_streak || 0);
          setTotalPoints(tasks.current_level_points || 0);
          setLevel(tasks.current_level || 1);
        }
        
        // Load posts from API when available
        setIsLoadingPosts(false);
      } catch (error) {
        console.error('Error loading user data:', error);
        setIsLoadingStories(false);
        setIsLoadingPosts(false);
      } finally {
        setIsLoadingTasks(false);
      }
    };

    loadUserData();
  }, [language]);

  // Update time every minute
  useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timeInterval);
  }, []);

  // Refresh daily tasks every 7 seconds
  useEffect(() => {
    const refreshTasks = async () => {
      try {
        const tasks = await api.getDailyTasks(language);
        setDailyTasks(tasks);
        
        if (tasks) {
          setDailyProgress(tasks.goal_progress || 0);
          setStreak(tasks.login_streak || 0);
          setTotalPoints(tasks.current_level_points || 0);
          setLevel(tasks.current_level || 1);
        }
      } catch (error) {
        console.error('Error refreshing tasks:', error);
      }
    };

    tasksIntervalRef.current = setInterval(refreshTasks, 7000);

    return () => {
      if (tasksIntervalRef.current) {
        clearInterval(tasksIntervalRef.current);
      }
    };
  }, [language]);

  // No simulation - only show real data from API

  const handleStoryClick = (storyIndex) => {
    setCurrentStoryIndex(storyIndex);
    setShowStoriesViewer(true);
  };

  const handleStoryClose = () => {
    setShowStoriesViewer(false);
  };

  const handleStoryComplete = (storyId) => {
    setViewedStories(prev => [...prev, storyId]);
  };

  const handleStoryCreated = async (newStory) => {
    // Refresh my stories after creating a new one
    try {
      const myStoriesData = await storiesAPI.getMyStories(false, 1, 20);
      setMyStories(myStoriesData.active_stories || []);
    } catch (error) {
      console.error('Error refreshing stories:', error);
    }
  };

  // Post rotation logic
  useEffect(() => {
    if (posts.length <= 1) return;
    
    const duration = getPostDuration(posts[currentPostIndex]?.content || '');
    
    postIntervalRef.current = setTimeout(() => {
      setCurrentPostIndex(prev => (prev + 1) % posts.length);
    }, duration);
    
    return () => {
      if (postIntervalRef.current) {
        clearTimeout(postIntervalRef.current);
      }
    };
  }, [currentPostIndex, posts]);


  const getStoryTypeLabel = (type) => {
    switch (type) {
      case 'academic': return t('home.academic');
      case 'research': return t('home.research');
      case 'community': return t('home.community');
      case 'ai': return t('home.ai');
      default: return 'General';
    }
  };

  const formatTime = (timeStr) => {
    if (language === 'ar') {
      return timeStr; // Already in Arabic
    }
    // Convert Arabic time to English
    return timeStr
      .replace('منذ ساعتين', '2 hours ago')
      .replace('منذ 4 ساعات', '4 hours ago')
      .replace('منذ 6 ساعات', '6 hours ago')
      .replace('منذ 8 ساعات', '8 hours ago')
      .replace('منذ 10 ساعات', '10 hours ago');
  };

  // Get appropriate greeting based on time
  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (language === 'ar') {
      if (hour >= 5 && hour < 12) {
        return 'صباح الخير';
      } else if (hour >= 12 && hour < 17) {
        return 'مساء الخير';
      } else {
        return 'مساء الخير';
      }
    } else {
      if (hour >= 5 && hour < 12) {
        return 'Good Morning';
      } else if (hour >= 12 && hour < 17) {
        return 'Good Afternoon';
      } else {
        return 'Good Evening';
      }
    }
  };

  // Get user's first name
  const getUserFirstName = () => {
    if (!userProfile || !userProfile.full_name) return '';
    const nameParts = userProfile.full_name.split(' ');
    return nameParts[0] || userProfile.full_name;
  };

  return (
    <div className="min-h-screen bg-[var(--background)] p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <div className="space-y-2">
            <h1 className="text-4xl md:text-6xl font-bold text-white">
              {getGreeting()}
            </h1>
            {getUserFirstName() && (
              <h2 className="text-2xl md:text-3xl font-semibold text-white">
                {getUserFirstName()}
              </h2>
            )}
          </div>
          <p className="text-xl text-white max-w-2xl mx-auto">
            {t('home.description')}
          </p>
        </motion.div>

        {/* Daily Progress & Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {isLoadingTasks || (dailyProgress === 0 && streak === 0 && totalPoints === 0 && level === 0) ? (
            <StatsSkeleton />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Daily Progress */}
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <Target className="w-8 h-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  {t('home.dailyProgress')}
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{t('home.dailyProgress')}</span>
                  <span>{Math.round(dailyProgress).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}%</span>
                </div>
                <Progress value={dailyProgress} className="h-2 bg-white/20">
                  <div className="h-full bg-white rounded-full transition-all duration-500" style={{ width: `${dailyProgress}%` }} />
                </Progress>
                {dailyTasks && (
                  <div className="text-xs opacity-90 mt-2">
                    {(dailyTasks.total_points_earned_today || 0).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')} / {(dailyTasks.daily_goal || 100).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')} {language === 'ar' ? 'نقطة' : 'points'}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Streak */}
          <Card className="bg-gradient-to-br from-orange-500 to-red-500 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <Flame className="w-8 h-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  {t('home.streak')}
                </Badge>
              </div>
              <div className="text-3xl font-bold">{streak.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
              <div className="text-sm opacity-90">{t('home.streak')}</div>
              {dailyTasks && dailyTasks.season_streak_days && (
                <div className="text-xs opacity-75 mt-1">
                  {language === 'ar' ? 'موسم' : 'Season'}: {dailyTasks.season_streak_days.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Total Points */}
          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <Trophy className="w-8 h-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  {t('home.totalPoints')}
                </Badge>
              </div>
              <div className="text-3xl font-bold">{totalPoints.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
              <div className="text-sm opacity-90">{t('home.totalPoints')}</div>
              {dailyTasks && dailyTasks.points_needed && (
                <div className="text-xs opacity-75 mt-1">
                  {language === 'ar' ? 'للمستوى التالي' : 'To next level'}: {dailyTasks.points_needed.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Level */}
          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <Star className="w-8 h-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  {t('home.currentLevel')}
                </Badge>
              </div>
              <div className="text-3xl font-bold">{level.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
              <div className="text-sm opacity-90">{t('home.currentLevel')}</div>
              {dailyTasks && dailyTasks.current_level_name_ar && (
                <div className="text-xs opacity-75 mt-1">
                  {language === 'ar' ? dailyTasks.current_level_name_ar : dailyTasks.current_level_name_en}
                </div>
              )}
              {dailyTasks && dailyTasks.level_progress_percentage && (
                <div className="mt-2">
                  <Progress value={dailyTasks.level_progress_percentage} className="h-1 bg-white/20">
                    <div className="h-full bg-white rounded-full transition-all duration-500" style={{ width: `${dailyTasks.level_progress_percentage}%` }} />
                  </Progress>
                </div>
              )}
            </CardContent>
          </Card>
            </div>
          )}
        </motion.div>

        {/* Stories Section */}
        {isLoadingStories ? (
          <StoriesSkeleton />
        ) : allStories.length > 0 ? (
        <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-sm border border-[var(--border-color)]">
          <div className="flex items-center justify-between mb-4">
            <h2 className={`text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[var(--text-primary)]'}`}>
              {t('home.stories')}
            </h2>
          </div>
          
          <div className="flex gap-4 overflow-x-auto pb-2">
            {/* My Story - Always first */}
            <StoryRing
              key="my-story"
              story={{
                id: 'my-story',
                user: userProfile?.display_name || userProfile?.username || 'You',
                avatar: userProfile?.profile_image || userProfile?.profile_image_url || null,
                type: 'my-story',
                title: 'Your Story',
                slides: myStories.length > 0 ? myStories.map(story => ({
                  type: story.media_type,
                  content: storiesAPI.buildMediaUrl(story.media_url),
                  caption: story.location || 'Your Story'
                })) : [],
                isMyStory: true,
                hasStories: myStories.length > 0
              }}
              isViewed={false}
              onClick={() => {
                if (myStories.length > 0) {
                  // Open stories viewer with my stories first
                  setCurrentStoryIndex(0);
                  setShowStoriesViewer(true);
                } else {
                  // Open story creator directly
                  setShowStoryCreator(true);
                }
              }}
              size="medium"
            />
            
            {/* Other Stories */}
            {allStories.map((story, index) => (
              <StoryRing
                key={story.id}
                story={{
                  id: story.id,
                  user: story.author?.display_name || story.author?.username || 'Unknown',
                  avatar: storiesAPI.buildMediaUrl(story.author?.profile_image) || null,
                  type: 'user-story',
                  title: story.location || 'Story',
                  slides: [{
                    type: story.media_type,
                    content: storiesAPI.buildMediaUrl(story.media_url),
                    caption: story.location || 'Story'
                  }]
                }}
                isViewed={viewedStories.includes(story.id)}
                onClick={() => {
                  // Calculate correct index considering my stories
                  const storyIndex = myStories.length > 0 ? index + 1 : index;
                  setCurrentStoryIndex(storyIndex);
                  setShowStoriesViewer(true);
                }}
                size="medium"
              />
            ))}
          </div>
        </div>
        ) : (
          language === 'ar' ? (
            <ComingSoonAR 
              title={t('home.stories')}
              description="ستكون الستوريز متاحة قريباً لمشاركة تجاربك التعليمية"
              icon={BookOpen}
            />
          ) : (
            <ComingSoon 
              title={t('home.stories')}
              description="Stories will be available soon to share your learning experiences"
              icon={BookOpen}
            />
          )
        )}

        {/* Daily Challenges */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">{t('home.dailyChallenges')}</h2>
            {dailyTasks && (
              <Badge variant="outline" className="text-[var(--accent-color)] border-[var(--accent-color)]">
                {dailyTasks.completed_tasks}/{dailyTasks.total_tasks}
              </Badge>
            )}
          </div>
          
          {isLoadingTasks ? (
            <ChallengesSkeleton />
          ) : dailyTasks && dailyTasks.tasks ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {dailyTasks.tasks.map((task, index) => {
                const isCompleted = task.is_completed;
                const progress = task.progress_percentage || 0;
                
                return (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                  >
                    <Card className={`border-2 transition-all duration-300 hover:shadow-lg ${
                      isCompleted 
                        ? 'border-green-500 bg-green-50 dark:bg-green-950/20' 
                        : 'border-[var(--border-color)] hover:border-[var(--accent-color)]'
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className={`p-2 rounded-lg ${
                            isCompleted 
                              ? 'bg-green-500 text-white' 
                              : 'bg-[var(--background-secondary)] text-[var(--text-secondary)]'
                          }`}>
                            {isCompleted ? <CheckCircle className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                          </div>
                          <Badge variant={isCompleted ? "default" : "outline"} className={
                            isCompleted 
                              ? 'bg-green-500 hover:bg-green-600' 
                              : 'text-[var(--accent-color)] border-[var(--accent-color)]'
                          }>
                            {task.points} {language === 'ar' ? 'نقطة' : 'points'}
                          </Badge>
                        </div>
                        <h4 className={`font-semibold mb-2 ${
                          isCompleted 
                            ? 'text-green-700 dark:text-green-400' 
                            : 'text-[var(--text-primary)]'
                        }`}>
                          {language === 'ar' ? task.name_ar : task.name_en}
                        </h4>
                        <p className={`text-sm mb-3 ${
                          isCompleted 
                            ? 'text-green-600 dark:text-green-400' 
                            : 'text-[var(--text-secondary)]'
                        }`}>
                          {language === 'ar' ? task.description_ar : task.description_en}
                        </p>
                        
                        {!isCompleted && progress > 0 && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs text-[var(--text-secondary)]">
                              <span>{language === 'ar' ? 'التقدم' : 'Progress'}</span>
                              <span>{progress}%</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between mt-3">
                          <span className={`text-sm ${
                            isCompleted 
                              ? 'text-green-600 dark:text-green-400' 
                              : 'text-[var(--text-secondary)]'
                          }`}>
                            {isCompleted 
                              ? (language === 'ar' ? 'مكتمل' : 'Completed')
                              : (language === 'ar' ? 'قيد التنفيذ' : 'In Progress')
                            }
                          </span>
                          {isCompleted && (
                            <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle className="w-3 h-3 text-white" />
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="col-span-full text-center py-8">
                <div className="w-16 h-16 bg-[var(--accent-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-[var(--accent-text-color)]" />
                        </div>
                <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">
                  {language === 'ar' ? 'لا توجد تحديات اليوم' : 'No challenges today'}
                </h3>
                <p className="text-[var(--text-secondary)]">
                  {language === 'ar' ? 'تحقق مرة أخرى لاحقاً للحصول على تحديات جديدة' : 'Check back later for new challenges'}
                </p>
                      </div>
            </div>
          )}
        </motion.div>

        {/* Posts Feed with Auto-rotation */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="space-y-4"
        >
          {isLoadingPosts ? (
            <PostsSkeleton />
          ) : posts.length > 0 ? (
            <>
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">{t('home.latestPosts')}</h2>
          </div>
          
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPostIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="w-full"
              >
                <Card className="border-[var(--border-color)] hover:shadow-lg transition-all duration-300">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={posts[currentPostIndex].avatar} />
                        <AvatarFallback>{posts[currentPostIndex].user.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-[var(--text-primary)]">{posts[currentPostIndex].user}</h4>
                          <Badge variant="outline" size="sm" className={`text-xs ${
                            posts[currentPostIndex].type === 'academic' ? 'border-blue-500 text-blue-600' :
                            posts[currentPostIndex].type === 'research' ? 'border-purple-500 text-purple-600' :
                            posts[currentPostIndex].type === 'community' ? 'border-green-500 text-green-600' :
                            'border-gray-500 text-gray-600'
                          }`}>
                            {getStoryTypeLabel(posts[currentPostIndex].type)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                          <Clock className="w-3 h-3" />
                          <span>{formatTime(posts[currentPostIndex].time)}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-[var(--text-primary)] leading-relaxed">{posts[currentPostIndex].content}</p>
                    
                    {posts[currentPostIndex].image && (
                      <div className="relative group cursor-pointer">
                        <img 
                          src={posts[currentPostIndex].image} 
                          alt="Post content" 
                          className="w-full h-64 object-cover rounded-lg"
                        />
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                          <Play className="w-12 h-12 text-white" />
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-6">
                        <Button variant="ghost" size="sm" className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-red-500">
                          <Heart className="w-4 h-4" />
                          <span>{posts[currentPostIndex].likes}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-blue-500">
                          <MessageCircle className="w-4 h-4" />
                          <span>{posts[currentPostIndex].comments}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-green-500">
                          <Share2 className="w-4 h-4" />
                          <span>{posts[currentPostIndex].shares}</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </AnimatePresence>
            
            {/* Post Navigation Dots */}
            {posts.length > 1 && (
              <div className="flex justify-center mt-4 space-x-2">
                {posts.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentPostIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index === currentPostIndex 
                        ? 'bg-[var(--accent-color)] w-6' 
                        : 'bg-[var(--border-color)]'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
            </>
          ) : (
            language === 'ar' ? (
              <ComingSoonAR 
                title={t('home.latestPosts')}
                description="ستكون المنشورات متاحة قريباً لمشاركة أفكارك ومناقشتها مع الآخرين"
                icon={MessageCircle}
              />
            ) : (
              <ComingSoon 
                title={t('home.latestPosts')}
                description="Posts will be available soon to share your thoughts and discuss with others"
                icon={MessageCircle}
              />
            )
          )}
        </motion.div>

        {/* Quick Actions with New Features */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">{t('home.quickActions')}</h2>
            <Button 
              variant="outline" 
              onClick={() => setShowQuickActions(!showQuickActions)}
              className="text-[var(--accent-color)] border-[var(--accent-color)]"
            >
              {showQuickActions ? 'إخفاء' : 'عرض'} {t('home.quickActions')}
            </Button>
          </div>
          
          <AnimatePresence>
            {showQuickActions && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
              >
                {quickActions.map((action, index) => (
                  <motion.div
                    key={action.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.1 * index }}
                  >
                    <Card 
                      className={`border-[var(--border-color)] hover:border-[var(--accent-color)] hover:shadow-lg transition-all duration-300 cursor-pointer group bg-gradient-to-br ${action.color}`}
                      onClick={action.action}
                    >
                      <CardContent className="p-6 text-center text-white">
                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                          {action.icon}
                        </div>
                        <h3 className="text-xl font-semibold mb-2">{action.title}</h3>
                        <p className="text-sm opacity-90">{action.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Stories Viewer Modal */}
      <StoriesViewer
        stories={[
          // My stories first (if any)
          ...(myStories.length > 0 ? [{
            id: 'my-story',
            user: userProfile?.display_name || userProfile?.username || 'You',
            avatar: userProfile?.profile_image || userProfile?.profile_image_url || null,
            type: 'my-story',
            title: 'Your Story',
            slides: myStories.map(story => ({
              type: story.media_type,
              content: storiesAPI.buildMediaUrl(story.media_url),
              caption: story.location || 'Your Story'
            }))
          }] : []),
          // Other stories
          ...allStories.map(story => ({
            id: story.id,
            user: story.author?.display_name || story.author?.username || 'Unknown',
            avatar: storiesAPI.buildMediaUrl(story.author?.profile_image) || null,
            type: 'user-story',
            title: story.location || 'Story',
            slides: [{
              type: story.media_type,
              content: storiesAPI.buildMediaUrl(story.media_url),
              caption: story.location || 'Story'
            }]
          }))
        ]}
        initialStoryIndex={currentStoryIndex}
        isOpen={showStoriesViewer}
        onClose={handleStoryClose}
        onStoryComplete={handleStoryComplete}
      />

      {/* Story Creator Modal */}
      <StoryCreator
        isOpen={showStoryCreator}
        onClose={() => setShowStoryCreator(false)}
        onStoryCreated={handleStoryCreated}
      />
    </div>
  );
} 