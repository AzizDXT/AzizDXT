
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import {
  FileText,
  Upload as UploadIcon,
  X,
  Download,
  Eye,
  Loader2,
  CheckCircle,
  AlertCircle,
  Calendar,
  File,
  Home,
  ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';

const mockAPI = {
  getUsageStats: () => Promise.resolve({ daily: 3, monthly: 45 }),
  getTaskHistory: () => Promise.resolve([
    {
      task_id: 'task_1',
      status: 'completed',
      created_at: new Date(Date.now() - 86400000).toISOString(),
      processing_type: 'summary',
      files_count: 1,
      input_filenames: ['Research_Paper_AI.pdf']
    },
    {
      task_id: 'task_2',
      status: 'processing',
      created_at: new Date().toISOString(),
      processing_type: 'detailed',
      files_count: 3,
      input_filenames: ['Chapter1.docx', 'Chapter2.docx', 'Chapter3.docx']
    }
  ]),
  processFiles: (files, type, instructions) => {
    console.log('Processing files:', files.map(f => f.name), type, instructions);
    return new Promise(resolve => setTimeout(() => resolve({ success: true, taskId: `task_${Date.now()}` }), 2000));
  },
  getTaskFiles: (taskId) => Promise.resolve([
    { name: 'summary_output.txt', url: '#' },
    { name: 'key_points.pdf', url: '#' }
  ])
};

export default function DeepWrite() {
  const { t, language } = useI18n();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [processingType, setProcessingType] = useState('summary');
  const [aiInstructions, setAiInstructions] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [usageStats, setUsageStats] = useState(null);
  const [taskHistory, setTaskHistory] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [taskFiles, setTaskFiles] = useState(null);
  const [loadingTaskDetails, setLoadingTaskDetails] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [stats, history] = await Promise.all([
          mockAPI.getUsageStats(),
          mockAPI.getTaskHistory()
        ]);
        setUsageStats(stats);
        setTaskHistory(history);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleFilesSelected = (files) => {
    const fileArray = Array.from(files);
    setSelectedFiles(fileArray);
  };

  const handleStartProcessing = async () => {
    if (selectedFiles.length === 0) return;

    setIsUploading(true);
    try {
      const result = await mockAPI.processFiles(selectedFiles, processingType, aiInstructions);
      console.log('Processing started:', result);
      setSelectedFiles([]);
      setAiInstructions('');
      // Refresh task history
      const history = await mockAPI.getTaskHistory();
      setTaskHistory(history);
    } catch (error) {
      console.error('Processing failed:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleTaskClick = async (task) => {
    setSelectedTask(task);
    setTaskFiles(null);

    if (task.status === 'completed') {
      setLoadingTaskDetails(true);
      try {
        const files = await mockAPI.getTaskFiles(task.task_id);
        setTaskFiles(files);
      } catch (error) {
        console.error('Failed to fetch task files:', error);
      } finally {
        setLoadingTaskDetails(false);
      }
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen text-[var(--text-primary)]">
        <Loader2 className="h-8 w-8 animate-spin mr-2" />
        {t('loading')}...
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main Content */}
      <div className="lg:col-span-2 space-y-6">
         {/* Breadcrumb Navigation */}
        <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
          <button 
            onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
            className="hover:text-[var(--text-primary)] transition-colors flex items-center gap-1"
          >
            <Home className="w-4 h-4" />
            {t('breadcrumb.library')}
          </button>
          <ChevronRight className="w-4 h-4" />
          <span className="text-[var(--text-primary)]">{t('breadcrumb.deepwrite')}</span>
        </div>

        <Card className="bg-[var(--background-secondary)] border-none">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)] text-2xl">{t('deepwrite.title')}</CardTitle>
            <p className="text-[var(--text-secondary)]">{t('deepwrite.description')}</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border border-dashed border-[var(--border-color)] rounded-lg p-6 text-center cursor-pointer hover:border-[var(--primary-color)] transition-colors"
                   onClick={() => fileInputRef.current?.click()}>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  multiple
                  onChange={(e) => handleFilesSelected(e.target.files)}
                />
                <UploadIcon className="mx-auto h-12 w-12 text-[var(--text-secondary)]" />
                <p className="mt-2 text-[var(--text-primary)]">{t('deepwrite.upload_prompt')}</p>
                <p className="text-sm text-[var(--text-secondary)]">{t('deepwrite.upload_description')}</p>
              </div>

              {selectedFiles.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-[var(--text-primary)]">{t('deepwrite.selected_files')}</h3>
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-md bg-[var(--background-tertiary)]">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-[var(--text-secondary)]" />
                        <span className="text-[var(--text-primary)] text-sm truncate">{file.name}</span>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => setSelectedFiles(selectedFiles.filter((_, i) => i !== index))}>
                        <X className="h-4 w-4 text-[var(--text-secondary)]" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">{t('deepwrite.processing_type')}</label>
                <div className="flex space-x-2">
                  <Button
                    variant={processingType === 'summary' ? 'default' : 'outline'}
                    onClick={() => setProcessingType('summary')}
                    className="flex-1"
                  >
                    {t('deepwrite.type_summary')}
                  </Button>
                  <Button
                    variant={processingType === 'detailed' ? 'default' : 'outline'}
                    onClick={() => setProcessingType('detailed')}
                    className="flex-1"
                  >
                    {t('deepwrite.type_detailed')}
                  </Button>
                </div>
              </div>

              <div>
                <label htmlFor="ai-instructions" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                  {t('deepwrite.ai_instructions')} ({t('deepwrite.optional')})
                </label>
                <Textarea
                  id="ai-instructions"
                  placeholder={t('deepwrite.ai_instructions_placeholder')}
                  value={aiInstructions}
                  onChange={(e) => setAiInstructions(e.target.value)}
                  className="bg-[var(--background-tertiary)] border-none text-[var(--text-primary)]"
                />
              </div>

              <Button
                className="w-full"
                onClick={handleStartProcessing}
                disabled={selectedFiles.length === 0 || isUploading}
              >
                {isUploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t('deepwrite.processing')}...
                  </>
                ) : (
                  t('deepwrite.start_processing')
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Task History */}
        <Card className="bg-[var(--background-secondary)] border-none">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)]">{t('deepwrite.task_history')}</CardTitle>
          </CardHeader>
          <CardContent>
            {taskHistory.length === 0 ? (
              <p className="text-[var(--text-secondary)]">{t('deepwrite.no_history')}</p>
            ) : (
              <div className="space-y-4">
                {taskHistory.map((task) => (
                  <Card key={task.task_id} className="bg-[var(--background-tertiary)] border-none cursor-pointer hover:bg-[var(--background-hover)]"
                        onClick={() => handleTaskClick(task)}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          {task.status === 'completed' && <CheckCircle className="h-5 w-5 text-green-500" />}
                          {task.status === 'processing' && <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />}
                          {task.status === 'failed' && <AlertCircle className="h-5 w-5 text-red-500" />}
                          <div>
                            <p className="text-[var(--text-primary)] font-medium capitalize">{t(`deepwrite.type_${task.processing_type}`)} ({task.files_count} {t('deepwrite.files')})</p>
                            <p className="text-sm text-[var(--text-secondary)] flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              {new Date(task.created_at).toLocaleDateString(language, { year: 'numeric', month: 'short', day: 'numeric' })}
                            </p>
                          </div>
                        </div>
                        <ChevronRight className="h-5 w-5 text-[var(--text-secondary)]" />
                      </div>
                      {selectedTask?.task_id === task.task_id && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                          className="mt-4 border-t border-[var(--border-color)] pt-4"
                        >
                          <h4 className="font-semibold text-[var(--text-primary)] mb-2">{t('deepwrite.task_details')}</h4>
                          <p className="text-sm text-[var(--text-secondary)]"><strong>{t('deepwrite.status')}:</strong> <span className="capitalize">{task.status}</span></p>
                          <p className="text-sm text-[var(--text-secondary)]"><strong>{t('deepwrite.input_files')}:</strong> {task.input_filenames.join(', ')}</p>

                          {loadingTaskDetails && (
                            <div className="flex items-center text-[var(--text-secondary)] mt-2">
                              <Loader2 className="h-4 w-4 animate-spin mr-1" />
                              {t('deepwrite.loading_files')}...
                            </div>
                          )}

                          {taskFiles && taskFiles.length > 0 && (
                            <div className="mt-4 space-y-2">
                              <h5 className="font-semibold text-[var(--text-primary)]">{t('deepwrite.output_files')}:</h5>
                              {taskFiles.map((file, fileIndex) => (
                                <div key={fileIndex} className="flex items-center justify-between text-sm text-[var(--text-primary)] bg-[var(--background-card)] p-2 rounded-md">
                                  <div className="flex items-center">
                                    <File className="h-4 w-4 mr-2 text-[var(--text-secondary)]" />
                                    <span>{file.name}</span>
                                  </div>
                                  <div className="flex space-x-2">
                                    <Button variant="ghost" size="sm" asChild>
                                      <a href={file.url} target="_blank" rel="noopener noreferrer" title={t('deepwrite.view_file')}>
                                        <Eye className="h-4 w-4 text-[var(--text-secondary)]" />
                                      </a>
                                    </Button>
                                    <Button variant="ghost" size="sm" asChild>
                                      <a href={file.url} download title={t('deepwrite.download_file')}>
                                        <Download className="h-4 w-4 text-[var(--text-secondary)]" />
                                      </a>
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </motion.div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Sidebar */}
      <div className="lg:col-span-1 space-y-6">
        {/* Usage Stats */}
        <Card className="bg-[var(--background-secondary)] border-none">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)]">{t('deepwrite.usage_stats')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-[var(--text-secondary)] text-sm">{t('deepwrite.daily_usage')}</p>
              <Progress value={(usageStats?.daily / 5) * 100} className="w-full h-2" />
              <p className="text-[var(--text-primary)] text-sm mt-1">{usageStats?.daily || 0}/{t('deepwrite.daily_limit')}</p>
            </div>
            <div>
              <p className="text-[var(--text-secondary)] text-sm">{t('deepwrite.monthly_usage')}</p>
              <Progress value={(usageStats?.monthly / 100) * 100} className="w-full h-2" />
              <p className="text-[var(--text-primary)] text-sm mt-1">{usageStats?.monthly || 0}/{t('deepwrite.monthly_limit')}</p>
            </div>
          </CardContent>
        </Card>

        {/* Tips and Tricks */}
        <Card className="bg-[var(--background-secondary)] border-none">
          <CardHeader>
            <CardTitle className="text-[var(--text-primary)]">{t('deepwrite.tips_tricks')}</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside text-[var(--text-secondary)] space-y-2 text-sm">
              <li>{t('deepwrite.tip1')}</li>
              <li>{t('deepwrite.tip2')}</li>
              <li>{t('deepwrite.tip3')}</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
