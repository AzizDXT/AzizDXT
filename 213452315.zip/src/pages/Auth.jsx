
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  AlertCircle, 
  Mail, 
  Lock, 
  User, 
  Calendar, 
  MapPin, 
  Eye, 
  EyeOff, 
  CheckCircle, 
  Loader2 
} from 'lucide-react';
import CountrySelector from '../components/ui/CountrySelector';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import AppProviders from '../components/AppProviders';
import AuthLayout from '../components/auth/AuthLayout';
import OAuthButton from '../components/auth/OAuthButton';
import GoogleSignInButton from '../components/auth/GoogleSignInButton';
import UsernameSetupModal from '../components/auth/UsernameSetupModal';
import PWAInstallPrompt from '../components/PWAInstallPrompt';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import { getRedirectAfterLogin } from '../utils/logout';
import api from '../components/utils/api';

// Progress Indicator Component
function ProgressIndicator({ currentStep, totalSteps }) {
  return (
    <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse mb-6">
      {Array.from({ length: totalSteps }).map((_, index) => (
        <div
          key={index}
          className={`w-3 h-3 rounded-full transition-all duration-300 ${
            index < currentStep 
              ? 'bg-[var(--accent-color)]' 
              : index === currentStep 
                ? 'bg-[var(--accent-color)] scale-125' 
                : 'bg-[var(--border-color)]'
          }`}
        />
      ))}
    </div>
  );
}

// Animated Words Component
function AnimatedWords({ isRTL }) {
  const words = isRTL ? [
    'لنبدع',
    'لنبتكر', 
    'لنصمم',
    'لنتناقش',
    'لنفكر',
    'لنتعلم',
    'لنتطور',
    'لننمو',
    'لنتحدى',
    'لنتفوق'
  ] : [
    'Let\'s Create',
    'Let\'s Innovate',
    'Let\'s Design', 
    'Let\'s Discuss',
    'Let\'s Think',
    'Let\'s Learn',
    'Let\'s Evolve',
    'Let\'s Grow',
    'Let\'s Challenge',
    'Let\'s Excel'
  ];

  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    const currentWord = words[currentWordIndex];
    
    if (isTyping) {
      if (currentCharIndex < currentWord.length) {
        const timer = setTimeout(() => {
          setCurrentCharIndex(prev => prev + 1);
        }, 135); // زيادة السرعة 10% (150 * 0.9 = 135)
        return () => clearTimeout(timer);
      } else {
        const timer = setTimeout(() => {
          setIsTyping(false);
        }, 1800); // زيادة السرعة 10% (2000 * 0.9 = 1800)
        return () => clearTimeout(timer);
      }
    } else {
      if (currentCharIndex > 0) {
        const timer = setTimeout(() => {
          setCurrentCharIndex(prev => prev - 1);
        }, 90); // زيادة السرعة 10% (100 * 0.9 = 90)
        return () => clearTimeout(timer);
      } else {
        const timer = setTimeout(() => {
          setCurrentWordIndex(prev => (prev + 1) % words.length);
          setIsTyping(true);
        }, 450); // زيادة السرعة 10% (500 * 0.9 = 450)
        return () => clearTimeout(timer);
      }
    }
  }, [currentCharIndex, isTyping, currentWordIndex, words]);

  const currentWord = words[currentWordIndex];
  const displayedText = currentWord.substring(0, currentCharIndex);

  return (
    <div className="text-center py-6 sm:py-8">
      <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-[var(--text-primary)] min-h-[2.5rem] sm:min-h-[3rem] flex items-center justify-center">
        <span className="inline-block">
          {displayedText}
          <span className="inline-block w-3 h-3 sm:w-4 sm:h-4 bg-[var(--accent-color)] rounded-full ml-2" style={{animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'}}></span>
        </span>
      </div>
    </div>
  );
}

function AuthContent() {
  const { t, isRTL, language } = useI18n();
  const { theme } = useTheme();
  const navigate = useNavigate();
  
  const [isLogin, setIsLogin] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showUsernameSetup, setShowUsernameSetup] = useState(false);
  const [pendingUserData, setPendingUserData] = useState(null);
  const [showEmailLogin, setShowEmailLogin] = useState(false);
  const [isDetectingCountry, setIsDetectingCountry] = useState(false);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    username: '',
    dateOfBirth: '',
    country: ''
  });

  const [validation, setValidation] = useState({
    username: { status: 'idle', message: '' },
    email: { status: 'idle', message: '' }
  });

  // Debounce refs for validation
  const usernameTimeoutRef = useRef(null);
  const emailTimeoutRef = useRef(null);

  useEffect(() => {
    // Reset form when switching between login/register
    if (isLogin) {
      setCurrentStep(0);
      setShowEmailLogin(false);
      setFormData(prev => ({ 
        ...prev, 
        confirmPassword: '', 
        name: '', 
        username: '', 
        dateOfBirth: '', 
        country: '' 
      }));
    }
    setError('');
    setValidation({
      username: { status: 'idle', message: '' },
      email: { status: 'idle', message: '' }
    });
  }, [isLogin]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
    
    // Real-time validation for username and email in registration
    if (!isLogin && (field === 'username' || field === 'email')) {
      if (value.trim()) {
        setValidation(prev => ({ 
          ...prev, 
          [field]: { status: 'checking', message: t('validation.checking') } 
        }));
        
        // Clear existing timeout
        const timeoutRef = field === 'username' ? usernameTimeoutRef : emailTimeoutRef;
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }
        
        // Set new timeout for 2 seconds after user stops typing
        timeoutRef.current = setTimeout(async () => {
          try {
            const result = field === 'username' 
              ? await api.checkUsername(value.trim())
              : await api.checkEmail(value.trim());
            
            setValidation(prev => ({ 
              ...prev, 
              [field]: { 
                status: result.available ? 'available' : 'unavailable', 
                message: result.message 
              } 
            }));
          } catch (error) {
            setValidation(prev => ({ 
              ...prev, 
              [field]: { status: 'error', message: 'Validation failed' } 
            }));
          }
        }, 2000); // 2 seconds delay
      } else {
        setValidation(prev => ({ ...prev, [field]: { status: 'idle', message: '' } }));
      }
    }
  };

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (usernameTimeoutRef.current) clearTimeout(usernameTimeoutRef.current);
      if (emailTimeoutRef.current) clearTimeout(emailTimeoutRef.current);
    };
  }, []);

  // Auto-detect country from IP
  useEffect(() => {
    const detectCountry = async () => {
      setIsDetectingCountry(true);
      try {
        // Try multiple IP geolocation services for better reliability
        const services = [
          'https://ipapi.co/json/',
          'https://ip-api.com/json/',
          'https://api.country.is/'
        ];

        for (const service of services) {
          try {
            const response = await fetch(service, {
              method: 'GET',
              headers: {
                'Accept': 'application/json',
              },
            });
            
            if (response.ok) {
              const data = await response.json();
              let countryCode = null;
              let countryName = null;
              
              // Parse different response formats
              if (data.country_code) {
                countryCode = data.country_code;
                countryName = data.country_name;
              } else if (data.countryCode) {
                countryCode = data.countryCode;
                countryName = data.country;
              } else if (data.country) {
                countryCode = data.country;
                countryName = data.country;
              }
              
              if (countryCode && !formData.country) {
                console.log('Auto-detected country code:', countryCode, 'name:', countryName);
                
                // Smart country matching algorithm
                const matchedCountry = findBestCountryMatch(countryCode, countryName);
                
                if (matchedCountry) {
                  console.log('Matched country:', matchedCountry);
                  setFormData(prev => ({ ...prev, country: matchedCountry }));
                  break; // Exit loop if successful
                }
              }
            }
          } catch (serviceError) {
            console.log(`Service ${service} failed:`, serviceError);
            continue; // Try next service
          }
        }
      } catch (error) {
        console.log('Country detection failed:', error);
      } finally {
        setIsDetectingCountry(false);
      }
    };

    // Smart country matching function
    const findBestCountryMatch = (countryCode, countryName) => {
      // Common country mappings for better matching
      const countryMappings = {
        'OM': 'Oman',
        'SA': 'Saudi Arabia',
        'AE': 'United Arab Emirates',
        'KW': 'Kuwait',
        'QA': 'Qatar',
        'BH': 'Bahrain',
        'EG': 'Egypt',
        'JO': 'Jordan',
        'LB': 'Lebanon',
        'SY': 'Syria',
        'IQ': 'Iraq',
        'YE': 'Yemen',
        'PS': 'Palestine',
        'MA': 'Morocco',
        'TN': 'Tunisia',
        'DZ': 'Algeria',
        'LY': 'Libya',
        'SD': 'Sudan',
        'SO': 'Somalia',
        'DJ': 'Djibouti',
        'KM': 'Comoros',
        'MR': 'Mauritania',
        'US': 'United States',
        'GB': 'United Kingdom',
        'CA': 'Canada',
        'AU': 'Australia',
        'DE': 'Germany',
        'FR': 'France',
        'IT': 'Italy',
        'ES': 'Spain',
        'NL': 'Netherlands',
        'BE': 'Belgium',
        'CH': 'Switzerland',
        'AT': 'Austria',
        'SE': 'Sweden',
        'NO': 'Norway',
        'DK': 'Denmark',
        'FI': 'Finland',
        'PL': 'Poland',
        'CZ': 'Czech Republic',
        'HU': 'Hungary',
        'RO': 'Romania',
        'BG': 'Bulgaria',
        'GR': 'Greece',
        'PT': 'Portugal',
        'IE': 'Ireland',
        'IS': 'Iceland',
        'LU': 'Luxembourg',
        'MT': 'Malta',
        'CY': 'Cyprus',
        'EE': 'Estonia',
        'LV': 'Latvia',
        'LT': 'Lithuania',
        'SK': 'Slovakia',
        'SI': 'Slovenia',
        'HR': 'Croatia',
        'BA': 'Bosnia and Herzegovina',
        'RS': 'Serbia',
        'ME': 'Montenegro',
        'MK': 'North Macedonia',
        'AL': 'Albania',
        'XK': 'Kosovo',
        'TR': 'Turkey',
        'RU': 'Russia',
        'UA': 'Ukraine',
        'BY': 'Belarus',
        'MD': 'Moldova',
        'GE': 'Georgia',
        'AM': 'Armenia',
        'AZ': 'Azerbaijan',
        'KZ': 'Kazakhstan',
        'UZ': 'Uzbekistan',
        'KG': 'Kyrgyzstan',
        'TJ': 'Tajikistan',
        'TM': 'Turkmenistan',
        'AF': 'Afghanistan',
        'PK': 'Pakistan',
        'IN': 'India',
        'BD': 'Bangladesh',
        'LK': 'Sri Lanka',
        'NP': 'Nepal',
        'BT': 'Bhutan',
        'MV': 'Maldives',
        'CN': 'China',
        'JP': 'Japan',
        'KR': 'South Korea',
        'KP': 'North Korea',
        'MN': 'Mongolia',
        'TW': 'Taiwan',
        'HK': 'Hong Kong',
        'MO': 'Macau',
        'SG': 'Singapore',
        'MY': 'Malaysia',
        'TH': 'Thailand',
        'VN': 'Vietnam',
        'LA': 'Laos',
        'KH': 'Cambodia',
        'MM': 'Myanmar',
        'PH': 'Philippines',
        'ID': 'Indonesia',
        'BN': 'Brunei',
        'TL': 'East Timor',
        'PG': 'Papua New Guinea',
        'FJ': 'Fiji',
        'SB': 'Solomon Islands',
        'VU': 'Vanuatu',
        'NC': 'New Caledonia',
        'PF': 'French Polynesia',
        'WS': 'Samoa',
        'TO': 'Tonga',
        'KI': 'Kiribati',
        'TV': 'Tuvalu',
        'NR': 'Nauru',
        'PW': 'Palau',
        'FM': 'Micronesia',
        'MH': 'Marshall Islands',
        'CK': 'Cook Islands',
        'NU': 'Niue',
        'TK': 'Tokelau',
        'AS': 'American Samoa',
        'GU': 'Guam',
        'MP': 'Northern Mariana Islands',
        'VI': 'U.S. Virgin Islands',
        'PR': 'Puerto Rico',
        'BR': 'Brazil',
        'AR': 'Argentina',
        'CL': 'Chile',
        'CO': 'Colombia',
        'PE': 'Peru',
        'VE': 'Venezuela',
        'EC': 'Ecuador',
        'BO': 'Bolivia',
        'PY': 'Paraguay',
        'UY': 'Uruguay',
        'GY': 'Guyana',
        'SR': 'Suriname',
        'GF': 'French Guiana',
        'FK': 'Falkland Islands',
        'MX': 'Mexico',
        'GT': 'Guatemala',
        'BZ': 'Belize',
        'SV': 'El Salvador',
        'HN': 'Honduras',
        'NI': 'Nicaragua',
        'CR': 'Costa Rica',
        'PA': 'Panama',
        'CU': 'Cuba',
        'JM': 'Jamaica',
        'HT': 'Haiti',
        'DO': 'Dominican Republic',
        'TT': 'Trinidad and Tobago',
        'BB': 'Barbados',
        'AG': 'Antigua and Barbuda',
        'DM': 'Dominica',
        'GD': 'Grenada',
        'KN': 'Saint Kitts and Nevis',
        'LC': 'Saint Lucia',
        'VC': 'Saint Vincent and the Grenadines',
        'BS': 'Bahamas',
        'ZA': 'South Africa',
        'NG': 'Nigeria',
        'KE': 'Kenya',
        'GH': 'Ghana',
        'ET': 'Ethiopia',
        'TZ': 'Tanzania',
        'UG': 'Uganda',
        'MW': 'Malawi',
        'ZM': 'Zambia',
        'ZW': 'Zimbabwe',
        'BW': 'Botswana',
        'NA': 'Namibia',
        'SZ': 'Eswatini',
        'LS': 'Lesotho',
        'MG': 'Madagascar',
        'MU': 'Mauritius',
        'SC': 'Seychelles',
        'RE': 'Réunion',
        'YT': 'Mayotte',
        'BI': 'Burundi',
        'RW': 'Rwanda',
        'CD': 'Democratic Republic of the Congo',
        'CG': 'Republic of the Congo',
        'CF': 'Central African Republic',
        'TD': 'Chad',
        'CM': 'Cameroon',
        'GQ': 'Equatorial Guinea',
        'GA': 'Gabon',
        'ST': 'São Tomé and Príncipe',
        'AO': 'Angola',
        'MZ': 'Mozambique',
        'MW': 'Malawi',
        'ZM': 'Zambia',
        'ZW': 'Zimbabwe',
        'BW': 'Botswana',
        'NA': 'Namibia',
        'SZ': 'Eswatini',
        'LS': 'Lesotho',
        'MG': 'Madagascar',
        'MU': 'Mauritius',
        'SC': 'Seychelles',
        'RE': 'Réunion',
        'YT': 'Mayotte',
        'BI': 'Burundi',
        'RW': 'Rwanda',
        'CD': 'Democratic Republic of the Congo',
        'CG': 'Republic of the Congo',
        'CF': 'Central African Republic',
        'TD': 'Chad',
        'CM': 'Cameroon',
        'GQ': 'Equatorial Guinea',
        'GA': 'Gabon',
        'ST': 'São Tomé and Príncipe',
        'AO': 'Angola',
        'MZ': 'Mozambique'
      };

      // First try direct mapping
      if (countryMappings[countryCode]) {
        return countryMappings[countryCode];
      }

      // If we have country name, try fuzzy matching
      if (countryName) {
        const normalizedName = countryName.toLowerCase().trim();
        
        // Try to find exact match in mappings
        for (const [code, name] of Object.entries(countryMappings)) {
          if (name.toLowerCase() === normalizedName) {
            return name;
          }
        }
        
        // Try partial matching for common variations
        for (const [code, name] of Object.entries(countryMappings)) {
          const normalizedMappedName = name.toLowerCase();
          if (normalizedName.includes(normalizedMappedName) || normalizedMappedName.includes(normalizedName)) {
            return name;
          }
        }
      }

      // Fallback: return the country code if no match found
      return countryCode;
    };

    // Only detect country if not already set and not in login mode
    if (!isLogin && !formData.country) {
      detectCountry();
    }
  }, [isLogin, formData.country]);

  const validateStep = () => {
    if (isLogin) {
      if (showEmailLogin) {
        if (!formData.email.trim()) {
          setError(t('errors.emailRequired'));
          return false;
        }
        if (!formData.password) {
          setError(t('errors.passwordRequired'));
          return false;
        }
      }
      return true;
    }

    // Registration validation by step
    switch (currentStep) {
      case 0: // Personal Info
        if (!formData.name.trim()) {
          setError(t('errors.nameRequired'));
          return false;
        }
        if (!formData.username.trim()) {
          setError(t('errors.usernameRequired'));
          return false;
        }
        if (validation.username.status === 'unavailable') {
          setError(t('errors.usernameUnavailable'));
          return false;
        }
        if (validation.username.status === 'checking') {
          setError(t('errors.waitForCheck'));
          return false;
        }
        return true;

      case 1: // Password
        if (!formData.password) {
          setError(t('errors.passwordRequired'));
          return false;
        }
        if (formData.password.length < 8) {
          setError(t('errors.passwordLength'));
          return false;
        }
        if (formData.password !== formData.confirmPassword) {
          setError(t('errors.passwordsDoNotMatch'));
          return false;
        }
        return true;

      case 2: // Additional Info
        if (!formData.email.trim()) {
          setError(t('errors.emailRequired'));
          return false;
        }
        if (validation.email.status === 'unavailable') {
          setError(t('errors.emailUnavailable'));
          return false;
        }
        if (validation.email.status === 'checking') {
          setError(t('errors.waitForCheck'));
          return false;
        }

        return true;

      default:
        return true;
    }
  };

  const handleNext = () => {
    if (validateStep()) {
      if (currentStep < 2) {
        setCurrentStep(prev => prev + 1);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateStep()) return;
    
    // For registration, only submit on the last step (step 2)
    if (!isLogin && currentStep < 2) {
      return;
    }
    
    setIsLoading(true);
    setError('');

    try {
      let result;

      if (isLogin && showEmailLogin) {
        console.log('Attempting login...');
        result = await api.login(formData.email, formData.password);
        console.log('Login successful:', result);
      } else if (!isLogin) {
        console.log('Attempting registration...');
        console.log('Form data being sent:', formData);
        result = await api.register(formData);
        console.log('Registration successful:', result);
      }

      // Redirect to intended page or dashboard on success
      console.log('Redirecting after successful login...');
      const redirectUrl = getRedirectAfterLogin();
      if (redirectUrl && redirectUrl !== '/Auth') {
        navigate(redirectUrl);
      } else {
        // Redirect to intended page or dashboard on success
        const redirectUrl = getRedirectAfterLogin();
        if (redirectUrl && redirectUrl !== '/Auth') {
          navigate(redirectUrl);
        } else {
          navigate(createPageUrl('Dashboard'));
        }
      }
    } catch (error) {
      console.error('Auth error details:', {
        message: error.message,
        name: error.name,
        stack: error.stack,
        fullError: JSON.stringify(error, Object.getOwnPropertyNames(error))
      });
      
      // Set user-friendly error message based on error type
      if (error.message.includes('Validation error')) {
        if (error.message.includes('confirm_password')) {
          setError('Please confirm your password correctly.');
        } else if (error.message.includes('date_of_birth')) {
          setError('Please provide a valid date of birth.');
        } else {
          setError('Please check all required fields and try again.');
        }
      } else {
        setError(error.message || (isLogin ? t('errors.unexpectedError') : 'Registration failed'));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleOAuthLogin = async (provider, userData = null) => {
    setIsLoading(true);
    setError('');

    try {
      console.log(`Starting ${provider} OAuth...`);
      
      let result;
      
      if (provider === 'google' && userData) {
        // Use actual Google OAuth data
        console.log('Google OAuth data:', userData);
        result = await api.googleOAuth(userData);
      } else if (provider === 'apple') {
        // Apple OAuth implementation
        console.log('Apple OAuth requested');
        const mockUserData = {
          id: 'apple_789',
          email: 'demo@icloud.com',
          name: 'Apple User',
          picture: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
          access_token: 'apple_mock_token'
        };
        result = await api.appleOAuth(mockUserData);
      } else {
        // For Microsoft or fallback - replace with actual OAuth implementation
        const mockUserData = {
          id: provider === 'google' ? 'google_123' : 'microsoft_456',
          email: `demo@${provider}.com`,
          name: 'Demo User',
          picture: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
          access_token: 'mock_token'
        };

        result = provider === 'google' 
          ? await api.googleOAuth(mockUserData)
          : await api.microsoftOAuth(mockUserData);
      }

      console.log(`${provider} OAuth successful:`, result);
      
      // Check if user needs to complete profile setup
      if (result.email_verified === true && result.role === 'PENDING') {
        // User needs to create username
        setPendingUserData({
          ...userData,
          email: result.email,
          name: result.name || userData?.name,
          picture: result.profile_image_url || userData?.picture
        });
        setShowUsernameSetup(true);
      } else {
        // User is complete, redirect to dashboard
        navigate(createPageUrl('Dashboard'));
      }
    } catch (error) {
      console.error(`${provider} OAuth error:`, {
        message: error.message,
        name: error.name,
        stack: error.stack
      });
      setError(error.message || t('errors.unexpectedError'));
    } finally {
      setIsLoading(false);
    }
  };

  const getCurrentStepTitle = () => {
    if (isLogin) return t('auth.loginTitle');
    
    switch (currentStep) {
      case 0: return t('auth.step1Title');
      case 1: return t('auth.step2Title');
      case 2: return t('auth.step3Title');
      default: return t('auth.registerTitle');
    }
  };

  const handleUsernameSetupComplete = () => {
    setShowUsernameSetup(false);
    setPendingUserData(null);
    // Redirect to intended page or profile on success
    const redirectUrl = getRedirectAfterLogin();
    if (redirectUrl && redirectUrl !== '/Auth') {
      navigate(redirectUrl);
    } else {
      navigate(createPageUrl('Profile'));
    }
  };

  const handleUsernameSetupClose = () => {
    setShowUsernameSetup(false);
    setPendingUserData(null);
    // User can try again or go back
  };

  return (
    <AuthLayout>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="w-full"
      >
        <div className="lg:hidden text-center mb-6 space-y-3">
          <div className="relative w-16 h-16 mx-auto">
            <img
              src="/src/assets/logo.png"
              alt="Taleb Logo"
              className="object-contain drop-shadow-lg w-full h-full"
            />
          </div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)]">{t('app.name')}</h1>
        </div>

        {/* Beta Warning Banner */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-yellow-500/20 border border-yellow-500/30 rounded-xl p-4 mx-4 mb-6"
        >
          <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse mb-2">
            <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
            <span className="text-yellow-700 dark:text-yellow-300 font-semibold text-sm">
              {isRTL ? 'إصدار بيتا للاختبار' : 'Beta Testing Version'}
            </span>
          </div>
          <p className="text-yellow-600 dark:text-yellow-400 text-xs leading-relaxed text-center">
            {isRTL 
              ? 'غير مستقر - قد تواجه أخطاء وفقدان البيانات. فقط استكشف وأعطنا ملاحظاتك. حسابك مؤقت وقد يتم إعادة ضبطه في أي وقت.'
              : 'Unstable - you may encounter errors and data loss. Just explore and give us feedback. Your account is temporary and may be reset at any time.'
            }
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div 
            className="text-center mb-4 sm:mb-6 space-y-2 sm:space-y-3"
            key={isLogin ? 'login-header' : 'register-header'}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          >
            <h1 className="text-2xl sm:text-3xl font-bold text-[var(--text-primary)]">{getCurrentStepTitle()}</h1>
            <p className="text-[var(--text-secondary)] text-sm sm:text-base">{isLogin ? t('auth.subtitle') : t('auth.registerSubtitle')}</p>
            {!isLogin && <ProgressIndicator currentStep={currentStep} totalSteps={3} />}
          </motion.div>
        </AnimatePresence>
        
        <motion.div 
          className="p-6 sm:p-8"
          layout
          transition={{ duration: 0.5, ease: "easeInOut" }}
        >
          {error && (
            <motion.div 
              className="border px-4 py-3 rounded-xl text-sm text-center flex items-center justify-center space-x-2 bg-red-500/10 border-red-500/30 text-red-500 mb-6"
              initial={{opacity: 0, y: -10}}
              animate={{opacity: 1, y: 0}}
            >
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
            <AnimatePresence mode="wait">
              <motion.div
                key={isLogin ? 'login' : `register-step-${currentStep}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="space-y-4"
              >
                <AnimatePresence>
                  {isLogin && showEmailLogin && (
                    <motion.div
                      initial={{ opacity: 0, height: 0, y: -10 }}
                      animate={{ opacity: 1, height: "auto", y: 0 }}
                      exit={{ opacity: 0, height: 0, y: -10 }}
                      transition={{ duration: 0.4, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <InputGroup>
                        <Label htmlFor="email" className="text-[var(--text-primary)]">{t('auth.email')}</Label>
                        <div className="relative">
                          <Mail className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                          <Input 
                            id="email" 
                            type="email" 
                            placeholder={t('auth.emailPlaceholder')} 
                            value={formData.email} 
                            onChange={(e) => handleInputChange('email', e.target.value)} 
                            disabled={isLoading}
                            className={`${isRTL ? 'pr-12' : 'pl-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                          />
                        </div>
                      </InputGroup>
                      
                      <InputGroup>
                        <Label htmlFor="password" className="text-[var(--text-primary)]">{t('auth.password')}</Label>
                        <div className="relative">
                          <Lock className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                          <Input 
                            id="password" 
                            type={showPassword ? "text" : "password"} 
                            placeholder={t('auth.passwordPlaceholder')} 
                            value={formData.password} 
                            onChange={(e) => handleInputChange('password', e.target.value)} 
                            disabled={isLoading}
                            className={`${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                          />
                          <button 
                            type="button" 
                            onClick={() => setShowPassword(!showPassword)} 
                            className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-[var(--text-secondary)] interactive-element`}
                          >
                            {showPassword ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" />}
                          </button>
                        </div>
                      </InputGroup>
                      
                      <div className="text-center">
                        <button
                          type="button"
                          onClick={() => setShowEmailLogin(false)}
                          className="text-sm text-[var(--text-secondary)] hover:text-[var(--accent-color)] transition-colors"
                        >
                          {t('auth.backToOAuth')}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {isLogin && !showEmailLogin && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: 10 }}
                      transition={{ duration: 0.4, ease: "easeInOut" }}
                    >
                      <AnimatedWords isRTL={isRTL} />
                    </motion.div>
                  )}
                </AnimatePresence>

                {!isLogin && currentStep === 0 && (
                  <>
                    <InputGroup>
                      <Label htmlFor="name" className="text-[var(--text-primary)]">{t('auth.name')}</Label>
                      <div className="relative">
                        <User className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="name" 
                          type="text" 
                          placeholder={t('auth.namePlaceholder')} 
                          value={formData.name} 
                          onChange={(e) => handleInputChange('name', e.target.value)} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12' : 'pl-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                      </div>
                    </InputGroup>
                    
                    <InputGroup>
                      <Label htmlFor="username" className="text-[var(--text-primary)]">{t('auth.username')}</Label>
                      <div className="relative">
                        <User className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="username" 
                          type="text" 
                          placeholder={t('auth.usernamePlaceholder')} 
                          value={formData.username} 
                          onChange={(e) => handleInputChange('username', e.target.value.toLowerCase())} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                        {validation.username.status !== 'idle' && (
                          <div className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2`}>
                            {validation.username.status === 'checking' && <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-[var(--text-secondary)]" />}
                            {validation.username.status === 'available' && <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />}
                            {validation.username.status === 'unavailable' && <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />}
                          </div>
                        )}
                      </div>
                      {validation.username.message && (
                        <p className={`text-xs mt-1 ${validation.username.status === 'available' ? 'text-green-500' : 'text-red-500'}`}>
                          {validation.username.message}
                        </p>
                      )}
                    </InputGroup>
                  </>
                )}

                {!isLogin && currentStep === 1 && (
                  <>
                    <InputGroup>
                      <Label htmlFor="password" className="text-[var(--text-primary)]">{t('auth.password')}</Label>
                      <div className="relative">
                        <Lock className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="password" 
                          type={showPassword ? "text" : "password"} 
                          placeholder={t('auth.passwordPlaceholder')} 
                          value={formData.password} 
                          onChange={(e) => handleInputChange('password', e.target.value)} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                        <button 
                          type="button" 
                          onClick={() => setShowPassword(!showPassword)} 
                          className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-[var(--text-secondary)] interactive-element`}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" />}
                        </button>
                      </div>
                    </InputGroup>
                    
                    <InputGroup>
                      <Label htmlFor="confirmPassword" className="text-[var(--text-primary)]">{t('auth.confirmPassword')}</Label>
                      <div className="relative">
                        <Lock className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="confirmPassword" 
                          type={showConfirmPassword ? "text" : "password"} 
                          placeholder={t('auth.passwordPlaceholder')} 
                          value={formData.confirmPassword} 
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                        <button 
                          type="button" 
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)} 
                          className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-[var(--text-secondary)] interactive-element`}
                        >
                          {showConfirmPassword ? <EyeOff className="w-4 h-4 sm:w-5 sm:h-5" /> : <Eye className="w-4 h-4 sm:w-5 sm:h-5" />}
                        </button>
                      </div>
                    </InputGroup>
                  </>
                )}

                {!isLogin && currentStep === 2 && (
                  <>
                    <InputGroup>
                      <Label htmlFor="email" className="text-[var(--text-primary)]">{t('auth.email')}</Label>
                      <div className="relative">
                        <Mail className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder={t('auth.emailPlaceholder')} 
                          value={formData.email} 
                          onChange={(e) => handleInputChange('email', e.target.value)} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                        {validation.email.status !== 'idle' && (
                          <div className={`absolute ${isRTL ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2`}>
                            {validation.email.status === 'checking' && <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-[var(--text-secondary)]" />}
                            {validation.email.status === 'available' && <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />}
                            {validation.email.status === 'unavailable' && <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />}
                          </div>
                        )}
                      </div>
                      {validation.email.message && (
                        <p className={`text-xs mt-1 ${validation.email.status === 'available' ? 'text-green-500' : 'text-red-500'}`}>
                          {validation.email.message}
                        </p>
                      )}
                    </InputGroup>

                    <InputGroup>
                      <Label htmlFor="dateOfBirth" className="text-[var(--text-primary)]">{t('auth.dateOfBirth')}</Label>
                      <div className="relative">
                        <Calendar className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[var(--text-secondary)]`} />
                        <Input 
                          id="dateOfBirth" 
                          type="date" 
                          value={formData.dateOfBirth} 
                          onChange={(e) => handleInputChange('dateOfBirth', e.target.value)} 
                          disabled={isLoading}
                          className={`${isRTL ? 'pr-12' : 'pl-12'} h-11 sm:h-12 rounded-lg sm:rounded-xl border-2 bg-[var(--background)] border-[var(--border-color)] text-[var(--text-primary)] focus:ring-0 transition-all duration-300 hover:shadow-lg hover:scale-[1.02] interactive-element`}
                        />
                      </div>
                    </InputGroup>

                    <InputGroup>
                      <CountrySelector
                        value={formData.country}
                        onChange={(value) => handleInputChange('country', value)}
                        placeholder={isDetectingCountry ? (isRTL ? 'جاري تحديد البلد...' : 'Detecting country...') : t('auth.countryPlaceholder')}
                        label={t('auth.country')}
                        disabled={isLoading || isDetectingCountry}
                        isRTL={isRTL}
                        loading={isDetectingCountry}
                      />
                    </InputGroup>
                  </>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 pt-3 sm:pt-4">
              {!isLogin && currentStep > 0 && (
                <Button 
                  type="button" 
                  onClick={handleBack}
                  variant="outline"
                  disabled={isLoading}
                  className="w-full sm:flex-1 h-11 sm:h-12 rounded-lg sm:rounded-xl transition-all duration-300 hover:scale-[1.02] interactive-element"
                >
                  {t('auth.back')}
                </Button>
              )}
              
              {(isLogin && showEmailLogin) || currentStep === 2 ? (
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full sm:flex-1 h-11 sm:h-12 rounded-lg sm:rounded-xl bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90 transition-all duration-300 hover:scale-[1.02] interactive-element"
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                  ) : (
                    isLogin ? t('auth.signIn') : t('auth.signUp')
                  )}
                </Button>
              ) : !isLogin && currentStep < 2 ? (
                <Button 
                  type="button" 
                  onClick={handleNext}
                  disabled={isLoading}
                  className="w-full sm:flex-1 h-11 sm:h-12 rounded-lg sm:rounded-xl bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90 transition-all duration-300 hover:scale-[1.02] interactive-element"
                >
                  {t('auth.next')}
                </Button>
              ) : null}
            </div>
            

          </form>

          <div className="mt-4 sm:mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[var(--border-color)]" />
              </div>
              <div className="relative flex justify-center text-xs sm:text-sm">
                <span className="px-3 sm:px-4 text-[var(--text-secondary)]">{t('auth.orContinueWith')}</span>
              </div>
            </div>

            <div className="mt-3 sm:mt-4 space-y-2 sm:space-y-3">
              <GoogleSignInButton 
                onSuccess={(userData) => handleOAuthLogin('google', userData)}
                onError={(error) => setError('فشل في تسجيل الدخول بجوجل: ' + error.message)}
                disabled={isLoading}
                theme={theme}
              />
              
              <OAuthButton 
                provider="apple" 
                onClick={() => handleOAuthLogin('apple')}
                disabled={isLoading}
                theme={theme}
              >
                {t('auth.appleButton')}
              </OAuthButton>
              
              <OAuthButton 
                provider="microsoft" 
                onClick={() => handleOAuthLogin('microsoft')}
                disabled={isLoading}
                theme={theme}
              >
                {t('auth.microsoftButton')}
              </OAuthButton>
              
              {isLogin && !showEmailLogin && (
                <button
                  type="button"
                  onClick={() => setShowEmailLogin(true)}
                  className="w-full h-11 sm:h-12 rounded-lg sm:rounded-xl font-medium text-center transition-all duration-300 ease-out transform hover:scale-[1.02] hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed interactive-element bg-[var(--accent-color)] text-[var(--accent-text-color)] hover:opacity-90"
                >
                  <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse">
                    <div className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0">
                      <Mail className="w-full h-full" />
                    </div>
                    <span className="text-sm font-medium">
                      {t('auth.signInWithEmail')}
                    </span>
                  </div>
                </button>
              )}
            </div>
          </div>

          <div className="mt-4 sm:mt-6 text-center">
            <p className="text-xs sm:text-sm text-[var(--text-secondary)]">
              {isLogin ? t('auth.noAccount') : t('auth.hasAccount')}{' '}
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                disabled={isLoading}
                className="font-medium text-[var(--accent-color)] hover:opacity-80 transition-opacity interactive-element"
              >
                {isLogin ? t('auth.signUp') : t('auth.signIn')}
              </button>
            </p>
          </div>
          
          {/* Terms and Privacy Notice - Always visible */}
          <div className="mt-4 sm:mt-6 text-center">
            <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
              {t('auth.termsNotice')}{' '}
              <a
                href="/terms"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--accent-color)] hover:underline font-medium"
              >
                {t('auth.termsAndConditions')}
              </a>
              {' '}{t('auth.and')}{' '}
              <a
                href="/privacy"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--accent-color)] hover:underline font-medium"
              >
                {t('auth.privacyPolicy')}
              </a>
            </p>
          </div>
        </motion.div>
      </motion.div>

      {/* Username Setup Modal */}
      <UsernameSetupModal
        isOpen={showUsernameSetup}
        onClose={handleUsernameSetupClose}
        onComplete={handleUsernameSetupComplete}
        userData={pendingUserData}
      />

      {/* PWA Install Prompt */}
      <PWAInstallPrompt />
    </AuthLayout>
  );
}

// InputGroup Component
function InputGroup({ children }) {
  return <div className="space-y-2">{children}</div>;
}

// Main Auth Component with Providers
export default function Auth() {
  return (
    <AppProviders>
      <AuthContent />
    </AppProviders>
  );
}
3