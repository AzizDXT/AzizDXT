
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import {
  Edit,
  Camera,
  MapPin,
  Calendar,
  Check,
  Loader2,
  User,
  Trash2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import api from '../components/utils/api';
import EditProfileModal from '../components/profile/EditProfileModal';
import ImageCropDialog from '../components/profile/ImageCropDialog';
import CachedImage from '../components/profile/CachedImage';
import { findCountryAndGetLocalizedName } from '../utils/countries';





// Main Profile Component
export default function Profile() {
  const { t, language } = useI18n();
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [uploading, setUploading] = useState({ profile: false, banner: false });
  const [showCropModal, setShowCropModal] = useState(false);
  const [cropData, setCropData] = useState({ file: null, type: null });
  const profileImageRef = useRef(null);
  const bannerImageRef = useRef(null);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        console.log('Loading profile data...');
        const profileData = await api.getProfile();
        console.log('Profile data loaded:', profileData);
        setProfile(profileData);
      } catch (error) {
        console.error('Error loading profile data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const handleProfileImageChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setCropData({ file, type: 'profile' });
      setShowCropModal(true);
    }
  };

  const handleBannerImageChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setCropData({ file, type: 'banner' });
      setShowCropModal(true);
    }
  };

  const handleDeleteProfileImage = async () => {
    if (confirm(language === 'ar' ? 'هل تريد حذف صورة الملف الشخصي؟' : 'Delete profile image?')) {
      try {
        await api.deleteProfileImage();
        const updatedProfile = await api.getProfile();
        setProfile(updatedProfile);
      } catch (error) {
        console.error('Error deleting profile image:', error);
        alert(language === 'ar' ? 'فشل في حذف الصورة' : 'Failed to delete image');
      }
    }
  };

  const handleDeleteBannerImage = async () => {
    if (confirm(language === 'ar' ? 'هل تريد حذف صورة الغلاف؟' : 'Delete banner image?')) {
      try {
        await api.deleteBannerImage();
        const updatedProfile = await api.getProfile();
        setProfile(updatedProfile);
      } catch (error) {
        console.error('Error deleting banner image:', error);
        alert(language === 'ar' ? 'فشل في حذف الصورة' : 'Failed to delete image');
      }
    }
  };

  // Function to force image reload by adding timestamp
  const forceImageReload = (imageUrl) => {
    if (imageUrl) {
      // Add timestamp to force browser to reload
      return `${imageUrl}?t=${Date.now()}`;
    }
    return imageUrl;
  };

  const handleCropComplete = async (croppedFile) => {
    const uploadType = cropData.type === 'profile' ? 'profile' : 'banner';
    setUploading(prev => ({ ...prev, [uploadType]: true }));

    try {
      let response;
      if (cropData.type === 'profile') {
        console.log('Uploading profile image...');
        response = await api.uploadProfileImage(croppedFile);
      } else {
        console.log('Uploading banner image...');
        response = await api.uploadBannerImage(croppedFile);
      }

      console.log('Upload successful:', response);

      // Force image reload for the updated image type
      if (cropData.type === 'profile' && profile?.profile_image_url) {
        // Force reload by adding timestamp
        const newUrl = `${profile.profile_image_url}?t=${Date.now()}`;
        setProfile(prev => ({
          ...prev,
          profile_image_url: newUrl
        }));
      } else if (cropData.type === 'banner' && profile?.banner_image_url) {
        // Force reload by adding timestamp
        const newUrl = `${profile.banner_image_url}?t=${Date.now()}`;
        setProfile(prev => ({
          ...prev,
          banner_image_url: newUrl
        }));
      }

      // Wait a bit for the server to process the image
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Force reload profile data to get new image URLs
      const updatedProfile = await api.getProfile();
      setProfile(updatedProfile);

      // Force re-render of images by adding timestamp to URLs
      if (cropData.type === 'profile' && updatedProfile.profile_image_url) {
        const newUrl = `${updatedProfile.profile_image_url}?t=${Date.now()}`;
        // Update the profile with the new URL to force re-render
        setProfile(prev => ({
          ...prev,
          profile_image_url: newUrl
        }));
      } else if (cropData.type === 'banner' && updatedProfile.banner_image_url) {
        const newUrl = `${updatedProfile.banner_image_url}?t=${Date.now()}`;
        // Update the profile with the new URL to force re-render
        setProfile(prev => ({
          ...prev,
          banner_image_url: newUrl
        }));
      }

      // Show success message
      const successMessage = cropData.type === 'profile' 
        ? (language === 'ar' ? 'تم تحديث صورة الملف الشخصي بنجاح!' : 'Profile image updated successfully!')
        : (language === 'ar' ? 'تم تحديث صورة الغلاف بنجاح!' : 'Banner image updated successfully!');
      
      // You can replace this with a proper toast notification
      console.log(successMessage);

    } catch (error) {
      console.error(`Error uploading ${cropData.type} image:`, error);
      const errorMessage = error.message || `Failed to upload ${cropData.type} image`;
      alert(errorMessage);
    } finally {
      setUploading(prev => ({ ...prev, [uploadType]: false }));
      setCropData({ file: null, type: null });
      setShowCropModal(false);
    }
  };

  const handleSave = async (updatedData) => {
    try {
      await api.updateProfile(updatedData);
      const updatedProfile = await api.getProfile();
      setProfile(updatedProfile);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-4"
        >
          <Loader2 className="w-12 h-12 animate-spin text-[var(--accent-color)] mx-auto" />
          <p className="text-[var(--text-secondary)]">Loading profile...</p>
        </motion.div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-12">
        <p className="text-[var(--text-secondary)]">{t('profile.errorLoading')}</p>
      </div>
    );
  }

  const joinedDate = new Date(profile.created_at);
  const formattedDate = language === 'en'
    ? `Joined ${joinedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}`
    : `انضم في ${joinedDate.toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' })}`;

  return (
    <>
      <div className="max-w-4xl mx-auto space-y-4 md:space-y-6 p-4 md:p-0">
        {/* Banner and Profile Info Card */}
        <div className="bg-[var(--background)] rounded-2xl md:rounded-3xl overflow-hidden shadow-lg border border-[var(--border-color)]">
          {/* Banner Section */}
          <motion.div
            className="relative h-32 sm:h-48 md:h-64 group"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {profile?.banner_image_url ? (
              <CachedImage
                src={profile.banner_image_url}
                alt="Banner"
                className="w-full h-full object-cover"
                type="banner"
                fallback={
                  <div className="w-full h-full bg-[var(--background-secondary)]" />
                }
              />
            ) : (
              <div className="w-full h-full bg-[var(--background-secondary)]" />
            )}

            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => bannerImageRef.current?.click()}
                disabled={uploading.banner}
                className="bg-black/50 text-white p-3 rounded-full hover:bg-black/70 disabled:opacity-50"
              >
                {uploading.banner ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera size={20} />}
              </button>
              {profile?.banner_image_url && (
                <button
                  onClick={handleDeleteBannerImage}
                  className="bg-red-500/70 text-white p-3 rounded-full hover:bg-red-500/90"
                >
                  <Trash2 size={20} />
                </button>
              )}
            </div>
            <input
              ref={bannerImageRef}
              type="file"
              accept="image/*"
              onChange={handleBannerImageChange}
              className="hidden"
            />
          </motion.div>

          {/* Profile Info Section */}
          <motion.div
            className="relative px-4 md:px-6 pb-4 md:pb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4 -mt-12 sm:-mt-16 md:-mt-20">
              <div className="relative group">
                {profile?.profile_image_url ? (
                  <CachedImage
                    src={profile.profile_image_url}
                    alt={profile?.name}
                    className="w-24 h-24 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-full object-cover border-4 border-[var(--background)] shadow-lg"
                    type="profile"
                    fallback={
                      <div className="w-24 h-24 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-full bg-[var(--background-secondary)] flex items-center justify-center text-2xl sm:text-4xl font-bold border-4 border-[var(--background)] shadow-lg text-[var(--text-secondary)]">
                        {profile?.name?.charAt(0) || 'U'}
                      </div>
                    }
                  />
                ) : (
                  <div className="w-24 h-24 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-full bg-[var(--background-secondary)] flex items-center justify-center text-2xl sm:text-4xl font-bold border-4 border-[var(--background)] shadow-lg text-[var(--text-secondary)]">
                    {profile?.name?.charAt(0) || 'U'}
                  </div>
                )}

                {profile?.verified && (
                  <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-1.5 border-2 border-[var(--background)]">
                    <Check size={16} />
                  </div>
                )}

                <div className="absolute inset-0 bg-black/50 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-2">
                    <button
                      onClick={() => profileImageRef.current?.click()}
                      disabled={uploading.profile}
                      className="p-2 bg-white/20 rounded-full hover:bg-white/30"
                    >
                      {uploading.profile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera size={16} />}
                    </button>
                    {profile?.profile_image_url && (
                      <button
                        onClick={handleDeleteProfileImage}
                        className="p-2 bg-red-500/70 rounded-full hover:bg-red-500/90"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>

                <input
                  ref={profileImageRef}
                  type="file"
                  accept="image/*"
                  onChange={handleProfileImageChange}
                  className="hidden"
                />
              </div>
              <Button
                onClick={() => setShowEditProfile(true)}
                variant="outline"
                className="px-4 md:px-6 py-2 rounded-2xl w-full sm:w-auto"
              >
                <Edit className="w-4 h-4 mr-2" />
                {t('profile.editProfile')}
              </Button>
            </div>

            <div className="mt-4">
              <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-[var(--text-primary)]">
                {profile?.name}
              </h1>
              <p className="text-[var(--text-secondary)] mb-4 text-sm max-w-md">
                {profile?.bio || (language === 'ar' ? 'لا توجد سيرة ذاتية' : 'No bio available')}
              </p>

              <div className="flex flex-wrap items-center gap-3 md:gap-4 text-sm text-[var(--text-secondary)] mb-4">
                {profile?.country && (
                  <div className="flex items-center gap-1">
                    <MapPin size={16} />
                    <span>{findCountryAndGetLocalizedName(profile.country, language)}</span>
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <Calendar size={16} />
                  <span>{formattedDate}</span>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:flex sm:justify-start gap-4 sm:gap-6 text-center">
                <div>
                  <div className="text-lg sm:text-xl font-bold text-[var(--text-primary)]">{profile.statistics?.posts_count || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('profile.posts')}</div>
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-bold text-[var(--text-primary)]">{profile.statistics?.followers_count || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('profile.followers')}</div>
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-bold text-[var(--text-primary)]">{profile.statistics?.following_count || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('profile.following')}</div>
                </div>
                <div>
                  <div className="text-lg sm:text-xl font-bold text-[var(--text-primary)]">{profile.statistics?.reels_count || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('profile.reels')}</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Profile Content Message */}
        <div className="bg-[var(--background)] rounded-2xl md:rounded-3xl overflow-hidden shadow-lg border border-[var(--border-color)] p-4 md:p-8 text-center">
          <h2 className="text-lg md:text-xl font-bold text-[var(--text-primary)] mb-2">
            {language === 'ar' ? 'الملف الشخصي' : 'Profile'}
          </h2>
          <p className="text-sm md:text-base text-[var(--text-secondary)]">
            {language === 'ar' 
              ? 'مرحباً بك في ملفك الشخصي. يمكنك تحرير معلوماتك الشخصية وصورك.'
              : 'Welcome to your profile. You can edit your personal information and images.'
            }
          </p>
        </div>
      </div>

      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
        profile={{ name: profile?.name, bio: profile?.bio, country: profile?.country, username: profile?.username }}
        onSave={handleSave}
      />

      <ImageCropDialog
        isOpen={showCropModal}
        onClose={() => {
          setShowCropModal(false);
          setCropData({ file: null, type: null });
        }}
        imageFile={cropData.file}
        onSave={handleCropComplete}
        cropType={cropData.type}
      />
    </>
  );
}
