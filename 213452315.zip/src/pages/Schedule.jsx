import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Calendar,
  Clock,
  MapPin,
  User,
  GraduationCap,
  TrendingUp,
  Upload,
  CheckCircle2,
  AlertTriangle,
  X,
  Eye,
  EyeOff,
  Loader2,
  FileText,
  Download,
  BarChart3,
  Users,
  Target,
  Award,
  BookOpen,
  Timer,
  Bell,
  ChevronDown,
  ChevronUp,
  CalendarDays,
  Info
} from 'lucide-react';
import { useI18n } from '../components/utils/i18n';
import { scheduleAPI } from '../components/utils/api';

export default function Schedule() {
  const { t } = useI18n();
  
  // State Management
  const [scheduleData, setScheduleData] = useState(null);
  const [nextClass, setNextClass] = useState(null);
  const [upcomingClasses, setUpcomingClasses] = useState([]);
  const [attendanceSummary, setAttendanceSummary] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hasData, setHasData] = useState(false);
  
  // Upload state
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [currentTask, setCurrentTask] = useState(null);
  const [showUpload, setShowUpload] = useState(false);
  
  // UI state
  const [expandedDetails, setExpandedDetails] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  
  const fileInputRef = useRef(null);
  const taskStreamRef = useRef(null);

  useEffect(() => {
    loadScheduleData();
    return () => {
      // Cleanup SSE connection
      if (taskStreamRef.current) {
        taskStreamRef.current.close();
      }
    };
  }, []);

  const loadScheduleData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Check if user has schedule data
      const hasSchedule = await scheduleAPI.hasData();
      setHasData(hasSchedule);

      if (hasSchedule) {
        // Load all schedule data in parallel
        const [general, nextClassData, upcoming, summary] = await Promise.all([
          scheduleAPI.getGeneral().catch(err => {
            console.warn('Failed to load general schedule:', err);
            return null;
          }),
          scheduleAPI.getNextClassWithAttendance().catch(err => {
            console.warn('Failed to load next class:', err);
            return null;
          }),
          scheduleAPI.getUpcoming({ limit: 5, timezone: 'Asia/Muscat' }).catch(err => {
            console.warn('Failed to load upcoming classes:', err);
            return [];
          }),
          scheduleAPI.getAttendanceSummary().catch(err => {
            console.warn('Failed to load attendance summary:', err);
            return null;
          })
        ]);

        setScheduleData(general);
        setNextClass(nextClassData);
        setUpcomingClasses(upcoming?.classes || []);
        setAttendanceSummary(summary);
      }
    } catch (error) {
      console.error('Error loading schedule data:', error);
      if (error.message.includes('Access denied')) {
        setError('Access denied to schedule features. Please contact administrator.');
      } else {
        setError(error.message);
      }
      setHasData(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (files) => {
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadProgress({ status: 'uploading', message: t('schedule.analyzing') });

    try {
      // Upload files with timezone
      const uploadResult = await scheduleAPI.uploadFiles(files, 'Student schedule analysis');
      
      if (uploadResult.task_id) {
        setCurrentTask(uploadResult.task_id);
        setUploadProgress({
          status: 'processing',
          message: t('schedule.analyzing'),
          estimatedTime: uploadResult.estimated_time_minutes || '2-5'
        });

        // Start streaming task progress
        startTaskStreaming(uploadResult.task_id);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      setUploadProgress({
        status: 'error',
        message: error.message || 'Upload failed'
      });
      setIsUploading(false);
    }
  };

  const startTaskStreaming = (taskId) => {
    // Close existing stream
    if (taskStreamRef.current) {
      taskStreamRef.current.close();
    }

    taskStreamRef.current = scheduleAPI.createTaskStream(
      taskId,
      (data) => {
        console.log('Task update:', data);
        
        // Handle progress updates
        if (data.status === 'completed') {
          setUploadProgress({
            status: 'completed',
            message: t('schedule.analysisComplete')
          });
          setIsUploading(false);
          setShowUpload(false);
          
          // Show success message briefly then refresh the page
          setTimeout(() => {
            // Refresh the entire page to show updated data
            window.location.reload();
          }, 1500); // Wait 1.5 seconds to show completion message
          
        } else if (data.status === 'failed') {
          setUploadProgress({
            status: 'error',
            message: data.message || 'Analysis failed'
          });
          setIsUploading(false);
        } else {
          setUploadProgress({
            status: 'processing',
            message: data.message || t('schedule.analyzing'),
            progress: data.progress
          });
        }
      },
      (error) => {
        console.error('Task stream error:', error);
        setUploadProgress({
          status: 'error',
          message: 'Connection lost. Please refresh to check status.'
        });
        setIsUploading(false);
      }
    );
  };

  const handleAttendanceUpdate = async (sessionId, status, notes = '') => {
    try {
      await scheduleAPI.updateAttendance(sessionId, { 
        session_id: sessionId,
        status: status,
        notes: notes 
      });
      // Reload data to reflect changes
      loadScheduleData();
    } catch (error) {
      console.error('Failed to update attendance:', error);
      // Show error to user - you might want to add a toast notification here
    }
  };

  const formatTime = (timeString) => {
    if (!timeString) return '';
    try {
      return new Date(`2000-01-01T${timeString}`).toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    } catch {
      return timeString;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return dateString;
    }
  };

  const getAttendanceStatus = (percentage) => {
    if (percentage >= 85) return { label: t('schedule.good'), color: 'text-green-600' };
    if (percentage >= 75) return { label: t('schedule.warning'), color: 'text-yellow-600' };
    return { label: t('schedule.critical'), color: 'text-red-600' };
  };

  const calculateTimeUntil = (dateTime) => {
    if (!dateTime) return null;
    
    const now = new Date();
    const classTime = new Date(dateTime);
    const diff = classTime - now;
    
    if (diff <= 0) return null;
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="container mx-auto p-3 lg:p-6 space-y-4">
        <div className="text-center py-12">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-[var(--accent-color)]" />
          <p className="text-[var(--text-secondary)]">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error && !hasData) {
    return (
      <div className="container mx-auto p-3 lg:p-6 space-y-4">
        <div className="text-center py-12">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-2">
            {t('common.error')}
          </h3>
          <p className="text-[var(--text-secondary)] mb-4 text-sm">{error}</p>
          <Button onClick={loadScheduleData} size="sm">
            {t('common.retry')}
          </Button>
        </div>
      </div>
    );
  }

  // No data state - show upload interface
  if (!hasData) {
    return (
      <div className="container mx-auto p-3 lg:p-6 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl lg:text-3xl font-bold text-[var(--text-primary)]">
              {t('schedule.title')}
            </h1>
            <p className="text-[var(--text-secondary)] mt-1 text-sm">
              {t('schedule.description')}
            </p>
          </div>
        </div>

        <Card className="bg-[var(--background)] border border-[var(--border-color)]">
          <CardContent className="p-6 lg:p-8 text-center">
            <Upload className="w-12 lg:w-16 h-12 lg:h-16 mx-auto mb-4 text-[var(--text-secondary)]" />
            <h3 className="text-lg lg:text-xl font-semibold text-[var(--text-primary)] mb-2">
              {t('schedule.uploadSchedule')}
            </h3>
            <p className="text-[var(--text-secondary)] mb-6 text-sm">
              {t('schedule.uploadDescription')}
            </p>
            
            {/* Upload Progress */}
            <AnimatePresence>
              {uploadProgress && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="mb-6 p-4 bg-[var(--background-secondary)] rounded-lg"
                >
                  <div className="flex items-center gap-3 mb-2">
                    {uploadProgress.status === 'uploading' && (
                      <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                    )}
                    {uploadProgress.status === 'processing' && (
                      <Timer className="w-5 h-5 text-yellow-500" />
                    )}
                    {uploadProgress.status === 'completed' && (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    )}
                    {uploadProgress.status === 'error' && (
                      <AlertTriangle className="w-5 h-5 text-red-500" />
                    )}
                    <span className="font-medium text-sm">{uploadProgress.message}</span>
                  </div>
                  
                  {uploadProgress.progress && (
                    <Progress value={uploadProgress.progress} className="mb-2" />
                  )}
                  
                  {uploadProgress.estimatedTime && (
                    <p className="text-xs text-[var(--text-secondary)]">
                      Estimated time: {uploadProgress.estimatedTime} minutes
                    </p>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleFileUpload([...e.target.files])}
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              multiple
              className="hidden"
              disabled={isUploading}
            />
            
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              size="lg"
              className="w-full sm:w-auto"
            >
              {isUploading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  {t('schedule.analyzing')}
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5 mr-2" />
                  {t('common.selectFile')}
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main Schedule Interface
  return (
    <div className="container mx-auto p-3 lg:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4">
        <div>
          <h1 className="text-xl lg:text-3xl font-bold text-[var(--text-primary)]">
            {t('schedule.title')}
          </h1>
          <p className="text-[var(--text-secondary)] mt-1 text-sm">
            {t('schedule.description')}
          </p>
        </div>
        
        <Button
          onClick={() => setShowUpload(!showUpload)}
          variant="outline"
          className="w-full lg:w-auto text-sm"
          size="sm"
        >
          <Upload className="w-4 h-4 mr-2" />
          {t('schedule.uploadSchedule')}
        </Button>
      </div>

      {/* Upload Panel */}
      <AnimatePresence>
        {showUpload && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card className="bg-[var(--background-secondary)] border border-[var(--border-color)]">
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold text-[var(--text-primary)] text-sm">
                    {t('schedule.uploadSchedule')}
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowUpload(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="text-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => handleFileUpload([...e.target.files])}
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    multiple
                    className="hidden"
                    disabled={isUploading}
                  />
                  
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="w-full sm:w-auto text-sm"
                    size="sm"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {t('schedule.analyzing')}
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        {t('common.selectFile')}
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Student Info Card */}
      {scheduleData?.student_info && (
        <Card className="bg-[var(--background)] border border-[var(--border-color)]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <User className="w-4 h-4" />
              {t('schedule.studentInfo')}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('academic.student_name')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.student_info.student_name}
                </p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('academic.student_number')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.student_info.student_id}
                </p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('academic.program')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.student_info.program}
                </p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('schedule.currentSemester')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.student_info.semester}
                </p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('academic.branch')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.student_info.institution}
                </p>
              </div>
              <div>
                <p className="text-xs text-[var(--text-secondary)]">{t('schedule.timezone')}</p>
                <p className="font-medium text-[var(--text-primary)] text-sm">
                  {scheduleData.timezone || 'UTC+4'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next Class & Summary Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Next Class */}
        {nextClass && (
          <Card className="bg-[var(--background)] border border-[var(--border-color)]">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Bell className="w-4 h-4" />
                {t('schedule.nextClass')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <div>
                <h3 className="font-semibold text-sm text-[var(--text-primary)]">
                  {nextClass.course_code}
                  {nextClass.course_name && ` - ${nextClass.course_name}`}
                </h3>
                <p className="text-[var(--text-secondary)] text-xs">
                  {nextClass.instructor}
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-3 h-3 text-[var(--text-secondary)]" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">{t('schedule.time')}</p>
                    <p className="font-medium text-[var(--text-primary)] text-xs">
                      {nextClass.start_time} - {nextClass.end_time}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="w-3 h-3 text-[var(--text-secondary)]" />
                  <div>
                    <p className="text-xs text-[var(--text-secondary)]">{t('schedule.location')}</p>
                    <p className="font-medium text-[var(--text-primary)] text-xs">
                      {nextClass.location}
                    </p>
                  </div>
                </div>
              </div>

              {nextClass.time_until && (
                <div className="bg-[var(--background-secondary)] rounded-lg p-3">
                  <p className="text-xs text-[var(--text-secondary)] mb-1">
                    {t('schedule.timeUntil')}
                  </p>
                  <p className="font-semibold text-[var(--accent-color)] text-sm">
                    {nextClass.time_until.human_readable || calculateTimeUntil(nextClass.date + 'T' + nextClass.start_time) || t('schedule.noUpcomingClass')}
                  </p>
                </div>
              )}

              {nextClass.session?.session_id && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleAttendanceUpdate(nextClass.session.session_id, 'attended')}
                    className="flex-1 text-xs"
                  >
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    {t('schedule.present')}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleAttendanceUpdate(nextClass.session.session_id, 'missed')}
                    className="flex-1 text-xs"
                  >
                    <X className="w-3 h-3 mr-1" />
                    {t('schedule.absent')}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Attendance Summary */}
        {attendanceSummary && (
          <Card className="bg-[var(--background)] border border-[var(--border-color)]">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <BarChart3 className="w-4 h-4" />
                {t('schedule.attendance')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-[var(--text-secondary)]">
                    {t('schedule.attendancePercentage')}
                  </span>
                  <span className={`font-semibold text-sm ${getAttendanceStatus(attendanceSummary.overall_summary?.overall_attendance_percentage || 0).color}`}>
                    {attendanceSummary.overall_summary?.overall_attendance_percentage || 0}%
                  </span>
                </div>
                <Progress value={attendanceSummary.overall_summary?.overall_attendance_percentage || 0} className="mb-2" />
                <p className={`text-xs font-medium ${getAttendanceStatus(attendanceSummary.overall_summary?.overall_attendance_percentage || 0).color}`}>
                  {getAttendanceStatus(attendanceSummary.overall_summary?.overall_attendance_percentage || 0).label}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-lg font-bold text-green-600">
                    {attendanceSummary.overall_summary?.attended_sessions || 0}
                  </p>
                  <p className="text-xs text-green-700">{t('schedule.present')}</p>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <p className="text-lg font-bold text-red-600">
                    {attendanceSummary.overall_summary?.missed_sessions || 0}
                  </p>
                  <p className="text-xs text-red-700">{t('schedule.absent')}</p>
                </div>
              </div>

              {attendanceSummary.overall_summary?.warning_level && (
                <div className={`p-3 rounded-lg ${
                  attendanceSummary.overall_summary.warning_level === 'critical' ? 'bg-red-50' :
                  attendanceSummary.overall_summary.warning_level === 'high' ? 'bg-yellow-50' : 'bg-green-50'
                }`}>
                  <p className={`text-xs font-medium ${
                    attendanceSummary.overall_summary.warning_level === 'critical' ? 'text-red-700' :
                    attendanceSummary.overall_summary.warning_level === 'high' ? 'text-yellow-700' : 'text-green-700'
                  }`}>
                    {attendanceSummary.overall_summary.warning_level === 'critical' ? 'Critical: Risk of failure' :
                     attendanceSummary.overall_summary.warning_level === 'high' ? 'Warning: Low attendance' : 'Good attendance'}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Weekly Schedule */}
      {scheduleData?.schedule && (
        <Card className="bg-[var(--background)] border border-[var(--border-color)]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarDays className="w-4 h-4" />
              {t('schedule.weeklySchedule')}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {scheduleData.schedule.map((course) => (
                <div key={course.course_code} className="border border-[var(--border-color)] rounded-lg p-3">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-[var(--text-primary)] text-sm">
                        {course.course_code}
                        {course.course_name && ` - ${course.course_name}`}
                      </h3>
                      <p className="text-xs text-[var(--text-secondary)]">
                        {course.instructor} • {course.credits} {t('schedule.credits')} • {course.section}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {course.fees}
                    </Badge>
                  </div>

                  {course.schedules && course.schedules.map((schedule, idx) => (
                    <div key={idx} className="flex flex-wrap items-center gap-3 text-xs mb-2">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[var(--text-secondary)]" />
                        <span>{schedule.days?.join(', ')}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-[var(--text-secondary)]" />
                        <span>{schedule.time}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[var(--text-secondary)]" />
                        <span>{schedule.location}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upcoming Classes */}
      {upcomingClasses && upcomingClasses.length > 0 && (
        <Card className="bg-[var(--background)] border border-[var(--border-color)]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="w-4 h-4" />
              Upcoming Classes
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              {upcomingClasses.map((classItem, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-[var(--background-secondary)] rounded-lg">
                  <div>
                    <p className="font-medium text-[var(--text-primary)] text-sm">
                      {classItem.course_code}
                    </p>
                    <p className="text-xs text-[var(--text-secondary)]">
                      {formatDate(classItem.date)} • {classItem.start_time}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-[var(--text-secondary)]">
                      {classItem.location}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {classItem.time_until?.human_readable || 'Now'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary Stats */}
      {scheduleData?.summary && (
        <Card className="bg-[var(--background)] border border-[var(--border-color)]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="w-4 h-4" />
              {t('schedule.semesterSummary')}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <p className="text-lg font-bold text-blue-600">
                  {scheduleData.summary.total_courses || 0}
                </p>
                <p className="text-xs text-blue-700">{t('schedule.totalCourses')}</p>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <p className="text-lg font-bold text-purple-600">
                  {scheduleData.summary.total_credits || 0}
                </p>
                <p className="text-xs text-purple-700">{t('schedule.totalCredits')}</p>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <p className="text-lg font-bold text-green-600">
                  {scheduleData.summary.total_weeks || 0}
                </p>
                <p className="text-xs text-green-700">Total Weeks</p>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <p className="text-lg font-bold text-orange-600">
                  {scheduleData.summary.total_fees || '0 OMR'}
                </p>
                <p className="text-xs text-orange-700">{t('schedule.totalFees')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
