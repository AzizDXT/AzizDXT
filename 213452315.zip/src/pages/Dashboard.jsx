
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import SplashScreen from '../components/SplashScreen';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import { createPageUrl } from '@/utils';

// مخزن عام للصفحات المحملة (خارج المكون لضمان البقاء)
const PAGE_CACHE = {};
const CACHE_TIMESTAMPS = {};
const CACHE_DURATION = 60 * 60 * 1000; // ساعة واحدة

export default function Dashboard() {
  const [showSplash, setShowSplash] = useState(!sessionStorage.getItem('splashShown'));
  const { search } = useLocation();
  const navigate = useNavigate();
  
  const urlParams = new URLSearchParams(search);
  const initialTab = urlParams.get('tab') || 'home';
  const [activeTab, setActiveTab] = useState(initialTab);
  
  // حالة التحميل للصفحات
  const [loadingPages, setLoadingPages] = useState({});
  const loadingRef = useRef({});
  // حالة محتوى الصفحة النشطة المحملة
  const [currentPageContent, setCurrentPageContent] = useState(null);

  const { t, language } = useI18n(); // `language` variable is still used for backward compatibility with existing hardcoded strings, though 't' is preferred.

  useEffect(() => {
    const newTab = new URLSearchParams(search).get('tab') || 'home';
    setActiveTab(newTab);
  }, [search, navigate]);
  
  const handleSplashFinish = () => {
    sessionStorage.setItem('splashShown', 'true');
    setShowSplash(false);
  };

  // فحص صحة الكاش
  const isCacheValid = useCallback((tabName) => {
    const timestamp = CACHE_TIMESTAMPS[tabName];
    if (!timestamp) return false;
    
    const now = Date.now();
    return (now - timestamp) < CACHE_DURATION;
  }, []);

  // دالة لتحميل الصفحة وتخزينها مؤقتاً
  const loadPageContent = useCallback(async (tabName) => {
    // فحص الكاش أولاً
    if (PAGE_CACHE[tabName] && isCacheValid(tabName)) {
      console.log(`Using cached page: ${tabName}`);
      return PAGE_CACHE[tabName];
    }

    // منع التحميل المتكرر
    if (loadingRef.current[tabName]) {
      return null;
    }

    loadingRef.current[tabName] = true;
    setLoadingPages(prev => ({...prev, [tabName]: true}));

    try {
      let content;
      
      console.log(`Loading page: ${tabName}`);
      
      switch (tabName) {
        case 'home':
          const Home = (await import('./Home')).default;
          content = <Home key={`home-${Date.now()}`} />;
          break;
        case 'library':
          const Library = (await import('./Library')).default;
          content = <Library key={`library-${Date.now()}`} />;
          break;
        case 'notes':
          const Notes = (await import('./Notes')).default;
          content = <Notes key={`notes-${Date.now()}`} />;
          break;
        case 'tasks':
          const Tasks = (await import('./Tasks')).default;
          content = <Tasks key={`tasks-${Date.now()}`} />;
          break;
        case 'research':
          const Research = (await import('./Research')).default;
          content = <Research key={`research-${Date.now()}`} />;
          break;
        case 'deepwrite':
          const DeepWrite = (await import('./DeepWrite')).default;
          content = <DeepWrite key={`deepwrite-${Date.now()}`} />;
          break;
        case 'cloudstorage':
          const CloudStorage = (await import('./CloudStorage')).default;
          content = <CloudStorage key={`cloudstorage-${Date.now()}`} />;
          break;
        case 'ai':
          const AIAssistant = (await import('./AIAssistant')).default;
          content = <AIAssistant key={`ai-${Date.now()}`} />;
          break;
        case 'schedule':
          const Schedule = (await import('./Schedule')).default;
          content = <Schedule key={`schedule-${Date.now()}`} />;
          break;
        case 'settings':
          const Settings = (await import('../components/dashboard/Settings')).default;
          content = <Settings key={`settings-${Date.now()}`} />;
          break;
        default:
          content = null;
      }

      if (content) {
        PAGE_CACHE[tabName] = content;
        CACHE_TIMESTAMPS[tabName] = Date.now();
        console.log(`Cached page: ${tabName}`);
      }

      return content;
    } catch (error) {
      console.error(`Error loading ${tabName}:`, error);
      return null;
    } finally {
      loadingRef.current[tabName] = false;
      setLoadingPages(prev => ({...prev, [tabName]: false}));
    }
  }, [isCacheValid, setLoadingPages]);

  // Effect to manage dynamic page content loading
  useEffect(() => {
    const dynamicTabs = ['home', 'library', 'notes', 'tasks', 'research', 'deepwrite', 'cloudstorage', 'ai', 'settings', 'schedule'];

    if (dynamicTabs.includes(activeTab)) {
      // If content is already in cache and valid, set it immediately
      if (PAGE_CACHE[activeTab] && isCacheValid(activeTab)) {
        setCurrentPageContent(PAGE_CACHE[activeTab]);
        // Ensure loading state is false if already cached
        if (loadingPages[activeTab]) {
          setLoadingPages(prev => ({...prev, [activeTab]: false}));
        }
      } else {
        // Clear current content, and initiate load if not already loading
        setCurrentPageContent(null);

        // Only initiate load if not already loading this tab
        if (!loadingRef.current[activeTab]) {
          const fetchAndSetContent = async () => {
            const content = await loadPageContent(activeTab);
            // Only set content if this is still the active tab
            // This prevents race conditions if the user switches tabs quickly
            const currentUrlTab = new URLSearchParams(search).get('tab') || 'home';
            if (activeTab === currentUrlTab) {
               setCurrentPageContent(content);
            }
          };
          fetchAndSetContent();
        }
      }
    } else {
      // For static tabs (home), clear currentPageContent
      setCurrentPageContent(null);
    }
  }, [activeTab, search, isCacheValid, loadPageContent, loadingPages, setLoadingPages]);

  const getTabContent = () => {
    switch (activeTab) {
      case 'home':
        // If content is loaded, display it
        if (currentPageContent && activeTab === (new URLSearchParams(search).get('tab') || 'home')) {
          return currentPageContent;
        }
        // Otherwise, show loading spinner
        return (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--accent-color)]"></div>
            <span className="ml-3 text-[var(--text-secondary)]">
              {t('loading')}
            </span>
          </div>
        );
      
      // الصفحات المحفوظة مؤقتاً (الآن تشمل Schedule أيضاً)
      case 'library':
      case 'notes':
      case 'tasks':
      case 'research':
      case 'deepwrite':
      case 'cloudstorage':
      case 'ai':
      case 'settings':
      case 'schedule': // Schedule is now handled like other dynamic tabs
        // If content is loaded, display it
        // Ensure that `currentPageContent` corresponds to the current `activeTab`
        if (currentPageContent && activeTab === (new URLSearchParams(search).get('tab') || 'home')) {
          return currentPageContent;
        }
        // Otherwise, show loading spinner
        return (
          <div className="flex items-center justify-center py-8 md:py-12 p-4 md:p-0">
            <div className="animate-spin rounded-full h-8 w-8 md:h-12 md:w-12 border-b-2 border-[var(--accent-color)]"></div>
            <span className="ml-2 md:ml-3 text-sm md:text-base text-[var(--text-secondary)]">
              {t('loading')} {/* Using 't' for translation */}
            </span>
          </div>
        );

      default:
        return (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4 md:space-y-6 p-4 md:p-0">
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--text-primary)]">{t(`sidebar.${activeTab}`)}</h2>
            <div className="rounded-2xl p-4 md:p-8 border border-[var(--border-color)] bg-[var(--background-secondary)]">
              <p className="text-sm md:text-base text-[var(--text-secondary)]">{t('pageUnderDevelopment')}</p> {/* Using 't' for translation */}
            </div>
          </motion.div>
        );
    }
  };

  if (showSplash) {
    return <SplashScreen onFinish={handleSplashFinish} />;
  }

  return (
    <>
      <AnimatePresence mode="wait">
        <motion.div key={activeTab} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>
          {getTabContent()}
        </motion.div>
      </AnimatePresence>
    </>
  );
}
