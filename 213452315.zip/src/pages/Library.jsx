import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  ArrowLeft,
  BookOpen,
  CheckSquare,
  Search,
  FileText,
  Cloud,
  Zap,
  Plus,
  Calendar,
  Clock,
  TrendingUp,
  ChevronRight,
  Loader2,
  FileIcon,
  Folder,
  User,
  Target,
  Download
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl, createDashboardTabUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';
import api from '../components/utils/api';

export default function Library() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [recentActivity, setRecentActivity] = useState({
    notes: { count: 0, latest: null, loading: true },
    tasks: { pending: 0, latest: null, loading: true },
    research: { active: 0, latest: null, loading: true },
    deepwrite: { processed: 0, latest: null, loading: true },
    cloudstorage: { used: '0GB', latest: null, loading: true },
    schedule: { upcoming: 0, latest: null, loading: true }
  });

  useEffect(() => {
    loadRecentActivity();
  }, []);

  const loadRecentActivity = async () => {
    try {
      // Load Notes - prioritize pinned, then latest
      try {
        const pinnedNotes = await api.post('/api/v1/notes/filter', {
          skip: 0,
          limit: 1,
          pinned: true
        });
        
        let latestNote = null;
        if (pinnedNotes && pinnedNotes.length > 0) {
          latestNote = pinnedNotes[0];
        } else {
          // If no pinned notes, get latest note
          const latestNotes = await api.post('/api/v1/notes/filter', {
            skip: 0,
            limit: 1
          });
          if (latestNotes && latestNotes.length > 0) {
            latestNote = latestNotes[0];
          }
        }

        // Get total notes count
        const allNotes = await api.post('/api/v1/notes/filter', {
          skip: 0,
          limit: 100
        });

        setRecentActivity(prev => ({
          ...prev,
          notes: {
            count: allNotes ? allNotes.length : 0,
            latest: latestNote ? {
              title: latestNote.content ? latestNote.content.substring(0, 50) + '...' : 'Untitled Note',
              date: new Date(latestNote.time_updated || latestNote.time_created),
              pinned: latestNote.meta?.pinned || false
            } : null,
            loading: false
          }
        }));
      } catch (error) {
        console.error('Error loading notes:', error);
        setRecentActivity(prev => ({
          ...prev,
          notes: { ...prev.notes, loading: false }
        }));
      }

      // Load Tasks - prioritize pinned pending, then latest pending
      try {
        const pinnedTasks = await api.post('/api/v1/tasks/filter', {
          skip: 0,
          limit: 1,
          status: "PENDING",
          pinned: true
        });
        
        let latestTask = null;
        if (pinnedTasks && pinnedTasks.length > 0) {
          latestTask = pinnedTasks[0];
        } else {
          // If no pinned pending tasks, get latest pending task
          const pendingTasks = await api.post('/api/v1/tasks/filter', {
            skip: 0,
            limit: 1,
            status: "PENDING"
          });
          if (pendingTasks && pendingTasks.length > 0) {
            latestTask = pendingTasks[0];
          }
        }

        // Get pending tasks count
        const allPendingTasks = await api.post('/api/v1/tasks/filter', {
          skip: 0,
          limit: 100,
          status: "PENDING"
        });

        setRecentActivity(prev => ({
          ...prev,
          tasks: {
            pending: allPendingTasks ? allPendingTasks.length : 0,
            latest: latestTask ? {
              title: latestTask.title,
              date: new Date(latestTask.time_updated || latestTask.time_created),
              priority: latestTask.priority,
              pinned: latestTask.meta?.pinned || false
            } : null,
            loading: false
          }
        }));
      } catch (error) {
        console.error('Error loading tasks:', error);
        setRecentActivity(prev => ({
          ...prev,
          tasks: { ...prev.tasks, loading: false }
        }));
      }

      // Load other sections with mock data for now
      setRecentActivity(prev => ({
        ...prev,
        research: {
          active: 3,
          latest: {
            title: "AI Applications in Healthcare",
            date: new Date(),
            status: 'in_progress'
          },
          loading: false
        },
        deepwrite: {
          processed: 5,
          latest: {
            title: "Research Paper Analysis",
            date: new Date(),
            type: 'summary'
          },
          loading: false
        },
        cloudstorage: {
          used: '2.1GB',
          latest: {
            title: "Lecture Recording.mp4",
            date: new Date(),
            size: '156MB'
          },
          loading: false
        },
        schedule: {
          upcoming: 4,
          latest: {
            title: "Mathematics 101",
            date: new Date(),
            time: '10:00 AM'
          },
          loading: false
        }
      }));

    } catch (error) {
      console.error('Error loading recent activity:', error);
      // Set all to not loading even on error
      setRecentActivity(prev => ({
        notes: { ...prev.notes, loading: false },
        tasks: { ...prev.tasks, loading: false },
        research: { ...prev.research, loading: false },
        deepwrite: { ...prev.deepwrite, loading: false },
        cloudstorage: { ...prev.cloudstorage, loading: false },
        schedule: { ...prev.schedule, loading: false }
      }));
    }
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const libraryItems = [
    {
      title: t('library.notes'),
      description: t('library.notesDescription'),
      icon: <BookOpen className="w-8 h-8 text-blue-600" />,
      path: 'notes',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      stats: recentActivity.notes.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.notes.count} ${t('library.items')}`
      ),
      latest: recentActivity.notes.latest
    },
    {
      title: t('library.tasks'),
      description: t('library.tasksDescription'),
      icon: <CheckSquare className="w-8 h-8 text-green-600" />,
      path: 'tasks',
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      stats: recentActivity.tasks.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.tasks.pending} ${t('tasks.pending')}`
      ),
      latest: recentActivity.tasks.latest
    },
    {
      title: t('library.research'),
      description: t('library.researchDescription'),
      icon: <Search className="w-8 h-8 text-purple-600" />,
      path: 'research',
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      stats: recentActivity.research.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.research.active} active`
      ),
      latest: recentActivity.research.latest
    },
    {
      title: t('library.deepwrite'),
      description: t('library.deepwriteDescription'),
      icon: <FileText className="w-8 h-8 text-orange-600" />,
      path: 'deepwrite',
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50',
      stats: recentActivity.deepwrite.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.deepwrite.processed} processed`
      ),
      latest: recentActivity.deepwrite.latest
    },
    {
      title: t('library.cloudstorage'),
      description: t('library.cloudstorageDescription'),
      icon: <Cloud className="w-8 h-8 text-indigo-600" />,
      path: 'cloudstorage',
      color: 'from-indigo-500 to-indigo-600',
      bgColor: 'bg-indigo-50',
      stats: recentActivity.cloudstorage.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.cloudstorage.used} used`
      ),
      latest: recentActivity.cloudstorage.latest
    },
    {
      title: 'My Schedule',
      description: 'View your academic schedule and track attendance',
      icon: <Calendar className="w-8 h-8 text-teal-600" />,
      path: 'schedule',
      color: 'from-teal-500 to-teal-600',
      bgColor: 'bg-teal-50',
      stats: recentActivity.schedule.loading ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        `${recentActivity.schedule.upcoming} upcoming`
      ),
      latest: recentActivity.schedule.latest
    }
  ];

  const handleNavigation = (path) => {
    const url = createDashboardTabUrl(path);
    navigate(url);
  };

  return (
    <div className="space-y-6 md:space-y-8 p-4 md:p-0">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <BookOpen className="w-4 h-4" />
        <span>{t('breadcrumb.library')}</span>
      </div>

      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-[var(--text-primary)] mb-2">
          {t('library.title')}
        </h1>
        <p className="text-[var(--text-secondary)] text-base md:text-lg">
          {t('library.description')}
        </p>
      </div>

      {/* Library Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {libraryItems.map((item, index) => (
          <motion.div
            key={item.path}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card 
              className="group relative overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer border border-[var(--border-color)] bg-[var(--background)]"
              onClick={() => handleNavigation(item.path)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className={`p-2 md:p-3 rounded-xl ${item.bgColor} group-hover:scale-110 transition-transform duration-300`}>
                    {item.icon}
                  </div>
                  <ChevronRight className="w-4 h-4 md:w-5 md:h-5 text-[var(--text-secondary)] group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <h3 className="font-bold text-base md:text-lg text-[var(--text-primary)] mb-2 group-hover:text-[var(--accent-color)] transition-colors">
                  {item.title}
                </h3>
                <p className="text-[var(--text-secondary)] text-sm mb-4 line-clamp-2">
                  {item.description}
                </p>
                
                {/* Stats */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs md:text-sm font-medium text-[var(--text-primary)]">
                    {item.stats}
                  </span>
                  <TrendingUp className="w-3 h-3 md:w-4 md:h-4 text-green-500" />
                </div>

                {/* Latest Activity */}
                {item.latest && !recentActivity[item.path]?.loading && (
                  <div className="pt-3 border-t border-[var(--border-color)]">
                    <div className="flex items-center gap-2 text-xs text-[var(--text-secondary)]">
                      <Clock className="w-3 h-3 flex-shrink-0" />
                      <span>{formatTimeAgo(item.latest.date)}</span>
                      {item.latest.pinned && <span className="text-yellow-600">📌</span>}
                    </div>
                    <p className="text-xs md:text-sm text-[var(--text-primary)] mt-1 truncate">
                      {item.latest.title}
                    </p>
                  </div>
                )}
              </CardContent>

              {/* Gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${item.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <Card className="border border-[var(--border-color)] bg-[var(--background)]">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-[var(--text-primary)]">
            <Plus className="w-5 h-5" />
            {t('library.quickActions')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button
              variant="outline"
              className="flex items-center gap-2 h-12"
              onClick={() => handleNavigation('notes')}
            >
              <BookOpen className="w-4 h-4" />
              New Note
            </Button>
            <Button
              variant="outline"
              className="flex items-center gap-2 h-12"
              onClick={() => handleNavigation('tasks')}
            >
              <CheckSquare className="w-4 h-4" />
              Add Task
            </Button>
            <Button
              variant="outline"
              className="flex items-center gap-2 h-12"
              onClick={() => handleNavigation('research')}
            >
              <Search className="w-4 h-4" />
              Start Research
            </Button>
            <Button
              variant="outline"
              className="flex items-center gap-2 h-12"
              onClick={() => handleNavigation('cloudstorage')}
            >
              <Cloud className="w-4 h-4" />
              Upload File
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
