

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from '../components/dashboard/Sidebar';
import AppProviders from '../components/AppProviders';
import PWAInstallPrompt from '../components/PWAInstallPrompt';
import { useI18n } from '../components/utils/i18n';
import { notificationManager } from '../components/utils/notificationManager';
import DebugCenter from '../components/debug/DebugCenter';

function LayoutContent({ children, currentPageName }) {
  const [isMobile, setIsMobile] = useState(false);
  const [showDebugCenter, setShowDebugCenter] = useState(false);
  const { isRTL } = useI18n();

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Setup Debug Center event listener
  useEffect(() => {
    const handleOpenDebugCenter = () => {
      setShowDebugCenter(true);
    };

    window.addEventListener('openDebugCenter', handleOpenDebugCenter);
    return () => {
      window.removeEventListener('openDebugCenter', handleOpenDebugCenter);
    };
  }, []);

  // Initialize cross-domain cookie support on app load
  useEffect(() => {
    // Check if we have token in localStorage but not in cookie (migration)
    const localToken = localStorage.getItem('taleb-access-token') || localStorage.getItem('access_token');
    const cookieToken = document.cookie.split('; ').find(row => row.startsWith('access_token='));
    
    if (localToken && !cookieToken) {
      // Migrate token to cross-domain cookie
      const setCrossDomainCookie = (name, value, days = 30) => {
        try {
          const expires = new Date();
          expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
          const domain = '.taleb.run';
          // Changed SameSite from Lax to None for cross-site compatibility, essential for redirects
          const cookieString = `${name}=${value}; expires=${expires.toUTCString()}; path=/; domain=${domain}; SameSite=None; Secure`;
          document.cookie = cookieString;
        } catch (error) {
          console.error(`Error setting cookie '${name}':`, error);
        }
      };
      
      setCrossDomainCookie('access_token', localToken, 30);
      // Add Authorization cookie for storage pool redirects
      setCrossDomainCookie('Authorization', `Bearer ${localToken}`, 30);
    }
  }, []);

  // Initialize notifications
  useEffect(() => {
    notificationManager.initialize();
  }, []);

  // Setup PWA
  useEffect(() => {
    // Create and inject manifest
    const manifest = {
      name: "Taleb",
      short_name: "Taleb",
      description: "Taleb is a platform for students to manage their academic life, connect with peers, and enhance their learning experience.",
      start_url: "/",
      display: "standalone",
      background_color: "#ffffff",
      theme_color: "#212121",
      orientation: "portrait-primary",
      scope: "/",
      lang: "ar",
      dir: "rtl",
      icons: [
        {
          src: "/logo.png",
          sizes: "192x192",
          type: "image/png",
          purpose: "maskable"
        },
        {
          src: "/logo.png",
          sizes: "512x512",
          type: "image/png",
          purpose: "any"
        }
      ],
      categories: ["education", "productivity", "social"],
      shortcuts: [
        {
          name: "Profile",
          short_name: "Profile",
          description: "View your profile",
          url: "/Profile",
          icons: [
            {
              src: "/logo.png",
              sizes: "96x96"
            }
          ]
        }
      ],
      prefer_related_applications: false
    };

    // Create manifest link
    const manifestBlob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
    const manifestUrl = URL.createObjectURL(manifestBlob);
    const manifestLink = document.createElement('link');
    manifestLink.rel = 'manifest';
    manifestLink.href = manifestUrl;
    document.head.appendChild(manifestLink);

    // Register service worker inline
    if ('serviceWorker' in navigator) {
      const swCode = `
        const CACHE_NAME = 'taleb-v1';
        const urlsToCache = [
          '/',
          '/logo.png'
        ];

        self.addEventListener('install', (event) => {
          event.waitUntil(
            caches.open(CACHE_NAME)
              .then((cache) => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache).catch(err => console.log('Cache addAll failed:', err));
              })
          );
        });

        self.addEventListener('fetch', (event) => {
          event.respondWith(
            caches.match(event.request)
              .then((response) => {
                if (response) {
                  return response;
                }
                return fetch(event.request);
              }
            )
          );
        });

        self.addEventListener('activate', (event) => {
          event.waitUntil(
            caches.keys().then((cacheNames) => {
              return Promise.all(
                cacheNames.map((cacheName) => {
                  if (cacheName !== CACHE_NAME) {
                    return caches.delete(cacheName);
                  }
                })
              );
            })
          );
        });
      `;

      const swBlob = new Blob([swCode], { type: 'application/javascript' });
      const swUrl = URL.createObjectURL(swBlob);
      
      navigator.serviceWorker.register(swUrl)
        .then((registration) => {
          console.log('SW registered: ', registration);
        })
        .catch((registrationError) => {
          console.log('SW registration failed: ', registrationError);
        });
    }

    // Add meta tags for PWA
    const metaTags = [
      { name: 'mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-status-bar-style', content: 'default' },
      { name: 'apple-mobile-web-app-title', content: 'طالب' },
      { name: 'application-name', content: 'طالب' },
      { name: 'msapplication-TileColor', content: '#212121' },
      { name: 'theme-color', content: '#212121' }
    ];

    metaTags.forEach(tag => {
      const meta = document.createElement('meta');
      meta.name = tag.name;
      meta.content = tag.content;
      document.head.appendChild(meta);
    });

    // Apple touch icons
    const appleTouchIcon = document.createElement('link');
    appleTouchIcon.rel = 'apple-touch-icon';
    appleTouchIcon.href = '/logo.png';
    document.head.appendChild(appleTouchIcon);

    // Cleanup
    return () => {
      URL.revokeObjectURL(manifestUrl);
    };
  }, []);

  // إظهار الشريط الجانبي في جميع الصفحات عدا صفحة تسجيل الدخول
  const pagesWithoutSidebar = ['Auth'];
  const showSidebar = !pagesWithoutSidebar.includes(currentPageName);

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <style>
        {`
          @font-face {
            font-family: 'IBMPlexSansArabic';
            src: url('/src/assets/fonts/IBMPlexSansArabic.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
            unicode-range: U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF, U+0660-0669;
          }
          
          @font-face {
            font-family: 'Nekst';
            src: url('/src/assets/fonts/Nekst.otf') format('truetype');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
            unicode-range: U+0000-00FF, U+0100-017F, U+0180-024F, U+1E00-1EFF, U+2000-206F, U+20A0-20CF, U+2100-214F, U+2190-21FF, U+0030-0039;
          }

          *, body, html {
            font-family: 'Nekst', 'IBMPlexSansArabic', system-ui, sans-serif;
          }

          :root {
            --background: #ffffff;
            --background-secondary: #f9fafb;
            --background-tertiary: #f3f4f6;
            --text-primary: #212121;
            --text-secondary: #6b7280;
            --text-muted: #9ca3af;
            --border-color: #e5e7eb;
            --accent-color: #212121;
            --accent-text-color: #ffffff;
            --shadow-light: rgba(0, 0, 0, 0.05);
            --shadow-medium: rgba(0, 0, 0, 0.1);
            --shadow-heavy: rgba(0, 0, 0, 0.25);
          }

          [data-theme="dark"] {
            --background: #0a0a0a;
            --background-secondary: #121212;
            --background-tertiary: #1a1a1a;
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
            --text-muted: #94a3b8;
            --border-color: #0d0d0d;
            --accent-color: #f8fafc;
            --accent-text-color: #0a0a0a;
            --shadow-light: rgba(255, 255, 255, 0.05);
            --shadow-medium: rgba(255, 255, 255, 0.1);
            --shadow-heavy: rgba(255, 255, 255, 0.2);
          }

          /* Mobile optimizations - تصغير 10% */
          @media (max-width: 768px) {
            .container {
              padding: 0.8rem; /* تصغير من 1rem */
            }
            
            .text-responsive {
              font-size: 0.75rem; /* تصغير من 0.875rem */
            }
            
            .card-mobile {
              border-radius: 0.8rem; /* تصغير من 1rem */
              padding: 0.8rem; /* تصغير من 1rem */
            }
            
            .button-mobile {
              height: 2.4rem; /* تصغير من 2.75rem */
              font-size: 0.75rem; /* تصغير من 0.875rem */
            }
            
            .input-mobile {
              height: 2.4rem; /* تصغير من 2.75rem */
              font-size: 0.9rem; /* تصغير من 1rem */
            }

            /* Optimize text sizes for mobile - تصغير 10% */
            h1 { font-size: 1.35rem !important; } /* تصغير من 1.5rem */
            h2 { font-size: 1.125rem !important; } /* تصغير من 1.25rem */
            h3 { font-size: 1rem !important; } /* تصغير من 1.125rem */
            
            /* Better touch targets */
            button, .button {
              min-height: 40px; /* تصغير من 44px */
              min-width: 40px; /* تصغير من 44px */
            }
            
            /* Improve spacing - تصغير 10% */
            .space-y-6 > * + * { margin-top: 0.9rem !important; } /* تصغير من 1rem */
            .space-y-4 > * + * { margin-top: 0.65rem !important; } /* تصغير من 0.75rem */
            
            /* Mobile-first padding - تصغير 10% */
            .p-6 { padding: 0.9rem !important; } /* تصغير من 1rem */
            .p-8 { padding: 1.35rem !important; } /* تصغير من 1.5rem */
            .px-6 { padding-left: 0.9rem !important; padding-right: 0.9rem !important; } /* تصغير من 1rem */
            .py-6 { padding-top: 0.9rem !important; padding-bottom: 0.9rem !important; } /* تصغير من 1rem */
            
            /* تحسين الـ sidebar في الهاتف */
            .mobile-sidebar-bottom {
              position: fixed !important;
              bottom: 0 !important;
              left: 0 !important;
              right: 0 !important;
              top: auto !important;
              height: auto !important;
              width: 100% !important;
              flex-direction: row !important;
              background: var(--background) !important;
              border-top: 1px solid var(--border-color) !important;
              border-radius: 0 !important;
              z-index: 1000 !important;
              padding: 0.6rem 0.8rem !important; /* تصغير padding */
              box-shadow: 0 -2px 10px rgba(0,0,0,0.1) !important;
            }
          }

          /* تحسين الانيميشن للهاتف */
          @media (max-width: 768px) {
            .motion-reduce {
              animation-duration: 0.01ms !important;
              animation-iteration-count: 1 !important;
              transition-duration: 0.01ms !important;
            }
            
            * {
              animation-duration: 0.2s !important;
              transition-duration: 0.2s !important;
            }
          }

          /* PWA styles */
          @media all and (display-mode: standalone) {
            body {
              -webkit-user-select: none;
              -webkit-touch-callout: none;
              -webkit-tap-highlight-color: transparent;
            }
            
            .browser-only {
              display: none !important;
            }
          }
          
          /* iOS specific styles */
          @supports (-webkit-touch-callout: none) {
            .ios-safe-area {
              padding-bottom: env(safe-area-inset-bottom);
              padding-top: env(safe-area-inset-top);
            }
            
            .ios-safe-bottom {
              padding-bottom: calc(env(safe-area-inset-bottom) + 0.9rem); /* تصغير من 1rem */
            }
          }
        `}
      </style>
      
      {showSidebar ? (
        <div className={`flex min-h-screen relative overflow-hidden ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Sidebar 
            currentPageName={currentPageName} 
            isMobile={isMobile}
          />
          <main className="flex-1 transition-all duration-200" style={{
            paddingLeft: !isMobile ? (isRTL ? '0' : '80px') : '0',
            paddingRight: !isMobile ? (isRTL ? '80px' : '0') : '0',
            paddingBottom: isMobile ? '70px' : '0',
          }}>
            <div className={`p-3 sm:p-4 lg:p-6 ${isMobile ? 'pb-16 ios-safe-bottom' : ''}`}>
              {children}
            </div>
          </main>
        </div>
      ) : (
        <div className="ios-safe-area">
          {children}
        </div>
      )}

      <PWAInstallPrompt />
      
      {/* Debug Center */}
      <DebugCenter 
        isOpen={showDebugCenter} 
        onClose={() => setShowDebugCenter(false)} 
      />
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <LayoutContent currentPageName={currentPageName}>
      {children}
    </LayoutContent>
  );
}

