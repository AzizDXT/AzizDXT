
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Plus,
  Search,
  Filter,
  MoreVertical,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Circle,
  Pin,
  PinOff,
  Edit,
  Trash2,
  Tag,
  Paperclip,
  Play,
  Pause,
  X,
  ChevronDown,
  ChevronUp,
  Star,
  Timer,
  Target,
  TrendingUp,
  ChevronRight,
  Loader2,
  BookOpen,
  User,
  Briefcase,
  GraduationCap,
  Home,
  Palette,
  Eye,
  Hash,
  Save
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';
import { tasksAPI } from '../components/utils/api';

// Categories Sidebar Component
const CategoriesSidebar = ({ tasks, selectedCategory, onCategorySelect, className = "" }) => {
  const { t } = useI18n();
  
  // Extract categories from tasks
  const categories = React.useMemo(() => {
    const categoryCount = {};
    tasks.forEach(task => {
      if (task.meta?.tags) {
        task.meta.tags.forEach(tag => {
          categoryCount[tag] = (categoryCount[tag] || 0) + 1;
        });
      }
    });
    return Object.entries(categoryCount).map(([name, count]) => ({ name, count }));
  }, [tasks]);

  const getCategoryIcon = (category) => {
    switch (category.toLowerCase()) {
      case 'work': return <Briefcase className="w-4 h-4" />;
      case 'academic': return <GraduationCap className="w-4 h-4" />;
      case 'personal': return <User className="w-4 h-4" />;
      case 'study': return <BookOpen className="w-4 h-4" />;
      default: return <Tag className="w-4 h-4" />;
    }
  };

  return (
    <div className={`bg-[var(--background)] border border-[var(--border-color)] rounded-xl p-4 ${className}`}>
      <div className="mb-4">
        <h3 className="font-semibold text-[var(--text-primary)] mb-3 flex items-center gap-2">
          <Tag className="w-4 h-4" />
          {t('tasks.categories')}
        </h3>

        <button
          onClick={() => onCategorySelect('')}
          className={`w-full text-left px-3 py-2 rounded-lg transition-colors mb-2 ${
            selectedCategory === ''
              ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)]'
              : 'hover:bg-[var(--background-secondary)] text-[var(--text-secondary)]'
          }`}
        >
          {t('tasks.filters.all')}
        </button>
      </div>

      <div className="space-y-1 max-h-80 overflow-y-auto">
        {categories.map((category, index) => (
          <button
            key={index}
            onClick={() => onCategorySelect(category.name)}
            className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 text-sm ${
              selectedCategory === category.name
                ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)]'
                : 'hover:bg-[var(--background-secondary)] text-[var(--text-secondary)]'
            }`}
          >
            {getCategoryIcon(category.name)}
            <span className="flex-1 truncate">{category.name}</span>
            <Badge variant="outline" className="ml-auto">
              {category.count}
            </Badge>
          </button>
        ))}
      </div>

      {categories.length === 0 && (
        <div className="text-center py-8 text-[var(--text-secondary)]">
          <Tag className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">{t('tasks.noCategories')}</p>
        </div>
      )}
    </div>
  );
};

// Task Preview Modal Component
const TaskPreviewModal = ({ isOpen, task, onClose, onSave, onDelete }) => {
  const { t } = useI18n();
  const [isEditing, setIsEditing] = useState(false);
  const [localTask, setLocalTask] = useState(task);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setLocalTask(task);
    setIsEditing(false);
  }, [task]);

  const handleSubtaskToggle = async (subtaskIndex) => {
    if (!localTask || isEditing) return;

    const updatedSubtasks = [...localTask.meta.subtasks];
    updatedSubtasks[subtaskIndex] = {
      ...updatedSubtasks[subtaskIndex],
      completed: !updatedSubtasks[subtaskIndex].completed
    };

    const updatedTask = {
      ...localTask,
      meta: {
        ...localTask.meta,
        subtasks: updatedSubtasks
      }
    };

    try {
      const result = await onSave(localTask.id, updatedTask);
      setLocalTask(result);
    } catch (error) {
      console.error('Error updating subtask:', error);
    }
  };

  const handleSave = async () => {
    if (!localTask.title.trim()) return;

    setIsSaving(true);
    try {
      const result = await onSave(localTask.id, localTask);
      setLocalTask(result);
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving task:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH': return 'text-red-600 bg-red-50 border-red-200';
      case 'MEDIUM': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'LOW': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'COMPLETED': return 'text-green-600 bg-green-50 border-green-200';
      case 'PENDING': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'OVERDUE': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  if (!isOpen || !localTask) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-xl w-full max-w-2xl max-h-[90vh] overflow-hidden border border-[var(--border-color)] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
          <div className="flex items-center gap-3">
            <div
              className="w-4 h-4 rounded-full border border-gray-300"
              style={{ backgroundColor: localTask.meta?.color || '#121212' }}
            />
            {isEditing ? (
              <Input
                value={localTask.title}
                onChange={(e) => setLocalTask({...localTask, title: e.target.value})}
                className="text-xl font-bold bg-transparent border-none p-0 h-auto"
                placeholder={t('tasks.edit.titlePlaceholder')}
              />
            ) : (
              <h2 className="text-xl font-bold text-[var(--text-primary)]">
                {localTask.title}
              </h2>
            )}
            {localTask.meta?.pinned && (
              <Pin className="w-4 h-4 text-yellow-500" />
            )}
          </div>
          <div className="flex items-center gap-2">
            {!isEditing && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
              >
                <Edit className="w-4 h-4 mr-2" />
                {t('common.edit')}
              </Button>
            )}
            <button
              onClick={onClose}
              className="p-2 hover:bg-[var(--background-secondary)] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Status and Priority */}
          <div className="flex flex-wrap gap-3">
            {isEditing ? (
              <div className="flex gap-3">
                <Select 
                  value={localTask.status} 
                  onValueChange={(value) => setLocalTask({...localTask, status: value})}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PENDING">{t('tasks.pending')}</SelectItem>
                    <SelectItem value="COMPLETED">{t('tasks.completed')}</SelectItem>
                    <SelectItem value="OVERDUE">{t('tasks.overdueTasks')}</SelectItem>
                  </SelectContent>
                </Select>
                <Select 
                  value={localTask.priority} 
                  onValueChange={(value) => setLocalTask({...localTask, priority: value})}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LOW">{t('tasks.low')}</SelectItem>
                    <SelectItem value="MEDIUM">{t('tasks.medium')}</SelectItem>
                    <SelectItem value="HIGH">{t('tasks.high')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <>
                <Badge className={getStatusColor(localTask.status)}>
                  {localTask.status === 'COMPLETED' ? t('tasks.completed') :
                   localTask.status === 'PENDING' ? t('tasks.pending') :
                   localTask.status === 'OVERDUE' ? t('tasks.overdueTasks') :
                   localTask.status}
                </Badge>
                <Badge className={getPriorityColor(localTask.priority)}>
                  {localTask.priority === 'HIGH' ? t('tasks.high') :
                   localTask.priority === 'MEDIUM' ? t('tasks.medium') :
                   t('tasks.low')}
                </Badge>
                {localTask.task_id && (
                  <Badge variant="outline">ID: {localTask.task_id}</Badge>
                )}
              </>
            )}
          </div>

          {/* Description */}
          <div>
            <h3 className="font-medium text-[var(--text-primary)] mb-2">{t('tasks.edit.descriptionLabel')}</h3>
            {isEditing ? (
              <Textarea
                value={localTask.description || ''}
                onChange={(e) => setLocalTask({...localTask, description: e.target.value})}
                placeholder={t('tasks.edit.descriptionPlaceholder')}
                className="h-24"
              />
            ) : (
              <p className="text-[var(--text-secondary)] bg-[var(--background-secondary)] p-4 rounded-lg">
                {localTask.description || t('tasks.noDescription')}
              </p>
            )}
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(localTask.due_date || isEditing) && (
              <div className="flex items-center gap-2 p-3 bg-[var(--background-secondary)] rounded-lg">
                <Calendar className="w-4 h-4 text-blue-500" />
                <div className="flex-1">
                  <p className="text-xs text-[var(--text-secondary)]">{t('tasks.dueDate')}</p>
                  {isEditing ? (
                    <Input
                      type="date"
                      value={localTask.due_date ? localTask.due_date.split('T')[0] : ''}
                      onChange={(e) => setLocalTask({
                        ...localTask, 
                        due_date: e.target.value ? new Date(e.target.value).toISOString() : null
                      })}
                      className="h-6 p-0 border-none bg-transparent font-medium"
                    />
                  ) : (
                    <p className="font-medium text-[var(--text-primary)]">{formatDateTime(localTask.due_date)}</p>
                  )}
                </div>
              </div>
            )}
            {(localTask.reminder_date || isEditing) && (
              <div className="flex items-center gap-2 p-3 bg-[var(--background-secondary)] rounded-lg">
                <Clock className="w-4 h-4 text-orange-500" />
                <div className="flex-1">
                  <p className="text-xs text-[var(--text-secondary)]">{t('tasks.reminderDate')}</p>
                  {isEditing ? (
                    <Input
                      type="date"
                      value={localTask.reminder_date ? localTask.reminder_date.split('T')[0] : ''}
                      onChange={(e) => setLocalTask({
                        ...localTask, 
                        reminder_date: e.target.value ? new Date(e.target.value).toISOString() : null
                      })}
                      className="h-6 p-0 border-none bg-transparent font-medium"
                    />
                  ) : (
                    <p className="font-medium text-[var(--text-primary)]">{formatDateTime(localTask.reminder_date)}</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Progress */}
          {localTask.completion_percentage > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-[var(--text-primary)]">{t('tasks.progress')}</h3>
                <span className="text-sm text-[var(--text-secondary)]">{localTask.completion_percentage}%</span>
              </div>
              <Progress value={localTask.completion_percentage} className="h-2" />
            </div>
          )}

          {/* Tags */}
          <div>
            <h3 className="font-medium text-[var(--text-primary)] mb-3">{t('tasks.edit.tagsLabel')}</h3>
            {isEditing ? (
              <Input
                value={localTask.meta?.tags?.join(', ') || ''}
                onChange={(e) => setLocalTask({
                  ...localTask,
                  meta: {
                    ...localTask.meta,
                    tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag)
                  }
                })}
                placeholder={t('tasks.addTag')}
              />
            ) : (
              <div className="flex flex-wrap gap-2">
                {localTask.meta?.tags && localTask.meta.tags.length > 0 ? (
                  localTask.meta.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="flex items-center gap-1">
                      <Hash className="w-3 h-3" />
                      {tag}
                    </Badge>
                  ))
                ) : (
                  <p className="text-[var(--text-secondary)]">{t('tasks.noTags')}</p>
                )}
              </div>
            )}
          </div>

          {/* Subtasks */}
          {localTask.meta?.subtasks && localTask.meta.subtasks.length > 0 && (
            <div>
              <h3 className="font-medium text-[var(--text-primary)] mb-3">{t('tasks.subtaskTitle')}</h3>
              <div className="space-y-2">
                {localTask.meta.subtasks.map((subtask, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 bg-[var(--background-secondary)] rounded-lg hover:bg-[var(--background-tertiary)] transition-colors"
                  >
                    <button
                      onClick={() => handleSubtaskToggle(index)}
                      className="flex-shrink-0"
                      disabled={isEditing}
                    >
                      {subtask.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      ) : (
                        <Circle className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                    <span className={`flex-1 ${subtask.completed ? 'line-through text-[var(--text-secondary)]' : 'text-[var(--text-primary)]'}`}>
                      {subtask.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Timestamps */}
          <div className="pt-4 border-t border-[var(--border-color)]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-[var(--text-secondary)]">
              <div>
                <p className="font-medium">Created</p>
                <p>{formatDateTime(localTask.time_created)}</p>
              </div>
              <div>
                <p className="font-medium">Last Updated</p>
                <p>{formatDateTime(localTask.time_updated)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between p-6 border-t border-[var(--border-color)] bg-[var(--background-secondary)] gap-4">
          <div className="flex items-center gap-2">
            {localTask.meta?.estimated_duration > 0 && ( // Display duration only if > 0
              <div className="flex items-center gap-1 text-sm text-[var(--text-secondary)]">
                <Timer className="w-4 h-4" />
                <span>{Math.floor(localTask.meta.estimated_duration / 60)} {t('tasks.minutes')}</span>
              </div>
            )}
            {localTask?.id && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => onDelete(localTask.id)}
                disabled={isSaving}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {t('common.delete')}
              </Button>
            )}
          </div>
          {isEditing && ( // Save and Cancel buttons only visible when editing
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setLocalTask(task); // Revert changes
                  setIsEditing(false); // Exit editing mode
                }}
                disabled={isSaving}
                className="min-w-20"
              >
                {t('common.cancel')}
              </Button>
              <Button
                onClick={handleSave} // Calls handleSave to persist changes
                disabled={isSaving || !localTask.title?.trim()}
                className="min-w-24"
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {isSaving ? t('tasks.edit.saving') : t('tasks.edit.save')}
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

// Task Item Component
const TaskItem = ({ task, onEdit, onDelete, onComplete, onTogglePin, onUpdate, onView }) => {
  const { t } = useI18n();

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH': return 'text-red-600 bg-red-50 border-red-200';
      case 'MEDIUM': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'LOW': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'COMPLETED': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'PENDING': return <Circle className="w-5 h-5 text-gray-400" />;
      case 'OVERDUE': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const handleStatusToggle = async () => {
    const newStatus = task.status === 'COMPLETED' ? 'PENDING' : 'COMPLETED';
    try {
      if (newStatus === 'COMPLETED') {
        await onComplete(task.id, { completion_percentage: 100 });
      } else {
        await onUpdate(task.id, { status: newStatus, completion_percentage: 0 });
      }
    } catch (error) {
      console.error('Error updating task status:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      layout
    >
      <Card className="cursor-pointer hover:shadow-lg transition-shadow border border-[var(--border-color)] relative">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1" onClick={() => onView(task)}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleStatusToggle();
                }}
                className="mt-1 hover:scale-110 transition-transform"
              >
                {getStatusIcon(task.status)}
              </button>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-3">
                  <div
                    className="w-3 h-3 rounded-full border border-gray-300 flex-shrink-0"
                    style={{ backgroundColor: task.meta?.color || '#121212' }}
                  />
                  {task.meta?.pinned && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">
                      <Pin className="w-3 h-3" />
                      <span>{t('tasks.pin')}</span>
                    </div>
                  )}
                  <span className="text-xs text-[var(--text-secondary)]">
                    {formatDate(task.time_updated)}
                  </span>
                </div>

                <h3 className={`font-semibold text-[var(--text-primary)] mb-2 ${task.status === 'COMPLETED' ? 'line-through opacity-60' : ''}`}>
                  {task.title}
                </h3>

                {task.description && (
                  <p className="text-[var(--text-secondary)] mb-4 line-clamp-2">
                    {task.description}
                  </p>
                )}

                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge className={getPriorityColor(task.priority)}>
                    {task.priority === 'HIGH' ? t('tasks.high') : 
                     task.priority === 'MEDIUM' ? t('tasks.medium') : 
                     t('tasks.low')}
                  </Badge>

                  {task.due_date && (
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(task.due_date)}
                    </Badge>
                  )}

                  {task.meta?.subtasks && task.meta.subtasks.length > 0 && (
                    <Badge variant="outline">
                      {task.meta.subtasks.filter(st => st.completed).length}/{task.meta.subtasks.length} {t('tasks.subtasks')}
                    </Badge>
                  )}
                </div>

                {task.meta?.tags && task.meta.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {task.meta.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        <Hash className="w-3 h-3 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-2 ml-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onTogglePin(task.id, !task.meta?.pinned);
                }}
                className="h-8 w-8"
              >
                {task.meta?.pinned ?
                  <PinOff className="w-4 h-4 text-yellow-500" /> :
                  <Pin className="w-4 h-4" />
                }
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(task);
                }}
                className="h-8 w-8"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(task.id);
                }}
                className="h-8 w-8 text-red-500 hover:bg-red-100"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Task Editor Modal
const TaskEditorModal = ({ isOpen, task, onClose, onSave }) => {
  const { t } = useI18n();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    due_date: '',
    reminder_date: '',
    priority: 'MEDIUM',
    meta: {
      tags: [],
      color: '#121212',
      pinned: false,
      attachments: [],
      subtasks: [],
      estimated_duration: 0,
      actual_duration: 0
    }
  });
  const [newTag, setNewTag] = useState('');
  const [newSubtask, setNewSubtask] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title || '',
        description: task.description || '',
        due_date: task.due_date ? task.due_date.split('T')[0] : '',
        reminder_date: task.reminder_date ? task.reminder_date.split('T')[0] : '',
        priority: task.priority || 'MEDIUM',
        meta: {
          tags: task.meta?.tags || [],
          color: task.meta?.color || '#121212',
          pinned: task.meta?.pinned || false,
          attachments: task.meta?.attachments || [],
          subtasks: task.meta?.subtasks || [],
          estimated_duration: task.meta?.estimated_duration || 0,
          actual_duration: task.meta?.actual_duration || 0
        }
      });
    } else {
      setFormData({
        title: '',
        description: '',
        due_date: '',
        reminder_date: '',
        priority: 'MEDIUM',
        meta: {
          tags: [],
          color: '#121212',
          pinned: false,
          attachments: [],
          subtasks: [],
          estimated_duration: 0,
          actual_duration: 0
        }
      });
    }
  }, [task]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    setIsLoading(true);
    try {
      const taskData = {
        ...formData,
        due_date: formData.due_date ? new Date(formData.due_date).toISOString() : null,
        reminder_date: formData.reminder_date ? new Date(formData.reminder_date).toISOString() : null,
        meta: {
          ...formData.meta,
          estimated_duration: parseInt(formData.meta.estimated_duration) * 60
        }
      };

      await onSave(taskData);
      onClose();
    } catch (error) {
      console.error('Error saving task:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addTag = () => {
    if (newTag.trim() && !formData.meta.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        meta: {
          ...formData.meta,
          tags: [...formData.meta.tags, newTag.trim()]
        }
      });
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove) => {
    setFormData({
      ...formData,
      meta: {
        ...formData.meta,
        tags: formData.meta.tags.filter(tag => tag !== tagToRemove)
      }
    });
  };

  const addSubtask = () => {
    if (newSubtask.trim()) {
      setFormData({
        ...formData,
        meta: {
          ...formData.meta,
          subtasks: [...formData.meta.subtasks, { title: newSubtask.trim(), completed: false }]
        }
      });
      setNewSubtask('');
    }
  };

  const removeSubtask = (index) => {
    setFormData({
      ...formData,
      meta: {
        ...formData.meta,
        subtasks: formData.meta.subtasks.filter((_, i) => i !== index)
      }
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-xl w-full max-w-2xl max-h-[90vh] overflow-hidden border border-[var(--border-color)]"
      >
        <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
          <h2 className="text-xl font-bold text-[var(--text-primary)]">
            {task ? t('tasks.edit.editTitle') : t('tasks.edit.createTitle')}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-[var(--background-secondary)] rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('tasks.edit.titleLabel')}
            </label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder={t('tasks.edit.titlePlaceholder')}
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('tasks.edit.descriptionLabel')}
            </label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder={t('tasks.edit.descriptionPlaceholder')}
              rows={3}
            />
          </div>

          {/* Priority and Color */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                {t('tasks.edit.priorityLabel')}
              </label>
              <Select value={formData.priority} onValueChange={(value) => setFormData({...formData, priority: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LOW">{t('tasks.edit.priorityOption.low')}</SelectItem>
                  <SelectItem value="MEDIUM">{t('tasks.edit.priorityOption.medium')}</SelectItem>
                  <SelectItem value="HIGH">{t('tasks.edit.priorityOption.high')}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                {t('tasks.color')}
              </label>
              <Input
                type="color"
                value={formData.meta.color}
                onChange={(e) => setFormData({...formData, meta: {...formData.meta, color: e.target.value}})}
                className="w-full h-10"
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                {t('tasks.edit.dueDateLabel')}
              </label>
              <Input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({...formData, due_date: e.target.value})}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                {t('tasks.reminderDate')}
              </label>
              <Input
                type="date"
                value={formData.reminder_date}
                onChange={(e) => setFormData({...formData, reminder_date: e.target.value})}
              />
            </div>
          </div>

          {/* Estimated Duration */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('tasks.edit.estimatedDurationLabel')}
            </label>
            <Input
              type="number"
              value={Math.floor(formData.meta.estimated_duration / 60)}
              onChange={(e) => setFormData({
                ...formData, 
                meta: {...formData.meta, estimated_duration: parseInt(e.target.value) || 0}
              })}
              placeholder="0"
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('tasks.edit.tagsLabel')}
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {formData.meta.tags.map((tag, index) => (
                <Badge key={index} variant="outline" className="flex items-center gap-1">
                  <Hash className="w-3 h-3" />
                  {tag}
                  <button type="button" onClick={() => removeTag(tag)} className="ml-1 hover:text-red-500">
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder={t('tasks.addTag')}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
              />
              <Button type="button" onClick={addTag} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Subtasks */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">
              {t('tasks.subtaskTitle')}
            </label>
            <div className="space-y-2 mb-2">
              {formData.meta.subtasks.map((subtask, index) => (
                <div key={index} className="flex items-center gap-2 p-2 bg-[var(--background-secondary)] rounded">
                  <span className="flex-1">{subtask.title}</span>
                  <button type="button" onClick={() => removeSubtask(index)} className="text-red-500">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={newSubtask}
                onChange={(e) => setNewSubtask(e.target.value)}
                placeholder={t('tasks.addSubtask')}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSubtask())}
              />
              <Button type="button" onClick={addSubtask} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Pin Toggle */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="pinned"
              checked={formData.meta.pinned}
              onChange={(e) => setFormData({
                ...formData, 
                meta: {...formData.meta, pinned: e.target.checked}
              })}
              className="rounded border-gray-300"
            />
            <label htmlFor="pinned" className="text-sm font-medium text-[var(--text-primary)]">
              {t('tasks.pinTask')}
            </label>
          </div>
        </form>

        <div className="flex items-center justify-end gap-3 p-6 border-t border-[var(--border-color)]">
          <Button variant="outline" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            {t('tasks.edit.save')}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

// Main Tasks Component
export default function Tasks() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  // Load tasks
  const loadTasks = async () => {
    setIsLoading(true);
    try {
      const filters = {
        skip: 0,
        limit: 50,
        ...(searchTerm && { search: searchTerm }),
        ...(selectedCategory && { tag: selectedCategory }),
        ...(showPinnedOnly && { pinned: true })
      };

      const response = await tasksAPI.filterTasks(filters);
      
      if (Array.isArray(response)) {
        const sortedTasks = [...response].sort((a, b) => {
          const aIsPinned = a.meta?.pinned || false;
          const bIsPinned = b.meta?.pinned || false;
          if (aIsPinned && !bIsPinned) return -1;
          if (!aIsPinned && bIsPinned) return 1;
          return new Date(b.time_updated) - new Date(a.time_updated);
        });
        
        setTasks(sortedTasks);
        setFilteredTasks(sortedTasks);
      } else {
        setTasks([]);
        setFilteredTasks([]);
      }
    } catch (error) {
      console.error('Error loading tasks:', error);
      setTasks([]);
      setFilteredTasks([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      loadTasks();
    }
  }, [searchTerm, selectedCategory, showPinnedOnly]);

  // Update individual task in state
  const updateTaskInState = useCallback((taskId, updatedTask) => {
    const updateTasksArray = (tasksArray) => {
      return tasksArray.map(task => 
        task.id === taskId ? { ...task, ...updatedTask } : task
      );
    };
    
    setTasks(prev => updateTasksArray(prev));
    setFilteredTasks(prev => updateTasksArray(prev));
    
    if (selectedTask && selectedTask.id === taskId) {
      setSelectedTask({ ...selectedTask, ...updatedTask });
    }
  }, [selectedTask]);

  // Remove task from state
  const removeTaskFromState = useCallback((taskId) => {
    const removeFromArray = (tasksArray) => tasksArray.filter(task => task.id !== taskId);
    
    setTasks(prev => removeFromArray(prev));
    setFilteredTasks(prev => removeFromArray(prev));
    
    if (selectedTask && selectedTask.id === taskId) {
      setSelectedTask(null);
      setShowPreviewModal(false);
    }
  }, [selectedTask]);

  // Add task to state
  const addTaskToState = useCallback((newTask) => {
    setTasks(prev => [newTask, ...prev]);
    setFilteredTasks(prev => [newTask, ...prev]);
  }, []);

  const handleSaveTask = async (taskData) => {
    try {
      if (editingTask && editingTask.id) {
        const updatedTask = await tasksAPI.updateTask(editingTask.id, taskData);
        updateTaskInState(editingTask.id, updatedTask);
      } else {
        const newTask = await tasksAPI.createTask(taskData);
        addTaskToState(newTask);
      }
      setEditingTask(null);
    } catch (error) {
      console.error('Error saving task:', error);
      throw error;
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (confirm(t('tasks.deleteConfirmText'))) {
      try {
        await tasksAPI.deleteTask(taskId);
        removeTaskFromState(taskId);
      } catch (error) {
        console.error('Error deleting task:', error);
      }
    }
  };

  const handleCompleteTask = async (taskId, completionData) => {
    try {
      const updatedTask = await tasksAPI.completeTask(taskId, completionData);
      updateTaskInState(taskId, updatedTask);
    } catch (error) {
      console.error('Error completing task:', error);
    }
  };

  const handleTogglePin = async (taskId, shouldPin) => {
    try {
      const task = tasks.find(t => t.id === taskId);
      if (task) {
        const updatedTaskData = {
          ...task,
          meta: {
            ...task.meta,
            pinned: shouldPin
          }
        };
        const updatedTask = await tasksAPI.updateTask(taskId, updatedTaskData);
        updateTaskInState(taskId, updatedTask);
      }
    } catch (error) {
      console.error('Error toggling pin:', error);
    }
  };

  const handleUpdateTask = async (taskId, updateData) => {
    try {
      const updatedTask = await tasksAPI.updateTask(taskId, updateData);
      updateTaskInState(taskId, updatedTask);
      return updatedTask;
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  };

  const handleViewTask = (task) => {
    setSelectedTask(task);
    setShowPreviewModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <button
          onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
          className="hover:text-[var(--text-primary)] transition-colors flex items-center gap-1"
        >
          <Home className="w-4 h-4" />
          {t('breadcrumb.library')}
        </button>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[var(--text-primary)]">{t('breadcrumb.tasks')}</span>
      </div>

      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--text-primary)]">{t('tasks.title')}</h1>
        <p className="text-[var(--text-secondary)]">{t('tasks.description')}</p>
      </div>

      {/* Controls */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-center">
        <div className="flex gap-4 w-full lg:w-auto">
          {/* Search */}
          <div className="relative flex-1 lg:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
            <Input
              placeholder={t('tasks.searchPlaceholder')}
              className="pl-10 h-12"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Pinned Filter */}
          <Button
            variant={showPinnedOnly ? "default" : "outline"}
            onClick={() => setShowPinnedOnly(!showPinnedOnly)}
            className="h-12 flex items-center gap-2"
          >
            <Pin className="w-4 h-4" />
            {t('notes.pinnedOnly')}
          </Button>
        </div>

        <Button
          className="w-full lg:w-auto h-12"
          onClick={() => {
            setSelectedTask(null);
            setEditingTask({ title: '', description: '', meta: { tags: [], subtasks: [], pinned: false } });
          }}
        >
          <Plus className="w-5 h-5 mr-2" />
          {t('tasks.newTask')}
        </Button>
      </div>

      {/* Main Content with Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Categories Sidebar */}
        <CategoriesSidebar
          tasks={tasks}
          selectedCategory={selectedCategory}
          onCategorySelect={setSelectedCategory}
          className="lg:col-span-1"
        />

        {/* Tasks Content */}
        <div className="lg:col-span-3 space-y-6">
          <AnimatePresence mode="wait">
            <motion.div key="list" className="space-y-4">
              {isLoading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
                  <span className="ml-3 text-[var(--text-secondary)]">
                    {t('common.loading')}
                  </span>
                </div>
              ) : filteredTasks.length > 0 ? filteredTasks.map(task => (
                <TaskItem
                  key={task.id}
                  task={task}
                  onEdit={setEditingTask}
                  onDelete={handleDeleteTask}
                  onComplete={handleCompleteTask}
                  onTogglePin={handleTogglePin}
                  onUpdate={handleUpdateTask}
                  onView={handleViewTask}
                />
              )) : (
                <div className="text-center py-16">
                  <Target className="mx-auto w-16 h-16 text-[var(--text-secondary)] opacity-50" />
                  <h3 className="mt-4 text-xl font-semibold text-[var(--text-primary)]">
                    {t('tasks.emptyTitle')}
                  </h3>
                  <p className="mt-2 text-[var(--text-secondary)]">
                    {t('tasks.emptyDescription')}
                  </p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Modals */}
      <TaskEditorModal
        isOpen={!!editingTask}
        task={editingTask}
        onClose={() => setEditingTask(null)}
        onSave={handleSaveTask}
      />

      <TaskPreviewModal
        isOpen={showPreviewModal}
        task={selectedTask}
        onClose={() => setShowPreviewModal(false)}
        onSave={handleUpdateTask}
        onDelete={handleDeleteTask}
      />
    </div>
  );
}
