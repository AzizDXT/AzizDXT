// AI Assistant Page - Supports RAW TEXT streaming from API
// The API returns plain text directly (not JSON) ending with [DONE] markers
// Example: "Hi there! How can I assist you today?[DONE][DONE]"

// Custom Scrollbar Styles for AI Assistant
const scrollbarStyles = `
  /* Webkit browsers (Chrome, Safari, Edge) */
  ::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  
  ::-webkit-scrollbar-track {
    background: transparent;
  }
  
  ::-webkit-scrollbar-thumb {
    background: rgba(156, 163, 175, 0.2);
    border-radius: 2px;
    transition: background 0.2s ease;
  }
  
  ::-webkit-scrollbar-thumb:hover {
    background: rgba(156, 163, 175, 0.4);
  }
  
  /* Firefox */
  * {
    scrollbar-width: thin;
    scrollbar-color: rgba(156, 163, 175, 0.2) transparent;
  }
  
  /* Dark theme specific scrollbar - أكثر تناسقاً مع الثيم */
  .dark ::-webkit-scrollbar-thumb,
  [data-theme="dark"] ::-webkit-scrollbar-thumb {
    background: rgba(75, 85, 99, 0.3);
  }
  
  .dark ::-webkit-scrollbar-thumb:hover,
  [data-theme="dark"] ::-webkit-scrollbar-thumb:hover {
    background: rgba(75, 85, 99, 0.5);
  }
  
  /* Custom scrollbar for specific containers - أنحف وأكثر تناسقاً */
  .custom-scrollbar::-webkit-scrollbar {
    width: 3px;
    height: 3px;
  }
  
  .custom-scrollbar::-webkit-scrollbar-thumb {
    background: rgba(156, 163, 175, 0.15);
    border-radius: 1.5px;
  }
  
  .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: rgba(156, 163, 175, 0.3);
  }
  
  /* Dark theme custom scrollbar */
  .dark .custom-scrollbar::-webkit-scrollbar-thumb,
  [data-theme="dark"] .custom-scrollbar::-webkit-scrollbar-thumb {
    background: rgba(75, 85, 99, 0.25);
  }
  
  .dark .custom-scrollbar::-webkit-scrollbar-thumb:hover,
  [data-theme="dark"] .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: rgba(75, 85, 99, 0.4);
  }
`;

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from 'react-toastify';

import {
  Image as ImageIcon,
  Plus,
  MessageCircle,
  Sparkles,
  Images,
  Paperclip,
  File,
  BookOpen,
  Code,
  Calculator,
  Music,
  Heart,
  Download,
  Eye,
  Paintbrush,
  Globe,
  ArrowUp,
  Camera,
  Loader2,
  Bot,
  Zap,
  Star,
  Lightbulb,
  Gamepad2,
  Activity,
  X,
  Info,
  FileText,
  ExternalLink
} from 'lucide-react';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import { getChatConversations, getChatById, getChatMessages, downloadImage, updateChatConversation, getModels, API_BASE_URL, chatAPI, chatUtils, cloudStorageAPI, fileUrlAPI, getFileDownloadUrl, loadImageWithCache, testImageLoad, getAIGeneratedImagesCount } from '../components/utils/api';
import ChatContent from '../components/chat/ChatContent';
import ChatInput from '../components/chat/ChatInput';

// Enhanced Authenticated Image Component with retry logic (same as chat images)
const AuthenticatedImage = ({ src, alt, className, onLoad, onError }) => {
  const [imageSrc, setImageSrc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [retryAfterMinute, setRetryAfterMinute] = useState(false);

  useEffect(() => {
    const loadAuthenticatedImage = async () => {
      if (!src) return;
      
      try {
        setLoading(true);
        setError(false);
        
        console.log(`Loading authenticated image (attempt ${retryCount + 1}):`, src);
        
        // Try different methods based on the URL pattern (same as chat)
        let authenticatedUrl = null;
        
        // Method 1: Check if it's a file ID (for attached images)
        if (src.match(/^[a-f0-9-]{36}$/i)) {
          // This looks like a file ID, use getFileDownloadUrl approach
          const fileUrl = `${API_BASE_URL}/api/v1/storage/files/${src}/download`;
          authenticatedUrl = await loadImageWithCache(fileUrl, 'image');
        } 
        // Method 2: Check if it's already an absolute URL (for generated images)
        else if (src.startsWith('http')) {
          // Use the same logic as GeneratedImageDisplay
          authenticatedUrl = await loadImageWithCache(src, 'image');
        }
        // Method 3: Relative URL, make it absolute
        else {
          const absoluteUrl = src.startsWith('/') ? `${API_BASE_URL}${src}` : `${API_BASE_URL}/${src}`;
          authenticatedUrl = await loadImageWithCache(absoluteUrl, 'image');
        }
        
        if (authenticatedUrl) {
          setImageSrc(authenticatedUrl);
          setRetryCount(0); // Reset retry count on success
          setRetryAfterMinute(false);
          onLoad?.();
        } else {
          throw new Error('Failed to load authenticated image');
        }
      } catch (err) {
        console.error(`Error loading authenticated image (attempt ${retryCount + 1}):`, err);
        
        // Retry logic: 2 attempts, then wait 1 minute
        if (retryCount < 2) {
          console.log(`Retrying in 2 seconds... (attempt ${retryCount + 2})`);
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
          }, 2000);
        } else if (!retryAfterMinute) {
          console.log('Max retries reached, waiting 1 minute before next attempt');
          setRetryAfterMinute(true);
          setTimeout(() => {
            console.log('Retrying after 1 minute wait');
            setRetryCount(0);
            setRetryAfterMinute(false);
          }, 60000); // 1 minute
        } else {
          console.error('All retry attempts exhausted for authenticated image:', src, err);
          setError(true);
          onError?.(err);
        }
      } finally {
        if (retryCount >= 2 && !retryAfterMinute) {
          // Don't set loading to false if we're going to retry after a minute
        } else {
          setLoading(false);
        }
      }
    };

    loadAuthenticatedImage();
  }, [src, retryCount, onLoad, onError]);

  if (loading) {
    return (
      <div className={`bg-[var(--background-secondary)] flex items-center justify-center ${className}`}>
        <div className="text-center">
          <Loader2 className="w-6 h-6 animate-spin text-[var(--text-secondary)] mx-auto mb-2" />
          <p className="text-xs text-[var(--text-secondary)]">
            {retryAfterMinute 
              ? 'انتظار دقيقة...'
              : retryCount > 0 
                ? `محاولة ${retryCount + 1} من 3`
                : 'جاري التحميل...'
            }
          </p>
        </div>
      </div>
    );
  }

  if (error || !imageSrc) {
    return (
      <div className={`bg-[var(--background-secondary)] flex items-center justify-center ${className}`}>
        <div className="text-center">
          <ImageIcon className="w-8 h-8 text-[var(--text-secondary)] mx-auto mb-2" />
          <p className="text-xs text-[var(--text-secondary)]">فشل التحميل</p>
          <p className="text-xs text-[var(--text-secondary)]">تم المحاولة 3 مرات</p>
        </div>
      </div>
    );
  }

  return (
    <img
      src={imageSrc}
      alt={alt}
      className={className}
      onLoad={onLoad}
      onError={onError}
    />
  );
};

// Enhanced Gallery Image Component with retry logic (same as chat images)
const OptimizedImage = ({ src, alt, className, onLoad, onError }) => {
  const [imageSrc, setImageSrc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [retryAfterMinute, setRetryAfterMinute] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const imgRef = useRef(null);
  const retryTimeoutRef = useRef(null);

  // Intersection Observer للتحميل عند الرؤية
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => {
      observer.disconnect();
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
      }
    };
  }, []);

  // Load image with same logic as chat images
  useEffect(() => {
    if (!isVisible || !src) return;

    const loadGalleryImage = async () => {
      try {
        setLoading(true);
        setError(false);
        
        console.log(`Loading gallery image (attempt ${retryCount + 1}):`, src);
        
        // Try different methods based on the URL pattern (same as chat)
        let authenticatedUrl = null;
        
        // Method 1: Check if it's a file ID (for attached images)
        if (src.match(/^[a-f0-9-]{36}$/i)) {
          // This looks like a file ID, use getFileDownloadUrl approach
          const fileUrl = `${API_BASE_URL}/api/v1/storage/files/${src}/download`;
          authenticatedUrl = await loadImageWithCache(fileUrl, 'image');
        } 
        // Method 2: Check if it's already an absolute URL (for generated images)
        else if (src.startsWith('http')) {
          // Use the same logic as GeneratedImageDisplay
          authenticatedUrl = await loadImageWithCache(src, 'image');
        }
        // Method 3: Relative URL, make it absolute
        else {
          const absoluteUrl = src.startsWith('/') ? `${API_BASE_URL}${src}` : `${API_BASE_URL}/${src}`;
          authenticatedUrl = await loadImageWithCache(absoluteUrl, 'image');
        }
        
        if (authenticatedUrl) {
          setImageSrc(authenticatedUrl);
          setRetryCount(0); // Reset retry count on success
          setRetryAfterMinute(false);
          onLoad && onLoad();
        } else {
          throw new Error('Failed to load authenticated image');
        }
      } catch (err) {
        console.error(`Error loading gallery image (attempt ${retryCount + 1}):`, err);
        
        // Retry logic: 2 attempts, then wait 1 minute
        if (retryCount < 2) {
          console.log(`Retrying in 2 seconds... (attempt ${retryCount + 2})`);
          retryTimeoutRef.current = setTimeout(() => {
            setRetryCount(prev => prev + 1);
          }, 2000);
        } else if (!retryAfterMinute) {
          console.log('Max retries reached, waiting 1 minute before next attempt');
          setRetryAfterMinute(true);
          retryTimeoutRef.current = setTimeout(() => {
            console.log('Retrying after 1 minute wait');
            setRetryCount(0);
            setRetryAfterMinute(false);
          }, 60000); // 1 minute
        } else {
          console.error('All retry attempts exhausted for gallery image:', src, err);
          setError(true);
          onError && onError(err);
        }
      } finally {
        if (retryCount >= 2 && !retryAfterMinute) {
          // Don't set loading to false if we're going to retry after a minute
        } else {
          setLoading(false);
        }
      }
    };

    loadGalleryImage();
  }, [src, retryCount, isVisible]);

  const retryManually = () => {
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
    }
    setRetryCount(0);
    setRetryAfterMinute(false);
    setError(false);
    setLoading(true);
  };

  return (
    <div ref={imgRef} className={className}>
      {isVisible && (
        <>
          {loading && (
            <div className="w-full h-full bg-[var(--background-tertiary)] flex items-center justify-center">
              <div className="text-center">
                <Loader2 className="w-6 h-6 animate-spin text-[var(--text-secondary)] mx-auto mb-2" />
                <p className="text-xs text-[var(--text-secondary)]">
                  {retryAfterMinute 
                    ? 'انتظار دقيقة...'
                    : retryCount > 0 
                      ? `محاولة ${retryCount + 1} من 3`
                      : 'جاري التحميل...'
                  }
                </p>
              </div>
            </div>
          )}
          
          {error && !loading ? (
            <div className="w-full h-full bg-[var(--background-tertiary)] flex flex-col items-center justify-center gap-2 p-4">
              <ImageIcon className="w-8 h-8 text-[var(--text-secondary)]" />
              <p className="text-xs text-[var(--text-secondary)] text-center">فشل التحميل</p>
              <p className="text-xs text-[var(--text-secondary)] text-center">تم المحاولة 3 مرات</p>
              <button 
                onClick={retryManually}
                className="text-xs text-[var(--text-primary)] bg-[var(--background)] px-3 py-1 rounded-lg hover:bg-[var(--background-secondary)] transition-colors"
              >
                إعادة المحاولة
              </button>
            </div>
          ) : imageSrc && (
            <img
              src={imageSrc}
              alt={alt}
              className="w-full h-full object-cover transition-opacity duration-300"
              loading="lazy"
            />
          )}
        </>
      )}
    </div>
  );
};

// مكون عرض الصورة المكبرة
const ImageModal = ({ image, isOpen, onClose }) => {
  if (!isOpen || !image) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          className="relative max-w-4xl max-h-[90vh] bg-[var(--background)] rounded-2xl overflow-hidden shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="absolute top-4 right-4 z-10 flex gap-2">
            <motion.button
              onClick={() => downloadImage(image.id, image.original_name)}
              className="p-2 bg-black/50 backdrop-blur-sm rounded-full hover:bg-black/70 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Download className="w-5 h-5 text-white" />
            </motion.button>
            <motion.button
              onClick={onClose}
              className="p-2 bg-black/50 backdrop-blur-sm rounded-full hover:bg-black/70 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <X className="w-5 h-5 text-white" />
            </motion.button>
          </div>
          
          <AuthenticatedImage
            src={getFileDownloadUrl(image.id)}
            alt={image.original_name}
            className="w-full h-full object-contain"
          />
          
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
            <h3 className="text-white font-semibold text-lg mb-2">{image.original_name}</h3>
            <div className="flex items-center gap-4 text-white/70 text-sm">
              <span>{(image.size_mb || 0).toFixed(2)} MB</span>
              <span>{image.extension?.toUpperCase()}</span>
              <span>{new Date(image.created_at).toLocaleDateString('ar-EG')}</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

// مكون عرض الملف المرفق
const AttachmentPreview = ({ attachment, onToggleDetails }) => {
  const [showDetails, setShowDetails] = useState(false);
  
  const handleToggleDetails = () => {
    setShowDetails(!showDetails);
    onToggleDetails && onToggleDetails(!showDetails);
  };

  if (attachment.content?.type === 'image') {
    return (
      <motion.div
        className="relative inline-block max-w-xs rounded-xl overflow-hidden bg-[var(--background-secondary)] border border-[var(--border-color)]"
        whileHover={{ scale: 1.02 }}
      >
        <div className="aspect-video bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 flex items-center justify-center">
          <ImageIcon className="w-12 h-12 text-[var(--text-secondary)]" />
        </div>
        <div className="p-3">
          <div className="flex items-center justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[var(--text-primary)] truncate">{attachment.name}</p>
              <p className="text-xs text-[var(--text-secondary)]">{attachment.size}</p>
            </div>
            <motion.button
              onClick={handleToggleDetails}
              className="p-1 rounded-lg hover:bg-[var(--background-tertiary)] transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Info className="w-4 h-4 text-[var(--text-secondary)]" />
            </motion.button>
          </div>
        </div>
      </motion.div>
    );
  }

  if (attachment.content?.type === 'document') {
    return (
      <motion.div
        className="relative inline-block max-w-sm rounded-xl bg-[var(--background-secondary)] border border-[var(--border-color)] p-4"
        whileHover={{ scale: 1.02 }}
      >
        <div className="flex items-start gap-3">
          <div className="p-2 bg-[var(--background-tertiary)] rounded-lg">
            <FileText className="w-5 h-5 text-[var(--text-primary)]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-[var(--text-primary)] truncate">{attachment.name}</p>
              <motion.button
                onClick={handleToggleDetails}
                className="p-1 rounded-lg hover:bg-[var(--background-tertiary)] transition-colors ml-2"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Info className="w-4 h-4 text-[var(--text-secondary)]" />
              </motion.button>
            </div>
            <p className="text-xs text-[var(--text-secondary)] mb-2">{attachment.size}</p>
            
            {showDetails && attachment.content?.text && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 p-3 bg-[var(--background)] rounded-lg border border-[var(--border-color)]/50"
              >
                <p className="text-xs text-[var(--text-secondary)] mb-2">محتوى الملف:</p>
                <p className="text-xs text-[var(--text-primary)] leading-relaxed max-h-32 overflow-y-auto">
                  {attachment.content.text.substring(0, 200)}
                  {attachment.content.text.length > 200 && '...'}
                </p>
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>
    );
  }

  return null;
};

// مكون التاب المحسن
const TabButton = ({ icon: Icon, label, isActive, onClick, count, isRTL }) => (
  <motion.button
    onClick={onClick}
    className={`relative group w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all duration-300 ${
      isActive 
        ? 'bg-[var(--text-primary)] text-[var(--background)] shadow-lg' 
        : 'bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] text-[var(--text-primary)] border border-[var(--border-color)]'
    }`}
    whileHover={{ scale: 1.02, y: -2 }}
    whileTap={{ scale: 0.98 }}
    layout
  >
    <div className={`flex items-center gap-3 flex-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
      <motion.div
        className={`p-2 rounded-xl flex-shrink-0 ${
          isActive 
            ? 'bg-[var(--background)]/20' 
            : 'bg-[var(--background-tertiary)] group-hover:bg-[var(--background)]'
        }`}
        whileHover={{ rotate: 5 }}
        transition={{ type: "spring", stiffness: 400, damping: 10 }}
      >
        <Icon className={`w-5 h-5 ${
          isActive ? 'text-[var(--background)]' : 'text-[var(--text-primary)]'
        }`} />
      </motion.div>
      
      <div className="flex flex-col items-start flex-1 min-w-0">
        <span className={`font-semibold text-sm truncate w-full ${
          isActive ? 'text-[var(--background)]' : 'text-[var(--text-primary)]'
        }`}>
          {label}
        </span>
        <span className={`text-xs ${
          isActive ? 'text-[var(--background)]/70' : 'text-[var(--text-secondary)]'
        }`}>
          {count !== undefined ? `${count} عنصر` : 'جاهز'}
        </span>
      </div>
    </div>
    
    {isActive && (
      <motion.div
        className="absolute bottom-0 left-1/2 w-12 h-1 bg-[var(--background)]/50 rounded-full"
        initial={{ width: 0, x: '-50%' }}
        animate={{ width: 48, x: '-50%' }}
        transition={{ duration: 0.3 }}
      />
    )}
  </motion.button>
);

// مكون الاقتراحات المحسن
const SuggestionCard = ({ suggestion, onClick, isRTL, t }) => (
  <motion.button
    onClick={() => onClick(suggestion)}
    className="group relative p-4 bg-[var(--background-secondary)] border border-[var(--border-color)] rounded-xl hover:bg-[var(--background-tertiary)] hover:border-[var(--text-primary)]/30 transition-all duration-300 text-left"
    whileHover={{ 
      scale: 1.02, 
      y: -2
    }}
    whileTap={{ scale: 0.98 }}
    layout
  >
    <div className={`flex items-start gap-3 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
      <motion.div
        className="p-2 bg-[var(--background-tertiary)] rounded-lg group-hover:bg-[var(--text-primary)] group-hover:text-[var(--background)] transition-all duration-300"
        whileHover={{ rotate: 5, scale: 1.05 }}
        transition={{ type: "spring", stiffness: 400, damping: 10 }}
      >
        {React.cloneElement(suggestion.icon, { 
          className: "w-4 h-4 transition-colors duration-300" 
        })}
      </motion.div>
      
      <div className="flex-1 min-w-0">
        <div className={`text-xs font-medium text-[var(--text-secondary)] mb-1 uppercase tracking-wider ${isRTL ? 'text-right' : ''}`}>
          {t(suggestion.category)}
        </div>
        <div className={`font-medium text-sm text-[var(--text-primary)] group-hover:text-[var(--text-primary)] transition-colors duration-300 ${isRTL ? 'text-right' : ''}`}>
          {t(suggestion.title)}
        </div>
      </div>
      
      <motion.div
        className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        whileHover={{ x: isRTL ? -2 : 2 }}
      >
        <ArrowUp className={`w-3 h-3 text-[var(--text-secondary)] ${isRTL ? 'rotate-225' : 'rotate-45'}`} />
      </motion.div>
    </div>
  </motion.button>
);

// الاقتراحات المحدثة
const suggestions = [
  {
    id: 1,
    title: 'ai.suggestions.explainAI',
    icon: <Zap />,
    category: 'ai.suggestions.education'
  },
  {
    id: 2,
    title: 'ai.suggestions.helpCode',
    icon: <Code />,
    category: 'ai.suggestions.programming'
  },
  {
    id: 3,
    title: 'ai.suggestions.calcMath',
    icon: <Calculator />,
    category: 'ai.suggestions.math'
  },
  {
    id: 4,
    title: 'ai.suggestions.createPlaylist',
    icon: <Music />,
    category: 'ai.suggestions.entertainment'
  },
  {
    id: 5,
    title: 'ai.suggestions.healthTips',
    icon: <Activity />,
    category: 'ai.suggestions.health'
  },
  {
    id: 6,
    title: 'ai.suggestions.creativeWriting',
    icon: <Lightbulb />,
    category: 'ai.suggestions.creativity'
  }
];

// مكون عرض الصورة في الشات مع الأزرار
const ChatImageDisplay = ({ imageId, imageName, imageSize, userInput, onRegenerate, onEdit, onInfo, onCopy }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showActions, setShowActions] = useState(false);

  return (
    <motion.div
      className="relative max-w-md mx-auto"
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {/* Image Container - Clean, no borders */}
      <div className="relative rounded-2xl overflow-hidden bg-[var(--background-secondary)]">
        <img
          src={getFileDownloadUrl(imageId)}
          alt={imageName}
          className="w-full h-auto object-cover"
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />
        
        {!imageLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
          </div>
        )}
      </div>

      {/* User Input Text */}
      {userInput && (
        <div className="mt-3 p-3 bg-[var(--background-secondary)] rounded-lg border border-[var(--border-color)]">
          <p className="text-sm text-[var(--text-primary)] leading-relaxed">
            {userInput}
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <AnimatePresence>
        {showActions && imageLoaded && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.2 }}
            className="flex items-center justify-center gap-2 mt-3"
          >
            <motion.button
              onClick={onRegenerate}
              className="p-2.5 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title="إعادة توليد"
            >
              <svg className="w-4 h-4 text-[var(--text-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </motion.button>
            
            <motion.button
              onClick={onEdit}
              className="p-2.5 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title="تعديل"
            >
              <svg className="w-4 h-4 text-[var(--text-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
            </motion.button>
            
            <motion.button
              onClick={onInfo}
              className="p-2.5 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title="معلومات"
            >
              <Info className="w-4 h-4 text-[var(--text-primary)]" />
            </motion.button>
            
            <motion.button
              onClick={onCopy}
              className="p-2.5 bg-[var(--background-secondary)] hover:bg-[var(--background-tertiary)] rounded-full border border-[var(--border-color)] transition-colors shadow-sm"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              title="نسخ"
            >
              <svg className="w-4 h-4 text-[var(--text-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// مكون عرض الملف المرفق المحسن
const FileAttachmentDisplay = ({ attachment, onDownload, onInfo }) => {
  const getFileIcon = (extension) => {
    const ext = extension?.toLowerCase();
    
    // Microsoft Office files with proper colors
    if (['doc', 'docx'].includes(ext)) {
      return { 
        icon: FileText, 
        color: 'text-blue-600', 
        bgColor: 'bg-blue-500',
        lightBg: 'bg-blue-50 dark:bg-blue-900/20',
        name: 'Word'
      };
    }
    if (['xls', 'xlsx'].includes(ext)) {
      return { 
        icon: FileText, 
        color: 'text-green-600', 
        bgColor: 'bg-green-500',
        lightBg: 'bg-green-50 dark:bg-green-900/20',
        name: 'Excel'
      };
    }
    if (['ppt', 'pptx'].includes(ext)) {
      return { 
        icon: FileText, 
        color: 'text-orange-600', 
        bgColor: 'bg-orange-500',
        lightBg: 'bg-orange-50 dark:bg-orange-900/20',
        name: 'PowerPoint'
      };
    }
    
    // PDF
    if (ext === 'pdf') {
      return { 
        icon: FileText, 
        color: 'text-red-600', 
        bgColor: 'bg-red-500',
        lightBg: 'bg-red-50 dark:bg-red-900/20',
        name: 'PDF'
      };
    }
    
    // Text files
    if (['txt', 'md', 'rtf'].includes(ext)) {
      return { 
        icon: FileText, 
        color: 'text-gray-600', 
        bgColor: 'bg-gray-500',
        lightBg: 'bg-gray-50 dark:bg-gray-900/20',
        name: 'Text'
      };
    }
    
    // Default
    return { 
      icon: File, 
      color: 'text-gray-600', 
      bgColor: 'bg-gray-500',
      lightBg: 'bg-gray-50 dark:bg-gray-900/20',
      name: 'File'
    };
  };

  const { icon: IconComponent, color, bgColor, lightBg, name } = getFileIcon(attachment.name?.split('.').pop());
  const fileSize = attachment.size || '0 KB';

  return (
    <motion.div
      className={`inline-flex items-center gap-4 p-4 ${lightBg} border border-[var(--border-color)] rounded-xl max-w-sm shadow-sm`}
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {/* File Icon with colored background */}
      <div className={`p-3 rounded-lg ${bgColor} shadow-sm`}>
        <IconComponent className="w-6 h-6 text-white" />
      </div>
      
      {/* File Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <p className="text-sm font-semibold text-[var(--text-primary)] truncate">
            {attachment.name}
          </p>
          <span className={`text-xs px-2 py-0.5 rounded-full ${color} bg-white/80 dark:bg-black/20 font-medium`}>
            {name}
          </span>
        </div>
        <p className="text-xs text-[var(--text-secondary)] font-medium">
          {fileSize}
        </p>
      </div>
      
      {/* Action Buttons */}
      <div className="flex gap-1">
        <motion.button
          onClick={onInfo}
          className="p-2 hover:bg-white/50 dark:hover:bg-black/20 rounded-lg transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          title="معلومات الملف"
        >
          <Info className="w-4 h-4 text-[var(--text-secondary)]" />
        </motion.button>
        
        <motion.button
          onClick={onDownload}
          className="p-2 hover:bg-white/50 dark:hover:bg-black/20 rounded-lg transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          title="تحميل الملف"
        >
          <Download className="w-4 h-4 text-[var(--text-secondary)]" />
        </motion.button>
      </div>
    </motion.div>
  );
};

export default function AIAssistant() {
  const { t, language, isRTL } = useI18n();
  const { isDark } = useTheme();
  const { chatId } = useParams(); // Get chat_id from URL
  const navigate = useNavigate(); // For navigation

  // Apply custom scrollbar styles
  useEffect(() => {
    // Create and inject scrollbar styles
    const styleElement = document.createElement('style');
    styleElement.textContent = scrollbarStyles;
    document.head.appendChild(styleElement);

    // Cleanup on unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Debug info on component mount
  useEffect(() => {
    console.log('🔧 AIAssistant Debug Info:', {
      currentURL: window.location.href,
      domain: window.location.hostname,
      protocol: window.location.protocol,
      apiBaseUrl: API_BASE_URL,
      cookies: document.cookie,
      localStorage: {
        authToken: localStorage.getItem('taleb-access-token') ? 'present' : 'missing',
        userData: localStorage.getItem('taleb-user-data') ? 'present' : 'missing'
      }
    });
  }, []);
  const [activeSection, setActiveSection] = useState('conversations'); // Default to conversations
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [sidebarWidth, setSidebarWidth] = useState(280);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  // Real conversations states
  const [conversations, setConversations] = useState([]);
  const [conversationsPage, setConversationsPage] = useState(0);
  const [conversationsLoading, setConversationsLoading] = useState(false);
  const [conversationsHasMore, setConversationsHasMore] = useState(true);
  const [conversationsInitialLoad, setConversationsInitialLoad] = useState(false);

  // Gallery states
  const [galleryImages, setGalleryImages] = useState([]);
  const [galleryPage, setGalleryPage] = useState(1);
  const [galleryLoading, setGalleryLoading] = useState(false);
  const [galleryHasMore, setGalleryHasMore] = useState(true);
  const [galleryInitialLoad, setGalleryInitialLoad] = useState(false);
  const [galleryTotalCount, setGalleryTotalCount] = useState(0);
  const [selectedImage, setSelectedImage] = useState(null);
  const [imageModalOpen, setImageModalOpen] = useState(false);

  // Chat loading state
  const [chatLoading, setChatLoading] = useState(false);
  const [chatLoadingId, setChatLoadingId] = useState(null);

  // Chat input states
  const [inputMessage, setInputMessage] = useState('');
  const [webSearchActive, setWebSearchActive] = useState(false);
  const [imageGenActive, setImageGenActive] = useState(false);
  const [autoOperationsActive, setAutoOperationsActive] = useState(false);

  // Expose autoOperationsActive and language globally for code blocks
  useEffect(() => {
    window.autoOperationsActive = autoOperationsActive;
    window.language = language;
    return () => {
      delete window.autoOperationsActive;
      delete window.language;
    };
  }, [autoOperationsActive, language]);
  const [attachmentsMenuOpen, setAttachmentsMenuOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);
  const [textDirection, setTextDirection] = useState('ltr');
  
  // Model selection states
  const [selectedModel, setSelectedModel] = useState(null);
  const [availableModels, setAvailableModels] = useState([]);
  
  // Streaming states
  const [isSending, setIsSending] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Refs
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const attachmentsMenuRef = useRef(null);
  const attachmentsBtnRef = useRef(null);
  const galleryRef = useRef(null);
  const loadingTriggerRef = useRef(null);
  const conversationsRef = useRef(null);
  const conversationsLoadingTriggerRef = useRef(null);
  const chatLoadingRef = useRef(false);
  const currentChatIdRef = useRef(null);

  // Helper functions
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const detectTextDirection = (text) => {
    const arabicRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
    return arabicRegex.test(text) ? 'rtl' : 'ltr';
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    
    try {
      // Handle both Unix timestamp (seconds) and milliseconds
      const date = new Date(typeof timestamp === 'number' && timestamp < 1e12 ? timestamp * 1000 : timestamp);
      const now = new Date();
      const diffInSeconds = Math.floor((now - date) / 1000);
      
      if (diffInSeconds < 60) {
        return t('chat.now') || 'الآن';
      } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return t('chat.minutesAgo', { count: minutes }) || `${minutes} دقيقة مضت`;
      } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return t('chat.hoursAgo', { count: hours }) || `${hours} ساعة مضت`;
      } else if (diffInSeconds < 604800) {
        const days = Math.floor(diffInSeconds / 86400);
        return t('chat.daysAgo', { count: days }) || `${days} يوم مضى`;
      } else {
        return date.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
          month: 'short',
          day: 'numeric',
          year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
        });
      }
    } catch (error) {
      console.error('Error formatting time:', error);
      return '';
    }
  };

  // Load conversations with infinite scroll - إصلاح مشكلة التكرار
  const loadConversations = useCallback(async (reset = false) => {
    if (conversationsLoading || (!conversationsHasMore && !reset)) return;

    setConversationsLoading(true);
    try {
      const skip = reset ? 0 : conversationsPage;
      const limit = 10;
      
      console.log('Loading conversations:', { skip, limit, reset });
      const response = await getChatConversations(skip, limit);
      
      if (response && Array.isArray(response)) {
        const newConversations = response.map(conv => ({
          ...conv,
          id: conv.id || conv._id,
          title: conv.title || conv.name || 'محادثة جديدة',
          lastMessage: conv.last_message || conv.lastMessage || '',
          timestamp: conv.updated_at || conv.updatedAt || conv.created_at || conv.createdAt || new Date().toISOString(),
          messageCount: conv.message_count || conv.messageCount || 0
        }));

        if (reset) {
          setConversations(newConversations);
          setConversationsPage(limit);
        } else {
          setConversations(prev => [...prev, ...newConversations]);
          setConversationsPage(prev => prev + limit);
        }

        setConversationsHasMore(newConversations.length === limit);
        
        if (!conversationsInitialLoad) {
          setConversationsInitialLoad(true);
        }
      } else {
        console.warn('Invalid conversations response:', response);
        setConversationsHasMore(false);
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
      setConversationsHasMore(false);
    } finally {
      setConversationsLoading(false);
    }
  }, [conversationsPage, conversationsLoading, conversationsHasMore, conversationsInitialLoad]);

  // Load gallery images with infinite scroll - استخدام cloudStorageAPI
  const loadGalleryImages = useCallback(async (reset = false) => {
    if (galleryLoading || (!galleryHasMore && !reset)) return;

    setGalleryLoading(true);
    try {
      const page = reset ? 1 : galleryPage;
      const limit = 12;
      
      console.log('Loading gallery images:', { page, limit, reset });
      
      // استخدام cloudStorageAPI مع المعاملات الصحيحة
      const imagesResponse = await cloudStorageAPI.getStorageFiles({
        page: page,
        limit: limit,
        tags: ['ai-generated']
      });
      
      if (imagesResponse && Array.isArray(imagesResponse.files)) {
        const newImages = imagesResponse.files.map(img => {
          const imageUrl = getFileDownloadUrl(img.id);
          console.log('🖼️ Gallery image processed:', {
            id: img.id,
            name: img.original_name || img.name,
            url: imageUrl,
            size: img.size_mb || 'unknown'
          });
          
          return {
            ...img,
            id: img.id || img._id,
            url: imageUrl, // Use the authenticated function
            thumbnailUrl: fileUrlAPI.getFileThumbnailUrl(img.id, 300),
            name: img.original_name || img.name || 'صورة',
            createdAt: img.created_at || img.createdAt || new Date().toISOString()
          };
        });

        if (reset) {
          setGalleryImages(newImages);
          setGalleryPage(2);
        } else {
          setGalleryImages(prev => [...prev, ...newImages]);
          setGalleryPage(prev => prev + 1);
        }

        setGalleryHasMore(newImages.length === limit);
        
        if (reset) {
          setGalleryTotalCount(imagesResponse.total_count || newImages.length);
        }
        
        if (!galleryInitialLoad) {
          setGalleryInitialLoad(true);
        }
      } else {
        console.warn('Invalid gallery response:', imagesResponse);
        setGalleryHasMore(false);
      }
    } catch (error) {
      console.error('Error loading gallery images:', error);
      setGalleryHasMore(false);
    } finally {
      setGalleryLoading(false);
    }
  }, [galleryPage, galleryLoading, galleryHasMore, galleryTotalCount, galleryInitialLoad]);

  // Load chat by ID - إصلاح مشكلة التكرار نهائياً
  const loadChatById = useCallback(async (targetChatId) => {
    // التحقق من الحالة باستخدام refs لمنع التكرار
    if (!targetChatId || chatLoadingRef.current || currentChatIdRef.current === targetChatId) {
      return;
    }

    chatLoadingRef.current = true;
    currentChatIdRef.current = targetChatId;
    setChatLoading(true);
    setChatLoadingId(targetChatId);
    
    // Update URL if needed
    if (chatId !== targetChatId) {
      console.log('Navigating to chat:', targetChatId);
      navigate(`/aiassistant/chat/${targetChatId}`, { replace: true });
    }
    
    // Set current chat_id in localStorage for API calls
    chatUtils.setCurrentChatId(targetChatId);
    
    try {
      console.log('Loading chat by ID:', targetChatId);
      const response = await getChatById(targetChatId);
      
      if (response && response.chat && Array.isArray(response.chat.messages)) {
        const chatMessages = response.chat.messages;
        const transformedMessages = chatMessages.map(msg => ({
          ...msg,
          id: msg.id || msg._id,
          content: msg.content || msg.message || '',
          role: msg.role || msg.sender || 'user',
          timestamp: msg.timestamp || msg.created_at || msg.createdAt || new Date().toISOString(),
          attachments: msg.attachments || []
        }));
        
        setMessages(transformedMessages);
        
        setSelectedChat({
          ...response,
          id: response.id || response._id || targetChatId,
          title: response.title || response.name || 'محادثة جديدة'
        });
      }
    } catch (error) {
      console.error('Error loading chat:', error);
      setMessages([]);
      
      // If chat not found, redirect to main page
      if (error.message.includes('404') || error.message.includes('Not Found')) {
        console.log('Chat not found, redirecting to main page');
        navigate('/aiassistant', { replace: true });
      } else {
        // For other errors, just clear the chat but stay on the page
        setSelectedChat(null);
      }
    } finally {
      chatLoadingRef.current = false;
      setChatLoading(false);
      setChatLoadingId(null);
    }
  }, [chatId, navigate]);

  // Load initial counts and default model on app start
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        // Load image count
        try {
          const imageCount = await getAIGeneratedImagesCount();
          setGalleryTotalCount(imageCount);
        } catch (error) {
          console.error('Error loading image count:', error);
          setGalleryTotalCount(0);
        }
        
        // Load available models
        const models = await getModels(0, 50, null, true);
        setAvailableModels(models);
        
        // Load default model from localStorage or session
        const savedModel = sessionStorage.getItem('selectedModel');
        const defaultModel = localStorage.getItem('defaultModel');
        
        if (savedModel) {
          setSelectedModel(JSON.parse(savedModel));
        } else if (defaultModel) {
          const parsedDefault = JSON.parse(defaultModel);
          setSelectedModel(parsedDefault);
          sessionStorage.setItem('selectedModel', JSON.stringify(parsedDefault));
        } else if (models.length > 0) {
          // Select first available model as default
          const firstModel = models[0];
          setSelectedModel(firstModel);
          sessionStorage.setItem('selectedModel', JSON.stringify(firstModel));
        }
      } catch (error) {
        console.error('Error loading initial data:', error);
      }
    };

    loadInitialData();
  }, []);

  // Initialize data loading
  useEffect(() => {
    if (activeSection === 'conversations' && !conversationsInitialLoad) {
      loadConversations(true);
    } else if (activeSection === 'gallery' && !galleryInitialLoad) {
      loadGalleryImages(true);
    }
  }, [activeSection, conversationsInitialLoad, galleryInitialLoad, loadConversations, loadGalleryImages]);

  // Auto-refresh conversations every minute (only when not viewing a specific chat)
  useEffect(() => {
    const interval = setInterval(() => {
      if (activeSection === 'conversations' && !selectedChat && !chatId) {
        loadConversations(true);
        console.log('Auto-refreshing conversations...');
      }
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, [activeSection, loadConversations, selectedChat, chatId]);

  // Intersection Observer for infinite scroll - Conversations
  useEffect(() => {
    if (!conversationsLoadingTriggerRef.current || activeSection !== 'conversations') return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && conversationsHasMore && !conversationsLoading) {
          loadConversations();
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(conversationsLoadingTriggerRef.current);

    return () => observer.disconnect();
  }, [loadConversations, conversationsHasMore, conversationsLoading, activeSection]);

  // Intersection Observer for infinite scroll - Gallery
  useEffect(() => {
    if (!loadingTriggerRef.current || activeSection !== 'gallery') return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && galleryHasMore && !galleryLoading) {
          loadGalleryImages();
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(loadingTriggerRef.current);

    return () => observer.disconnect();
  }, [loadGalleryImages, galleryHasMore, galleryLoading, activeSection]);

  // Handle input changes and text direction detection
  useEffect(() => {
    if (inputMessage) {
      const direction = detectTextDirection(inputMessage);
      setTextDirection(direction);
    } else {
      setTextDirection('ltr');
    }
  }, [inputMessage]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [inputMessage]);

  // Close attachments menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        attachmentsMenuOpen &&
        attachmentsMenuRef.current &&
        !attachmentsMenuRef.current.contains(event.target) &&
        attachmentsBtnRef.current &&
        !attachmentsBtnRef.current.contains(event.target)
      ) {
        setAttachmentsMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [attachmentsMenuOpen]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle URL-based navigation
  useEffect(() => {
    const path = window.location.pathname;
    
    if (path.includes('/gallery')) {
      setActiveSection('gallery');
    } else if (path.includes('/chat/')) {
      setActiveSection('conversations');
    } else if (path.includes('/aiassistant')) {
      setActiveSection('conversations');
    } else {
      setActiveSection('conversations');
    }
  }, []);

  // Handle chatId from URL
  useEffect(() => {
    if (chatId) {
      // Load chat from URL parameter
      setActiveSection('conversations');
      if (currentChatIdRef.current !== chatId) {
        currentChatIdRef.current = null;
        chatLoadingRef.current = false;
        loadChatById(chatId);
      }
    } else {
      // No chat ID in URL, clear current chat but keep conversations view
      const path = window.location.pathname;
      if (path.includes('/aiassistant') && !path.includes('/gallery')) {
        setActiveSection('conversations');
      }
      
      currentChatIdRef.current = null;
      chatLoadingRef.current = false;
      setSelectedChat(null);
      setMessages([]);
      chatUtils.clearCurrentChatId();
    }
  }, [chatId, loadChatById]);

  // Load chat when selectedChat changes - إصلاح التكرار نهائياً
  useEffect(() => {
    if (selectedChat && selectedChat.id && !chatId) {
      // If we have a selected chat but no URL chatId, update URL
      navigate(`/aiassistant/chat/${selectedChat.id}`, { replace: true });
    }
  }, [selectedChat?.id, chatId, navigate]);

  const startNewChat = () => {
    // تنظيف refs
    currentChatIdRef.current = null;
    chatLoadingRef.current = false;
    
    // Navigate to main AI assistant page (no chat ID)
    navigate('/aiassistant');
    
    // Clear current state
    setSelectedChat(null);
    setMessages([]);
    setInputMessage('');
    setWebSearchActive(false);
    setImageGenActive(false);
    setIsTyping(false);
    setTextDirection('ltr');
    setActiveSection('conversations');
    
    // Clear chat ID from utils
    chatUtils.clearCurrentChatId();
  };

  const showGallery = () => {
    // تنظيف refs
    currentChatIdRef.current = null;
    chatLoadingRef.current = false;
    
    // Navigate to gallery
    navigate('/aiassistant/gallery');
    
    setActiveSection('gallery');
    setSelectedChat(null);
    setMessages([]);
    chatUtils.clearCurrentChatId();
  };

  const showConversations = () => {
    // تنظيف refs
    currentChatIdRef.current = null;
    chatLoadingRef.current = false;
    
    // Navigate to conversations
    navigate('/aiassistant');
    
    setActiveSection('conversations');
    setSelectedChat(null);
    setMessages([]);
    chatUtils.clearCurrentChatId();
  };

  // Handle image view
  const handleImageView = (image) => {
    setSelectedImage(image);
    setImageModalOpen(true);
  };

  // Test image loading for debugging
  const handleTestImageLoad = async (image) => {
    const imageUrl = getFileDownloadUrl(image.id);
    console.log('Testing image load for:', image.name, imageUrl);
    await testImageLoad(imageUrl);
  };

  // Handle image download with error handling
  const handleImageDownload = async (image) => {
    try {
      if (image.id.startsWith('mock-')) {
        console.log('Cannot download mock image');
        return;
      }
      
      await downloadImage(image.id, image.original_name);
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  // Handle suggestion click
  const handleSuggestionClick = useCallback((prompt) => {
    // Set the input message
    setInputMessage(prompt);
    
    // If no chat is selected, create a new one and navigate to it
    if (!selectedChat) {
      const newChatId = chatUtils.generateChatId();
      navigate(`/aiassistant/chat/${newChatId}`);
      
      // Small delay to ensure navigation is complete before setting message
      setTimeout(() => {
        setInputMessage(prompt);
      }, 100);
    }
  }, [selectedChat, navigate]);

  // Expose handleSuggestionClick globally for ChatContent
  useEffect(() => {
    window.handleSuggestionClick = handleSuggestionClick;
    return () => {
      delete window.handleSuggestionClick;
    };
  }, [handleSuggestionClick]);

  // Streaming message handlers
  const handleStreamingMessage = useCallback((messageData, type) => {
    if (type === 'user') {
      // Add user message immediately
      const userMsg = {
        ...messageData,
        id: Date.now(),
        timestamp: Date.now() / 1000
      };
      setMessages(prev => [...prev, userMsg]);
      setIsSending(true);
    } else if (type === 'assistant') {
      // Add assistant message placeholder
      console.log('Adding assistant message:', JSON.stringify(messageData.content));
      console.log('Raw content length:', messageData.content ? messageData.content.length : 0);
      setMessages(prev => [...prev, messageData]);
      setIsSending(false);
      setIsGenerating(true);
    } else if (type === 'update') {
      // Update streaming assistant message immediately - preserve RAW content exactly
      console.log('Updating message with raw content:', JSON.stringify(messageData.content));
      console.log('Raw content length:', messageData.content ? messageData.content.length : 0);
      console.log('Content preview:', messageData.content ? messageData.content.substring(0, 50) + '...' : 'empty');
      
      setMessages(prev => 
        prev.map(msg => 
          msg.id === messageData.id ? { 
            ...messageData,
            // CRITICAL: Preserve raw content exactly as received from stream
            content: messageData.content 
          } : msg
        )
      );
    } else if (type === 'clear') {
      // Clear messages for new conversation
      setMessages([]);
      setIsSending(false);
      setIsGenerating(false);
    }
  }, []);

  const handleStreamingComplete = useCallback((finalMessage) => {
    console.log('Stream completed with final message:', JSON.stringify(finalMessage?.content?.substring(0, 100)));
    console.log('Final message length:', finalMessage?.content?.length || 0);
    
    setMessages(prev => 
      prev.map(msg => 
        msg.id === finalMessage.id ? {
          ...finalMessage,
          streaming: false // Ensure streaming flag is set to false
        } : msg
      )
    );
    setIsGenerating(false);
    
    // Refresh conversations list after message is completed (without affecting current chat)
    // Only refresh if we're not currently viewing a specific chat
    if (!selectedChat || !chatId) {
      loadConversations(true);
    }
    
    console.log('تم إكمال الرد - Raw text streaming finished');
  }, [loadConversations]);

  const handleStreamingError = useCallback((error) => {
    setIsSending(false);
    setIsGenerating(false);
    console.error('Streaming error:', error);
  }, []);

  const handleStopGeneration = useCallback(() => {
    setIsGenerating(false);
    console.log('تم إيقاف التوليد');
  }, []);

  const handleNewConversation = useCallback(async (newChatId) => {
    try {
      // Navigate to the new chat
      navigate(`/aiassistant/chat/${newChatId}`);
      console.log('Started new conversation with ID:', newChatId);
      
      // Reload conversations to update sidebar (without reset to preserve current state)
      await loadConversations(false);
      
      // Set the new chat as selected
      const newChat = await getChatById(newChatId);
      if (newChat) {
        setSelectedChat(newChat);
      }
    } catch (error) {
      console.error('Error handling new conversation:', error);
    }
  }, [navigate, loadConversations]);

  // Placeholder functions for chat input
  const handleSendMessage = () => {
    console.log('Send message:', inputMessage);
    // This is now handled by ChatInput's streaming functionality
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleAttachmentsMenu = () => {
    setAttachmentsMenuOpen(!attachmentsMenuOpen);
  };

  const toggleWebSearchButton = () => {
    setWebSearchActive(!webSearchActive);
    if (imageGenActive) setImageGenActive(false);
  };

  const toggleImageGenButton = () => {
    setImageGenActive(!imageGenActive);
    if (webSearchActive) setWebSearchActive(false);
  };

  const handleFileUpload = () => {
    console.log('File upload');
    setAttachmentsMenuOpen(false);
  };

  const handleImageUpload = () => {
    console.log('Image upload');
    setAttachmentsMenuOpen(false);
  };

  const handleCameraCapture = () => {
    console.log('Camera capture');
    setAttachmentsMenuOpen(false);
  };

  // Handle image actions
  const handleImageRegenerate = (imageId) => {
    console.log('Regenerate image:', imageId);
    // Implement regeneration logic
  };

  const handleImageEdit = (imageId) => {
    console.log('Edit image:', imageId);
    // Implement edit logic
  };

  const handleImageInfo = (attachment) => {
    console.log('Show image info:', attachment);
    // Implement info display logic
  };

  const handleImageCopy = (imageId) => {
    console.log('Copy image:', imageId);
    // Implement copy logic
  };

  // Handle file actions
  const handleFileDownload = async (fileId, fileName) => {
    try {
      await downloadImage(fileId, fileName);
    } catch (error) {
      console.error('Error downloading file:', error);
    }
  };

  const handleFileInfo = (attachment) => {
    console.log('Show file info:', attachment);
    // Implement file info display logic
  };

  // Handle model selection
  const handleModelSelect = useCallback((model) => {
    setSelectedModel(model);
    sessionStorage.setItem('selectedModel', JSON.stringify(model));
    console.log('Selected model:', model);
  }, []);

  // Handle message editing - Updated to work with inline editing
  const handleEditMessage = useCallback(async (updatedMessage) => {
    try {
      if (updatedMessage.content.trim() === '') {
        console.error('Cannot save empty message');
        return;
      }

      // Update the message in the local state first
      const updatedMessages = messages.map(msg => 
        msg.id === updatedMessage.id 
          ? { ...msg, content: updatedMessage.content.trim() }
          : msg
      );
      
      setMessages(updatedMessages);
      
      // Prepare the chat data for API update
      const chatData = {
        title: selectedChat.title,
        messages: updatedMessages.map(msg => ({
          id: msg.id,
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp || msg.created_at,
          attachments: msg.attachments || [],
          generated_images: msg.generated_images || [],
          websearch: msg.websearch || false,
          search_urls: msg.search_urls || [],
          search_query: msg.search_query || ''
        }))
      };
      
      // Send update to API using the dedicated function
      const result = await updateChatConversation(selectedChat.id, chatData);
      console.log('Chat updated successfully:', result);
      
    } catch (error) {
      console.error('Error editing message:', error);
      // Revert the local changes if API call failed
      loadChatById(selectedChat.id);
      // You can add an error toast notification here
    }
  }, [messages, selectedChat, loadChatById]);

  // Use the new ChatContent component
  const renderChatContent = () => {
    return (
      <ChatContent
        selectedChat={selectedChat}
        messages={messages}
        chatLoading={chatLoading}
        getFileDownloadUrl={getFileDownloadUrl}
        handleImageRegenerate={handleImageRegenerate}
        handleImageEdit={handleImageEdit}
        handleImageInfo={handleImageInfo}
        handleImageCopy={handleImageCopy}
        handleFileDownload={handleFileDownload}
        onEditMessage={handleEditMessage}
        t={t}
      />
    );
  };











  const renderGalleryContent = () => (
    <div className="flex-1 h-full flex flex-col">
      {/* Gallery Header */}
      <motion.div 
        className="p-6 border-b border-[var(--border-color)] bg-[var(--background)]/80 backdrop-blur-sm"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-2">
              {t('ai.imageGallery')}
            </h2>
            <p className="text-[var(--text-secondary)]">
              {galleryTotalCount > 0 
                ? t('ai.gallery.totalImages', { count: galleryTotalCount })
                : t('ai.gallery.noImages')
              }
            </p>
          </div>
          
                     <motion.div
             className="p-3 bg-[var(--background-tertiary)] rounded-2xl"
             whileHover={{ scale: 1.05 }}
           >
             <Images className="w-6 h-6 text-[var(--text-primary)]" />
           </motion.div>
        </div>
      </motion.div>

      {/* Gallery Grid */}
      <div className="flex-1 overflow-auto custom-scrollbar">
        <div className="p-6">
          {!galleryInitialLoad && galleryLoading ? (
            <div className="flex justify-center items-center py-20">
              <div className="text-center">
                <Loader2 className="w-12 h-12 animate-spin text-[var(--text-secondary)] mx-auto mb-4" />
                <p className="text-[var(--text-secondary)]">{t('common.loading')}</p>
              </div>
            </div>
          ) : galleryImages.length > 0 ? (
            <>
              <motion.div 
                className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                layout
              >
                {galleryImages.map((image, index) => (
                  <motion.div
                    key={image.id}
                    className="group relative aspect-square bg-[var(--background-secondary)] rounded-2xl overflow-hidden border border-[var(--border-color)]/30 hover:border-[var(--accent-color)]/30 transition-all duration-300"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05, duration: 0.3 }}
                    whileHover={{ y: -4, scale: 1.02 }}
                    layout
                  >
                    <OptimizedImage
                      src={image.id}
                      alt={image.name}
                      className="w-full h-full"
                    />
                    
                    {/* Overlay */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      initial={false}
                    >
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-sm font-medium truncate">
                              {image.name}
                            </p>
                            <p className="text-white/70 text-xs">
                              {formatTime(image.createdAt)}
                            </p>
                          </div>
                          
                          <div className="flex gap-2 ml-2">
                            <motion.button
                              onClick={() => handleImageView(image)}
                              className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              title="عرض مكبر"
                            >
                              <Eye className="w-4 h-4 text-white" />
                            </motion.button>
                            
                            <motion.button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTestImageLoad(image);
                              }}
                              className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              title="اختبار التحميل"
                            >
                              <Info className="w-4 h-4 text-white" />
                            </motion.button>
                            
                            <motion.button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleImageDownload(image);
                              }}
                              className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              title="تحميل الصورة"
                            >
                              <Download className="w-4 h-4 text-white" />
                            </motion.button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                ))}
              </motion.div>
              
              {/* Loading trigger for gallery */}
              <div ref={loadingTriggerRef} className="h-20 flex items-center justify-center mt-8 custom-scrollbar">
                {galleryLoading && (
                  <div className="flex items-center gap-3">
                    <Loader2 className="w-5 h-5 animate-spin text-[var(--text-secondary)]" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('common.loading')}</span>
                  </div>
                )}
                {!galleryHasMore && galleryImages.length > 0 && (
                  <div className="text-center py-8">
                    <p className="text-sm text-[var(--text-secondary)]">{t('ai.gallery.noImages')}</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <motion.div 
              className="flex flex-col items-center justify-center py-20 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="w-24 h-24 bg-[var(--background-secondary)] rounded-3xl flex items-center justify-center mb-6">
                <Images className="w-12 h-12 text-[var(--text-secondary)]" />
              </div>
              <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">
                {t('ai.gallery.noImages')}
              </h3>
              <p className="text-[var(--text-secondary)] max-w-md">
                {t('ai.welcome.description')}
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );

  const renderSidebarConversations = () => (
    <>
      {conversations.length > 0 ? (
        <div className="space-y-2">
          {conversations.map((chat, index) => (
            <motion.button
              key={chat.id}
              onClick={() => {
                navigate(`/aiassistant/chat/${chat.id}`);
              }}
              className={`w-full p-4 rounded-xl text-left transition-all duration-200 group ${
                selectedChat?.id === chat.id
                  ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)]'
                  : 'bg-[var(--background)] hover:bg-[var(--background-tertiary)] text-[var(--text-primary)] border border-[var(--border-color)]/30'
              }`}
              initial={{ opacity: 0, x: currentIsRTL ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02, x: currentIsRTL ? -4 : 4 }}
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${
                  selectedChat?.id === chat.id
                    ? 'bg-white/20'
                    : 'bg-[var(--background-secondary)] group-hover:bg-[var(--background-tertiary)]'
                }`}>
                  <MessageCircle className="w-4 h-4" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm truncate mb-1">
                    {chat.title}
                  </h4>
                  {chat.lastMessage && (
                    <p className={`text-xs truncate ${
                      selectedChat?.id === chat.id
                        ? 'text-white/70'
                        : 'text-[var(--text-secondary)]'
                    }`}>
                      {chat.lastMessage}
                    </p>
                  )}
                  <p className={`text-xs mt-1 ${
                    selectedChat?.id === chat.id
                      ? 'text-white/60'
                      : 'text-[var(--text-secondary)]'
                  }`}>
                    {formatTime(chat.timestamp)}
                  </p>
                </div>
              </div>
            </motion.button>
          ))}
          
          {/* Loading trigger for conversations */}
          <div ref={conversationsLoadingTriggerRef} className="h-16 flex items-center justify-center custom-scrollbar">
            {conversationsLoading && (
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-[var(--text-secondary)]" />
                <span className="text-xs text-[var(--text-secondary)]">{t('common.loading')}</span>
              </div>
            )}
            {!conversationsHasMore && conversations.length > 0 && (
              <div className="text-center py-4">
                <p className="text-xs text-[var(--text-secondary)]">{t('ai.conversations')}</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <motion.div 
          className="text-center py-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-16 h-16 bg-[var(--background-secondary)] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <MessageCircle className="w-8 h-8 text-[var(--text-secondary)]" />
          </div>
          <p className="text-sm text-[var(--text-secondary)] mb-4">{t('ai.gallery.noImages')}</p>
          <Button
            onClick={startNewChat}
            size="sm"
            className="bg-[var(--accent-color)] hover:bg-[var(--accent-color)]/90 text-[var(--accent-text-color)]"
          >
            {t('ai.newChat')}
          </Button>
        </motion.div>
      )}
    </>
  );

  // Fallback RTL detection - نفس الحل المستخدم في Communities
  const currentIsRTL = isRTL || language === 'ar' || document.documentElement.dir === 'rtl';
  
  console.log('🎯 AIAssistant RTL State:', { 
    isRTL, 
    language, 
    documentDir: document.documentElement.dir,
    currentIsRTL,
    finalLayout: currentIsRTL ? 'RTL (Right)' : 'LTR (Left)',
    layoutType: 'Horizontal (Sidebar beside Chat)'
  });

  return (
    <div className={`fixed inset-0 bg-[var(--background)] flex ${currentIsRTL ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Sidebar - Takes space in layout on desktop, overlay on mobile */}
      <div className={`
        ${showMobileSidebar ? 'translate-x-0' : (currentIsRTL ? 'translate-x-full' : '-translate-x-full')}
        lg:translate-x-0
        ${showMobileSidebar ? 'fixed' : 'lg:relative fixed'}
        inset-y-0
        ${currentIsRTL ? 'right-0' : 'left-0'}
        z-40
        w-[280px]
        bg-[var(--background-secondary)]
        ${currentIsRTL ? 'border-l' : 'border-r'} border-[var(--border-color)]
        h-full
        overflow-hidden
        transition-transform duration-300 ease-in-out
        lg:flex-shrink-0
      `}>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col h-full"
        >
                 {/* Header with Logo - ثيم أبيض وأسود */}
        <motion.div 
          className="p-4 md:p-6 border-b border-[var(--border-color)] bg-[var(--background-tertiary)]"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
            <motion.div
              className="relative"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <img
                src="/src/assets/logo.png"
                alt="TalebGPT"
                className="w-8 h-8 md:w-10 md:h-10 rounded-2xl object-contain shadow-lg"
              />
              <div className="absolute -top-1 -right-1 w-3 h-3 md:w-4 md:h-4 bg-gradient-to-br from-green-400 to-green-500 rounded-full border-2 border-[var(--background-secondary)]"></div>
            </motion.div>
            <div className="flex-1">
              <h1 className="text-base md:text-lg font-bold text-[var(--text-primary)]">
                {t('ai.title')}
              </h1>
              <p className="text-xs text-[var(--text-secondary)]">
                {selectedModel ? `${t('ai.currentModel')}: ${selectedModel.name}` : (t('ai.assistant') || 'مساعدك الذكي')}
              </p>
            </div>
          </div>

          {/* Navigation Tabs - Image Gallery and Conversations only */}
          <div className="flex flex-col gap-2">
            <button
              onClick={showGallery}
              className={`px-3 md:px-4 py-2 md:py-3 rounded-lg transition-all duration-200 flex items-center gap-2 md:gap-3 ${
                activeSection === 'gallery'
                  ? 'bg-[var(--text-primary)] text-[var(--background)] shadow-md'
                  : 'text-[var(--text-primary)] hover:bg-[var(--background-secondary)]'
              }`}
            >
              <Images className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-xs md:text-sm font-medium">{t('ai.imageGallery')}</span>
            </button>
            
            <button
              onClick={showConversations}
              className={`px-3 md:px-4 py-2 md:py-3 rounded-lg transition-all duration-200 flex items-center gap-2 md:gap-3 ${
                activeSection === 'conversations'
                  ? 'bg-[var(--text-primary)] text-[var(--background)] shadow-md'
                  : 'text-[var(--text-primary)] hover:bg-[var(--background-secondary)]'
              }`}
            >
              <MessageCircle className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-xs md:text-sm font-medium">{t('ai.conversations')}</span>
            </button>
          </div>

          <motion.div 
            className="mt-4 md:mt-6 pt-3 md:pt-4 border-t border-[var(--border-color)]/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={startNewChat}
              className="w-full bg-[var(--text-primary)] hover:bg-[var(--text-primary)]/90 text-[var(--background)] border-0 shadow-lg transition-all duration-300"
              size="sm"
            >
              <Plus className="w-3 h-3 md:w-4 md:h-4 mr-2" />
              <span className="text-xs md:text-sm">{t('ai.newChat')}</span>
            </Button>
          </motion.div>
        </motion.div>

        {/* Content Area */}
        <div className="flex-1 overflow-auto custom-scrollbar">
          <div className="p-3 md:p-4">
            {activeSection === 'conversations' ? (
              <div>
                <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                  <div className="p-1.5 md:p-2 bg-[var(--background-tertiary)] rounded-xl">
                    <MessageCircle className="w-4 h-4 md:w-5 md:h-5 text-[var(--text-primary)]" />
                  </div>
                  <div>
                    <h3 className="text-xs md:text-sm font-semibold text-[var(--text-primary)]">
                      {t('ai.conversations')}
                    </h3>
                  </div>
                </div>
                
                {!conversationsInitialLoad && conversationsLoading ? (
                  <div className="flex justify-center items-center py-12">
                    <div className="text-center">
                      <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)] mx-auto mb-3" />
                      <p className="text-sm text-[var(--text-secondary)]">{t('common.loading')}</p>
                    </div>
                  </div>
                ) : (
                  renderSidebarConversations()
                )}
              </div>
            ) : activeSection === 'gallery' ? (
              <div>
                <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                  <div className="p-1.5 md:p-2 bg-[var(--background-tertiary)] rounded-xl">
                    <Images className="w-4 h-4 md:w-5 md:h-5 text-[var(--text-primary)]" />
                  </div>
                  <div>
                    <h3 className="text-xs md:text-sm font-semibold text-[var(--text-primary)]">
                      {t('ai.imageGallery')}
                    </h3>
                    <p className="text-xs text-[var(--text-secondary)]">
                      {galleryTotalCount > 0 
                        ? t('ai.gallery.totalImages', { count: galleryTotalCount })
                        : t('ai.gallery.noImages')
                      }
                    </p>
                  </div>
                </div>
                
                <motion.div
                  className="p-3 md:p-4 bg-[var(--background-secondary)] rounded-2xl border border-[var(--border-color)] hover:border-[var(--text-primary)]/30 transition-all duration-300"
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center gap-2 md:gap-3 mb-2 md:mb-3">
                    <motion.div
                      className="p-1.5 md:p-2 bg-[var(--background-tertiary)] rounded-xl"
                      whileHover={{ rotate: 10 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-[var(--text-primary)]" />
                    </motion.div>
                    <span className="text-sm md:text-base font-semibold text-[var(--text-primary)]">{t('ai.generatedImages')}</span>
                  </div>
                  <p className="text-xs md:text-sm text-[var(--text-secondary)] leading-relaxed">
                                          {t('ai.welcome.description')}
                  </p>
                </motion.div>
              </div>
            ) : null}
          </div>
        </div>
        </motion.div>
      </div>

      {/* Main Content Area - Flex-1 takes remaining space beside sidebar */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Mobile Menu Button - Professional Design */}
        <button
          onClick={() => setShowMobileSidebar(!showMobileSidebar)}
          className={`
            lg:hidden
            absolute top-4 ${currentIsRTL ? 'right-4' : 'left-4'}
            z-50
            p-3
            bg-[var(--accent-color)]
            text-[var(--accent-text-color)]
            rounded-full
            shadow-lg
            hover:shadow-xl
            transition-all duration-200
            hover:scale-105
          `}
        >
          {showMobileSidebar ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>

        <motion.div 
          className="flex-1 flex flex-col h-full"
          initial={{ opacity: 0, x: currentIsRTL ? -20 : 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
        >
        {activeSection === 'gallery' ? (
          renderGalleryContent()
        ) : (
          <>
            {/* Chat Content - constrained by input width */}
            <div className="flex-1 overflow-hidden flex justify-center">
              <div className="w-full max-w-4xl custom-scrollbar">
                {renderChatContent()}
              </div>
            </div>

            {/* Chat Input - show when in conversations section */}
            {activeSection === 'conversations' && (
              <motion.div 
                className="w-full max-w-4xl mx-auto p-3 md:p-6 bg-transparent"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <ChatInput
                  message={inputMessage}
                  setMessage={setInputMessage}
                  handleSendMessage={handleSendMessage}
                  textareaRef={textareaRef}
                  direction={currentIsRTL ? 'rtl' : 'ltr'}
                  textInputDir={textDirection}
                  isMobile={false}
                  t={t}
                  isSending={isSending}
                  isGenerating={isGenerating}
                  onStopGeneration={handleStopGeneration}
                  webSearchActive={webSearchActive}
                  imageGenActive={imageGenActive}
                  autoOperationsActive={autoOperationsActive}
                  setWebSearchActive={setWebSearchActive}
                  setImageGenActive={setImageGenActive}
                  setAutoOperationsActive={setAutoOperationsActive}
                  selectedModel={selectedModel}
                  onModelSelect={handleModelSelect}
                  // New streaming props
                  selectedChat={selectedChat}
                  onStreamingMessage={handleStreamingMessage}
                  onStreamingComplete={handleStreamingComplete}
                  onStreamingError={handleStreamingError}
                  onNewConversation={handleNewConversation}
                />
              </motion.div>
            )}
          </>
        )}
        </motion.div>
      </div>

      {/* Mobile Overlay */}
      {showMobileSidebar && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setShowMobileSidebar(false)}
        />
      )}

      {/* Image Modal */}
      <ImageModal
        image={selectedImage}
        isOpen={imageModalOpen}
        onClose={() => {
          setImageModalOpen(false);
          setSelectedImage(null);
        }}
      />
    </div>
  );
}
