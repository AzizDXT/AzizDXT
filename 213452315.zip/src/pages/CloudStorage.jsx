
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Cloud,
  Upload,
  FolderPlus,
  Share2,
  Download,
  Trash2,
  Search,
  Filter,
  Grid3X3,
  List,
  ArrowLeft,
  Home,
  ChevronRight,
  MoreVertical,
  File,
  Folder,
  Image,
  FileText,
  Video,
  Music,
  Archive,
  Eye,
  Move,
  Copy,
  Star,
  Clock,
  User,
  HardDrive,
  AlertCircle,
  CheckCircle,
  Loader2,
  X,
  Plus,
  Settings,
  Link as LinkIcon,
  Lock,
  Globe,
  Users,
  Key,
  Calendar,
  BarChart3,
  RefreshCw,
  Smartphone,
  Monitor,
  Tablet
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom'; // Added useLocation
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';
import api from '../components/utils/api';

// Utility functions
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const formatDate = (dateString, locale) => {
  return new Date(dateString).toLocaleDateString(locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const getFileIcon = (mimeType, extension) => {
  if (mimeType?.startsWith('image/')) return <Image className="w-5 h-5 text-blue-500" />;
  if (mimeType?.startsWith('video/')) return <Video className="w-5 h-5 text-purple-500" />;
  if (mimeType?.startsWith('audio/')) return <Music className="w-5 h-5 text-green-500" />;
  if (mimeType?.includes('pdf') || mimeType?.includes('document')) return <FileText className="w-5 h-5 text-red-500" />;
  if (mimeType?.includes('zip') || mimeType?.includes('archive')) return <Archive className="w-5 h-5 text-orange-500" />;
  return <File className="w-5 h-5 text-gray-500" />;
};

const getFileTypeFilter = (mimeType) => {
  if (mimeType?.startsWith('image/')) return 'images';
  if (mimeType?.startsWith('video/')) return 'videos';
  if (mimeType?.startsWith('audio/')) return 'audio';
  if (mimeType?.includes('pdf') || mimeType?.includes('document')) return 'documents';
  if (mimeType?.includes('zip') || mimeType?.includes('archive')) return 'archives';
  return 'others';
};

// Custom Confirm Dialog
const ConfirmDialog = ({ isOpen, title, message, onConfirm, onCancel, isDestructive = false }) => {
  const { t, language } = useI18n();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-4 mb-6">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
            isDestructive ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
          }`}>
            {isDestructive ? <AlertCircle className="w-6 h-6" /> : <Cloud className="w-6 h-6" />}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-[var(--text-primary)] mb-2">{title}</h3>
            <p className="text-[var(--text-secondary)] text-sm leading-relaxed">{message}</p>
          </div>
        </div>
        
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={onCancel} className="min-w-[80px]">
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button 
            variant={isDestructive ? "destructive" : "default"} 
            onClick={onConfirm}
            className="min-w-[80px]"
          >
            {language === 'ar' ? 'تأكيد' : 'Confirm'}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

// Upload Progress Component
const UploadProgress = ({ uploads, onCancel }) => {
  const { t } = useI18n();

  if (uploads.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 w-80 max-h-96 overflow-y-auto bg-[var(--background)] border border-[var(--border-color)] rounded-2xl shadow-2xl z-40">
      <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
        <h3 className="font-semibold text-[var(--text-primary)]">{t('storage.uploadProgress')}</h3>
        <Button variant="ghost" size="icon" onClick={() => onCancel('all')}>
          <X className="w-4 h-4" />
        </Button>
      </div>
      <div className="p-4 space-y-3">
        {uploads.map((upload) => (
          <div key={upload.id} className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-[var(--text-primary)] truncate">{upload.name}</span>
              <Button variant="ghost" size="icon" onClick={() => onCancel(upload.id)} className="w-6 h-6">
                <X className="w-3 h-3" />
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Progress value={upload.progress} className="flex-1" />
              <span className="text-xs text-[var(--text-secondary)]">{upload.progress}%</span>
            </div>
            <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
              <span>{upload.status}</span>
              <span>{formatFileSize(upload.size)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// File Upload Component
const FileUploadZone = ({ onFilesSelected, isUploading }) => {
  const { t } = useI18n();
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    onFilesSelected(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    onFilesSelected(files);
  };

  return (
    <div
      className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
        isDragOver 
          ? 'border-[var(--accent-color)] bg-[var(--accent-color)]/5' 
          : 'border-[var(--border-color)] hover:border-[var(--accent-color)]'
      } ${isUploading ? 'pointer-events-none opacity-50' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="space-y-4">
        <div className="w-16 h-16 mx-auto bg-[var(--background-secondary)] rounded-full flex items-center justify-center">
          {isUploading ? (
            <Loader2 className="w-8 h-8 text-[var(--accent-color)] animate-spin" />
          ) : (
            <Upload className="w-8 h-8 text-[var(--accent-color)]" />
          )}
        </div>
        <div>
          <p className="text-lg font-semibold text-[var(--text-primary)] mb-2">
            {isUploading ? t('storage.uploading') : t('storage.dragDropUpload')}
          </p>
          <p className="text-sm text-[var(--text-secondary)]">
            {t('storage.supportedFormats')}
          </p>
        </div>
        {!isUploading && (
          <div>
            <input
              type="file"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload">
              <Button as="span" className="cursor-pointer">
                <Upload className="w-4 h-4 mr-2" />
                {t('storage.uploadFile')}
              </Button>
            </label>
          </div>
        )}
      </div>
    </div>
  );
};

// Storage Overview Component
const StorageOverview = ({ quota, onRefresh }) => {
  const { t, language } = useI18n();

  if (!quota) return null;

  const usagePercentage = quota.usage_percentage || 0;
  const isNearLimit = usagePercentage > 80;
  const isOverLimit = quota.is_over_quota;

  return (
    <Card className="bg-[var(--background)] border-[var(--border-color)]">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-[var(--text-primary)] flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            {t('storage.storageOverview')}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onRefresh}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-[var(--text-secondary)]">{t('storage.used')}</span>
            <span className="font-medium text-[var(--text-primary)]">
              {quota.used_storage_gb?.toFixed(2)} GB {t('storage.of')} {quota.quota_gb?.toFixed(2)} GB
            </span>
          </div>
          <Progress 
            value={usagePercentage} 
            className={`h-2 ${isOverLimit ? 'text-red-500' : isNearLimit ? 'text-yellow-500' : 'text-green-500'}`}
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-1">
            <div className="text-[var(--text-secondary)]">{t('storage.available')}</div>
            <div className="font-semibold text-[var(--text-primary)]">
              {quota.available_storage_gb?.toFixed(2)} GB
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-[var(--text-secondary)]">{t('storage.fileCount')}</div>
            <div className="font-semibold text-[var(--text-primary)]">
              {quota.file_count || 0} {t('storage.files')}
            </div>
          </div>
        </div>

        {isOverLimit && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <div className="font-medium text-red-800">{t('storage.quotaExceeded')}</div>
              <div className="text-red-700">{t('storage.upgradeStorage')}</div>
            </div>
          </div>
        )}

        {isNearLimit && !isOverLimit && (
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <div className="font-medium text-yellow-800">{t('storage.quotaWarning')}</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Breadcrumb Component
const Breadcrumb = ({ path, onNavigate }) => {
  const { t } = useI18n();

  return (
    <nav className="flex items-center space-x-1 text-sm text-[var(--text-secondary)] mb-4">
      <button
        onClick={() => onNavigate(null)}
        className="flex items-center gap-1 hover:text-[var(--text-primary)] transition-colors"
      >
        <Home className="w-4 h-4" />
        {t('storage.rootFolder')}
      </button>
      
      {path && path.length > 0 && (
        <>
          {path.map((folder, index) => (
            <React.Fragment key={folder.id}>
              <ChevronRight className="w-4 h-4" />
              <button
                onClick={() => onNavigate(folder.id)}
                className="hover:text-[var(--text-primary)] transition-colors"
              >
                {folder.name}
              </button>
            </React.Fragment>
          ))}
        </>
      )}
    </nav>
  );
};

// File/Folder Item Component
const FileItem = ({ item, isSelected, onSelect, onAction, viewMode = 'list' }) => {
  const { t, language } = useI18n();
  const [showActions, setShowActions] = useState(false);

  const isFolder = item.hasOwnProperty('file_count');
  const isShared = item.share_level && item.share_level !== 'disabled';

  if (viewMode === 'grid') {
    return (
      <motion.div
        layout
        className={`group relative bg-[var(--background)] border border-[var(--border-color)] rounded-xl p-4 hover:shadow-lg transition-all duration-200 ${
          isSelected ? 'ring-2 ring-[var(--accent-color)] border-[var(--accent-color)]' : ''
        }`}
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isFolder ? (
                <Folder className="w-6 h-6 text-yellow-500" />
              ) : (
                getFileIcon(item.mime_type, item.extension)
              )}
              {isShared && <Share2 className="w-3 h-3 text-blue-500" />}
            </div>
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={isSelected}
                onChange={() => onSelect(item.id)}
                className="rounded border-gray-300"
              />
              <Button
                variant="ghost"
                size="icon"
                className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => setShowActions(!showActions)}
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="font-medium text-[var(--text-primary)] truncate text-sm">
              {item.original_name || item.name}
            </h3>
            <div className="text-xs text-[var(--text-secondary)] space-y-1">
              {isFolder ? (
                <>
                  <div>{item.file_count} {t('storage.files')}</div>
                  <div>{item.subfolder_count} {t('storage.folders')}</div>
                </>
              ) : (
                <>
                  <div>{formatFileSize(item.size)}</div>
                  <div>{formatDate(item.updated_at || item.time_updated, language)}</div>
                </>
              )}
            </div>
          </div>

          {/* Grid Actions Menu */}
          <AnimatePresence>
            {showActions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute top-12 right-2 bg-[var(--background)] border border-[var(--border-color)] rounded-lg shadow-lg py-1 min-w-[120px] z-10"
              >
                <button
                  onClick={() => onAction('view', item)}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-[var(--background-secondary)] flex items-center gap-2"
                >
                  <Eye className="w-4 h-4" />
                  {isFolder ? t('common.open') : t('storage.preview')}
                </button>
                {!isFolder && (
                  <button
                    onClick={() => onAction('download', item)}
                    className="w-full px-3 py-2 text-left text-sm hover:bg-[var(--background-secondary)] flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    {t('storage.download')}
                  </button>
                )}
                <button
                  onClick={() => onAction('share', item)}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-[var(--background-secondary)] flex items-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  {t('storage.share')}
                </button>
                <button
                  onClick={() => onAction('move', item)}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-[var(--background-secondary)] flex items-center gap-2"
                >
                  <Move className="w-4 h-4" />
                  {t('storage.move')}
                </button>
                <button
                  onClick={() => onAction('delete', item)}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-red-50 text-red-600 flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  {t('storage.delete')}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    );
  }

  // List view
  return (
    <motion.tr
      layout
      className={`group hover:bg-[var(--background-secondary)] transition-colors ${
        isSelected ? 'bg-[var(--accent-color)]/5' : ''
      }`}
    >
      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => onSelect(item.id)}
            className="rounded border-gray-300"
          />
          <div className="flex items-center gap-2">
            {isFolder ? (
              <Folder className="w-5 h-5 text-yellow-500" />
            ) : (
              getFileIcon(item.mime_type, item.extension)
            )}
            {isShared && <Share2 className="w-3 h-3 text-blue-500" />}
          </div>
          <span className="font-medium text-[var(--text-primary)] truncate max-w-xs">
            {item.original_name || item.name}
          </span>
        </div>
      </td>
      <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
        {isFolder ? `${item.file_count} ${t('storage.files')}` : formatFileSize(item.size)}
      </td>
      <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
        {formatDate(item.updated_at || item.time_updated, language)}
      </td>
      <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">
        {isFolder ? t('storage.folder') : (item.mime_type?.split('/')[0] || 'file')}
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onAction('view', item)}
            className="w-8 h-8"
          >
            <Eye className="w-4 h-4" />
          </Button>
          {!isFolder && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onAction('download', item)}
              className="w-8 h-8"
            >
              <Download className="w-4 h-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onAction('share', item)}
            className="w-8 h-8"
          >
            <Share2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onAction('move', item)}
            className="w-8 h-8"
          >
            <Move className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onAction('delete', item)}
            className="w-8 h-8 text-red-500 hover:text-red-700"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </td>
    </motion.tr>
  );
};

// Share Modal Component
const ShareModal = ({ isOpen, item, onClose, onShare }) => {
  const { t, language } = useI18n();
  const [shareConfig, setShareConfig] = useState({
    share_level: 'disabled',
    share_password: '',
    share_expires_at: '',
    share_max_downloads: '',
    specific_user_ids: []
  });
  const [isSharing, setIsSharing] = useState(false);
  const [shareResult, setShareResult] = useState(null);

  useEffect(() => {
    if (item && isOpen) {
      setShareConfig({
        share_level: item.share_level || 'disabled',
        share_password: '',
        share_expires_at: item.share_expires_at || '',
        share_max_downloads: item.share_max_downloads || '',
        specific_user_ids: []
      });
      setShareResult(item.share_token ? {
        share_token: item.share_token,
        share_url: `${api.baseURL}/api/v1/storage/share/${item.share_token}`
      } : null);
    }
  }, [item, isOpen]);

  const handleShare = async () => {
    setIsSharing(true);
    try {
      const result = await onShare(item.id, shareConfig);
      setShareResult(result);
    } catch (error) {
      console.error('Share error:', error);
    } finally {
      setIsSharing(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // Could add a toast notification here
  };

  if (!isOpen || !item) return null;

  const isFolder = item.hasOwnProperty('file_count');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            {t('storage.share')} {isFolder ? t('storage.folder') : t('storage.file')}
          </h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-4">
          <div className="p-3 bg-[var(--background-secondary)] rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              {isFolder ? (
                <Folder className="w-4 h-4 text-yellow-500" />
              ) : (
                getFileIcon(item.mime_type, item.extension)
              )}
              <span className="font-medium text-[var(--text-primary)] truncate">
                {item.original_name || item.name}
              </span>
            </div>
            {!isFolder && (
              <div className="text-sm text-[var(--text-secondary)]">
                {formatFileSize(item.size)} • {formatDate(item.updated_at || item.time_updated, language)}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                {t('storage.shareLevel')}
              </label>
              <select
                value={shareConfig.share_level}
                onChange={(e) => setShareConfig({...shareConfig, share_level: e.target.value})}
                className="w-full p-2 border border-[var(--border-color)] rounded-lg bg-[var(--background)] text-[var(--text-primary)]"
              >
                <option value="disabled">{t('storage.shareDisabled')}</option>
                <option value="public_open">{t('storage.sharePublicOpen')}</option>
                <option value="public_platform">{t('storage.sharePublicPlatform')}</option>
                <option value="private_specific">{t('storage.sharePrivateSpecific')}</option>
                <option value="private_request">{t('storage.sharePrivateRequest')}</option>
              </select>
            </div>

            {shareConfig.share_level !== 'disabled' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                    {t('storage.sharePassword')} ({t('deepwrite.optional')})
                  </label>
                  <Input
                    type="password"
                    value={shareConfig.share_password}
                    onChange={(e) => setShareConfig({...shareConfig, share_password: e.target.value})}
                    placeholder={t('storage.sharePassword')}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                    {t('storage.shareExpiry')} ({t('deepwrite.optional')})
                  </label>
                  <Input
                    type="datetime-local"
                    value={shareConfig.share_expires_at}
                    onChange={(e) => setShareConfig({...shareConfig, share_expires_at: e.target.value})}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                    {t('storage.shareMaxDownloads')} ({t('deepwrite.optional')})
                  </label>
                  <Input
                    type="number"
                    value={shareConfig.share_max_downloads}
                    onChange={(e) => setShareConfig({...shareConfig, share_max_downloads: e.target.value})}
                    placeholder="100"
                  />
                </div>
              </>
            )}
          </div>

          {shareResult && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start gap-2 mb-3">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <div className="font-medium text-green-800">{t('storage.shareSuccess')}</div>
                  <div className="text-sm text-green-700">{t('storage.shareLink')}:</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Input
                  value={shareResult.share_url}
                  readOnly
                  className="text-sm"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(shareResult.share_url)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={onClose}>
              {t('common.cancel')}
            </Button>
            <Button 
              onClick={handleShare} 
              disabled={isSharing || shareConfig.share_level === 'disabled'}
            >
              {isSharing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('storage.sharing')}
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4 mr-2" />
                  {t('storage.share')}
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// Create Folder Modal
const CreateFolderModal = ({ isOpen, onClose, onCreateFolder, parentFolderId = null }) => {
  const { t, language } = useI18n();
  const [folderData, setFolderData] = useState({
    name: '',
    description: '',
    parent_folder_id: parentFolderId
  });
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFolderData({
        name: '',
        description: '',
        parent_folder_id: parentFolderId
      });
    }
  }, [isOpen, parentFolderId]);

  const handleCreate = async () => {
    if (!folderData.name.trim()) return;

    setIsCreating(true);
    try {
      await onCreateFolder(folderData);
      onClose();
    } catch (error) {
      console.error('Create folder error:', error);
      // Optionally show an error message to the user
    } finally {
      setIsCreating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-[var(--text-primary)] flex items-center gap-2">
            <FolderPlus className="w-5 h-5" />
            {t('storage.createFolderTitle')}
          </h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {t('storage.folderName')} *
            </label>
            <Input
              value={folderData.name}
              onChange={(e) => setFolderData({...folderData, name: e.target.value})}
              placeholder={t('storage.folderName')}
              autoFocus
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {t('storage.folderDescription')} ({t('deepwrite.optional')})
            </label>
            <Input
              value={folderData.description}
              onChange={(e) => setFolderData({...folderData, description: e.target.value})}
              placeholder={t('storage.folderDescription')}
            />
          </div>

          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={onClose}>
              {t('common.cancel')}
            </Button>
            <Button 
              onClick={handleCreate} 
              disabled={isCreating || !folderData.name.trim()}
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('common.creating')}
                </>
              ) : (
                <>
                  <FolderPlus className="w-4 h-4 mr-2" />
                  {t('common.create')}
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// Main CloudStorage Component
export default function CloudStorage() {
  const navigate = useNavigate();
  const { t, language, isRTL } = useI18n();
  const location = useLocation(); // Added useLocation hook

  // Determine if navigated from library based on URL query parameter
  const fromLibrary = new URLSearchParams(location.search).get('from') === 'library';

  // State management
  const [currentView, setCurrentView] = useState('myFiles'); // myFiles, sharedFiles, trash
  const [viewMode, setViewMode] = useState('list'); // list, grid
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [breadcrumbPath, setBreadcrumbPath] = useState([]);
  
  // Data states
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [quota, setQuota] = useState(null);
  const [uploads, setUploads] = useState([]);
  
  // Infinite scroll states
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 20;

  // UI states
  const [isLoading, setIsLoading] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('date');
  
  // Modal states
  const [showUploadZone, setShowUploadZone] = useState(false);
  const [showCreateFolder, setShowCreateFolder] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareItem, setShareItem] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState({ isOpen: false });

  // Load storage data with pagination
  const loadStorageData = useCallback(async (page = 1, append = false) => {
    setIsLoading(true);
    try {
      if (currentView === 'myFiles') {
        if (currentFolderId) {
          // Load folder contents with pagination
          const folderData = await api.getFolderContents(currentFolderId, { page, limit: ITEMS_PER_PAGE });
          const newFiles = folderData.files || [];
          const newFolders = folderData.subfolders || [];
          const currentHasMore = folderData.has_more !== undefined ? folderData.has_more : (newFiles.length + newFolders.length) === ITEMS_PER_PAGE;
          
          if (append) {
            setFiles(prev => [...prev, ...newFiles]);
            setFolders(prev => [...prev, ...newFolders]);
          } else {
            setFiles(newFiles);
            setFolders(newFolders);
          }
          setBreadcrumbPath(folderData.breadcrumb || []);
          setHasMore(currentHasMore);
        } else {
          // Load root level files and folders with pagination
          const [filesData, foldersData] = await Promise.all([
            api.getStorageFiles({ page, limit: ITEMS_PER_PAGE }),
            api.getFolders({ page, page_size: ITEMS_PER_PAGE, parent_folder_id: null })
          ]);
          
          const newFiles = filesData.files || [];
          const newFolders = foldersData.folders || [];
          
          if (append) {
            setFiles(prev => [...prev, ...newFiles]);
            setFolders(prev => [...prev, ...newFolders]);
          } else {
            setFiles(newFiles);
            setFolders(newFolders);
          }
          setBreadcrumbPath([]);
          setHasMore(filesData.has_more || newFiles.length === ITEMS_PER_PAGE);
        }
      } else if (currentView === 'sharedFiles') {
        const sharedData = await api.getSharedFiles({ page, page_size: ITEMS_PER_PAGE });
        const newFiles = sharedData.files || [];
        
        if (append) {
          setFiles(prev => [...prev, ...newFiles]);
        } else {
          setFiles(newFiles);
        }
        setFolders([]);
        setBreadcrumbPath([]);
        setHasMore(sharedData.has_next || newFiles.length === ITEMS_PER_PAGE);
      } else if (currentView === 'trash') {
        const trashData = await api.getTrashFiles({ page, limit: ITEMS_PER_PAGE });
        const newFiles = trashData.files || [];
        
        if (append) {
          setFiles(prev => [...prev, ...newFiles]);
        } else {
          setFiles(newFiles);
        }
        setFolders([]);
        setBreadcrumbPath([]);
        setHasMore(trashData.has_more || newFiles.length === ITEMS_PER_PAGE);
      }
    } catch (error) {
      console.error('Error loading storage data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [currentView, currentFolderId, ITEMS_PER_PAGE]);

  // Load storage quota
  const loadQuota = async () => {
    try {
      const quotaData = await api.getStorageQuota();
      setQuota(quotaData);
    } catch (error) {
      console.error('Error loading quota:', error);
    }
  };

  // Reset pagination and load initial data when view or folder changes
  useEffect(() => {
    setCurrentPage(1);
    setHasMore(true);
    setFiles([]); // Clear existing data to prevent flicker/incorrect state before new data loads
    setFolders([]); // Clear existing data
    loadStorageData(1, false);
    loadQuota();
  }, [currentView, currentFolderId, loadStorageData]);

  // Infinite scroll handler
  const handleScroll = useCallback(() => {
    const isAtBottom = (window.innerHeight + window.scrollY) >= (document.documentElement.scrollHeight - 1);

    if (isAtBottom && !isLoading && hasMore) {
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      loadStorageData(nextPage, true);
    }
  }, [currentPage, isLoading, hasMore, loadStorageData]);

  // Attach/detach scroll event listener
  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  // Handle file upload
  const handleFilesSelected = async (selectedFiles) => {
    const newUploads = selectedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      progress: 0,
      status: t('storage.uploading'),
      file
    }));

    setUploads(prev => [...prev, ...newUploads]);

    // Upload files sequentially
    for (const upload of newUploads) {
      try {
        // Simulate upload progress
        for (let progress = 0; progress <= 100; progress += 10) {
          setUploads(prev => prev.map(u => 
            u.id === upload.id ? { ...u, progress } : u
          ));
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        // Actual upload
        const result = await api.uploadFile(
          upload.file, 
          '', // description
          [], // tags
          currentFolderId // folder_id
        );

        setUploads(prev => prev.map(u => 
          u.id === upload.id ? { ...u, status: t('storage.uploadComplete'), progress: 100 } : u
        ));

        // Remove completed upload after 3 seconds
        setTimeout(() => {
          setUploads(prev => prev.filter(u => u.id !== upload.id));
        }, 3000);

      } catch (error) {
        console.error('Upload error:', error);
        setUploads(prev => prev.map(u => 
          u.id === upload.id ? { ...u, status: t('storage.uploadFailed'), progress: 0 } : u
        ));
      }
    }

    // Reload data after uploads complete
    setTimeout(() => {
      loadStorageData(1, false);
      loadQuota();
    }, 1000);
  };

  // Handle folder creation
  const handleCreateFolder = async (folderData) => {
    try {
      await api.createFolder(folderData);
      loadStorageData(1, false);
    } catch (error) {
      console.error('Error creating folder:', error);
      throw error;
    }
  };

  // Handle item actions
  const handleItemAction = async (action, item) => {
    switch (action) {
      case 'view':
        if (item.hasOwnProperty('file_count')) {
          // Navigate to folder
          setCurrentFolderId(item.id);
        } else {
          // Download file using proper API endpoint
          const downloadUrl = api.getFileDownloadUrl(item.id);
          window.open(downloadUrl, '_blank');
        }
        break;

      case 'download':
        try {
          const downloadUrl = api.getFileDownloadUrl(item.id);
          // Create a temporary link to trigger download
          const link = document.createElement('a');
          link.href = downloadUrl;
          link.download = item.original_name || 'download';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } catch (error) {
          console.error('Download error:', error);
        }
        break;

      case 'share':
        setShareItem(item);
        setShowShareModal(true);
        break;

      case 'move':
        // Could open folder selection modal
        console.log('Move item:', item);
        break;

      case 'delete':
        setConfirmDialog({
          isOpen: true,
          title: t('storage.confirmDelete'),
          message: t('storage.confirmDeleteText'),
          onConfirm: () => handleDeleteItem(item),
          isDestructive: true
        });
        break;

      case 'restore':
        try {
          await api.restoreFileFromTrash(item.id);
          loadStorageData(1, false);
        } catch (error) {
          console.error('Restore error:', error);
        }
        break;

      case 'permanentDelete':
        setConfirmDialog({
          isOpen: true,
          title: t('storage.confirmPermanentDelete'),
          message: t('storage.confirmPermanentDeleteText'),
          onConfirm: () => handlePermanentDelete(item),
          isDestructive: true
        });
        break;
    }
  };

  // Handle delete item
  const handleDeleteItem = async (item) => {
    try {
      await api.moveFileToTrash(item.id);
      loadStorageData(1, false);
      setConfirmDialog({ isOpen: false });
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  // Handle permanent delete
  const handlePermanentDelete = async (item) => {
    try {
      await api.deleteFilePermanently(item.id);
      loadStorageData(1, false);
      setConfirmDialog({ isOpen: false });
    } catch (error) {
      console.error('Permanent delete error:', error);
    }
  };

  // Handle share
  const handleShare = async (itemId, shareConfig) => {
    try {
      const result = await api.configureFileShare(itemId, shareConfig);
      loadStorageData(1, false); // Refresh to show updated share status
      return result;
    } catch (error) {
      console.error('Share error:', error);
      throw error;
    }
  };

  // Navigation functions
  const navigateToFolder = (folderId) => {
    setCurrentFolderId(folderId);
  };

  const handleBackToLibrary = () => {
    navigate(createPageUrl('Dashboard?tab=library'));
  };

  // Filter and sort items
  const filteredAndSortedItems = () => {
    let allItems = [...folders, ...files];

    // Apply search filter
    if (searchQuery) {
      allItems = allItems.filter(item => 
        (item.name || item.original_name || '').toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply type filter
    if (filterType !== 'all') {
      allItems = allItems.filter(item => {
        if (item.hasOwnProperty('file_count')) return filterType === 'folders';
        return getFileTypeFilter(item.mime_type) === filterType;
      });
    }

    // Apply sorting
    allItems.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return (a.name || a.original_name || '').localeCompare(b.name || b.original_name || '');
        case 'size':
          return (b.size || 0) - (a.size || 0);
        case 'type':
          if (a.hasOwnProperty('file_count') && !b.hasOwnProperty('file_count')) return -1;
          if (!a.hasOwnProperty('file_count') && b.hasOwnProperty('file_count')) return 1;
          return (a.mime_type || '').localeCompare(b.mime_type || '');
        case 'date':
        default:
          const dateA = new Date(a.updated_at || a.time_updated);
          const dateB = new Date(b.updated_at || b.time_updated);
          return dateB.getTime() - dateA.getTime();
      }
    });

    return allItems;
  };

  const allItems = filteredAndSortedItems();
  const isEmpty = allItems.length === 0 && !isLoading;

  return (
    <div className="min-h-screen bg-[var(--background)] p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Breadcrumb */}
        {fromLibrary && (
          <div className="mb-6">
            <nav className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-[var(--text-secondary)]">
              <button
                onClick={() => navigate(createPageUrl('Dashboard'))}
                className="flex items-center hover:text-[var(--text-primary)] transition-colors"
              >
                <Home className="w-4 h-4 mr-1" />
                {t('sidebar.home')}
              </button>
              <span>/</span>
              <button
                onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
                className="hover:text-[var(--text-primary)] transition-colors"
              >
                {t('library.title')}
              </button>
              <span>/</span>
              <span className="text-[var(--text-primary)] font-medium">{t('storage.title')}</span>
            </nav>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBackToLibrary}
              className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)] flex items-center gap-3">
                <Cloud className="w-8 h-8 text-blue-500" />
                {t('storage.title')}
              </h1>
              <p className="text-[var(--text-secondary)] mt-1">{t('storage.description')}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={() => setShowCreateFolder(true)}
              className="flex items-center gap-2"
            >
              <FolderPlus className="w-4 h-4" />
              {t('storage.createFolder')}
            </Button>
            <Button
              onClick={() => setShowUploadZone(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
            >
              <Upload className="w-4 h-4" />
              {t('storage.uploadFile')}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Storage Overview */}
            <StorageOverview quota={quota} onRefresh={loadQuota} />

            {/* Navigation */}
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  <button
                    onClick={() => setCurrentView('myFiles')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentView === 'myFiles'
                        ? 'bg-[var(--accent-color)] text-white'
                        : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <Folder className="w-4 h-4" />
                    {t('storage.myFiles')}
                  </button>
                  <button
                    onClick={() => setCurrentView('sharedFiles')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentView === 'sharedFiles'
                        ? 'bg-[var(--accent-color)] text-white'
                        : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <Share2 className="w-4 h-4" />
                    {t('storage.sharedFiles')}
                  </button>
                  <button
                    onClick={() => setCurrentView('trash')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentView === 'trash'
                        ? 'bg-[var(--accent-color)] text-white'
                        : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <Trash2 className="w-4 h-4" />
                    {t('storage.trash')}
                  </button>
                </nav>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-[var(--text-primary)]">
                  {t('storage.quickActions')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => setShowUploadZone(true)}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {t('storage.uploadFile')}
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => setShowCreateFolder(true)}
                >
                  <FolderPlus className="w-4 h-4 mr-2" />
                  {t('storage.createFolder')}
                </Button>
                {currentView === 'trash' && (
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-red-600 hover:text-red-700"
                    onClick={() => setConfirmDialog({
                      isOpen: true,
                      title: t('storage.confirmEmptyTrash'),
                      message: t('storage.confirmEmptyTrashText'),
                      onConfirm: async () => {
                        try {
                          await api.cleanupTrash();
                          loadStorageData(1, false);
                          setConfirmDialog({ isOpen: false });
                        } catch (error) {
                          console.error('Empty trash error:', error);
                        }
                      },
                      isDestructive: true
                    })}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    {t('storage.confirmEmptyTrash')}
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card className="bg-[var(--background)] border-[var(--border-color)]">
              <CardHeader className="pb-4">
                <div className="space-y-4">
                  {/* Breadcrumb */}
                  {currentView === 'myFiles' && (
                    <Breadcrumb path={breadcrumbPath} onNavigate={navigateToFolder} />
                  )}

                  {/* Controls */}
                  <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                    <div className="flex-1 flex gap-3">
                      {/* Search */}
                      <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-secondary)] w-4 h-4" />
                        <Input
                          placeholder={t('storage.searchFiles')}
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                      </div>

                      {/* Type Filter */}
                      <select
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        className="px-3 py-2 border border-[var(--border-color)] rounded-lg bg-[var(--background)] text-[var(--text-primary)]"
                      >
                        <option value="all">{t('storage.allTypes')}</option>
                        <option value="folders">{t('storage.folders')}</option>
                        <option value="images">{t('storage.images')}</option>
                        <option value="documents">{t('storage.documents')}</option>
                        <option value="videos">{t('storage.videos')}</option>
                        <option value="audio">{t('storage.audio')}</option>
                        <option value="archives">{t('storage.archives')}</option>
                        <option value="others">{t('storage.others')}</option>
                      </select>

                      {/* Sort */}
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="px-3 py-2 border border-[var(--border-color)] rounded-lg bg-[var(--background)] text-[var(--text-primary)]"
                      >
                        <option value="date">{t('storage.sortDate')}</option>
                        <option value="name">{t('storage.sortName')}</option>
                        <option value="size">{t('storage.sortSize')}</option>
                        <option value="type">{t('storage.sortType')}</option>
                      </select>
                    </div>

                    {/* View Mode */}
                    <div className="flex items-center gap-1 bg-[var(--background-secondary)] rounded-lg p-1">
                      <Button
                        variant={viewMode === 'list' ? 'default' : 'ghost'}
                        size="icon"
                        onClick={() => setViewMode('list')}
                        className="w-8 h-8"
                      >
                        <List className="w-4 h-4" />
                      </Button>
                      <Button
                        variant={viewMode === 'grid' ? 'default' : 'ghost'}
                        size="icon"
                        onClick={() => setViewMode('grid')}
                        className="w-8 h-8"
                      >
                        <Grid3X3 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Selected Items Actions */}
                  {selectedItems.length > 0 && (
                    <div className="flex items-center gap-3 p-3 bg-[var(--accent-color)]/10 rounded-lg">
                      <span className="text-sm font-medium text-[var(--text-primary)]">
                        {selectedItems.length} {t('storage.selectedFiles')}
                      </span>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Download className="w-4 h-4 mr-1" />
                          {t('storage.downloadSelected')}
                        </Button>
                        <Button size="sm" variant="outline">
                          <Move className="w-4 h-4 mr-1" />
                          {t('storage.moveSelected')}
                        </Button>
                        <Button size="sm" variant="outline">
                          <Share2 className="w-4 h-4 mr-1" />
                          {t('storage.shareSelected')}
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                          <Trash2 className="w-4 h-4 mr-1" />
                          {t('storage.deleteSelected')}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardHeader>

              <CardContent>
                {/* Upload Zone */}
                {showUploadZone && (
                  <div className="mb-6">
                    <FileUploadZone 
                      onFilesSelected={handleFilesSelected}
                      isUploading={uploads.length > 0}
                    />
                  </div>
                )}

                {/* Loading State */}
                {isLoading && allItems.length === 0 && (
                  <div className="flex items-center justify-center py-12">
                    <div className="flex items-center gap-3">
                      <Loader2 className="w-6 h-6 animate-spin text-[var(--accent-color)]" />
                      <span className="text-[var(--text-secondary)]">{t('common.loading')}</span>
                    </div>
                  </div>
                )}

                {/* Empty State */}
                {!isLoading && isEmpty && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto mb-4 bg-[var(--background-secondary)] rounded-full flex items-center justify-center">
                      <Cloud className="w-8 h-8 text-[var(--text-secondary)]" />
                    </div>
                    <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-2">
                      {currentView === 'trash' ? t('storage.noFilesInTrash') : t('storage.emptyStorage')}
                    </h3>
                    <p className="text-[var(--text-secondary)] mb-4">
                      {currentView === 'trash' 
                        ? t('storage.trashDescription')
                        : t('storage.emptyStorageDesc')
                      }
                    </p>
                    {currentView !== 'trash' && (
                      <Button onClick={() => setShowUploadZone(true)}>
                        <Upload className="w-4 h-4 mr-2" />
                        {t('storage.uploadFirstFile')}
                      </Button>
                    )}
                  </div>
                )}

                {/* Content */}
                {allItems.length > 0 && (
                  <div>
                    {viewMode === 'grid' ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                        <AnimatePresence>
                          {allItems.map((item) => (
                            <FileItem
                              key={item.id}
                              item={item}
                              isSelected={selectedItems.includes(item.id)}
                              onSelect={(id) => {
                                setSelectedItems(prev => 
                                  prev.includes(id) 
                                    ? prev.filter(i => i !== id)
                                    : [...prev, id]
                                );
                              }}
                              onAction={handleItemAction}
                              viewMode="grid"
                            />
                          ))}
                        </AnimatePresence>
                      </div>
                    ) : (
                      <div className="border border-[var(--border-color)] rounded-lg overflow-hidden">
                        <table className="w-full">
                          <thead className="bg-[var(--background-secondary)]">
                            <tr>
                              <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                                {t('storage.fileName')}
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                                {t('storage.fileSize')}
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                                {t('storage.dateModified')}
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                                {t('storage.fileType')}
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                                {t('storage.actions')}
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-[var(--background)] divide-y divide-[var(--border-color)]">
                            <AnimatePresence>
                              {allItems.map((item) => (
                                <FileItem
                                  key={item.id}
                                  item={item}
                                  isSelected={selectedItems.includes(item.id)}
                                  onSelect={(id) => {
                                    setSelectedItems(prev => 
                                      prev.includes(id) 
                                        ? prev.filter(i => i !== id)
                                        : [...prev, id]
                                    );
                                  }}
                                  onAction={handleItemAction}
                                  viewMode="list"
                                />
                              ))}
                            </AnimatePresence>
                          </tbody>
                        </table>
                      </div>
                    )}
                    {isLoading && allItems.length > 0 && (
                      <div className="flex items-center justify-center py-4">
                        <Loader2 className="w-5 h-5 animate-spin text-[var(--accent-color)]" />
                        <span className="text-sm text-[var(--text-secondary)] ml-2">{t('common.loadingMore')}</span>
                      </div>
                    )}
                    {!hasMore && allItems.length > 0 && (
                      <div className="text-center py-4 text-sm text-[var(--text-secondary)]">
                        {t('storage.noMoreFiles')}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Upload Progress */}
      <UploadProgress 
        uploads={uploads}
        onCancel={(uploadId) => {
          if (uploadId === 'all') {
            setUploads([]);
          } else {
            setUploads(prev => prev.filter(u => u.id !== uploadId));
          }
        }}
      />

      {/* Modals */}
      <CreateFolderModal
        isOpen={showCreateFolder}
        onClose={() => setShowCreateFolder(false)}
        onCreateFolder={handleCreateFolder}
        parentFolderId={currentFolderId}
      />

      <ShareModal
        isOpen={showShareModal}
        item={shareItem}
        onClose={() => {
          setShowShareModal(false);
          setShareItem(null);
        }}
        onShare={handleShare}
      />

      <ConfirmDialog
        isOpen={confirmDialog.isOpen}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog({ isOpen: false })}
        isDestructive={confirmDialog.isDestructive}
      />
    </div>
  );
}
