import Layout from "./Layout.jsx";
import SplashScreen from "../components/SplashScreen";
import ProtectedRoute from "../components/ProtectedRoute";
import Auth from "./Auth";
import Dashboard from "./Dashboard";
import Home from "./Home.jsx";
import Profile from "./Profile";
import Academic from "./Academic";
import Library from "./Library";
import DeepWrite from "./DeepWrite";
import Notes from "./Notes";
import Tasks from "./Tasks";
import Research from "./Research";
import CloudStorage from "./CloudStorage";
import AIAssistant from "./AIAssistant";
import Schedule from "./Schedule";
import Settings from "./Settings";
import Communities from "./Communities";
import Leaderboard from "./Leaderboard";
import TermsAndConditions from "./TermsAndConditions";
import PrivacyPolicy from "./PrivacyPolicy";
import { BrowserRouter as Router, Route, Routes, useLocation, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

const PAGES = {
    
    Auth: Auth,
    
    Dashboard: Dashboard,
    
    Home: Home,
    
    Profile: Profile,
    
    Academic: Academic,
    
    Library: Library,
    
    DeepWrite: DeepWrite,
    
    Notes: Notes,
    
    Tasks: Tasks,
    
    Research: Research,
    
    CloudStorage: CloudStorage,
    
    AIAssistant: AIAssistant,
    
    Schedule: Schedule,
    
    Settings: Settings,
    
    Communities: Communities,
    
    Leaderboard: Leaderboard,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    
    // Handle special AI Assistant routes
    if (url.includes('/aiassistant')) {
        return 'AIAssistant';
    }
    
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Auth />} />
                
                
                <Route path="/Auth" element={<Auth />} />
                
                <Route path="/Home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                
                <Route path="/Dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                
                <Route path="/Profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
                
                <Route path="/Academic" element={<ProtectedRoute><Academic /></ProtectedRoute>} />
                
                <Route path="/Library" element={<ProtectedRoute><Library /></ProtectedRoute>} />
                
                <Route path="/DeepWrite" element={<ProtectedRoute><DeepWrite /></ProtectedRoute>} />
                
                <Route path="/Notes" element={<ProtectedRoute><Notes /></ProtectedRoute>} />
                
                <Route path="/Tasks" element={<ProtectedRoute><Tasks /></ProtectedRoute>} />
                
                <Route path="/Research" element={<ProtectedRoute><Research /></ProtectedRoute>} />
                
                <Route path="/CloudStorage" element={<ProtectedRoute><CloudStorage /></ProtectedRoute>} />
                
                {/* AI Assistant routes with chat support */}
                <Route path="/aiassistant" element={<ProtectedRoute><AIAssistant /></ProtectedRoute>} />
                <Route path="/aiassistant/gallery" element={<ProtectedRoute><AIAssistant /></ProtectedRoute>} />
                <Route path="/aiassistant/chat/:chatId" element={<ProtectedRoute><AIAssistant /></ProtectedRoute>} />
                
                {/* Redirect from old AIAssistant route to new lowercase route */}
                <Route path="/AIAssistant" element={<Navigate to="/aiassistant" replace />} />
                
                <Route path="/Schedule" element={<ProtectedRoute><Schedule /></ProtectedRoute>} />
                
                <Route path="/Settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
                
                <Route path="/Communities" element={<ProtectedRoute><Communities /></ProtectedRoute>} />
                
                <Route path="/Leaderboard" element={<ProtectedRoute><Leaderboard /></ProtectedRoute>} />
                
                {/* Legal Pages */}
                <Route path="/terms" element={<TermsAndConditions />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    const [showSplash, setShowSplash] = useState(true);
    
    const handleSplashFinish = () => {
        setShowSplash(false);
    };

    return (
        <Router>
            {showSplash ? (
                <SplashScreen onFinish={handleSplashFinish} />
            ) : (
                <PagesContent />
            )}
        </Router>
    );
}
