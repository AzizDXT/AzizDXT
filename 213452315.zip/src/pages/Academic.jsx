
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Upload,
  FileText,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Camera,
  Edit,
  User,
  BookOpen,
  Calendar,
  BarChart3,
  Target,
  Star,
  TrendingUp,
  Clock,
  GraduationCap,
  ChevronRight
} from 'lucide-react';
import { useI18n } from '../components/utils/i18n';
import { academicAPI } from '../components/utils/api'; // Changed import path
import EditProfileModal from '../components/profile/EditProfileModal';
import StudentInfoCard from '../components/profile/StudentInfoCard';
import AcademicProgress from '../components/profile/AcademicProgress';
import CourseTable from '../components/profile/CourseTable';
import SemesterCard from '../components/profile/SemesterCard';
import AcademicAnalytics from '../components/profile/AcademicAnalytics';
import CachedImage from '../components/profile/CachedImage';

// Upload Component
const UploadSection = ({ onUploadComplete }) => {
  const { t } = useI18n();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef(null);

  const handleFileUpload = async (files) => {
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // Upload files
      const result = await academicAPI.uploadTranscriptFiles(Array.from(files), 'Academic transcript analysis');
      
      if (result.task_id) {
        // Start tracking the task with streaming
        await trackTaskProgress(result.task_id);
      }
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const trackTaskProgress = async (taskId) => {
    try {
      // Get initial task details
      const taskDetails = await academicAPI.getAnalysisTaskDetails(taskId, true);
      
      // Update progress based on task status
      if (taskDetails.progress) {
        setUploadProgress(taskDetails.progress);
      }

      // If task is completed, get the analysis results
      if (taskDetails.status === 'completed') {
        const analysisData = await academicAPI.getLatestAnalysis();
        onUploadComplete(analysisData);
      } else if (taskDetails.status === 'processing' || taskDetails.status === 'queued') {
        // Continue tracking if still processing
        setTimeout(() => trackTaskProgress(taskId), 2000);
      } else if (taskDetails.status === 'failed') {
        console.error('Task failed:', taskDetails.error_message);
        throw new Error(taskDetails.error_message || 'Task processing failed');
      }
    } catch (error) {
      console.error('Error tracking task:', error);
      throw error;
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <div className="relative">
          <div className="w-24 h-24 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
            <GraduationCap className="w-12 h-12 text-white" />
          </div>
          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <Upload className="w-4 h-4 text-white" />
          </div>
        </div>

        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-2">
            {t('academic.title')}
          </h1>
          <p className="text-[var(--text-secondary)] text-lg">
            Upload your academic transcript to get started with AI-powered analysis
          </p>
        </div>

        {!isUploading ? (
          <div className="space-y-4">
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[var(--border-color)] rounded-xl p-8 hover:border-blue-500 transition-colors cursor-pointer bg-[var(--background-secondary)] hover:bg-blue-50"
            >
              <FileText className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
              <p className="text-[var(--text-primary)] font-medium mb-2">
                Click to upload your academic transcript
              </p>
              <p className="text-sm text-[var(--text-secondary)]">
                Support for PDF, JPG, PNG files
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              onChange={(e) => handleFileUpload(e.target.files)}
              className="hidden"
            />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-[var(--background-secondary)] rounded-xl p-6">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500 mx-auto mb-4" />
              <p className="text-[var(--text-primary)] font-medium mb-2">
                Processing your transcript...
              </p>
              <p className="text-sm text-[var(--text-secondary)] mb-4">
                Our AI is analyzing your academic data
              </p>
              <Progress value={uploadProgress} className="w-full" />
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

// Main Academic Component
export default function Academic() {
  const { t, language } = useI18n();
  const [studentData, setStudentData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [profileImage, setProfileImage] = useState(null);
  const [hasData, setHasData] = useState(false);
  const [error, setError] = useState(null); // Added error state
  const imageInputRef = useRef(null);

  const isRTL = language === 'ar';

  useEffect(() => {
    loadAcademicData();
  }, []);

  const loadAcademicData = async () => {
    setIsLoading(true);
    setError(null); // Clear any previous errors
    
    try {
      // First check if there are any recent tasks
      const tasks = await academicAPI.getAnalysisTasks(0, 1);
      
      if (tasks.tasks && tasks.tasks.length > 0) {
        const latestTask = tasks.tasks[0];
        
        // If there's a completed task, get the latest analysis
        if (latestTask.status === 'completed') {
          const data = await academicAPI.getLatestAnalysis();
          setStudentData(data);
          setHasData(true);
          return;
        }
        
        // If there's a processing task, track it
        if (latestTask.status === 'processing' || latestTask.status === 'queued') {
          await trackExistingTask(latestTask.task_id);
          return;
        }
      }
      
      // Check if there's existing academic data
      const hasAcademicData = await academicAPI.hasAcademicData();
      
      if (hasAcademicData) {
        const data = await academicAPI.getLatestAnalysis();
        setStudentData(data);
        setHasData(true);
      } else {
        setHasData(false);
      }
    } catch (error) {
      console.error('Error loading academic data:', error);
      
      // Specific handling for authentication errors
      if (error.message && error.message.includes('Authentication required')) {
        setError('Authentication required. Please login to access your academic data.');
      } else {
        setError('Failed to load academic data. Please try again.');
      }
      
      setHasData(false);
    } finally {
      setIsLoading(false);
    }
  };

  const trackExistingTask = async (taskId) => {
    try {
      const taskDetails = await academicAPI.getAnalysisTaskDetails(taskId, true);
      
      if (taskDetails.status === 'completed') {
        const data = await academicAPI.getLatestAnalysis();
        setStudentData(data);
        setHasData(true);
      } else if (taskDetails.status === 'processing' || taskDetails.status === 'queued') {
        // Show processing state
        setHasData(false);
        // Continue tracking
        setTimeout(() => trackExistingTask(taskId), 2000);
      } else {
        setHasData(false);
      }
    } catch (error) {
      console.error('Error tracking existing task:', error);
      setHasData(false);
    }
  };

  const handleUploadComplete = (data) => {
    setStudentData(data);
    setHasData(true);
    setError(null); // Clear error on successful upload
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (updatedData) => {
    setStudentData(prev => ({
      ...prev,
      student_info: {
        ...prev.student_info,
        student_name: updatedData.name
      }
    }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center space-y-4"
        >
          <Loader2 className="w-12 h-12 animate-spin text-[var(--accent-color)] mx-auto" />
          <p className="text-[var(--text-secondary)]">{t('common.loading')}</p>
        </motion.div>
      </div>
    );
  }

  // Show error if authentication failed
  if (error) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">Authentication Required</h2>
        <p className="text-[var(--text-secondary)] mb-6">{error}</p>
        <div className="flex gap-4 justify-center">
          <Button 
            onClick={loadAcademicData} 
            variant="outline"
          >
            Try Again
          </Button>
          <Button 
            onClick={() => window.location.href = '/auth'} // Assuming /auth is your login route
            className="bg-[var(--accent-color)] text-[var(--accent-text-color)]"
          >
            Login
          </Button>
        </div>
      </div>
    );
  }

  // Show upload section if no data
  if (!hasData) {
    return (
      <div className="min-h-[calc(100vh-200px)] flex items-center justify-center p-6">
        <UploadSection onUploadComplete={handleUploadComplete} />
      </div>
    );
  }

  // Show error if failed to load data (generic, non-auth error)
  if (!studentData) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <p className="text-[var(--text-secondary)]">Failed to load student data</p>
        <Button 
          onClick={loadAcademicData} 
          className="mt-4"
          variant="outline"
        >
          Try Again
        </Button>
      </div>
    );
  }

  const { student_info, academic_record, semester_records, cumulative } = studentData;

  // Calculate dynamic stats based on real data
  const completedCourses = academic_record ?
    Object.values(academic_record).reduce((total, section) =>
      total + section.courses.filter(c => c.grade).length, 0
    ) : 0;

  const totalCreditsEarned = academic_record ?
    Object.values(academic_record).reduce((total, section) =>
      total + section.credits_completed, 0
    ) : 0;

  const remainingCredits = student_info?.plan_credits - totalCreditsEarned;
  const currentSemester = semester_records?.find(s => s.status === 'In Progress')?.semester || 
    semester_records?.[semester_records.length - 1]?.semester || 'Current Semester';

  // Find best grade from completed courses
  const allGrades = academic_record ?
    Object.values(academic_record).flatMap(section =>
      section.courses.filter(c => c.grade).map(c => c.grade)
    ) : [];
  const bestGrade = allGrades.length > 0 ?
    allGrades.reduce((best, current) => {
      const gradeValues = {'A+': 4.33, 'A': 4.0, 'A-': 3.67, 'B+': 3.33, 'B': 3.0, 'B-': 2.67, 'C+': 2.33, 'C': 2.0, 'C-': 1.67, 'D+': 1.33, 'D': 1.0, 'F': 0};
      return (gradeValues[current] || 0) > (gradeValues[best] || 0) ? current : best;
    }) : 'N/A';

  const tabs = [
    { id: 'overview', label: t('academic.tabs.overview'), icon: <User /> },
    { id: 'academic', label: t('academic.tabs.record'), icon: <BookOpen /> },
    { id: 'semesters', label: t('academic.tabs.semesters'), icon: <Calendar /> },
    { id: 'analytics', label: t('academic.tabs.analytics'), icon: <BarChart3 /> },
  ];

  return (
    <>
      <div className="max-w-7xl mx-auto space-y-4 md:space-y-6 pb-20 p-4 md:p-0">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)] mb-4">
          <GraduationCap className="w-4 h-4" />
          <span>{t('academic.title')}</span>
        </div>

        {/* Hero Section */}
        <div className="w-full bg-[var(--background)] rounded-2xl md:rounded-3xl overflow-hidden shadow-lg border border-[var(--border-color)] p-4 md:p-6 lg:p-8">
          <motion.div
            className="flex flex-col lg:flex-row items-center lg:items-center gap-6 lg:gap-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Profile Image */}
            <div className="relative group">
              <div className="relative">
                {profileImage || student_info?.profile_image_url ? (
                  <CachedImage
                    src={profileImage || student_info.profile_image_url}
                    alt={student_info?.student_name}
                    className="w-20 h-20 sm:w-24 sm:h-24 lg:w-32 lg:h-32 rounded-full object-cover border-4 border-[var(--background)] shadow-lg"
                    type="profile"
                  />
                ) : (
                  <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-32 lg:h-32 rounded-full bg-gradient-to-br from-[var(--accent-color)] to-gray-600 flex items-center justify-center text-xl sm:text-2xl lg:text-4xl font-bold shadow-lg text-white border-4 border-[var(--background)]">
                    {student_info?.student_name?.charAt(0) || 'A'}
                  </div>
                )}
                <button
                  onClick={() => imageInputRef.current?.click()}
                  className="absolute inset-0 bg-black/50 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Camera size={16} className="lg:w-5 lg:h-5" />
                </button>
              </div>
              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </div>

            {/* Profile Details */}
            <div className="flex-1 text-center lg:text-left">
              <div className="flex flex-col lg:flex-row items-center gap-3 lg:gap-4 mb-3 lg:mb-4">
                <h1 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-bold text-[var(--text-primary)]">
                  {student_info?.student_name}
                </h1>
                <Button
                  onClick={() => setShowEditProfile(true)}
                  className="bg-white/10 backdrop-blur-xl border border-white/30 hover:bg-white/20 text-[var(--text-primary)] px-3 md:px-4 lg:px-6 py-2 transition-all duration-300 text-xs sm:text-sm w-full sm:w-auto"
                >
                  <Edit className="w-3 h-3 lg:w-4 lg:h-4 mr-2" />
                  {t('academic.editProfile')}
                </Button>
              </div>

              <p className={`text-[var(--text-secondary)] mb-4 lg:mb-6 text-sm lg:text-base ${isRTL ? 'text-right' : 'text-left'}`}>
                {isRTL ? 
                  `${student_info?.degree} • ${student_info?.program_of_study}` :
                  `${student_info?.program_of_study} • ${student_info?.degree}`
                }
              </p>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:flex lg:justify-start gap-3 lg:gap-8 text-center">
                <div>
                  <div className="text-base sm:text-lg lg:text-2xl font-bold text-[var(--text-primary)]">{student_info?.gpa || '0.00'}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('academic.gpa')}</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg lg:text-2xl font-bold text-[var(--text-primary)]">{totalCreditsEarned || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('academic.credits')}</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg lg:text-2xl font-bold text-[var(--text-primary)]">{student_info?.plan_credits || 0}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('academic.totalPlan')}</div>
                </div>
                <div>
                  <div className="text-base sm:text-lg lg:text-2xl font-bold text-[var(--text-primary)]">{t('academic.status.enrolled')}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{t('academic.status')}</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Navigation Tabs */}
        <div className="sticky top-0 z-20 bg-[var(--background)] py-3 lg:py-4 border-b border-[var(--border-color)] -mx-4 md:-mx-3 lg:-mx-4 px-4 md:px-3 lg:px-4">
          <div className="flex justify-center gap-1 lg:gap-2 overflow-x-auto scrollbar-hide">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1 lg:gap-2 px-2 sm:px-3 lg:px-6 py-2 lg:py-3 rounded-full text-xs lg:text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)] shadow-lg scale-105'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--background-secondary)] hover:scale-105'
                }`}
              >
                {React.cloneElement(tab.icon, { size: 12 })}
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="min-h-[400px] lg:min-h-[600px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }} /* تقليل مدة الانيميشن */
              className="space-y-4 lg:space-y-6"
            >
              {activeTab === 'overview' && (
                <>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3 lg:gap-4">
                    {[
                      {
                        label: t('academic.currentSemester'),
                        value: currentSemester.replace(/^\d{4}\/\d{4}\s/, ''),
                        icon: <Calendar className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />,
                        color: 'from-blue-500 to-cyan-500'
                      },
                      {
                        label: t('academic.coursesCompleted'),
                        value: completedCourses,
                        icon: <CheckCircle2 className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />,
                        color: 'from-green-500 to-emerald-500'
                      },
                      {
                        label: t('academic.remainingCredits'),
                        value: Math.max(0, remainingCredits),
                        icon: <Target className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />,
                        color: 'from-orange-500 to-red-500'
                      },
                      {
                        label: t('academic.bestGrade'),
                        value: bestGrade,
                        icon: <Star className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />,
                        color: 'from-purple-500 to-pink-500'
                      }
                    ].map((stat, index) => (
                      <motion.div
                        key={stat.label}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.05 }} /* تقليل التأخير */
                        className={`relative overflow-hidden rounded-lg md:rounded-xl lg:rounded-2xl p-2 md:p-3 lg:p-4 bg-gradient-to-br ${stat.color} text-white`}
                      >
                        <div className="flex items-center justify-between mb-1 md:mb-2 lg:mb-3">
                          {stat.icon}
                          <div className="text-right">
                            <div className="text-xs sm:text-sm lg:text-lg font-bold">{stat.value}</div>
                            <div className="text-xs opacity-90 leading-tight">{stat.label}</div>
                          </div>
                        </div>
                        <div className="absolute bottom-0 right-0 w-6 h-6 md:w-8 md:h-8 lg:w-12 lg:h-12 bg-white/10 rounded-full -mr-2 md:-mr-4 lg:-mr-6 -mb-2 md:-mb-4 lg:-mb-6" />
                      </motion.div>
                    ))}
                  </div>

                  <AcademicProgress studentInfo={{...student_info, academic_record}} />
                  <StudentInfoCard info={student_info} />
                </>
              )}

              {activeTab === 'academic' && (
                <div className="space-y-4 lg:space-y-6">
                   <div className="relative p-3 md:p-4 lg:p-6 bg-[var(--background)] border border-[var(--border-color)] rounded-lg md:rounded-xl lg:rounded-2xl shadow-lg">
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-3 lg:mb-4 gap-2">
                          <h2 className="text-lg md:text-xl lg:text-2xl font-bold text-[var(--text-primary)]">{t('academic.record')}</h2>
                          <div className="text-xs md:text-sm text-[var(--text-secondary)]">
                              {completedCourses} {t('academic.coursesCompleted')}
                          </div>
                      </div>
                      <div className="w-full bg-[var(--background-secondary)] rounded-full h-2 lg:h-2.5">
                          <div 
                              className="bg-blue-600 h-2 lg:h-2.5 rounded-full transition-all duration-500" 
                              style={{ width: `${Math.min(100, (totalCreditsEarned / (student_info?.plan_credits || 1)) * 100)}%` }}
                          ></div>
                      </div>
                  </div>
                  {Object.entries(academic_record || {}).map(([sectionKey, section]) => {
                    const sectionTitles = {
                      general_requirements: t('academic.category.general'),
                      special_requirements_mandatory: t('academic.category.major'),
                      faculty_requirements_mandatory: t('academic.category.faculty'),
                      university_requirements_electives: t('academic.category.electives')
                    };

                    return (
                      <motion.div
                        key={sectionKey}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.05 }} /* تقليل التأخير */
                      >
                        <CourseTable
                          title={sectionTitles[sectionKey] || sectionKey}
                          description={`${section.credits_completed}/${section.credits_needed} ${t('academic.credits')} ${t('academic.credits_complete')}`}
                          courses={section.courses}
                        />
                      </motion.div>
                    );
                  })}
                </div>
              )}

              {activeTab === 'semesters' && (
                <div className="space-y-4 lg:space-y-6">
                  {semester_records?.map((record, index) => (
                    <motion.div
                      key={record.semester}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }} /* تقليل التأخير */
                    >
                      <SemesterCard record={record} />
                    </motion.div>
                  ))}
                </div>
              )}

              {activeTab === 'analytics' && (
                <AcademicAnalytics
                  studentData={studentData}
                  semesterRecords={semester_records}
                  academicRecord={academic_record}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
        profile={{ name: student_info?.student_name, bio: '' }}
        onSave={handleSave}
      />
    </>
  );
}
