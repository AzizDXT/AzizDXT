import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Trophy, 
  Medal, 
  Award, 
  Star, 
  Crown,
  Info,
  Flame,
  Zap,
  Calendar,
  Clock,
  Target,
  Sparkles
} from 'lucide-react';
import { useI18n } from '../components/utils/i18n';
import api from '../components/utils/api';

export default function Leaderboard() {
  const { t, isRTL, language } = useI18n();
  const [seasonData, setSeasonData] = useState(null);
  const [leaderboardData, setLeaderboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [error, setError] = useState(null);
  const [leaderboardError, setLeaderboardError] = useState(null);
  const [showSeasonInfo, setShowSeasonInfo] = useState(false);
  const [typedDescription, setTypedDescription] = useState('');
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Mock leaderboard data
  const mockLeaderboard = [
      {
        id: 1,
        name: 'أحمد علي',
        username: 'ahmed_ali',
        avatar: '/src/assets/logo.png',
        points: 15420,
        level: 15,
        rank: 1,
        badge: 'gold',
      streak: 12
      },
      {
        id: 2,
        name: 'فاطمة محمد',
        username: 'fatima_m',
        avatar: '/src/assets/logo.png',
        points: 12850,
        level: 12,
        rank: 2,
        badge: 'silver',
      streak: 8
      },
      {
        id: 3,
        name: 'محمد السعيد',
        username: 'mohammed_s',
        avatar: '/src/assets/logo.png',
        points: 11200,
        level: 11,
        rank: 3,
        badge: 'bronze',
      streak: 5
    }
  ];

  // Fetch current season data
  useEffect(() => {
    const fetchSeasonData = async () => {
      try {
        setLoading(true);
        const data = await api.getCurrentSeason(language);
        console.log('🎯 Season Data from API:', data);
        setSeasonData(data);
        setError(null);
      } catch (err) {
        console.error('Failed to fetch season data:', err);
        setError('Failed to load season data');
        setLoading(true); // Keep loading state when API fails
      } finally {
        setLoading(false);
      }
    };

    fetchSeasonData();
  }, [language]);

  // Fetch leaderboard data function
  const fetchLeaderboardData = async (page = 1, append = false) => {
    try {
      if (page === 1) {
        setLeaderboardLoading(true);
      } else {
        setLoadingMore(true);
      }
      
      const data = await api.getLeaderboard(10, language);
      console.log('🏆 Leaderboard Data from API:', data);
      
      if (append && leaderboardData?.entries) {
        // Append new data to existing data
        setLeaderboardData(prev => ({
          ...prev,
          entries: [...prev.entries, ...data.entries]
        }));
      } else {
        // Set new data
        setLeaderboardData(data);
      }
      
      // Check if there are more entries to load
      setHasMore(data.entries && data.entries.length >= 10);
      setCurrentPage(page);
      setLeaderboardError(null);
    } catch (err) {
      console.error('Failed to fetch leaderboard data:', err);
      setLeaderboardError('Failed to load leaderboard data');
      if (page === 1) {
        setLeaderboardLoading(true); // Keep loading state when API fails
      }
    } finally {
      setLeaderboardLoading(false);
      setLoadingMore(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchLeaderboardData(1, false);
  }, [language]);

  // Load more data function
  const loadMoreData = async () => {
    if (!loadingMore && hasMore) {
      await fetchLeaderboardData(currentPage + 1, true);
    }
  };

  // Infinite scroll effect
  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + document.documentElement.scrollTop >= document.documentElement.offsetHeight - 1000) {
        loadMoreData();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [loadingMore, hasMore, currentPage]);

  // Auto refresh data every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      // Refresh season data
      const refreshSeasonData = async () => {
        try {
          const data = await api.getCurrentSeason(language);
          setSeasonData(data);
        } catch (err) {
          console.error('Failed to refresh season data:', err);
        }
      };

      // Refresh leaderboard data
      const refreshLeaderboardData = async () => {
        try {
          const data = await api.getLeaderboard(10, language);
          setLeaderboardData(data);
        } catch (err) {
          console.error('Failed to refresh leaderboard data:', err);
        }
      };

      refreshSeasonData();
      refreshLeaderboardData();
      setLastUpdated(new Date());
    }, 5000); // 5 seconds

    return () => clearInterval(interval);
  }, [language]);

  // Reset typewriter effect when language or season data changes
  useEffect(() => {
    setTypedDescription('');
    setCurrentWordIndex(0);
  }, [language, seasonData]);

  // Typewriter effect for description
  useEffect(() => {
    if (!seasonData) return;

    const description = language === 'ar' ? seasonData.description_ar : seasonData.description_en;
    const words = description.split(' ');
    
    if (currentWordIndex < words.length) {
      const timer = setTimeout(() => {
        setTypedDescription(prev => prev + (prev ? ' ' : '') + words[currentWordIndex]);
        setCurrentWordIndex(prev => prev + 1);
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [seasonData, currentWordIndex, language]);

  // Helper function to get badge type based on rank
  const getBadgeType = (rank) => {
    if (rank === 1) return 'gold';
    if (rank === 2) return 'silver';
    if (rank === 3) return 'bronze';
    return 'default';
  };

  // Helper function to get default avatar
  const getDefaultAvatar = () => '/src/assets/logo.png';

  // Helper function to process image URLs
  const processImageUrl = (imageUrl) => {
    if (!imageUrl) return getDefaultAvatar();
    
    // If it's already a full URL (http/https), return as is
    if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
      return imageUrl;
    }
    
    // If it's a local path starting with /storage or /api, construct full URL
    if (imageUrl.startsWith('/storage/') || imageUrl.startsWith('/api/')) {
      return `https://api.taleb.run${imageUrl}`;
    }
    
    // If it's a relative path, return as is
    return imageUrl;
  };

  // Helper function to process leaderboard data
  const getProcessedLeaderboard = () => {
    if (!leaderboardData?.entries || leaderboardData.entries.length === 0) {
      return []; // Return empty array instead of mock data
    }
    
    return leaderboardData.entries.map(entry => ({
      id: entry.user_id || `user-${entry.rank}`,
      name: entry.name || 'Unknown User',
      username: entry.username || 'unknown',
      avatar: processImageUrl(entry.profile_image_url),
      points: entry.total_points || 0,
      level: entry.current_level || 1,
      rank: entry.rank || 1,
      badge: getBadgeType(entry.rank),
      streak: entry.login_streak || 0,
      levelName: language === 'ar' ? (entry.current_level_name_ar || 'مبتدئ') : (entry.current_level_name_en || 'Beginner')
    }));
  };

  const getBadgeIcon = (badge) => {
    switch (badge) {
      case 'gold':
        return <Crown className="w-5 h-5 text-yellow-500" />;
      case 'silver':
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 'bronze':
        return <Award className="w-5 h-5 text-amber-600" />;
      default:
        return <Star className="w-5 h-5 text-blue-500" />;
    }
  };

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'gold':
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white';
      case 'silver':
        return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white';
      case 'bronze':
        return 'bg-gradient-to-r from-amber-500 to-amber-700 text-white';
      default:
        return 'bg-gradient-to-r from-blue-400 to-blue-600 text-white';
    }
  };

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-8 h-8 text-yellow-500" />;
      case 2:
        return <Medal className="w-8 h-8 text-gray-400" />;
      case 3:
        return <Award className="w-8 h-8 text-amber-600" />;
      default:
        return <span className="text-2xl font-bold text-gray-600">#{rank}</span>;
    }
  };

  if (loading || leaderboardLoading || !seasonData || !leaderboardData) {
    return (
      <div 
        className="fixed bg-[var(--background)] flex items-center justify-center h-full"
        style={{
          [isRTL ? 'right' : 'left']: '80px',
          [isRTL ? 'left' : 'right']: '0',
          top: '0',
          bottom: '0'
        }}
      >
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-[var(--text-secondary)]">
            {loading ? 'Loading season data...' : 'Loading leaderboard...'}
          </p>
        </div>
      </div>
    );
  }

  if ((error && !seasonData) || (leaderboardError && !leaderboardData)) {
    return (
      <div 
        className="fixed bg-[var(--background)] flex items-center justify-center h-full"
        style={{
          [isRTL ? 'right' : 'left']: '80px',
          [isRTL ? 'left' : 'right']: '0',
          top: '0',
          bottom: '0'
        }}
      >
        <div className="text-center">
          <p className="text-red-500 mb-4">
            {error && !seasonData ? error : leaderboardError}
          </p>
          <Button onClick={() => window.location.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`fixed bg-[var(--background)] flex flex-col h-full overflow-y-auto ${isRTL ? 'text-right' : 'text-left'}`}
      style={{
        [isRTL ? 'right' : 'left']: '0',
        [isRTL ? 'left' : 'right']: '0',
        top: '0',
        bottom: '0'
      }}
    >
      <div className="max-w-6xl mx-auto p-3 md:p-4 w-full">
        
        {/* Season Banner */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative mb-6 md:mb-8"
        >
          <Card className="relative overflow-hidden border-0 shadow-2xl">
              <div 
                className="h-48 md:h-64 bg-cover bg-center bg-no-repeat relative"
                style={{ 
                  backgroundImage: `url(${seasonData?.banner_url})`
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-white/50 to-transparent dark:from-black/90 dark:via-black/50 dark:to-transparent"></div>
              
              {/* Season Info */}
              <div className={`absolute inset-0 flex items-center ${language === 'ar' ? 'pr-4 md:pr-8 pl-8 md:pl-16' : 'pl-4 md:pl-8 pr-8 md:pr-16'}`}>
                <div 
                  className={`max-w-2xl ${language === 'ar' ? 'text-right' : 'text-left'}`}
                  style={{ 
                    direction: language === 'ar' ? 'rtl' : 'ltr',
                    textAlign: language === 'ar' ? 'right' : 'left'
                  }}
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                >
                  <motion.h1 
                    initial={{ opacity: 0, x: language === 'ar' ? 50 : -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className={`text-2xl md:text-4xl font-bold text-[var(--text-primary)] mb-3 md:mb-4 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                    dir={language === 'ar' ? 'rtl' : 'ltr'}
                  >
                    {language === 'ar' ? seasonData?.name_ar : seasonData?.name_en}
                  </motion.h1>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className={`text-[var(--text-secondary)] text-xs md:text-sm leading-relaxed ${language === 'ar' ? 'text-right' : 'text-left'}`}
                    dir={language === 'ar' ? 'rtl' : 'ltr'}
                  >
                    {typedDescription}
                    <span className="animate-pulse">|</span>
                  </motion.div>

                  {/* Season Status */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className={`flex flex-wrap items-center gap-2 md:gap-3 mt-4 md:mt-6 ${language === 'ar' ? 'flex-row-reverse justify-end' : 'flex-row justify-start'}`}
                  >
                    <Badge className="bg-emerald-500/20 backdrop-blur-md text-emerald-700 dark:text-emerald-300 border border-emerald-400/30 dark:border-emerald-500/30 shadow-lg hover:shadow-xl transition-all duration-300 px-2 md:px-4 py-1 md:py-2 rounded-full">
                      <Sparkles className={`w-3 h-3 md:w-4 md:h-4 ${language === 'ar' ? 'ml-1 md:ml-2' : 'mr-1 md:mr-2'} text-emerald-600 dark:text-emerald-400`} />
                      <span className="text-xs md:text-sm font-medium">
                        {seasonData?.is_active ? (language === 'ar' ? 'نشط' : 'Active') : (language === 'ar' ? 'غير نشط' : 'Inactive')}
                      </span>
                    </Badge>
                    <Badge className="bg-blue-500/20 backdrop-blur-md text-blue-700 dark:text-blue-300 border border-blue-400/30 dark:border-blue-500/30 shadow-lg hover:shadow-xl transition-all duration-300 px-2 md:px-4 py-1 md:py-2 rounded-full">
                      <Clock className={`w-3 h-3 md:w-4 md:h-4 ${language === 'ar' ? 'ml-1 md:ml-2' : 'mr-1 md:mr-2'} text-blue-600 dark:text-blue-400`} />
                      <span className="text-xs md:text-sm font-medium">
                        {seasonData?.remaining_days} {language === 'ar' ? 'يوم متبقي' : 'days left'}
                      </span>
                    </Badge>
                    <Badge className="bg-orange-500/20 backdrop-blur-md text-orange-700 dark:text-orange-300 border border-orange-400/30 dark:border-orange-500/30 shadow-lg hover:shadow-xl transition-all duration-300 px-2 md:px-4 py-1 md:py-2 rounded-full">
                      <Flame className={`w-3 h-3 md:w-4 md:h-4 ${language === 'ar' ? 'ml-1 md:ml-2' : 'mr-1 md:mr-2'} text-orange-600 dark:text-orange-400`} />
                      <span className="text-xs md:text-sm font-medium">
                        {seasonData?.total_season_points?.toLocaleString() || '0'} {language === 'ar' ? 'نقطة إجمالية' : 'total points'}
                      </span>
                    </Badge>
                  </motion.div>
                </div>
              </div>

              {/* Info Button and Auto Refresh Indicator */}
              <div className="absolute top-3 md:top-4 right-3 md:right-4 flex items-center gap-1 md:gap-2">
                <div className="flex items-center gap-1 bg-white/20 backdrop-blur-sm rounded-full px-1.5 md:px-2 py-0.5 md:py-1 text-xs text-[var(--text-primary)]">
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="hidden sm:inline">{language === 'ar' ? 'تحديث تلقائي' : 'Auto refresh'}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="bg-white/20 hover:bg-white/30 text-[var(--text-primary)] border-white/30 p-1.5 md:p-2"
                  onClick={() => setShowSeasonInfo(!showSeasonInfo)}
                >
                  <Info className="w-3 h-3 md:w-4 md:h-4" />
                </Button>
              </div>
            </div>
          </Card>

          {/* Season Info Modal */}
          <AnimatePresence>
            {showSeasonInfo && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute top-16 right-4 z-50"
                onClick={() => setShowSeasonInfo(false)}
              >
                <motion.div
                  initial={{ opacity: 0, y: -20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  className="w-80 bg-white/20 dark:bg-gray-900/20 backdrop-blur-md rounded-lg shadow-xl border border-white/30 dark:border-gray-700/50"
                  onClick={(e) => e.stopPropagation()}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-lg">{language === 'ar' ? 'معلومات الموسم' : 'Season Info'}</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 hover:bg-gray-200 dark:hover:bg-gray-700"
                        onClick={() => setShowSeasonInfo(false)}
                      >
                        ×
                      </Button>
                    </div>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between items-center">
                        <span className="text-[var(--text-secondary)]">{language === 'ar' ? 'الحالة:' : 'Status:'}</span>
                        <Badge className={seasonData?.is_active ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}>
                          {seasonData?.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[var(--text-secondary)]">{language === 'ar' ? 'الأيام المتبقية:' : 'Days Remaining:'}</span>
                        <span className="font-medium">{seasonData?.remaining_days}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[var(--text-secondary)]">{language === 'ar' ? 'التقدم:' : 'Progress:'}</span>
                        <span className="font-medium">{seasonData?.progress_percentage}%</span>
                      </div>
                    </div>
                  </CardContent>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Top 3 Podium */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6 md:mb-8"
        >
          <h2 className="text-xl md:text-2xl font-bold text-center mb-4 md:mb-6 text-[var(--text-primary)]">
            {language === 'ar' ? 'أفضل 3 متصدرين' : 'Top 3 Leaders'}
          </h2>
          
          <div className={`flex justify-center items-end gap-2 md:gap-4 ${language === 'ar' ? 'flex-row-reverse' : 'flex-row'}`}>
            {(() => {
              const processedData = getProcessedLeaderboard();
              const top3 = processedData.slice(0, 3);
              
              if (top3.length === 0) {
                return (
                  <div className="text-center py-8">
                    <p className="text-[var(--text-secondary)]">
                      {language === 'ar' ? 'لا توجد بيانات متاحة حالياً' : 'No data available at the moment'}
                    </p>
                  </div>
                );
              }
              
              return (
                <>
                  {/* 2nd Place */}
                  {top3[1] && (
                    <motion.div
                      key={`top3-2-${top3[1].id}-${top3[1].rank}-${top3[1].points}`}
                      layout
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ 
                        delay: 0.4,
                        layout: { duration: 0.5, ease: "easeInOut" }
                      }}
                      className="flex flex-col items-center"
                    >
                      <div className="relative mb-2">
                        <img
                          src={top3[1].avatar}
                          alt={top3[1].name}
                          className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover border-4 border-gray-300 shadow-lg"
                          onError={(e) => {
                            e.target.src = getDefaultAvatar();
                          }}
                        />
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center bg-gradient-to-r from-gray-300 to-gray-500 text-white">
                          <Medal className="w-3 h-3 md:w-5 md:h-5" />
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 rounded-xl p-3 md:p-4 w-28 md:w-36 text-center shadow-lg border border-gray-200 dark:border-gray-700">
                        <h3 className="font-bold text-[var(--text-primary)] text-xs md:text-sm mb-1 truncate">{top3[1].name}</h3>
                        <p className="text-xs text-[var(--text-secondary)] mb-2 md:mb-3 truncate">@{top3[1].username}</p>
                        <div className="space-y-1 md:space-y-2">
                          <div className="flex items-center justify-center gap-1">
                            <Flame className="w-3 h-3 md:w-4 md:h-4 text-orange-500" />
                            <span className="text-xs md:text-sm font-bold text-orange-500">{top3[1].points.toLocaleString()}</span>
                            <span className="text-xs text-orange-500">{language === 'ar' ? 'شعله' : 'flame'}</span>
                          </div>
                          <div className="flex items-center justify-center gap-1">
                            <Zap className="w-3 h-3 md:w-4 md:h-4 text-blue-500" />
                            <span className="text-xs text-blue-500">{top3[1].streak} {language === 'ar' ? 'نقاط' : 'points'}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* 1st Place */}
                  {top3[0] && (
                    <motion.div
                      key={`top3-1-${top3[0].id}-${top3[0].rank}-${top3[0].points}`}
                      layout
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ 
                        delay: 0.5,
                        layout: { duration: 0.5, ease: "easeInOut" }
                      }}
                      className="flex flex-col items-center"
                    >
                      <div className="relative mb-2">
                        <img
                          src={top3[0].avatar}
                          alt={top3[0].name}
                          className="w-20 h-20 md:w-24 md:h-24 rounded-full object-cover border-4 border-yellow-400 shadow-xl"
                          onError={(e) => {
                            e.target.src = getDefaultAvatar();
                          }}
                        />
                        <div className="absolute -bottom-1 -right-1 w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center bg-gradient-to-r from-yellow-400 to-yellow-600 text-white">
                          <Crown className="w-4 h-4 md:w-6 md:h-6" />
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 dark:from-yellow-900/40 dark:to-yellow-800/40 rounded-xl p-4 md:p-5 w-32 md:w-40 text-center shadow-xl border-2 border-yellow-300 dark:border-yellow-600">
                        <h3 className="font-bold text-[var(--text-primary)] text-sm md:text-base mb-1 truncate">{top3[0].name}</h3>
                        <p className="text-xs md:text-sm text-[var(--text-secondary)] mb-2 md:mb-3 truncate">@{top3[0].username}</p>
                        <div className="space-y-1 md:space-y-2">
                          <div className="flex items-center justify-center gap-1">
                            <Flame className="w-3 h-3 md:w-4 md:h-4 text-orange-500" />
                            <span className="text-sm md:text-base font-bold text-orange-500">{top3[0].points.toLocaleString()}</span>
                            <span className="text-xs md:text-sm text-orange-500">{language === 'ar' ? 'شعله' : 'flame'}</span>
                          </div>
                          <div className="flex items-center justify-center gap-1">
                            <Zap className="w-3 h-3 md:w-4 md:h-4 text-blue-500" />
                            <span className="text-xs md:text-sm text-blue-500">{top3[0].streak} {language === 'ar' ? 'نقاط' : 'points'}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* 3rd Place */}
                  {top3[2] && (
                    <motion.div
                      key={`top3-3-${top3[2].id}-${top3[2].rank}-${top3[2].points}`}
                      layout
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ 
                        delay: 0.6,
                        layout: { duration: 0.5, ease: "easeInOut" }
                      }}
                      className="flex flex-col items-center"
                    >
                      <div className="relative mb-2">
                        <img
                          src={top3[2].avatar}
                          alt={top3[2].name}
                          className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover border-4 border-amber-600 shadow-lg"
                          onError={(e) => {
                            e.target.src = getDefaultAvatar();
                          }}
                        />
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center bg-gradient-to-r from-amber-500 to-amber-700 text-white">
                          <Award className="w-3 h-3 md:w-5 md:h-5" />
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/30 dark:to-amber-800/30 rounded-xl p-3 md:p-4 w-28 md:w-36 text-center shadow-lg border border-amber-200 dark:border-amber-700">
                        <h3 className="font-bold text-[var(--text-primary)] text-xs md:text-sm mb-1 truncate">{top3[2].name}</h3>
                        <p className="text-xs text-[var(--text-secondary)] mb-2 md:mb-3 truncate">@{top3[2].username}</p>
                        <div className="space-y-1 md:space-y-2">
                          <div className="flex items-center justify-center gap-1">
                            <Flame className="w-3 h-3 md:w-4 md:h-4 text-orange-500" />
                            <span className="text-xs md:text-sm font-bold text-orange-500">{top3[2].points.toLocaleString()}</span>
                            <span className="text-xs text-orange-500">{language === 'ar' ? 'شعله' : 'flame'}</span>
                          </div>
                          <div className="flex items-center justify-center gap-1">
                            <Zap className="w-3 h-3 md:w-4 md:h-4 text-blue-500" />
                            <span className="text-xs text-blue-500">{top3[2].streak} {language === 'ar' ? 'نقاط' : 'points'}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </>
              );
            })()}
          </div>
        </motion.div>

        {/* Full Leaderboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="space-y-3 md:space-y-4"
        >
          <h2 className="text-xl md:text-2xl font-bold text-center mb-4 md:mb-6 text-[var(--text-primary)]">
            {language === 'ar' ? 'لوحة المتصدرين الكاملة' : 'Full Leaderboard'}
          </h2>
          
          {getProcessedLeaderboard().length === 0 ? (
            <div className="text-center py-8">
              <p className="text-[var(--text-secondary)]">
                {language === 'ar' ? 'لا توجد بيانات متاحة حالياً' : 'No data available at the moment'}
              </p>
            </div>
          ) : (
            getProcessedLeaderboard().map((user, index) => (
            <motion.div
              key={`${user.id}-${user.rank}-${user.points}`}
              layout
              initial={{ opacity: 0, x: language === 'ar' ? 50 : -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ 
                delay: 0.8 + index * 0.1,
                layout: { duration: 0.5, ease: "easeInOut" }
              }}
            >
              <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:scale-[1.02] ${
                user.rank <= 3 ? 'ring-2 ring-yellow-200 dark:ring-yellow-800 bg-gradient-to-r from-yellow-50/50 to-transparent dark:from-yellow-900/20' : 'bg-[var(--background-secondary)]'
              }`}>
                <CardContent className="p-4 md:p-6">
                  <div className={`flex items-center gap-3 md:gap-4 ${language === 'ar' ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* Rank */}
                    <div className="flex-shrink-0">
                      {getRankIcon(user.rank)}
                    </div>

                    {/* Avatar */}
                    <div className="relative">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-12 h-12 md:w-16 md:h-16 rounded-full object-cover border-4 border-white shadow-lg"
                        onError={(e) => {
                          e.target.src = getDefaultAvatar();
                        }}
                      />
                      <div className={`absolute -bottom-1 -right-1 w-5 h-5 md:w-6 md:h-6 rounded-full flex items-center justify-center ${getBadgeColor(user.badge)}`}>
                        {getBadgeIcon(user.badge)}
                      </div>
                    </div>

                    {/* User Info */}
                    <div className={`flex-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                      <h3 className="text-sm md:text-lg font-bold text-[var(--text-primary)] truncate">
                        {user.name}
                      </h3>
                      <p className="text-xs md:text-sm text-[var(--text-secondary)] truncate">
                        @{user.username}
                      </p>
                      <div className="flex items-center gap-1 md:gap-2 mt-1 md:mt-2">
                        <Badge variant="secondary" className="text-xs px-1.5 md:px-2 py-0.5 md:py-1">
                          Level {user.level}
                        </Badge>
                        <Badge variant="outline" className="text-xs px-1.5 md:px-2 py-0.5 md:py-1">
                          {user.levelName}
                        </Badge>
                      </div>
                    </div>

                    {/* Points and Streak */}
                    <div className={`flex items-center gap-4 md:gap-8 ${language === 'ar' ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className="text-center min-w-[60px] md:min-w-[80px]">
                        <div className="flex items-center justify-center gap-1 text-orange-500 mb-1">
                          <Flame className="w-4 h-4 md:w-5 md:h-5" />
                          <span className="text-lg md:text-xl font-bold">{user.points.toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-[var(--text-tertiary)] font-medium">{language === 'ar' ? 'شعله' : 'flame'}</p>
                      </div>
                      <div className="text-center min-w-[60px] md:min-w-[80px]">
                        <div className="flex items-center justify-center gap-1 text-blue-500 mb-1">
                          <Zap className="w-4 h-4 md:w-5 md:h-5" />
                          <span className="text-lg md:text-xl font-bold">{user.streak}</span>
                        </div>
                        <p className="text-xs text-[var(--text-tertiary)] font-medium">{language === 'ar' ? 'نقاط' : 'points'}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            ))
          )}
          
          {/* Loading More Indicator */}
          {loadingMore && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-center items-center py-8"
            >
              <div className="flex items-center gap-3">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
                <p className="text-[var(--text-secondary)]">
                  {language === 'ar' ? 'جاري تحميل المزيد...' : 'Loading more...'}
                </p>
              </div>
            </motion.div>
          )}
          
          {/* End of List Indicator */}
          {!hasMore && leaderboardData?.entries && leaderboardData.entries.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-center items-center py-8"
            >
              <div className="text-center">
                <p className="text-[var(--text-secondary)] text-sm">
                  {language === 'ar' ? 'تم عرض جميع المتصدرين' : 'All leaders displayed'}
                </p>
                <div className="w-24 h-px bg-gradient-to-r from-transparent via-[var(--border-color)] to-transparent mx-auto mt-2"></div>
              </div>
            </motion.div>
          )}
        </motion.div>

      </div>
    </div>
  );
}