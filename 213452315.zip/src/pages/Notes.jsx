
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  FileText, // Used in ConfirmDialog
  Plus,
  Search,
  Tag,
  Clock, // Used in preview modal
  BookOpen, // Used for categories, empty state
  Briefcase, // Used for categories
  User, // Used for categories
  ChevronRight,
  Pin,
  PinOff,
  Edit,
  Trash2,
  X,
  Save,
  Loader2,
  Home,
  Hash,
  Settings, // Used in main Notes component
  AlertTriangle, // Used in ConfirmDialog
  GraduationCap, // Added from outline
  Eye // Added from outline
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useI18n } from '../components/utils/i18n';
import api from '../components/utils/api';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

// Global helper for formatting dates consistently if needed by multiple components
const formatDate = (dateString, locale) => {
  if (!dateString) return '';
  return new Date(dateString).toLocaleDateString(locale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// تحويل tags من string إلى array إذا لزم الأمر
const processTags = (tags) => {
  if (Array.isArray(tags)) return tags;
  if (typeof tags === 'string') {
    return tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
  }
  return [];
};

// ترتيب الملاحظات: المثبتة أولاً حسب آخر تحديث، ثم الباقي حسب آخر تحديث
const sortNotes = (notes) => {
  return [...notes].sort((a, b) => {
    const aIsPinned = a.meta?.pinned || false;
    const bIsPinned = b.meta?.pinned || false;

    // إذا كانت إحداها مثبتة والأخرى لا
    if (aIsPinned && !bIsPinned) return -1;
    if (!aIsPinned && bIsPinned) return 1;

    // إذا كانتا نفس حالة التثبيت، رتب حسب آخر تحديث
    return new Date(b.time_updated) - new Date(a.time_updated);
  });
};

// Custom Confirm Dialog Component
const ConfirmDialog = ({ isOpen, title, message, onConfirm, onCancel, isDestructive = false }) => {
  const { t, language } = useI18n();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-2xl p-6 w-full max-w-md border border-[var(--border-color)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-4 mb-6">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
            isDestructive ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
          }`}>
            {isDestructive ? <AlertTriangle className="w-6 h-6" /> : <FileText className="w-6 h-6" />}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-[var(--text-primary)] mb-2">{title}</h3>
            <p className="text-[var(--text-secondary)] text-sm leading-relaxed">{message}</p>
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={onCancel} className="min-w-[80px]">
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button
            variant={isDestructive ? "destructive" : "default"}
            onClick={onConfirm}
            className="min-w-[80px]"
          >
            {language === 'ar' ? 'تأكيد' : 'Confirm'}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

// Tags Manager Component
const TagsManager = ({ isOpen, onClose, onTagsUpdated }) => {
  const { t, language } = useI18n();
  const [tags, setTags] = useState([]);
  const [stats, setStats] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateTag, setShowCreateTag] = useState(false);
  const [editingTag, setEditingTag] = useState(null); // This is present in original, but not fully used for editing form
  const [newTag, setNewTag] = useState({ name: '', color: '#ffffff', description: '' });

  useEffect(() => {
    if (isOpen) {
      loadTags();
      loadStats();
    }
  }, [isOpen]);

  const loadTags = async () => {
    setIsLoading(true);
    try {
      const response = await api.getNoteTags();
      setTags(response || []);
    } catch (error) {
      console.error('Error loading tags:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const response = await api.getNoteTagStats();
      setStats(response);
    } catch (error) {
      console.error('Error loading tag stats:', error);
    }
  };

  const handleCreateTag = async () => {
    if (!newTag.name.trim()) return;

    try {
      // Assuming API supports description and color for tags
      await api.createNoteTag(newTag.name, newTag.color, newTag.description);
      setNewTag({ name: '', color: '#ffffff', description: '' });
      setShowCreateTag(false);
      loadTags();
      loadStats();
      onTagsUpdated();
    } catch (error) {
      console.error('Error creating tag:', error);
    }
  };

  const handleUpdateTag = async (oldName, updatedData) => {
    // This function was present but not fully implemented in the given code,
    // and not used in the existing TagsManager's UI. I'll keep it as is.
    try {
      await api.updateNoteTag(oldName, updatedData);
      setEditingTag(null); // Assuming editingTag state is handled elsewhere in UI
      loadTags();
      loadStats();
      onTagsUpdated();
    } catch (error) {
      console.error('Error updating tag:', error);
    }
  };

  const handleDeleteTag = async (tagName) => {
    try {
      await api.deleteNoteTag(tagName, false); // Assuming the second param is 'force' or similar
      loadTags();
      loadStats();
      onTagsUpdated();
    } catch (error) {
      console.error('Error deleting tag:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-[var(--border-color)] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
          <h2 className="text-2xl font-bold text-[var(--text-primary)]">{t('notes.manageTags')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex h-[calc(90vh-120px)]">
          {/* Left Panel - Stats */}
          <div className="w-1/3 p-6 border-r border-[var(--border-color)] overflow-y-auto">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">{t('notes.tagStats')}</h3>
                {stats && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-[var(--background-secondary)]">
                      <div className="text-2xl font-bold text-[var(--text-primary)]">{stats.total_tags}</div>
                      <div className="text-sm text-[var(--text-secondary)]">{t('notes.totalTags')}</div>
                    </div>

                    {stats.most_used_tags && stats.most_used_tags.length > 0 && (
                      <div>
                        <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('notes.mostUsedTags')}</h4>
                        <div className="space-y-2">
                          {stats.most_used_tags.slice(0, 5).map((tag, index) => (
                            <div key={index} className="flex items-center justify-between p-2 rounded bg-[var(--background-secondary)]">
                              <span className="text-sm text-[var(--text-primary)]">{tag.name}</span>
                              <Badge variant="outline" className="text-xs">{tag.count}</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <Button
                onClick={() => setShowCreateTag(true)}
                className="w-full"
                disabled={showCreateTag}
              >
                <Plus className="w-4 h-4 mr-2" />
                {t('notes.createTag')}
              </Button>
            </div>
          </div>

          {/* Right Panel - Tags List */}
          <div className="flex-1 p-6 overflow-y-auto">
            {showCreateTag && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 border border-[var(--border-color)] rounded-lg bg-[var(--background-secondary)]"
              >
                <h4 className="font-medium text-[var(--text-primary)] mb-4">{t('notes.createTag')}</h4>
                <div className="space-y-4">
                  <Input
                    placeholder={t('notes.tagName')}
                    value={newTag.name}
                    onChange={(e) => setNewTag({...newTag, name: e.target.value})}
                  />
                  <Input
                    placeholder={t('notes.tagDescription')}
                    value={newTag.description}
                    onChange={(e) => setNewTag({...newTag, description: e.target.value})}
                  />
                  <div className="flex items-center gap-4">
                    <label className="text-sm font-medium text-[var(--text-secondary)]">{t('notes.tagColor')}</label>
                    <Input
                      type="color"
                      value={newTag.color}
                      onChange={(e) => setNewTag({...newTag, color: e.target.value})}
                      className="w-20 h-10"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleCreateTag} size="sm">
                      <Save className="w-4 h-4 mr-2" />
                      {t('common.save')}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setShowCreateTag(false)}>
                      {t('common.cancel')}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="space-y-3">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : tags.length > 0 ? (
                tags.map((tag) => (
                  <div key={tag.name} className="flex items-center justify-between p-4 border border-[var(--border-color)] rounded-lg hover:bg-[var(--background-secondary)] transition-colors">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-4 h-4 rounded-full border border-gray-300"
                        style={{ backgroundColor: tag.color }}
                      />
                      <div>
                        <div className="font-medium text-[var(--text-primary)]">{tag.name}</div>
                        {tag.description && (
                          <div className="text-sm text-[var(--text-secondary)]">{tag.description}</div>
                        )}
                        <div className="text-xs text-[var(--text-secondary)]">
                          {t('notes.tagUsage').replace('{count}', tag.notes_count)}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setEditingTag(tag)} // This should open an edit form
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteTag(tag.name)}
                        className="text-red-500 hover:bg-red-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <Tag className="w-12 h-12 mx-auto text-[var(--text-secondary)] opacity-50 mb-4" />
                  <h3 className="text-lg font-medium text-[var(--text-primary)] mb-2">{t('notes.noTagsYet')}</h3>
                  <p className="text-[var(--text-secondary)]">{t('notes.createFirstTag')}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// TagsInput component (Remains largely the same, used by NoteEditorModal)
const TagsInput = ({ tags, onChange, availableTags = [] }) => {
  const { t } = useI18n();
  const [newTagName, setNewTagName] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef(null);

  const addTag = (tagName) => {
    const trimmedTag = tagName.trim();
    if (trimmedTag && !tags.includes(trimmedTag)) {
      onChange([...tags, trimmedTag]);
      setNewTagName('');
      setShowSuggestions(false);
    }
  };

  const removeTag = (tagToRemove) => {
    onChange(tags.filter(tag => tag !== tagToRemove));
  };

  const filteredSuggestions = availableTags.filter(tag =>
    !tags.includes(tag) && tag.toLowerCase().includes(newTagName.toLowerCase())
  );

  const handleBlur = (e) => {
    // Only hide suggestions if the blur event is not from clicking a suggestion
    if (!e.relatedTarget || !e.relatedTarget.dataset.suggestion) {
      setShowSuggestions(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 min-h-[40px] p-3 border border-[var(--border-color)] rounded-lg bg-[var(--background)]">
        <AnimatePresence>
          {tags.map((tag) => (
            <motion.div
              key={tag}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
            >
              <Hash className="w-3 h-3" />
              <span>{tag}</span>
              <button
                type="button"
                onClick={() => removeTag(tag)}
                className="ml-1 text-blue-600 hover:text-blue-800 focus:outline-none"
              >
                <X className="w-3 h-3" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>

        <div className="relative flex-1 min-w-[120px]">
          <input
            ref={inputRef}
            type="text"
            placeholder={tags.length === 0 ? t('notes.tagsPlaceholder') : ""}
            value={newTagName}
            onChange={(e) => {
              setNewTagName(e.target.value);
              setShowSuggestions(true);
            }}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTag(newTagName);
              }
            }}
            onFocus={() => setShowSuggestions(true)}
            onBlur={handleBlur}
            className="w-full bg-transparent outline-none text-sm placeholder:text-gray-500"
          />

          {showSuggestions && newTagName.length > 0 && filteredSuggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[var(--background)] border border-[var(--border-color)] rounded-lg shadow-lg z-10 max-h-32 overflow-y-auto">
              {filteredSuggestions.slice(0, 5).map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => addTag(suggestion)}
                  onMouseDown={(e) => e.preventDefault()} // Prevents blur from hiding suggestions before click
                  data-suggestion="true" // For handleBlur logic
                  className="w-full text-left px-3 py-2 hover:bg-[var(--background-secondary)] text-sm flex items-center gap-2"
                >
                  <Hash className="w-3 h-3 text-gray-400" />
                  {suggestion}
                </button>
              ))}
            </div>
          )}
        </div>

        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => addTag(newTagName)}
          disabled={!newTagName.trim()}
          className="h-6 w-6 p-0 rounded-full"
        >
          <Plus className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
};

// NoteEditorModal (Formerly NoteEditor, now a modal and uses ReactQuill)
const NoteEditorModal = ({ isOpen, note, onClose, onSave, availableTags }) => {
  const { t, isRTL } = useI18n();
  const [currentNote, setCurrentNote] = useState({
    title: '', // New field
    content: '',
    tags: [],
    color: '#ffffff',
    pinned: false,
    category: '' // New field
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (note) {
      setCurrentNote({
        title: note.title || '',
        content: note.content || '',
        tags: processTags(note.meta?.tags || []),
        color: note.meta?.color || '#ffffff',
        pinned: note.meta?.pinned || false,
        category: note.meta?.category || 'personal' // Default category
      });
    } else {
      setCurrentNote({
        title: '',
        content: '',
        tags: [],
        color: '#ffffff',
        pinned: false,
        category: 'personal' // Default category for new notes
      });
    }
  }, [note, isOpen]);

  const handleSave = async () => {
    if (!currentNote.title.trim()) {
      alert(t('notes.editor.titleRequired'));
      return;
    }
    // Allow saving a note with just a title and no content, or vice-versa.
    // If both are empty, prevent save.
    if (!currentNote.content.trim() && !currentNote.title.trim()) {
      alert(t('notes.editor.contentOrTitleRequired'));
      return;
    }

    setIsSaving(true);
    try {
      const noteData = {
        title: currentNote.title,
        content: currentNote.content,
        meta: {
          tags: currentNote.tags,
          color: currentNote.color,
          pinned: currentNote.pinned,
          category: currentNote.category,
          attachments: [] // Preserve attachments if they were part of original meta
        }
      };

      if (note && note.id) {
        // Assuming API updateNote takes (id, title, content, category, meta)
        await api.updateNote(note.id, noteData.title, noteData.content, noteData.meta.category, noteData.meta);
      } else {
        // Assuming API createNote takes (title, content, category, meta)
        await api.createNote(noteData.title, noteData.content, noteData.meta.category, noteData.meta);
      }

      onSave(); // Callback to parent to reload notes
      onClose(); // Close the modal
    } catch (error) {
      console.error('Error saving note:', error);
      alert(error.message || t('common.saveError'));
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  const categoriesOptions = [
    { value: 'personal', label: t('notes.personal') },
    { value: 'work', label: t('notes.work') },
    { value: 'academic', label: t('notes.academic') },
    { value: 'lectures', label: t('notes.lectures') },
  ];

  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['link', 'image', 'video'],
      ['clean']
    ],
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-[var(--border-color)] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
          <h2 className="text-2xl font-bold text-[var(--text-primary)]">
            {note ? t('notes.editNote') : t('notes.newNote')}
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-120px-80px)]">
          {/* Title */}
          <div>
            <label htmlFor="note-title" className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {t('notes.titleLabel')}
            </label>
            <Input
              id="note-title"
              placeholder={t('notes.editor.titlePlaceholder')}
              value={currentNote.title}
              onChange={(e) => setCurrentNote({ ...currentNote, title: e.target.value })}
              className="text-lg font-semibold"
              required
            />
          </div>

          {/* Content */}
          <div>
            <label htmlFor="note-content" className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {t('notes.contentLabel')}
            </label>
            <ReactQuill
              theme="snow"
              value={currentNote.content}
              onChange={(content) => setCurrentNote({ ...currentNote, content })}
              modules={modules}
              className="bg-[var(--background)] rounded-lg border border-[var(--border-color)]"
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
              {t('notes.tagsLabel')}
            </label>
            <TagsInput
              tags={currentNote.tags}
              onChange={(newTags) => setCurrentNote({ ...currentNote, tags: newTags })}
              availableTags={availableTags}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Category Select */}
            <div>
              <label htmlFor="note-category" className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                {t('notes.categoryLabel')}
              </label>
              <select
                id="note-category"
                value={currentNote.category}
                onChange={(e) => setCurrentNote({ ...currentNote, category: e.target.value })}
                className="w-full p-2 border border-[var(--border-color)] rounded-lg bg-[var(--background)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-color)]"
              >
                {categoriesOptions.map(option => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>

            {/* Color Picker */}
            <div>
              <label htmlFor="note-color" className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                {t('notes.colorLabel')}
              </label>
              <div className="flex items-center gap-2">
                <Input
                  id="note-color"
                  type="color"
                  value={currentNote.color}
                  onChange={(e) => setCurrentNote({ ...currentNote, color: e.target.value })}
                  className="w-12 h-10 border-[var(--border-color)] bg-[var(--background)] cursor-pointer"
                />
                <span className="text-sm text-[var(--text-secondary)]">{currentNote.color}</span>
              </div>
            </div>

            {/* Pin Toggle */}
            <div className="col-span-full">
              <label className="block text-sm font-medium text-[var(--text-secondary)] mb-2">
                {t('notes.pinStatus')}
              </label>
              <button
                type="button"
                onClick={() => setCurrentNote({ ...currentNote, pinned: !currentNote.pinned })}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  currentNote.pinned
                    ? 'bg-yellow-500 text-white shadow-lg'
                    : 'bg-[var(--background-secondary)] text-[var(--text-primary)] border border-[var(--border-color)] hover:bg-[var(--hover-bg)]'
                }`}
              >
                {currentNote.pinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                <span className="text-sm font-medium">
                  {currentNote.pinned ? t('notes.unpinNote') : t('notes.pinNote')}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className={`flex gap-4 p-6 border-t border-[var(--border-color)] bg-[var(--background-secondary)] ${isRTL ? 'justify-start' : 'justify-end'}`}>
          <Button variant="outline" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
            {t('notes.save')}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};


// Categories Sidebar Component - same as Tasks (New component, replaces TagsSidebar)
const CategoriesSidebar = ({ notes, selectedCategory, onCategorySelect, className = "" }) => {
  const { t } = useI18n();

  const categories = React.useMemo(() => {
    const categoryCount = {
      personal: 0,
      work: 0,
      academic: 0,
      lectures: 0
    };
    notes.forEach(note => {
      // Assuming category is within note.meta
      const categoryName = note.meta?.category || 'personal'; // Default to personal if not set
      if (categoryCount.hasOwnProperty(categoryName)) {
        categoryCount[categoryName]++;
      }
    });

    // Convert to array of { name, count } and filter out zero counts
    return Object.entries(categoryCount)
      .filter(([, count]) => count > 0)
      .map(([name, count]) => ({ name, count }));
  }, [notes]);

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'work': return <Briefcase className="w-4 h-4" />;
      case 'academic': return <User className="w-4 h-4" />; // Changed from GraduationCap to User for now
      case 'personal': return <User className="w-4 h-4" />;
      case 'lectures': return <BookOpen className="w-4 h-4" />; // Changed from GraduationCap to BookOpen
      default: return <Hash className="w-4 h-4" />;
    }
  };

  return (
    <div className={`bg-[var(--background)] border border-[var(--border-color)] rounded-xl p-4 ${className}`}>
      <div className="mb-4">
        <h3 className="font-semibold text-[var(--text-primary)] mb-3 flex items-center gap-2">
          <Tag className="w-4 h-4" />
          {t('notes.categories')}
        </h3>

        <button
          onClick={() => onCategorySelect('')}
          className={`w-full text-left px-3 py-2 rounded-lg transition-colors mb-2 ${
            selectedCategory === ''
              ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)]'
              : 'hover:bg-[var(--background-secondary)] text-[var(--text-secondary)]'
          }`}
        >
          {t('notes.all')}
        </button>
      </div>

      <div className="space-y-1 max-h-80 overflow-y-auto">
        {categories.map((category) => (
          <button
            key={category.name}
            onClick={() => onCategorySelect(category.name)}
            className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 text-sm ${
              selectedCategory === category.name
                ? 'bg-[var(--accent-color)] text-[var(--accent-text-color)]'
                : 'hover:bg-[var(--background-secondary)] text-[var(--text-secondary)]'
            }`}
          >
            {getCategoryIcon(category.name)}
            <span className="flex-1 truncate">{t(`notes.${category.name}`)}</span>
            <Badge variant="outline" className="ml-auto">
              {category.count}
            </Badge>
          </button>
        ))}
      </div>

      {categories.length === 0 && (
        <div className="text-center py-8 text-[var(--text-secondary)]">
          <Tag className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">{t('notes.noCategoriesYet')}</p>
        </div>
      )}
    </div>
  );
};

// Note Preview Modal Component (New Component)
const NotePreviewModal = ({ isOpen, note, onClose, onSave, onDelete }) => {
  const { t } = useI18n();
  const [isEditing, setIsEditing] = useState(false);
  const [localNote, setLocalNote] = useState(note);
  const [isSaving, setIsSaving] = useState(false);

  // Update localNote when prop note changes
  useEffect(() => {
    setLocalNote(note);
    setIsEditing(false); // Reset editing state when a new note is loaded
  }, [note]);

  const handleSave = async () => {
    if (!localNote?.title?.trim()) {
      alert(t('notes.editor.titleRequired'));
      return;
    }
    if (!localNote?.content?.trim() && !localNote?.title?.trim()) {
      alert(t('notes.editor.contentOrTitleRequired'));
      return;
    }

    setIsSaving(true);
    try {
      // Reconstruct the note object based on how API expects it for update
      const updatedMeta = {
        tags: localNote.meta?.tags || [], // Preserve existing meta tags or default
        color: localNote.color || '#ffffff',
        pinned: localNote.pinned || false,
        category: localNote.category || 'personal',
        attachments: localNote.meta?.attachments || [] // Preserve attachments
      };

      // Call the onSave prop provided by Notes component
      // Assuming onSave expects (id, title, content, category, meta)
      const result = await onSave(localNote.id, localNote.title, localNote.content, localNote.category, updatedMeta);
      setLocalNote(result); // Update local note with saved result
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving note from preview:', error);
      alert(error.message || t('common.saveError'));
    } finally {
      setIsSaving(false);
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'work': return <Briefcase className="w-4 h-4" />;
      case 'academic': return <User className="w-4 h-4" />;
      case 'personal': return <User className="w-4 h-4" />;
      case 'lectures': return <BookOpen className="w-4 h-4" />;
      default: return <Hash className="w-4 h-4" />;
    }
  };

  if (!isOpen || !localNote) return null;

  const modules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }],
      [{ 'direction': 'rtl' }],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['link', 'image', 'video'],
      ['clean']
    ],
  };

  const categoriesOptions = [
    { value: 'personal', label: t('notes.personal') },
    { value: 'work', label: t('notes.work') },
    { value: 'academic', label: t('notes.academic') },
    { value: 'lectures', label: t('notes.lectures') },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-[var(--background)] rounded-xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-[var(--border-color)] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
          <div className="flex items-center gap-3">
            <div
              className="w-4 h-4 rounded-full border border-gray-300"
              style={{ backgroundColor: localNote.color || '#3B82F6' }}
            />
            {isEditing ? (
              <Input
                value={localNote.title}
                onChange={(e) => setLocalNote({...localNote, title: e.target.value})}
                className="text-xl font-bold bg-transparent border-none p-0 h-auto"
                placeholder={t('notes.editor.titlePlaceholder')}
              />
            ) : (
              <h2 className="text-xl font-bold text-[var(--text-primary)]">
                {localNote.title || t('notes.noTitle')}
              </h2>
            )}
            {localNote.pinned && (
              <Pin className="w-4 h-4 text-yellow-500" />
            )}
          </div>
          <div className="flex items-center gap-2">
            {isEditing ? (
              <>
                <Button
                  size="sm"
                  onClick={handleSave}
                  disabled={isSaving}
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                  {t('common.save')}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setLocalNote(note); // Revert changes
                    setIsEditing(false);
                  }}
                >
                  {t('common.cancel')}
                </Button>
              </>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
              >
                <Edit className="w-4 h-4 mr-2" />
                {t('common.edit')}
              </Button>
            )}
            <button
              onClick={onClose}
              className="p-2 hover:bg-[var(--background-secondary)] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-120px-80px)]">
          {/* Category and Color */}
          <div className="flex flex-wrap gap-3 items-center">
            {isEditing ? (
              <select
                value={localNote.category || 'personal'}
                onChange={(e) => setLocalNote({...localNote, category: e.target.value})}
                className="p-2 border border-[var(--border-color)] rounded-lg bg-[var(--background-secondary)] text-[var(--text-primary)] focus:ring-2 focus:ring-[var(--accent-color)]"
              >
                {categoriesOptions.map(option => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
            ) : (
              <Badge className="flex items-center gap-1">
                {getCategoryIcon(localNote.category)}
                {t(`notes.${localNote.category}`)}
              </Badge>
            )}
            {isEditing && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-[var(--text-secondary)]">{t('notes.colorLabel')}:</span>
                <Input
                  type="color"
                  value={localNote.color || '#3B82F6'}
                  onChange={(e) => setLocalNote({...localNote, color: e.target.value})}
                  className="w-10 h-10 p-0 border-none cursor-pointer"
                />
              </div>
            )}
          </div>

          {/* Content */}
          <div>
            <h3 className="font-medium text-[var(--text-primary)] mb-3">{t('notes.contentLabel')}</h3>
            {isEditing ? (
              <ReactQuill
                theme="snow"
                value={localNote.content || ''}
                onChange={(content) => setLocalNote({...localNote, content})}
                modules={modules}
                className="bg-[var(--background)] rounded-lg border border-[var(--border-color)]"
                style={{ minHeight: '300px' }}
              />
            ) : (
              <div
                className="prose prose-sm max-w-none text-[var(--text-primary)] bg-[var(--background-secondary)] p-4 rounded-lg min-h-[300px] overflow-auto"
                dangerouslySetInnerHTML={{ __html: localNote.content || t('notes.noContent') }}
              />
            )}
          </div>

          {/* Tags */}
          {localNote.meta?.tags && localNote.meta.tags.length > 0 && (
            <div>
              <h3 className="font-medium text-[var(--text-primary)] mb-3">{t('notes.tagsLabel')}</h3>
              <div className="flex flex-wrap gap-2">
                {localNote.meta.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="flex items-center gap-1">
                    <Hash className="w-3 h-3" />
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Timestamps */}
          <div className="pt-4 border-t border-[var(--border-color)]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-[var(--text-secondary)]">
              <div>
                <p className="font-medium">{t('common.created')}</p>
                <p>{formatDateTime(localNote.time_created)}</p>
              </div>
              <div>
                <p className="font-medium">{t('common.lastUpdated')}</p>
                <p>{formatDateTime(localNote.time_updated)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-[var(--border-color)] bg-[var(--background-secondary)]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[var(--text-secondary)]" />
            <span className="text-sm text-[var(--text-secondary)]">
              {localNote.content ? `${localNote.content.replace(/<[^>]*>/g, '').length} ${t('common.characters')}` : `0 ${t('common.characters')}`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(localNote.id)}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {t('common.delete')}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// Note Item Component - Updated to handle click for preview
const NoteItem = ({ note, onEdit, onDelete, onTogglePin, onView }) => {
  const { t, language } = useI18n();

  // Local formatDate to match outline's usage of 'updated_at'
  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString(language, { year: 'numeric', month: 'numeric', day: 'numeric' });
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'work': return <Briefcase className="w-3 h-3" />;
      case 'academic': return <User className="w-3 h-3" />;
      case 'personal': return <User className="w-3 h-3" />;
      case 'lectures': return <BookOpen className="w-3 h-3" />;
      default: return <Hash className="w-3 h-3" />;
    }
  };

  // Function to strip HTML tags for content preview
  const getPlainText = (html) => {
    if (!html) return '';
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      layout
    >
      <Card className="cursor-pointer hover:shadow-lg transition-shadow border border-[var(--border-color)] relative">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            {/* Clickable area for preview */}
            <div className="flex-1 min-w-0" onClick={() => onView(note)}>
              {/* Header with color indicator and date */}
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-3 h-3 rounded-full border border-gray-300 flex-shrink-0"
                  style={{ backgroundColor: note.meta?.color || '#3B82F6' }}
                />
                {note.meta?.pinned && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">
                    <Pin className="w-3 h-3" />
                    <span>{t('notes.pinned')}</span>
                  </div>
                )}
                <span className="text-xs text-[var(--text-secondary)]">
                  {formatDate(note.time_updated)}
                </span>
              </div>

              {/* Title */}
              <h3 className="font-semibold text-[var(--text-primary)] mb-2 line-clamp-2">
                {note.title || t('notes.noTitle')}
              </h3>

              {/* Content Preview */}
              {note.content && (
                <p className="text-[var(--text-secondary)] mb-4 line-clamp-3 text-sm">
                  {getPlainText(note.content)}
                </p>
              )}

              {/* Category and Tags */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="flex items-center gap-1">
                  {getCategoryIcon(note.meta?.category || 'personal')}
                  {t(`notes.${note.meta?.category || 'personal'}`)}
                </Badge>

                {note.meta?.tags && note.meta.tags.slice(0, 3).map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    <Hash className="w-3 h-3 mr-1" />
                    {tag}
                  </Badge>
                ))}

                {note.meta?.tags && note.meta.tags.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{note.meta.tags.length - 3} {t('common.more')}
                  </Badge>
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 ml-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onTogglePin(note);
                }}
                className="h-8 w-8"
              >
                {note.meta?.pinned ?
                  <PinOff className="w-4 h-4 text-yellow-500" /> :
                  <Pin className="w-4 h-4" />
                }
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(note);
                }}
                className="h-8 w-8"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(note.id);
                }}
                className="h-8 w-8 text-red-500 hover:bg-red-100"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Main Notes Component - Updated to handle preview and categories
export default function Notes() {
  const { t, language } = useI18n();
  const navigate = useNavigate();
  const [notes, setNotes] = useState([]); // All notes fetched
  const [filteredNotes, setFilteredNotes] = useState([]); // Notes after search/filter
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(''); // Changed from selectedTag
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);
  const [selectedNote, setSelectedNote] = useState(null); // For preview modal
  const [editingNote, setEditingNote] = useState(null); // For editor modal
  const [availableTags, setAvailableTags] = useState([]); // Still needed for TagsInput
  const [showTagsManager, setShowTagsManager] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false); // For preview modal

  const [showConfirmDialog, setShowConfirmDialog] = useState({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: null
  });

  // Load Notes (modified to filter by category client-side if API doesn't support)
  const loadNotes = async () => {
    setIsLoading(true);
    try {
      // Assuming api.filterNotes can take search and pinned filters
      // If backend supports category, add it here: ...(selectedCategory && { category: selectedCategory })
      const filters = {
        skip: 0,
        limit: 50, // Fetch more to allow client-side filtering if needed
        ...(searchTerm && { search: searchTerm }),
        ...(showPinnedOnly && { pinned: true })
      };

      const response = await api.filterNotes(filters);
      console.log('Notes loaded:', response);

      if (Array.isArray(response)) {
        // Process tags and categories from fetched notes, ensuring default values
        const allNotes = response.map(note => ({
          ...note,
          title: note.title || '', // Ensure title exists
          content: note.content || '', // Ensure content exists
          meta: { // Ensure meta and its properties exist
            tags: processTags(note.meta?.tags || []),
            color: note.meta?.color || '#ffffff',
            pinned: note.meta?.pinned || false,
            category: note.meta?.category || 'personal', // Default category
            attachments: note.meta?.attachments || []
          }
        }));

        // Sort all notes (pinned first, then by last updated)
        const sortedNotes = sortNotes(allNotes);
        setNotes(sortedNotes); // Store all fetched notes

        // Extract all unique tags for TagsInput in editor
        const tags = new Set();
        allNotes.forEach(note => {
          if (note.meta?.tags && Array.isArray(note.meta.tags)) {
            note.meta.tags.forEach(tag => tags.add(tag));
          }
        });
        setAvailableTags([...tags]);

        // Apply client-side category filter based on selectedCategory state
        const currentFiltered = selectedCategory
          ? sortedNotes.filter(note => note.meta?.category === selectedCategory)
          : sortedNotes;

        setFilteredNotes(currentFiltered);

      } else {
        setNotes([]);
        setFilteredNotes([]);
      }
    } catch (error) {
      console.error('Error loading notes:', error);
      setNotes([]);
      setFilteredNotes([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Effects for filtering and initial load
  useEffect(() => {
    loadNotes(); // Initial load
  }, []);

  useEffect(() => {
    // Re-load notes when search term, selected category, or pinned status changes
    // This will trigger loadNotes, which then applies relevant filters
    loadNotes();
  }, [searchTerm, selectedCategory, showPinnedOnly]);


  // Handler for saving/creating a note from NoteEditorModal
  const handleSaveNote = async () => {
    // This function is called after NoteEditorModal saves successfully
    setEditingNote(null); // Close the editor modal
    await loadNotes(); // Reload all notes to reflect changes
  };

  // Handler for updating a note from NotePreviewModal (onSave prop)
  const handleUpdateNote = async (id, title, content, category, meta) => {
    try {
      // Assuming API expects (id, title, content, category, meta)
      await api.updateNote(id, title, content, category, meta);
      await loadNotes(); // Reload notes
      // Return updated note with latest time_updated for local state consistency
      const updatedNote = { 
        id, title, content, 
        meta: { ...meta, category }, 
        time_updated: new Date().toISOString(), // Simulate immediate update
        time_created: selectedNote?.time_created || new Date().toISOString() // Preserve created date
      };
      return updatedNote;
    } catch (error) {
      console.error('Error updating note:', error);
      alert(error.message || t('common.updateError'));
      throw error; // Re-throw to indicate failure
    }
  };

  // Handler for deleting a note
  const handleDeleteNote = (noteId) => {
    setShowConfirmDialog({
      isOpen: true,
      title: t('notes.deleteConfirmTitle'),
      message: t('notes.deleteConfirmText'),
      onConfirm: async () => {
        try {
          await api.deleteNote(noteId);
          await loadNotes(); // Reload all notes
          setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null });
          setShowPreviewModal(false); // Close preview modal if open
        } catch (error) {
          console.error('Error deleting note:', error);
          alert(error.message || t('common.deleteError'));
        }
      }
    });
  };

  // Handler for toggling note pin status
  const togglePinNote = async (note) => {
    try {
      const updatedMeta = {
        ...note.meta, // Preserve other meta fields
        pinned: !note.meta?.pinned
      };
      // Assuming api.updateNote takes (id, title, content, category, meta)
      await api.updateNote(note.id, note.title, note.content, note.meta?.category, updatedMeta);
      await loadNotes(); // Reload notes to reflect new pin status and re-sort
    } catch (error) {
      console.error('Error toggling pin:', error);
      alert(error.message || t('common.updateError'));
    }
  };

  // Handler to open NotePreviewModal
  const handleViewNote = useCallback((note) => {
    setSelectedNote(note);
    setShowPreviewModal(true);
  }, []);

  // Handler to open NoteEditorModal for editing
  const handleEditNote = useCallback((note) => {
    setEditingNote(note);
    setShowPreviewModal(false); // Close preview if editing from there
  }, []);


  return (
    <div className="space-y-6">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <button
          onClick={() => navigate(createPageUrl('Dashboard?tab=library'))}
          className="hover:text-[var(--text-primary)] transition-colors flex items-center gap-1"
        >
          <Home className="w-4 h-4" />
          {t('breadcrumb.library')}
        </button>
        <ChevronRight className="w-4 h-4" />
        <span className="text-[var(--text-primary)]">{t('breadcrumb.notes')}</span>
      </div>

      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--text-primary)]">{t('notes.title')}</h1>
        <p className="text-[var(--text-secondary)]">{t('notes.description')}</p>
      </div>

      {/* Controls */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-center">
        <div className="flex gap-4 w-full lg:w-auto flex-wrap">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px] lg:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
            <Input
              placeholder={t('notes.searchPlaceholder')}
              className="pl-10 h-12"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Pinned Filter */}
          <Button
            variant={showPinnedOnly ? "default" : "outline"}
            onClick={() => setShowPinnedOnly(!showPinnedOnly)}
            className="h-12 flex items-center gap-2"
          >
            <Pin className="w-4 h-4" />
            {t('notes.pinnedOnly')}
          </Button>

          {/* Tags Manager */}
          <Button
            variant="outline"
            onClick={() => setShowTagsManager(true)}
            className="h-12 flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            {t('notes.manageTags')}
          </Button>
        </div>

        <Button
          className="w-full lg:w-auto h-12"
          onClick={() => {
            setSelectedNote(null); // Clear selected note for preview
            setEditingNote({ // Initialize new note for editor
              title: '',
              content: '',
              tags: [],
              color: '#ffffff',
              pinned: false,
              category: 'personal' // Default category
            });
          }}
        >
          <Plus className="w-5 h-5 mr-2" />
          {t('notes.newNote')}
        </Button>
      </div>

      {/* Main Content with Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Categories Sidebar (Replaces TagsSidebar) */}
        <CategoriesSidebar
          notes={notes} // Pass all notes for category count calculation
          selectedCategory={selectedCategory}
          onCategorySelect={setSelectedCategory}
          className="lg:col-span-1"
        />

        {/* Notes Content */}
        <div className="lg:col-span-3 space-y-6">
          <AnimatePresence mode="wait">
              {isLoading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader2 className="w-8 h-8 animate-spin text-[var(--text-secondary)]" />
                  <span className="ml-3 text-[var(--text-secondary)]">
                    {t('common.loading')}
                  </span>
                </div>
              ) : filteredNotes.length > 0 ? (
                <motion.div key="list" className="space-y-4"
                  initial="hidden"
                  animate="visible"
                  variants={{
                    hidden: { opacity: 0 },
                    visible: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.05
                      }
                    }
                  }}>
                  {filteredNotes.map(note => (
                    <NoteItem
                      key={note.id}
                      note={note}
                      onEdit={handleEditNote} // Pass handler for editing
                      onDelete={handleDeleteNote}
                      onTogglePin={togglePinNote}
                      onView={handleViewNote} // Pass handler for viewing
                    />
                  ))}
                </motion.div>
              ) : (
                <div className="text-center py-16">
                  <BookOpen className="mx-auto w-16 h-16 text-[var(--text-secondary)] opacity-50" />
                  <h3 className="mt-4 text-xl font-semibold text-[var(--text-primary)]">
                    {t('notes.emptyTitle')}
                  </h3>
                  <p className="mt-2 text-[var(--text-secondary)]">
                    {t('notes.emptyDescription')}
                  </p>
                </div>
              )}
          </AnimatePresence>
        </div>
      </div>

      {/* Modals */}
      <NoteEditorModal
        isOpen={!!editingNote}
        note={editingNote}
        onClose={() => setEditingNote(null)}
        onSave={handleSaveNote}
        availableTags={availableTags}
      />

      <NotePreviewModal
        isOpen={showPreviewModal}
        note={selectedNote}
        onClose={() => setShowPreviewModal(false)}
        onSave={handleUpdateNote} // onSave for preview modal means updating the current note
        onDelete={handleDeleteNote}
      />

      <TagsManager
        isOpen={showTagsManager}
        onClose={() => setShowTagsManager(false)}
        onTagsUpdated={loadNotes}
      />

      <ConfirmDialog
        isOpen={showConfirmDialog.isOpen}
        title={showConfirmDialog.title}
        message={showConfirmDialog.message}
        onConfirm={showConfirmDialog.onConfirm}
        onCancel={() => setShowConfirmDialog({ isOpen: false, title: '', message: '', onConfirm: null })}
        isDestructive={true}
      />
    </div>
  );
}
