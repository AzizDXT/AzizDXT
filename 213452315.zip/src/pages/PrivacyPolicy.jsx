import React from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import { Button } from '../components/ui/button';
import { ArrowLeft, Shield, Eye, Lock, Database, Globe, Users, Bell, Key, FileText, CheckCircle, AlertTriangle, XCircle, Zap, Brain } from 'lucide-react';

export default function PrivacyPolicy() {
  const { t, language, isRTL } = useI18n();
  const { isDark } = useTheme();

  const handleBack = () => {
    window.history.back();
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-[var(--background)] via-[var(--background-secondary)] to-[var(--background)] ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <motion.div 
        className="sticky top-0 z-50 bg-[var(--background-secondary)]/90 backdrop-blur-xl border-b border-[var(--border-color)]/50"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={handleBack}
                variant="ghost"
                size="sm"
                className="p-3 hover:bg-[var(--background-tertiary)] rounded-xl transition-all duration-300"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-gradient-to-br from-[var(--accent-color)] to-[var(--accent-color)]/80 rounded-2xl">
                  <Eye className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-[var(--text-primary)] to-[var(--accent-color)] bg-clip-text text-transparent">
                    {t('privacy.title')}
                  </h1>
                  <p className="text-sm text-[var(--text-secondary)] mt-1">
                    {t('privacy.subtitle')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-8"
        >
          {/* Introduction Card */}
          <div className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-color)]/5 to-transparent rounded-3xl"></div>
            <div className="relative p-8 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-gradient-to-br from-[var(--accent-color)]/20 to-[var(--accent-color)]/10 rounded-2xl border border-[var(--accent-color)]/20">
                  <Shield className="w-8 h-8 text-[var(--accent-color)]" />
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-4">
                    {t('privacy.introduction.title')}
                  </h2>
                  <p className="text-lg text-[var(--text-secondary)] leading-relaxed mb-6">
                    {t('privacy.introduction.description')}
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">
                        4 سبتمبر 2025
                      </div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('privacy.introduction.lastUpdated')}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">1.0</div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('privacy.introduction.version')}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">100%</div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('privacy.introduction.protection')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Data Collection Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="p-6 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-2xl border border-blue-500/20">
                  <Database className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('privacy.collection.title')}
                </h3>
              </div>
              <p className="text-[var(--text-secondary)] leading-relaxed mb-6">
                {t('privacy.collection.description')}
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Users className="w-5 h-5 text-blue-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('privacy.collection.personal.title')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('privacy.collection.usage.title')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Globe className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('privacy.collection.technical.title')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Brain className="w-5 h-5 text-purple-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('privacy.collection.ai.title')}</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="p-6 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-green-500/20 to-green-600/20 rounded-2xl border border-green-500/20">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('privacy.usage.title')}
                </h3>
              </div>
              <div className="space-y-4">
                <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.usage.service.title')}</h4>
                  <div className="space-y-2 text-sm text-[var(--text-secondary)]">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{t('privacy.usage.service.provide')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{t('privacy.usage.service.maintain')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{t('privacy.usage.service.improve')}</span>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.usage.ai.title')}</h4>
                  <div className="space-y-2 text-sm text-[var(--text-secondary)]">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{t('privacy.usage.ai.personalize')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>{t('privacy.usage.ai.enhance')}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Data Protection Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="p-8 bg-gradient-to-br from-green-500/5 to-emerald-500/5 rounded-3xl border border-green-500/20"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl border border-green-500/20">
                <Shield className="w-7 h-7 text-green-500" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">
                  {t('privacy.sharing.title')}
                </h3>
                <p className="text-[var(--text-secondary)] mt-2">
                  {t('privacy.sharing.description')}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-green-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('privacy.sharing.never.sell')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('privacy.sharing.never.sellDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-green-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('privacy.sharing.never.rent')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('privacy.sharing.never.rentDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-green-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('privacy.sharing.never.trade')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('privacy.sharing.never.tradeDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-green-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('privacy.sharing.never.marketing')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('privacy.sharing.never.marketingDesc')}</p>
              </div>
            </div>
          </motion.div>

          {/* Security Measures */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="p-8 bg-gradient-to-br from-blue-500/5 to-indigo-500/5 rounded-3xl border border-blue-500/20"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-2xl border border-blue-500/20">
                <Lock className="w-7 h-7 text-blue-500" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">
                  {t('privacy.security.title')}
                </h3>
                <p className="text-[var(--text-secondary)] mt-2">
                  {t('privacy.security.description')}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h4 className="text-lg font-semibold text-[var(--text-primary)] mb-4">{t('privacy.security.measures.title')}</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <CheckCircle className="w-5 h-5 text-blue-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.measures.encryption')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <CheckCircle className="w-5 h-5 text-blue-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.measures.access')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <CheckCircle className="w-5 h-5 text-blue-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.measures.monitoring')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <CheckCircle className="w-5 h-5 text-blue-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.measures.backup')}</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-[var(--text-primary)] mb-4">{t('privacy.security.protection.title')}</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <Shield className="w-5 h-5 text-indigo-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.protection.breach')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <Shield className="w-5 h-5 text-indigo-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.protection.unauthorized')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <Shield className="w-5 h-5 text-indigo-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.protection.alteration')}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <Shield className="w-5 h-5 text-indigo-500" />
                    <span className="text-sm text-[var(--text-secondary)]">{t('privacy.security.protection.disclosure')}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* User Rights Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            <div className="p-6 bg-gradient-to-br from-purple-500/5 to-pink-500/5 rounded-3xl border border-purple-500/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl border border-purple-500/20">
                  <Key className="w-6 h-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('privacy.rights.title')}
                </h3>
              </div>
              <div className="space-y-4 text-[var(--text-secondary)]">
                <p className="text-sm leading-relaxed">{t('privacy.rights.description')}</p>
                <div className="space-y-3">
                  <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.rights.access.title')}</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-purple-500" />
                        <span>{t('privacy.rights.access.view')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-purple-500" />
                        <span>{t('privacy.rights.access.download')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-purple-500" />
                        <span>{t('privacy.rights.access.update')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-gradient-to-br from-orange-500/5 to-yellow-500/5 rounded-3xl border border-orange-500/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-2xl border border-orange-500/20">
                  <Bell className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('privacy.cookies.title')}
                </h3>
              </div>
              <div className="space-y-4 text-[var(--text-secondary)]">
                <p className="text-sm leading-relaxed">{t('privacy.cookies.description')}</p>
                <div className="space-y-3">
                  <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.cookies.essential.title')}</h4>
                    <p className="text-sm">{t('privacy.cookies.essential.description')}</p>
                  </div>
                  <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.cookies.analytics.title')}</h4>
                    <p className="text-sm">{t('privacy.cookies.analytics.description')}</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact and Footer */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-center p-8 bg-gradient-to-br from-[var(--background-secondary)]/50 to-[var(--background-tertiary)]/50 rounded-3xl border border-[var(--border-color)]/30"
          >
            <div className="max-w-2xl mx-auto">
              <h3 className="text-xl font-bold text-[var(--text-primary)] mb-4">
                {t('privacy.contact.title')}
              </h3>
              <p className="text-[var(--text-secondary)] mb-6">
                {t('privacy.contact.description')}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.contact.email.title')}</h4>
                  <p className="text-sm text-[var(--accent-color)]">privacy@taleb.run</p>
                </div>
                <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('privacy.contact.website.title')}</h4>
                  <p className="text-sm text-[var(--accent-color)]">https://taleb.run</p>
                </div>
              </div>
              <div className="pt-6 border-t border-[var(--border-color)]/30">
                <p className="text-sm text-[var(--text-secondary)]">
                  {t('privacy.footer')}
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
} 