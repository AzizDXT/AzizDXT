import React, { useState, useEffect } from 'react';
import { useI18n } from '../components/utils/i18n';
import CommunitiesSidebar from '../components/communities/CommunitiesSidebar';
import CommunitiesChat from '../components/communities/CommunitiesChat';
import '../styles/communities.css';

// Wrapper component that safely uses useI18n
function CommunitiesContent() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  
  // Safely get i18n values with fallbacks
  let t, isRTL, language;
  try {
    const i18n = useI18n();
    t = i18n.t;
    isRTL = i18n.isRTL;
    language = i18n.language;
  } catch (error) {
    console.warn('I18n not available, using fallbacks:', error);
    // Fallback values
    t = (key) => key;
    isRTL = false;
    language = 'en';
  }

  // Debug RTL
  console.log('🔧 Communities RTL Debug:', { isRTL, language: document.documentElement.lang, dir: document.documentElement.dir });

  // Monitor RTL changes
  useEffect(() => {
    console.log('🔄 RTL Changed:', { isRTL, language: document.documentElement.lang, dir: document.documentElement.dir });
  }, [isRTL]);

  // Monitor language changes
  useEffect(() => {
    console.log('🌍 Language Changed:', { language, isRTL, dir: document.documentElement.dir });
  }, [language, isRTL]);

  const handleChatSelect = (chat) => {
    setSelectedChat(chat);
    setShowMobileSidebar(false); // Close mobile sidebar on chat selection
  };

  const handleBack = () => {
    setSelectedChat(null);
  };

  const handleSearch = (query) => {
    console.log('Searching for:', query);
    // Implement search functionality
  };

  const handleCreateGroup = () => {
    console.log('Create group clicked');
    // Implement create group functionality
  };

  const handleJoinGroup = () => {
    console.log('Join group clicked');
    // Implement join group functionality
  };

  const handleNewChat = () => {
    console.log('New chat clicked');
    // Implement new chat functionality
  };

  const handleMarkChatAsSeen = (chatId) => {
    console.log('Marking chat as seen:', chatId);
    // This will be handled by CommunitiesChat component
    // We just need to pass this callback to CommunitiesSidebar
  };

  // Fallback RTL detection
  const currentIsRTL = isRTL || language === 'ar' || document.documentElement.dir === 'rtl';
  
  console.log('🎯 Final RTL State:', { 
    isRTL, 
    language, 
    documentDir: document.documentElement.dir,
    currentIsRTL,
    finalLayout: currentIsRTL ? 'RTL (Right)' : 'LTR (Left)',
    layoutType: 'Horizontal (Sidebar beside Chat)'
  });
  
  return (
    <div className={`fixed inset-0 bg-[var(--background)] flex ${currentIsRTL ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Sidebar - Takes space in layout on desktop, overlay on mobile */}
      <div className={`
        ${showMobileSidebar ? 'translate-x-0' : (currentIsRTL ? 'translate-x-full' : '-translate-x-full')}
        lg:translate-x-0
        ${showMobileSidebar ? 'fixed' : 'lg:relative fixed'}
        inset-y-0
        ${currentIsRTL ? 'right-0' : 'left-0'}
        z-40
        w-72 sm:w-80
        bg-[var(--background-secondary)]
        ${currentIsRTL ? 'border-l' : 'border-r'} border-[var(--border-color)]
        h-full
        overflow-hidden
        transition-transform duration-300 ease-in-out
        lg:flex-shrink-0
      `}>
        <CommunitiesSidebar
          selectedChat={selectedChat}
          onChatSelect={handleChatSelect}
          onNewChat={handleNewChat}
          onSearch={handleSearch}
          onCreateGroup={handleCreateGroup}
          onJoinGroup={handleJoinGroup}
          onMarkChatAsSeen={handleMarkChatAsSeen}
        />
      </div>

      {/* Chat Area - Flex-1 takes remaining space beside sidebar */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Mobile Menu Button - Professional Design */}
        <button
          onClick={() => setShowMobileSidebar(!showMobileSidebar)}
          className={`
            lg:hidden
            absolute top-4 ${currentIsRTL ? 'right-4' : 'left-4'}
            z-50
            p-3
            bg-[var(--accent-color)]
            text-[var(--accent-text-color)]
            rounded-full
            shadow-lg
            hover:shadow-xl
            transition-all duration-200
            hover:scale-105
          `}
        >
          {showMobileSidebar ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
        
        <CommunitiesChat
          selectedChat={selectedChat}
          onBack={handleBack}
          onMarkChatAsSeen={handleMarkChatAsSeen}
        />
      </div>

      {/* Mobile Overlay */}
      {showMobileSidebar && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setShowMobileSidebar(false)}
        />
      )}
    </div>
  );
}

// Main component with error boundary
export default function Communities() {
  return <CommunitiesContent />;
} 