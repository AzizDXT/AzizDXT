import React from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '../components/utils/i18n';
import { useTheme } from '../components/utils/theme';
import { Button } from '../components/ui/button';
import { ArrowLeft, Shield, FileText, Users, Lock, Eye, Brain, Database, Globe, Zap, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

export default function TermsAndConditions() {
  const { t, language, isRTL } = useI18n();
  const { isDark } = useTheme();

  const handleBack = () => {
    window.history.back();
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-[var(--background)] via-[var(--background-secondary)] to-[var(--background)] ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <motion.div 
        className="sticky top-0 z-50 bg-[var(--background-secondary)]/90 backdrop-blur-xl border-b border-[var(--border-color)]/50"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={handleBack}
                variant="ghost"
                size="sm"
                className="p-3 hover:bg-[var(--background-tertiary)] rounded-xl transition-all duration-300"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-gradient-to-br from-[var(--accent-color)] to-[var(--accent-color)]/80 rounded-2xl">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-[var(--text-primary)] to-[var(--accent-color)] bg-clip-text text-transparent">
                    {t('terms.title')}
                  </h1>
                  <p className="text-sm text-[var(--text-secondary)] mt-1">
                    {t('terms.subtitle')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-8"
        >
          {/* Introduction Card */}
          <div className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-color)]/5 to-transparent rounded-3xl"></div>
            <div className="relative p-8 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-gradient-to-br from-[var(--accent-color)]/20 to-[var(--accent-color)]/10 rounded-2xl border border-[var(--accent-color)]/20">
                  <FileText className="w-8 h-8 text-[var(--accent-color)]" />
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-4">
                    {t('terms.introduction.title')}
                  </h2>
                  <p className="text-lg text-[var(--text-secondary)] leading-relaxed mb-6">
                    {t('terms.introduction.description')}
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">
                        4 سبتمبر 2025
                      </div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('terms.introduction.lastUpdated')}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">1.0</div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('terms.introduction.version')}
                      </div>
                    </div>
                    <div className="text-center p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                      <div className="text-2xl font-bold text-[var(--accent-color)] mb-1">100%</div>
                      <div className="text-sm text-[var(--text-secondary)]">
                        {t('terms.introduction.protection')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Platform Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="p-6 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-2xl border border-blue-500/20">
                  <Brain className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('terms.platform.title')}
                </h3>
              </div>
              <p className="text-[var(--text-secondary)] leading-relaxed mb-6">
                {t('terms.platform.description')}
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.platform.features.ai')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Users className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.platform.features.communities')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Database className="w-5 h-5 text-purple-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.platform.features.storage')}</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <Globe className="w-5 h-5 text-blue-500" />
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.platform.features.global')}</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="p-6 bg-[var(--background-secondary)]/50 backdrop-blur-sm rounded-3xl border border-[var(--border-color)]/30"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-green-500/20 to-green-600/20 rounded-2xl border border-green-500/20">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('terms.userResponsibilities.title')}
                </h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.userResponsibilities.accurate')}</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.userResponsibilities.security')}</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.userResponsibilities.compliance')}</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-[var(--text-secondary)]">{t('terms.userResponsibilities.respect')}</span>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Prohibited Activities */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="p-8 bg-gradient-to-br from-red-500/5 to-red-600/5 rounded-3xl border border-red-500/20"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-br from-red-500/20 to-red-600/20 rounded-2xl border border-red-500/20">
                <XCircle className="w-7 h-7 text-red-500" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">
                  {t('terms.prohibited.title')}
                </h3>
                <p className="text-[var(--text-secondary)] mt-2">
                  {t('terms.prohibited.description')}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.illegal')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.illegalDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.harmful')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.harmfulDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.spam')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.spamDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.unauthorized')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.unauthorizedDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.misuse')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.misuseDesc')}</p>
              </div>
              <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-red-500/20">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span className="font-semibold text-[var(--text-primary)]">{t('terms.prohibited.fraud')}</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{t('terms.prohibited.fraudDesc')}</p>
              </div>
            </div>
          </motion.div>

          {/* AI Services Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="p-8 bg-gradient-to-br from-orange-500/5 to-yellow-500/5 rounded-3xl border border-orange-500/20"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-br from-orange-500/20 to-yellow-500/20 rounded-2xl border border-orange-500/20">
                <Brain className="w-7 h-7 text-orange-500" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--text-primary)]">
                  {t('terms.ai.title')}
                </h3>
                <p className="text-[var(--text-secondary)] mt-2">
                  {t('terms.ai.description')}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h4 className="text-lg font-semibold text-[var(--text-primary)] mb-4 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-orange-500" />
                  {t('terms.ai.disclaimer.title')}
                </h4>
                <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-orange-500/20">
                  <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                    {t('terms.ai.disclaimer.content')}
                  </p>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-[var(--text-primary)] mb-4">
                  {t('terms.ai.limitations.title')}
                </h4>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-sm text-[var(--text-secondary)]">{t('terms.ai.limitations.accuracy')}</span>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-sm text-[var(--text-secondary)]">{t('terms.ai.limitations.reliability')}</span>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-sm text-[var(--text-secondary)]">{t('terms.ai.limitations.liability')}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Legal Protection Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            <div className="p-6 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 rounded-3xl border border-indigo-500/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-2xl border border-indigo-500/20">
                  <FileText className="w-6 h-6 text-indigo-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('terms.intellectualProperty.title')}
                </h3>
              </div>
              <div className="space-y-4 text-[var(--text-secondary)]">
                <p className="text-sm leading-relaxed">{t('terms.intellectualProperty.description')}</p>
                <div className="space-y-3">
                  <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('terms.intellectualProperty.user.title')}</h4>
                    <p className="text-sm">{t('terms.intellectualProperty.user.description')}</p>
                  </div>
                  <div className="p-3 bg-[var(--background-tertiary)]/30 rounded-xl">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('terms.intellectualProperty.platform.title')}</h4>
                    <p className="text-sm">{t('terms.intellectualProperty.platform.description')}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-gradient-to-br from-gray-500/5 to-slate-500/5 rounded-3xl border border-gray-500/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-gradient-to-br from-gray-500/20 to-slate-500/20 rounded-2xl border border-gray-500/20">
                  <Shield className="w-6 h-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-bold text-[var(--text-primary)]">
                  {t('terms.liability.title')}
                </h3>
              </div>
              <div className="space-y-4 text-[var(--text-secondary)]">
                <p className="text-sm leading-relaxed">{t('terms.liability.description')}</p>
                <div className="bg-[var(--background-tertiary)]/30 p-4 rounded-2xl border border-gray-500/20">
                  <h4 className="font-medium text-[var(--text-primary)] mb-3">{t('terms.liability.exclusions.title')}</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span>{t('terms.liability.exclusions.direct')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span>{t('terms.liability.exclusions.indirect')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span>{t('terms.liability.exclusions.consequential')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span>{t('terms.liability.exclusions.punitive')}</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm bg-[var(--accent-color)]/10 p-3 rounded-xl border border-[var(--accent-color)]/20">
                  <strong>{t('terms.liability.maximum')}</strong>
                </p>
              </div>
            </div>
          </motion.div>

          {/* Contact and Footer */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-center p-8 bg-gradient-to-br from-[var(--background-secondary)]/50 to-[var(--background-tertiary)]/50 rounded-3xl border border-[var(--border-color)]/30"
          >
            <div className="max-w-2xl mx-auto">
              <h3 className="text-xl font-bold text-[var(--text-primary)] mb-4">
                {t('terms.contact.title')}
              </h3>
              <p className="text-[var(--text-secondary)] mb-6">
                {t('terms.contact.description')}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('terms.contact.email.title')}</h4>
                  <p className="text-sm text-[var(--accent-color)]">support@taleb.run</p>
                </div>
                <div className="p-4 bg-[var(--background-tertiary)]/50 rounded-2xl border border-[var(--border-color)]/20">
                  <h4 className="font-medium text-[var(--text-primary)] mb-2">{t('terms.contact.website.title')}</h4>
                  <p className="text-sm text-[var(--accent-color)]">https://taleb.run</p>
                </div>
              </div>
              <div className="pt-6 border-t border-[var(--border-color)]/30">
                <p className="text-sm text-[var(--text-secondary)]">
                  {t('terms.footer')}
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
} 