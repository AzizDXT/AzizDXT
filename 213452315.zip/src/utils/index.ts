

export function createPageUrl(pageName: string, queryParams?: string) {
    if (queryParams) {
        return '/' + pageName.toLowerCase().replace(/ /g, '-') + '?' + queryParams;
    }
    return '/' + pageName.toLowerCase().replace(/ /g, '-');
}

export function createDashboardTabUrl(tabName: string) {
    return '/Dashboard?tab=' + tabName;
}