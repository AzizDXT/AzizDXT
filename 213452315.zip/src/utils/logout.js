// Secure logout utility
export const secureLogout = () => {
  // List of keys to remove (sensitive data)
  const sensitiveKeys = [
    'taleb-token',
    'token',
    'taleb-user',
    'user',
    'taleb-session',
    'session',
    'taleb-refresh-token',
    'refresh-token',
    'taleb-access-token',
    'access-token',
    'taleb-auth-data',
    'auth-data',
    'taleb-profile',
    'profile',
    'taleb-credentials',
    'credentials',
    'taleb-oauth-data',
    'oauth-data',
    'taleb-google-data',
    'google-data',
    'taleb-microsoft-data',
    'microsoft-data',
    'taleb-apple-data',
    'apple-data'
  ];

  // List of keys to keep (app preferences)
  const keepKeys = [
    'taleb-language',
    'language',
    'taleb-theme',
    'theme',
    'taleb-sidebar-layout',
    'sidebar-layout',
    'taleb-preferences',
    'preferences',
    'taleb-settings',
    'settings',
    'taleb-ui-state',
    'ui-state',
    'taleb-layout',
    'layout',
    'taleb-view-preferences',
    'view-preferences'
  ];

  // Clear localStorage (remove sensitive data only)
  sensitiveKeys.forEach(key => {
    localStorage.removeItem(key);
  });

  // Clear sessionStorage completely
  sessionStorage.clear();

  // Clear any cookies (if any)
  document.cookie.split(";").forEach(cookie => {
    const eqPos = cookie.indexOf("=");
    const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
    document.cookie = `${name.trim()}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
    document.cookie = `${name.trim()}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=${window.location.hostname}`;
    document.cookie = `${name.trim()}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.${window.location.hostname}`;
  });

  // Clear any cached data in memory
  if (window.caches) {
    caches.keys().then(cacheNames => {
      cacheNames.forEach(cacheName => {
        caches.delete(cacheName);
      });
    });
  }

  // Clear any service worker data
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(registrations => {
      registrations.forEach(registration => {
        registration.unregister();
      });
    });
  }

  // Clear any IndexedDB data
  if ('indexedDB' in window) {
    // Note: This is a simplified approach. In production, you might want to be more specific
    try {
      indexedDB.deleteDatabase('taleb-db');
      indexedDB.deleteDatabase('taleb-cache');
      indexedDB.deleteDatabase('taleb-session');
    } catch (error) {
      console.log('IndexedDB cleanup failed:', error);
    }
  }

  console.log('Secure logout completed - all sensitive data cleared');
};

// Check if user is authenticated
export const isAuthenticated = () => {
  // Check for access tokens (primary authentication)
  const accessToken = localStorage.getItem('taleb-access-token') || localStorage.getItem('access_token');
  
  // Check for user data
  const userData = localStorage.getItem('taleb-user-data') || localStorage.getItem('taleb-user') || localStorage.getItem('user');
  
  // Check for session data
  const sessionData = sessionStorage.getItem('taleb-session') || sessionStorage.getItem('session');
  
  // Check for refresh token as backup
  const refreshToken = localStorage.getItem('taleb-refresh-token') || localStorage.getItem('refresh_token');
  
  return !!(accessToken || userData || sessionData || refreshToken);
};

// Get stored redirect URL after login
export const getRedirectAfterLogin = () => {
  const redirectUrl = sessionStorage.getItem('taleb-redirect-after-login');
  if (redirectUrl) {
    sessionStorage.removeItem('taleb-redirect-after-login');
    return redirectUrl;
  }
  return null;
};

// Set redirect URL for after login
export const setRedirectAfterLogin = (url) => {
  sessionStorage.setItem('taleb-redirect-after-login', url);
};
