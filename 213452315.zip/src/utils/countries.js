// قائمة الدول مع أكوادها - ملف مركزي
export const countries = [
  { name: "أفغانستان", nameEn: "Afghanistan", code: "AF", phone: "+93", flag: "🇦🇫" },
  { name: "ألبانيا", nameEn: "Albania", code: "AL", phone: "+355", flag: "🇦🇱" },
  { name: "الجزائر", nameEn: "Algeria", code: "DZ", phone: "+213", flag: "🇩🇿" },
  { name: "الأرجنتين", nameEn: "Argentina", code: "AR", phone: "+54", flag: "🇦🇷" },
  { name: "أستراليا", nameEn: "Australia", code: "AU", phone: "+61", flag: "🇦🇺" },
  { name: "النمسا", nameEn: "Austria", code: "AT", phone: "+43", flag: "🇦🇹" },
  { name: "البحرين", nameEn: "Bahrain", code: "BH", phone: "+973", flag: "🇧🇭" },
  { name: "بنغلاديش", nameEn: "Bangladesh", code: "BD", phone: "+880", flag: "🇧🇩" },
  { name: "بلجيكا", nameEn: "Belgium", code: "BE", phone: "+32", flag: "🇧🇪" },
  { name: "البرازيل", nameEn: "Brazil", code: "BR", phone: "+55", flag: "🇧🇷" },
  { name: "كندا", nameEn: "Canada", code: "CA", phone: "+1", flag: "🇨🇦" },
  { name: "الصين", nameEn: "China", code: "CN", phone: "+86", flag: "🇨🇳" },
  { name: "كولومبيا", nameEn: "Colombia", code: "CO", phone: "+57", flag: "🇨🇴" },
  { name: "الدنمارك", nameEn: "Denmark", code: "DK", phone: "+45", flag: "🇩🇰" },
  { name: "مصر", nameEn: "Egypt", code: "EG", phone: "+20", flag: "🇪🇬" },
  { name: "فنلندا", nameEn: "Finland", code: "FI", phone: "+358", flag: "🇫🇮" },
  { name: "فرنسا", nameEn: "France", code: "FR", phone: "+33", flag: "🇫🇷" },
  { name: "ألمانيا", nameEn: "Germany", code: "DE", phone: "+49", flag: "🇩🇪" },
  { name: "اليونان", nameEn: "Greece", code: "GR", phone: "+30", flag: "🇬🇷" },
  { name: "الهند", nameEn: "India", code: "IN", phone: "+91", flag: "🇮🇳" },
  { name: "إندونيسيا", nameEn: "Indonesia", code: "ID", phone: "+62", flag: "🇮🇩" },
  { name: "إيران", nameEn: "Iran", code: "IR", phone: "+98", flag: "🇮🇷" },
  { name: "العراق", nameEn: "Iraq", code: "IQ", phone: "+964", flag: "🇮🇶" },
  { name: "أيرلندا", nameEn: "Ireland", code: "IE", phone: "+353", flag: "🇮🇪" },
  { name: "إيطاليا", nameEn: "Italy", code: "IT", phone: "+39", flag: "🇮🇹" },
  { name: "اليابان", nameEn: "Japan", code: "JP", phone: "+81", flag: "🇯🇵" },
  { name: "الأردن", nameEn: "Jordan", code: "JO", phone: "+962", flag: "🇯🇴" },
  { name: "الكويت", nameEn: "Kuwait", code: "KW", phone: "+965", flag: "🇰🇼" },
  { name: "لبنان", nameEn: "Lebanon", code: "LB", phone: "+961", flag: "🇱🇧" },
  { name: "ليبيا", nameEn: "Libya", code: "LY", phone: "+218", flag: "🇱🇾" },
  { name: "ماليزيا", nameEn: "Malaysia", code: "MY", phone: "+60", flag: "🇲🇾" },
  { name: "المكسيك", nameEn: "Mexico", code: "MX", phone: "+52", flag: "🇲🇽" },
  { name: "المغرب", nameEn: "Morocco", code: "MA", phone: "+212", flag: "🇲🇦" },
  { name: "هولندا", nameEn: "Netherlands", code: "NL", phone: "+31", flag: "🇳🇱" },
  { name: "نيوزيلندا", nameEn: "New Zealand", code: "NZ", phone: "+64", flag: "🇳🇿" },
  { name: "النرويج", nameEn: "Norway", code: "NO", phone: "+47", flag: "🇳🇴" },
  { name: "عُمان", nameEn: "Oman", code: "OM", phone: "+968", flag: "🇴🇲" },
  { name: "باكستان", nameEn: "Pakistan", code: "PK", phone: "+92", flag: "🇵🇰" },
  { name: "فلسطين", nameEn: "Palestine", code: "PS", phone: "+970", flag: "🇵🇸" },
  { name: "الفلبين", nameEn: "Philippines", code: "PH", phone: "+63", flag: "🇵🇭" },
  { name: "بولندا", nameEn: "Poland", code: "PL", phone: "+48", flag: "🇵🇱" },
  { name: "البرتغال", nameEn: "Portugal", code: "PT", phone: "+351", flag: "🇵🇹" },
  { name: "قطر", nameEn: "Qatar", code: "QA", phone: "+974", flag: "🇶🇦" },
  { name: "روسيا", nameEn: "Russia", code: "RU", phone: "+7", flag: "🇷🇺" },
  { name: "السعودية", nameEn: "Saudi Arabia", code: "SA", phone: "+966", flag: "🇸🇦" },
  { name: "سنغافورة", nameEn: "Singapore", code: "SG", phone: "+65", flag: "🇸🇬" },
  { name: "جنوب أفريقيا", nameEn: "South Africa", code: "ZA", phone: "+27", flag: "🇿🇦" },
  { name: "كوريا الجنوبية", nameEn: "South Korea", code: "KR", phone: "+82", flag: "🇰🇷" },
  { name: "إسبانيا", nameEn: "Spain", code: "ES", phone: "+34", flag: "🇪🇸" },
  { name: "السودان", nameEn: "Sudan", code: "SD", phone: "+249", flag: "🇸🇩" },
  { name: "السويد", nameEn: "Sweden", code: "SE", phone: "+46", flag: "🇸🇪" },
  { name: "سويسرا", nameEn: "Switzerland", code: "CH", phone: "+41", flag: "🇨🇭" },
  { name: "سوريا", nameEn: "Syria", code: "SY", phone: "+963", flag: "🇸🇾" },
  { name: "تايوان", nameEn: "Taiwan", code: "TW", phone: "+886", flag: "🇹🇼" },
  { name: "تايلاند", nameEn: "Thailand", code: "TH", phone: "+66", flag: "🇹🇭" },
  { name: "تونس", nameEn: "Tunisia", code: "TN", phone: "+216", flag: "🇹🇳" },
  { name: "تركيا", nameEn: "Turkey", code: "TR", phone: "+90", flag: "🇹🇷" },
  { name: "الإمارات العربية المتحدة", nameEn: "United Arab Emirates", code: "AE", phone: "+971", flag: "🇦🇪" },
  { name: "المملكة المتحدة", nameEn: "United Kingdom", code: "GB", phone: "+44", flag: "🇬🇧" },
  { name: "الولايات المتحدة", nameEn: "United States", code: "US", phone: "+1", flag: "🇺🇸" },
  { name: "فيتنام", nameEn: "Vietnam", code: "VN", phone: "+84", flag: "🇻🇳" },
  { name: "اليمن", nameEn: "Yemen", code: "YE", phone: "+967", flag: "🇾🇪" }
];

// دالة مساعدة للبحث في الدول
export const searchCountries = (searchTerm, language = 'ar') => {
  if (!searchTerm) return countries;
  
  const searchLower = searchTerm.toLowerCase();
  return countries.filter(country => 
    country.name.toLowerCase().includes(searchLower) ||
    country.nameEn.toLowerCase().includes(searchLower) ||
    country.phone.includes(searchTerm) ||
    country.code.toLowerCase().includes(searchLower)
  );
};

// دالة للحصول على اسم الدولة حسب اللغة
export const getCountryName = (country, language = 'ar') => {
  return language === 'ar' ? country.name : country.nameEn;
};

// دالة للعثور على دولة بواسطة الكود
export const getCountryByCode = (code) => {
  return countries.find(country => country.code === code);
};

// دالة للعثور على دولة بواسطة اسم الدولة
export const getCountryByName = (name, language = 'ar') => {
  return countries.find(country => 
    (language === 'ar' ? country.name : country.nameEn) === name
  );
};

// دالة للعثور على دولة بواسطة أي اسم (عربي أو إنجليزي) وإرجاع الاسم المناسب للغة
export const findCountryAndGetLocalizedName = (inputName, targetLanguage = 'ar') => {
  // البحث في الأسماء العربية والإنجليزية
  const country = countries.find(country => 
    country.name === inputName || country.nameEn === inputName
  );
  
  if (country) {
    return getCountryName(country, targetLanguage);
  }
  
  return inputName; // إرجاع الاسم الأصلي إذا لم يتم العثور على تطابق
};
