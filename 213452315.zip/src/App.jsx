import './App.css'
import Pages from "@/pages/index.jsx"
import { Toaster } from "@/components/ui/toaster"
import AppProviders from "@/components/AppProviders"

function App() {
  return (
    <AppProviders>
      <Pages />
      <Toaster />
    </AppProviders>
  )
}

export default App 
